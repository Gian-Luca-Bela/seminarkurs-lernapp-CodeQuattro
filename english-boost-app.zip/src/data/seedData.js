export const VOCABULARY_SEED = [
  // Grade 8 - Technology & Media
  { word: "algorithm", definition_en: "A set of rules or steps used to solve a problem or complete a task", definition_de: "Ein Algorithmus – eine Folge von Schritten zur Lösung eines Problems", translation_de: "der Algorithmus", example_sentence: "Search engines use complex algorithms to rank websites.", example_sentence_2: "The algorithm sorts the numbers from smallest to largest.", part_of_speech: "noun", grade: "8", theme: "Technology", difficulty: "medium", synonyms: ["procedure", "formula", "method"], collocations: ["run an algorithm", "design an algorithm", "use an algorithm"], ipa: "/ˈælɡərɪðəm/", common_mistake: "Don't confuse with 'arithmetic'. An algorithm is a process, not a calculation." },
  { word: "influence", definition_en: "The power to affect how someone thinks or behaves", definition_de: "Einfluss – die Kraft, jemanden zu beeinflussen", translation_de: "der Einfluss / beeinflussen", example_sentence: "Social media has a huge influence on young people.", example_sentence_2: "Her teacher influenced her decision to study science.", part_of_speech: "noun", grade: "8", theme: "Media & Society", difficulty: "easy", synonyms: ["impact", "effect", "power"], antonyms: ["insignificance"], collocations: ["have influence on", "under the influence of", "positive influence"], ipa: "/ˈɪnfluəns/", common_mistake: "Influence (noun) vs. to influence (verb) – don't mix them up." },
  { word: "prejudice", definition_en: "An unfair opinion about a person or group, formed without real knowledge", definition_de: "Vorurteil – eine vorschnelle negative Meinung über jemanden", translation_de: "das Vorurteil", example_sentence: "We should challenge prejudice wherever we find it.", example_sentence_2: "His prejudice against foreigners was obvious.", part_of_speech: "noun", grade: "8", theme: "Values & Society", difficulty: "medium", synonyms: ["bias", "discrimination", "stereotype"], antonyms: ["fairness", "tolerance", "open-mindedness"], collocations: ["racial prejudice", "overcome prejudice", "prejudice against"], ipa: "/ˈpredʒudɪs/", common_mistake: "Don't confuse prejudice with discrimination. Prejudice is an attitude; discrimination is an action." },
  { word: "extraordinary", definition_en: "Very unusual or surprising; beyond what is ordinary", definition_de: "außergewöhnlich – weit über das Normale hinaus", translation_de: "außergewöhnlich", example_sentence: "She showed extraordinary courage during the crisis.", example_sentence_2: "It was an extraordinary achievement for someone so young.", part_of_speech: "adjective", grade: "8", theme: "General", difficulty: "medium", synonyms: ["remarkable", "exceptional", "incredible"], antonyms: ["ordinary", "common", "typical"], collocations: ["extraordinary achievement", "extraordinary effort", "quite extraordinary"], ipa: "/ɪkˈstrɔːdɪnri/", common_mistake: "Note the spelling: extra + ordinary. Don't spell it 'extrodinary'." },
  { word: "consequence", definition_en: "Something that happens as a result of an action or event", definition_de: "Konsequenz / Folge – etwas, das als Ergebnis passiert", translation_de: "die Konsequenz / Folge", example_sentence: "One consequence of climate change is rising sea levels.", example_sentence_2: "You must face the consequences of your actions.", part_of_speech: "noun", grade: "8", theme: "Environment & Society", difficulty: "medium", synonyms: ["result", "outcome", "effect"], antonyms: ["cause", "reason"], collocations: ["as a consequence", "face the consequences", "serious consequences"], ipa: "/ˈkɒnsɪkwəns/", common_mistake: "Consequence (result) vs. sequence (order). Very different meanings!" },
  { word: "sustainable", definition_en: "Able to continue without damaging the environment or using up resources", definition_de: "nachhaltig – kann langfristig weitergeführt werden ohne Schaden anzurichten", translation_de: "nachhaltig", example_sentence: "We need more sustainable forms of energy.", example_sentence_2: "Is this business model really sustainable in the long term?", part_of_speech: "adjective", grade: "8", theme: "Environment", difficulty: "medium", synonyms: ["eco-friendly", "renewable", "long-lasting"], antonyms: ["unsustainable", "harmful", "destructive"], collocations: ["sustainable development", "sustainable energy", "sustainable lifestyle"], ipa: "/səˈsteɪnəbl/", common_mistake: "Don't confuse sustainable with 'maintainable'. Sustainable has environmental/long-term meaning." },
  { word: "opponent", definition_en: "A person who competes against you or disagrees with your views", definition_de: "Gegner – jemand, der gegen dich antritt oder anderer Meinung ist", translation_de: "der Gegner / die Gegnerin", example_sentence: "She beat her opponent easily in the final.", example_sentence_2: "He is a fierce opponent of the new law.", part_of_speech: "noun", grade: "8", theme: "Sport & Politics", difficulty: "easy", synonyms: ["rival", "adversary", "competitor"], antonyms: ["ally", "supporter", "partner"], collocations: ["main opponent", "political opponent", "face an opponent"], ipa: "/əˈpəʊnənt/", common_mistake: "Opponent (someone against you) vs. proponent (someone for you)" },
  { word: "refugee", definition_en: "A person who has been forced to leave their country due to war, persecution, or disaster", definition_de: "Flüchtling – jemand, der wegen Krieg oder Verfolgung fliehen musste", translation_de: "der Flüchtling / die Geflüchtete", example_sentence: "Thousands of refugees arrived at the border.", example_sentence_2: "The charity provides food and shelter for refugees.", part_of_speech: "noun", grade: "8", theme: "Global Issues", difficulty: "medium", synonyms: ["displaced person", "asylum seeker", "exile"], collocations: ["refugee camp", "refugee crisis", "political refugee"], ipa: "/ˈrefjuːdʒiː/", common_mistake: "Refugee (fleeing danger) vs. immigrant (moving by choice)" },

  // Grade 9 - More advanced
  { word: "ambiguous", definition_en: "Open to more than one interpretation; not clearly defined", definition_de: "mehrdeutig – kann auf verschiedene Weisen verstanden werden", translation_de: "mehrdeutig / zweideutig", example_sentence: "His answer was deliberately ambiguous.", example_sentence_2: "The law is ambiguous on this point.", part_of_speech: "adjective", grade: "9", theme: "Language & Communication", difficulty: "hard", synonyms: ["vague", "unclear", "uncertain"], antonyms: ["clear", "unambiguous", "definite"], collocations: ["deliberately ambiguous", "morally ambiguous", "ambiguous message"], ipa: "/æmˈbɪɡjuəs/", common_mistake: "Ambiguous (multiple meanings) vs. ambivalent (having mixed feelings)" },
  { word: "eloquent", definition_en: "Able to express ideas clearly and in a persuasive, fluent way", definition_de: "redegewandt – kann Gedanken klar und überzeugend ausdrücken", translation_de: "redegewandt / beredt", example_sentence: "She gave an eloquent speech at the ceremony.", example_sentence_2: "His writing is eloquent and precise.", part_of_speech: "adjective", grade: "9", theme: "Language & Communication", difficulty: "hard", synonyms: ["articulate", "expressive", "fluent"], antonyms: ["inarticulate", "tongue-tied"], collocations: ["eloquent speaker", "eloquent argument", "highly eloquent"], ipa: "/ˈeləkwənt/", common_mistake: "Don't confuse with 'eloquence' (the noun). They are related but used differently." },
  { word: "acknowledge", definition_en: "To admit or accept that something is true; to recognize someone's contribution", definition_de: "anerkennen – etwas zugeben oder als wahr akzeptieren", translation_de: "anerkennen / zugeben", example_sentence: "She acknowledged that the report contained errors.", example_sentence_2: "The award acknowledged his years of service.", part_of_speech: "verb", grade: "9", theme: "General Academic", difficulty: "medium", synonyms: ["admit", "recognize", "accept"], antonyms: ["deny", "ignore", "reject"], collocations: ["acknowledge a mistake", "publicly acknowledge", "acknowledge the fact"], ipa: "/əkˈnɒlɪdʒ/", common_mistake: "The silent 'k' at the start. Also: acknowledge (verb), acknowledgement (noun)." },
  { word: "controversial", definition_en: "Causing or likely to cause disagreement or strong debate", definition_de: "umstritten – verursacht Streit oder starke Meinungsverschiedenheiten", translation_de: "umstritten / kontrovers", example_sentence: "The new policy proved highly controversial.", example_sentence_2: "This is a controversial topic that divides opinion.", part_of_speech: "adjective", grade: "9", theme: "Society & Media", difficulty: "medium", synonyms: ["debatable", "contentious", "disputed"], antonyms: ["uncontroversial", "agreed"], collocations: ["controversial decision", "highly controversial", "controversial topic"], ipa: "/ˌkɒntrəˈvɜːʃl/", common_mistake: "Controversial (causing debate) vs. contradictory (saying the opposite)" },
];

export const GRAMMAR_LESSONS_SEED = [
  {
    title_de: "Present Perfect vs. Simple Past",
    title_en: "Present Perfect vs. Simple Past",
    topic_key: "present_perfect_vs_simple_past",
    grade: "8",
    explanation_de: "Das Present Perfect verwendest du, wenn eine Handlung in der Vergangenheit passiert ist, aber noch eine Verbindung zur Gegenwart hat (Ergebnis, Erfahrung). Das Simple Past verwendest du für abgeschlossene Handlungen in der Vergangenheit, oft mit Zeitangaben wie 'yesterday', 'last week', 'in 2020'.",
    memory_trick: "Present Perfect = Vergangenheit trifft Gegenwart. Simple Past = Vergangenheit ist abgeschlossen.",
    examples: [
      { en: "I have lost my keys. (I still don't have them)", de: "Ich habe meinen Schlüssel verloren. (immer noch weg)" },
      { en: "I lost my keys yesterday. (finished event)", de: "Ich verlor meinen Schlüssel gestern. (abgeschlossen)" },
      { en: "She has visited London three times. (life experience)", de: "Sie war schon dreimal in London. (Erfahrung)" },
    ],
    counter_examples: [
      "❌ I have seen him yesterday. → ✅ I saw him yesterday.",
      "❌ Did you ever eat sushi? → ✅ Have you ever eaten sushi?"
    ],
    common_mistakes: [
      "Mit 'yesterday', 'last week', 'in 2019' IMMER Simple Past!",
      "'already', 'yet', 'ever', 'never', 'just', 'for', 'since' → meist Present Perfect",
      "Nicht 'I have gone to the cinema yesterday' verwenden"
    ],
    signal_words: ["already", "yet", "ever", "never", "just", "for", "since", "yesterday", "last week", "ago"],
    test_relevance: "high",
    checklist: [
      "Gibt es eine Zeitangabe wie 'yesterday'? → Simple Past",
      "Geht es um eine Erfahrung oder ein Ergebnis? → Present Perfect",
      "Steht 'for/since' dabei? → Present Perfect",
      "Ist die Zeit abgeschlossen? → Simple Past"
    ],
    difficulty: "medium",
    order: 1
  },
  {
    title_de: "Past Perfect – die Vorvergangenheit",
    title_en: "Past Perfect",
    topic_key: "past_perfect",
    grade: "8",
    explanation_de: "Das Past Perfect verwendest du für Handlungen, die VOR einem anderen Ereignis in der Vergangenheit stattfanden. Bildung: had + Past Participle (3. Form). Es zeigt die 'ältere Vergangenheit' an.",
    memory_trick: "Past Perfect = Vergangenheit der Vergangenheit. Zwei Ereignisse: das ältere = Past Perfect, das neuere = Simple Past.",
    examples: [
      { en: "When I arrived, she had already left.", de: "Als ich ankam, war sie schon gegangen." },
      { en: "He had never seen snow before he moved to Germany.", de: "Er hatte noch nie Schnee gesehen, bevor er nach Deutschland zog." },
    ],
    counter_examples: [
      "❌ When I arrived, she already left. → ✅ When I arrived, she had already left.",
    ],
    common_mistakes: [
      "Nur dann Past Perfect, wenn zwei Vergangenheitsereignisse in Beziehung stehen",
      "had + 3. Form (not 'had went' → 'had gone'!)",
      "Signalwörter: before, after, when, already, just, never, by the time"
    ],
    signal_words: ["before", "after", "when", "already", "just", "never", "by the time", "as soon as"],
    test_relevance: "high",
    checklist: [
      "Gibt es zwei Vergangenheitsereignisse?",
      "Welches passierte zuerst? → Past Perfect",
      "Wurde 'had' + 3. Form verwendet?"
    ],
    difficulty: "medium",
    order: 2
  },
  {
    title_de: "Conditional I – Reale Bedingungssätze",
    title_en: "First Conditional",
    topic_key: "conditional_1",
    grade: "8",
    explanation_de: "Der 1. Conditional beschreibt reale oder mögliche Bedingungen und ihre wahrscheinlichen Folgen. Die If-Clause steht im Simple Present, der Hauptsatz im Future mit 'will'.",
    memory_trick: "If + Present → will + Infinitiv. Real und möglich = Conditional I.",
    examples: [
      { en: "If it rains, I will take an umbrella.", de: "Wenn es regnet, werde ich einen Schirm nehmen." },
      { en: "If you study hard, you will pass the test.", de: "Wenn du fleißig lernst, wirst du die Prüfung bestehen." },
    ],
    counter_examples: [
      "❌ If it will rain, I will take an umbrella. → After 'if': no will!",
    ],
    common_mistakes: [
      "Nach 'if' KEIN 'will' verwenden! → If it rains (NOT: if it will rain)",
      "Komma wenn If-Clause zuerst steht"
    ],
    signal_words: ["if", "unless", "provided that", "as long as"],
    test_relevance: "high",
    checklist: [
      "If-Clause: Simple Present (kein will)?",
      "Hauptsatz: will + Infinitiv?",
      "Komma gesetzt wenn If-Satz vorne steht?"
    ],
    difficulty: "easy",
    order: 3
  },
  {
    title_de: "Conditional II – Irreale Bedingungssätze",
    title_en: "Second Conditional",
    topic_key: "conditional_2",
    grade: "8",
    explanation_de: "Der 2. Conditional beschreibt hypothetische oder unwahrscheinliche Situationen in der Gegenwart oder Zukunft. If + Simple Past, would + Infinitiv.",
    memory_trick: "If + Past → would. Irreale Vorstellung = Conditional II.",
    examples: [
      { en: "If I were rich, I would travel the world.", de: "Wenn ich reich wäre, würde ich die Welt bereisen." },
      { en: "If she had more time, she would learn Spanish.", de: "Wenn sie mehr Zeit hätte, würde sie Spanisch lernen." },
    ],
    counter_examples: [
      "❌ If I would be rich, I would travel. → ✅ If I were rich, I would travel.",
    ],
    common_mistakes: [
      "Nach 'if' → were (nicht 'was') bei 'to be'",
      "KEIN 'would' in der If-Clause"
    ],
    signal_words: ["if", "if only", "I wish", "as if"],
    test_relevance: "high",
    checklist: [
      "If-Clause: Simple Past oder were?",
      "Hauptsatz: would + Infinitiv?",
      "Ist die Situation hypothetisch/unwahrscheinlich?"
    ],
    difficulty: "medium",
    order: 4
  },
  {
    title_de: "Relativsätze – defining & non-defining",
    title_en: "Relative Clauses",
    topic_key: "relative_clauses",
    grade: "8",
    explanation_de: "Relativsätze geben weitere Informationen über ein Nomen. Defining relative clauses: nötig für das Verständnis (kein Komma). Non-defining: Zusatzinfo, mit Komma.",
    memory_trick: "Defining = ohne Komma, notwendig. Non-defining = mit Komma, Zusatzinfo.",
    examples: [
      { en: "The man who lives next door is a teacher. (defining)", de: "Der Mann, der nebenan wohnt, ist Lehrer." },
      { en: "My sister, who lives in Berlin, is a doctor. (non-defining)", de: "Meine Schwester, die in Berlin wohnt, ist Ärztin." },
    ],
    counter_examples: [
      "❌ The book, which I read, was interesting. → (only ok if it's additional info) ✅ The book that/which I read was interesting.",
    ],
    common_mistakes: [
      "who = Personen, which = Dinge/Tiere, that = Personen+Dinge (nur defining!)",
      "Non-defining: 'that' geht NICHT",
      "Komma bei non-defining nicht vergessen"
    ],
    signal_words: ["who", "which", "that", "whose", "where", "when"],
    test_relevance: "high",
    checklist: [
      "Bezieht sich auf Person? → who",
      "Bezieht sich auf Sache? → which/that",
      "Zusatzinfo mit Komma? → non-defining, kein 'that'"
    ],
    difficulty: "medium",
    order: 5
  },
  {
    title_de: "Passiv – Grundformen",
    title_en: "Passive Voice",
    topic_key: "passive_voice",
    grade: "9",
    explanation_de: "Das Passiv verwendet man, wenn die Handlung wichtiger ist als die handelnde Person, oder wenn die Person unbekannt ist. Bildung: be + Past Participle.",
    memory_trick: "Passiv = be + 3. Form. Das Subjekt wird etwas getan, tut es nicht selbst.",
    examples: [
      { en: "The letter was written by Maria.", de: "Der Brief wurde von Maria geschrieben." },
      { en: "The museum is visited by millions of tourists.", de: "Das Museum wird von Millionen Touristen besucht." },
      { en: "The project has been completed.", de: "Das Projekt ist abgeschlossen worden." },
    ],
    counter_examples: [
      "❌ The letter was write by Maria. → ✅ The letter was written by Maria.",
    ],
    common_mistakes: [
      "3. Form (Past Participle) nicht vergessen, nicht Simple Past!",
      "'by' für die handelnde Person (agent)",
      "Present Passive: am/is/are + PP; Past Passive: was/were + PP"
    ],
    signal_words: ["by", "is/are + past participle", "was/were + past participle"],
    test_relevance: "high",
    checklist: [
      "be-Verb in richtiger Zeit?",
      "Past Participle (3. Form) verwendet?",
      "Agent mit 'by' angegeben wenn nötig?"
    ],
    difficulty: "medium",
    order: 6
  },
];

export const READING_TEXTS_SEED = [
  {
    title: "The Digital Generation",
    text_type: "article",
    grade: "8",
    topic: "Technology & Youth",
    difficulty: "medium",
    body: `Young people today are often called 'digital natives' – people who have grown up with technology and cannot imagine life without it. But what does this really mean, and is it always a good thing?

According to recent surveys, teenagers in Germany spend an average of four to six hours per day on their smartphones. Most of this time is spent on social media platforms, streaming videos, or messaging friends. While this keeps young people connected, experts worry about the effects on mental health and sleep.

Dr. Anna Müller, a psychologist from Heidelberg, explains: "The constant stream of notifications creates stress. Young people feel pressure to respond immediately and to present the best version of themselves online. This can lead to anxiety and reduced self-confidence."

However, not all digital activity is harmful. Many teenagers use technology for learning, creative projects, and staying informed about world events. Apps for language learning, coding, and music production have given young people powerful tools that previous generations never had.

The key, most experts agree, is balance. Learning to manage screen time, choosing quality content, and having regular offline activities are skills that will serve young people well into adulthood.`,
    word_count: 185,
    questions: [
      { type: "main_idea", question: "What is the main topic of this article?", options: ["The dangers of smartphones", "Digital technology and young people", "Social media addiction", "How to reduce screen time"], correct: 1 },
      { type: "detail", question: "How many hours do German teenagers spend on smartphones per day on average?", options: ["1-2 hours", "2-4 hours", "4-6 hours", "6-8 hours"], correct: 2 },
      { type: "inference", question: "What can be inferred about Dr. Müller's view on technology?", options: ["She thinks all technology is harmful", "She thinks technology is only useful for learning", "She has a balanced view, noting both risks and benefits", "She wants to ban smartphones for teenagers"], correct: 2 },
      { type: "true_false", question: "According to the article, technology always has negative effects on young people.", answer: false, correction: "The article says some digital activity is beneficial, e.g. for learning and creative projects." },
      { type: "vocabulary", question: "What does 'digital natives' mean in this context?", options: ["People who hate technology", "People who grew up with technology", "Technology experts", "People born in digital countries"], correct: 1 },
    ],
    vocabulary_focus: ["digital natives", "constant", "pressure", "anxiety", "beneficial"],
    curriculum_tags: ["grade8", "media", "technology", "reading"]
  },
  {
    title: "A Summer in Cornwall",
    text_type: "narrative",
    grade: "8",
    topic: "Travel & Culture",
    difficulty: "easy",
    body: `Maya had been looking forward to the trip for months. Her host family in Cornwall had sent friendly emails and a photo of their cottage near the cliffs. Now, as the train pulled into Penzance station, she felt both excited and nervous.

"You must be Maya!" A woman with red hair and a warm smile was waving at her from the platform. "I'm Helen, and this is my son Jack. Welcome to Cornwall!"

Jack, who was about Maya's age, gave her a shy smile. "Did you have a good journey?"

"Yes, thank you. Though it was very long," Maya said carefully, remembering her English lessons. "I have never been to England before."

"Well, you've picked the best part," Helen laughed. "The sea is beautiful this time of year. We're going to show you everything – the beaches, the old tin mines, the cream teas..."

"Cream teas?" Maya asked.

"Scones with clotted cream and jam," Jack explained. "A Cornish tradition. You'll love it, I promise."

As they drove along winding roads past stone walls and sheep-filled fields, Maya realised that this summer would be unlike anything she had experienced before.`,
    word_count: 195,
    questions: [
      { type: "detail", question: "Where is Maya going for her trip?", options: ["London", "Cornwall", "Edinburgh", "Cambridge"], correct: 1 },
      { type: "detail", question: "Who meets Maya at the station?", options: ["Her teacher", "Helen and Jack", "Her host father", "A tour guide"], correct: 1 },
      { type: "inference", question: "How does Maya feel when she arrives?", options: ["Only excited", "Only nervous", "Both excited and nervous", "Tired and unhappy"], correct: 2 },
      { type: "sequence", question: "What happens first in the story?", options: ["Maya arrives at the station", "Maya looks forward to the trip", "Jack explains cream teas", "They drive along winding roads"], correct: 1 },
    ],
    vocabulary_focus: ["winding", "cliffs", "tradition", "clotted cream", "tin mines"],
    curriculum_tags: ["grade8", "travel", "culture", "narrative"]
  },
  {
    title: "Artificial Intelligence: Friend or Foe?",
    text_type: "article",
    grade: "9",
    topic: "Technology & Society",
    difficulty: "hard",
    body: `Artificial intelligence has moved from science fiction to everyday reality with remarkable speed. Today, AI systems recommend what we watch, help doctors diagnose diseases, and even write software code. But as the technology becomes more capable, important questions arise about its role in society.

Proponents of AI argue that it has enormous potential to solve humanity's greatest challenges. Climate models powered by AI can predict natural disasters more accurately, potentially saving thousands of lives. AI-assisted medical imaging can detect cancers at earlier, more treatable stages. In agriculture, intelligent systems monitor crop health and optimise irrigation, reducing food waste while supporting a growing global population.

Critics, however, point to serious risks. As AI systems take over routine tasks, millions of jobs in manufacturing, transport, and administration may disappear. While new jobs will certainly emerge, the transition may be deeply disruptive for individuals and communities who lack the skills to adapt quickly. There are also concerns about bias: AI systems trained on historical data can perpetuate and even amplify existing inequalities.

Perhaps most concerning is the question of accountability. When an AI system makes a decision – about a loan application, a medical treatment, or a criminal sentence – who is responsible if that decision is wrong? Current legal frameworks were not designed for a world in which machines make consequential choices.

The debate over AI is not simply a technical one. It is fundamentally about what kind of future we want to build, and who gets to decide.`,
    word_count: 245,
    questions: [
      { type: "main_idea", question: "What is the main argument of the article?", options: ["AI is completely safe", "AI raises important benefits and risks that society must address", "AI will destroy all jobs", "Only scientists should decide about AI"], correct: 1 },
      { type: "detail", question: "How can AI help in medicine according to the article?", options: ["It can replace all doctors", "It can detect cancers earlier", "It can cure all diseases", "It manages hospitals"], correct: 1 },
      { type: "vocabulary", question: "What does 'perpetuate' mean in this context?", options: ["To stop completely", "To make something continue", "To improve something", "To delete something"], correct: 1 },
      { type: "author_attitude", question: "The author's perspective on AI is best described as:", options: ["Completely positive", "Completely negative", "Balanced and critical", "Indifferent"], correct: 2 },
      { type: "evidence", question: "Find one example from the text of AI helping society.", answer: "Accept: climate models for disaster prediction, medical imaging for cancer detection, agriculture/crop monitoring" },
    ],
    vocabulary_focus: ["proponents", "perpetuate", "amplify", "accountability", "consequential"],
    curriculum_tags: ["grade9", "technology", "society", "argumentative"]
  }
];

export const WRITING_PROMPTS_SEED = [
  {
    title: "A Blog Post About Social Media",
    genre: "blog_post",
    grade: "8",
    prompt_text: "Write a blog post (150–200 words) about the advantages and disadvantages of social media for teenagers. Give your personal opinion at the end.",
    context: "You are writing for a school website blog read by students and parents.",
    min_words: 150,
    max_words: 200,
    structure_guide: ["Introduction: What is social media? Hook sentence.", "Paragraph 2: Advantages (2-3 points)", "Paragraph 3: Disadvantages (2-3 points)", "Conclusion: Your opinion – is social media good or bad overall?"],
    useful_phrases: ["In my opinion...", "On the one hand...", "On the other hand...", "Furthermore, ...", "However, ...", "To sum up, ...", "I believe that...", "It is important to note that..."],
    dos: ["Use a catchy headline", "Address the reader directly (you)", "Give specific examples", "Use linking words", "Include your personal opinion"],
    donts: ["Don't just list facts without opinion", "Don't use very informal language (no slang)", "Don't forget a conclusion"],
    difficulty: "medium",
    exam_relevant: true
  },
  {
    title: "A Formal Email to a School",
    genre: "formal_email",
    grade: "8",
    prompt_text: "You have seen an advertisement for a summer school in London. Write a formal email (100–130 words) asking for more information about the programme, costs, and accommodation.",
    context: "You are a student writing to a British language school.",
    min_words: 100,
    max_words: 130,
    structure_guide: ["Subject line: clear and professional", "Salutation: Dear Sir/Madam or Dear [Name],", "Opening: State your purpose", "Main part: List your questions clearly", "Closing: Thank them, request response", "Sign-off: Yours faithfully / Yours sincerely"],
    useful_phrases: ["I am writing to enquire about...", "I would be grateful if you could...", "I would like to know more about...", "Could you please send me...", "I look forward to hearing from you.", "Yours faithfully, / Yours sincerely,"],
    dos: ["Use formal register throughout", "Organise questions clearly", "Keep it concise", "Use correct salutation and sign-off"],
    donts: ["Don't use contractions (don't → do not)", "Don't be too casual", "Don't forget subject line", "Don't use slang or emoji"],
    difficulty: "medium",
    exam_relevant: true
  },
  {
    title: "Summary: A News Article",
    genre: "summary",
    grade: "9",
    prompt_text: "Read the article 'Artificial Intelligence: Friend or Foe?' and write a summary in English (80–100 words). Do not copy sentences from the text. Write in your own words.",
    context: "This tests your reading comprehension and ability to rephrase ideas.",
    min_words: 80,
    max_words: 100,
    structure_guide: ["Sentence 1: Main topic of the article", "Sentences 2-3: Key arguments for AI", "Sentences 4-5: Key concerns about AI", "Final sentence: Author's conclusion or your view"],
    useful_phrases: ["The article deals with...", "According to the author,...", "The text argues that...", "Furthermore, ...", "However, ...", "In conclusion, the text suggests that..."],
    dos: ["Use your own words", "Cover the most important points", "Keep it objective", "Mention the source/author if possible"],
    donts: ["Don't copy sentences directly from the text", "Don't include your personal opinion (in a summary)", "Don't add information not in the text"],
    difficulty: "hard",
    exam_relevant: true
  }
];

export const EXERCISES_SEED = [
  // Grammar: Present Perfect vs Simple Past
  {
    title: "PP vs SP: Choose the correct tense",
    type: "multiple_choice",
    skill_area: "grammar",
    grade: "8",
    topic_key: "present_perfect_vs_simple_past",
    difficulty: "easy",
    question: "_______ you ever _______ to New York?",
    options: ["Did you ever go", "Have you ever been", "Did you ever been", "Have you ever went"],
    correct_answer: "Have you ever been",
    explanation: "With 'ever', we use the Present Perfect. The question is about a life experience, not a specific finished time.",
    hint: "Think about signal words. 'Ever' = Present Perfect.",
    xp_reward: 10,
    exam_relevant: true
  },
  {
    title: "PP vs SP: Yesterday or before?",
    type: "multiple_choice",
    skill_area: "grammar",
    grade: "8",
    topic_key: "present_perfect_vs_simple_past",
    difficulty: "easy",
    question: "She _______ her keys yesterday.",
    options: ["has lost", "lost", "have lost", "was losing"],
    correct_answer: "lost",
    explanation: "'Yesterday' is a finished time reference → Simple Past. Never use Present Perfect with 'yesterday'.",
    hint: "Look at the time expression. What does 'yesterday' tell you?",
    xp_reward: 10,
    exam_relevant: true
  },
  {
    title: "Fill in: Past Perfect",
    type: "fill_blank",
    skill_area: "grammar",
    grade: "8",
    topic_key: "past_perfect",
    difficulty: "medium",
    question: "When Tom arrived at the party, Maria _______ (already / leave) already.",
    correct_answer: "had already left",
    explanation: "Maria left BEFORE Tom arrived. The earlier action uses Past Perfect: had + past participle.",
    hint: "Which event happened first? The first event = Past Perfect.",
    xp_reward: 15,
    exam_relevant: true
  },
  {
    title: "Error Correction: Relative Clauses",
    type: "error_correction",
    skill_area: "grammar",
    grade: "8",
    topic_key: "relative_clauses",
    difficulty: "medium",
    question: "Find and correct the mistake: 'My brother, that lives in Berlin, is a musician.'",
    correct_answer: "My brother, who lives in Berlin, is a musician.",
    explanation: "In non-defining relative clauses, 'that' cannot be used. For people, use 'who'.",
    hint: "Is this a defining or non-defining clause? Check the commas.",
    xp_reward: 15,
    exam_relevant: true
  },
  // Vocabulary exercises
  {
    title: "Definition: Word to Meaning",
    type: "multiple_choice",
    skill_area: "vocabulary",
    grade: "8",
    topic_key: "general_vocabulary",
    difficulty: "medium",
    question: "What does 'sustainable' mean?",
    options: ["Causing damage to the environment", "Able to continue without harming the environment", "Very large and powerful", "Happening suddenly"],
    correct_answer: "Able to continue without harming the environment",
    explanation: "'Sustainable' comes from 'sustain' (to keep going). Something sustainable can continue long-term without negative effects.",
    hint: "Think about the environment and the future.",
    xp_reward: 10,
    exam_relevant: false
  },
  {
    title: "Synonym Challenge: Find the Best Match",
    type: "multiple_choice",
    skill_area: "vocabulary",
    grade: "9",
    topic_key: "general_vocabulary",
    difficulty: "hard",
    question: "Which word is closest in meaning to 'eloquent'?",
    options: ["Silent", "Articulate", "Aggressive", "Confused"],
    correct_answer: "Articulate",
    explanation: "Both 'eloquent' and 'articulate' describe someone who can express themselves clearly and persuasively.",
    hint: "Think about how someone speaks. Is it about speaking well or badly?",
    xp_reward: 15,
    exam_relevant: false
  },
  {
    title: "True or False: Word Meaning",
    type: "true_false",
    skill_area: "vocabulary",
    grade: "8",
    topic_key: "general_vocabulary",
    difficulty: "easy",
    question: "A 'refugee' is someone who moves to another country for economic reasons only.",
    correct_answer: "false",
    explanation: "A refugee is someone who has been FORCED to leave their country due to war, persecution, or disaster – not just economic reasons.",
    hint: "Think about WHY someone becomes a refugee.",
    xp_reward: 10,
    exam_relevant: false
  },
  {
    title: "Reading Comprehension: Digital Generation",
    type: "multiple_choice",
    skill_area: "reading",
    grade: "8",
    topic_key: "reading_digital_generation",
    difficulty: "medium",
    question: "According to the article 'The Digital Generation', how many hours per day do German teenagers spend on their smartphones?",
    options: ["1-2 hours", "2-4 hours", "4-6 hours", "More than 8 hours"],
    correct_answer: "4-6 hours",
    explanation: "The article states: 'teenagers in Germany spend an average of four to six hours per day on their smartphones'.",
    hint: "Look for numbers in the second paragraph of the article.",
    xp_reward: 10,
    exam_relevant: false
  }
];

export const SKILL_AREAS = [
  { key: "vocabulary", label: "Vokabeln", icon: "📚", color: "green" },
  { key: "grammar", label: "Grammatik", icon: "⚙️", color: "blue" },
  { key: "reading", label: "Lesen", icon: "📖", color: "purple" },
  { key: "writing", label: "Schreiben", icon: "✏️", color: "orange" },
  { key: "listening", label: "Hören", icon: "🎧", color: "pink" },
  { key: "speaking", label: "Sprechen", icon: "🗣️", color: "yellow" },
  { key: "mediation", label: "Mediation", icon: "🔄", color: "teal" },
  { key: "pronunciation", label: "Aussprache", icon: "🔊", color: "indigo" },
];

export const WRITING_GENRES = {
  summary: { label: "Summary", icon: "📋", color: "blue" },
  blog_post: { label: "Blog Post", icon: "💻", color: "green" },
  comment: { label: "Comment", icon: "💬", color: "purple" },
  formal_email: { label: "Formal Email", icon: "📧", color: "gray" },
  informal_email: { label: "Informal Email", icon: "📩", color: "yellow" },
  letter: { label: "Letter", icon: "✉️", color: "orange" },
  report: { label: "Report", icon: "📊", color: "blue" },
  article: { label: "Article", icon: "📰", color: "red" },
  discussion: { label: "Discussion / Statement", icon: "⚖️", color: "teal" },
  characterisation: { label: "Characterisation", icon: "👤", color: "indigo" },
  creative: { label: "Creative Writing", icon: "✨", color: "pink" },
  mediation: { label: "Mediation Text", icon: "🔄", color: "green" },
};

export const MASCOT_MESSAGES = [
  { context: "login", message: "Hey! Schön, dass du wieder da bist! 🌟 Lass uns heute etwas Großartiges lernen!" },
  { context: "correct", message: "Genau richtig! Du machst das super! 🎉" },
  { context: "incorrect", message: "Nicht ganz – aber aus Fehlern lernt man am meisten! 💪 Schau dir die Erklärung an." },
  { context: "streak", message: "Wow, {streak} Tage in Folge! Du bist unaufhaltsam! 🔥" },
  { context: "level_up", message: "Level {level} erreicht! 🏆 Du wächst wirklich schnell!" },
  { context: "daily_complete", message: "Tagesziel geschafft! 🌟 Das ist echter Fortschritt!" },
  { context: "encouragement", message: "Du lernst jeden Tag ein bisschen mehr. Keep going! 🚀" },
  { context: "weak_area", message: "Kein Stress – schwierige Bereiche werden durch Übung leichter. Du schaffst das!" },
];