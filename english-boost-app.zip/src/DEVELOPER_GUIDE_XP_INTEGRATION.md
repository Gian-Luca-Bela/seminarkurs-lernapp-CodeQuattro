# XP System Integration Guide for Developers

## Overview

The XP system is now **globally available** across all learning modules. This guide shows how to integrate XP rewards into any page or component.

---

## Quick Start

### 1. Import the XP Hook
```jsx
import { useXP } from '@/lib/useXP';
```

### 2. Use It in Your Component
```jsx
export default function MyLearningPage() {
  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];
  const { awardXP } = useXP(user, profile);

  const handleCorrectAnswer = () => {
    // Award XP to user
    awardXP(10);  // 10 XP for this action
    setShowXP(true);  // Trigger toast notification
  };

  return (
    <>
      <XPToast amount={xpAmount} show={showXP} onDone={() => setShowXP(false)} />
      {/* Your content */}
    </>
  );
}
```

---

## XP Values by Activity

### Exercise Completion
```js
// Based on difficulty:
const baseXP = {
  easy: 8,
  medium: 12,
  hard: 16,
};

awardXP(baseXP[difficulty]);
```

### Session Completion
```js
// Based on duration:
const sessionDuration = endTime - startTime;
const sessionXP = 
  sessionDuration < 10 * 60 * 1000 ? 20 :   // < 10 min
  sessionDuration < 20 * 60 * 1000 ? 35 :   // 10-20 min
  50;  // > 20 min

awardXP(sessionXP);
```

### Perfect Streaks
```js
const correctInARow = 5;
if (correctInARow === 3) awardXP(25);   // 3 in a row
if (correctInARow === 5) awardXP(50);   // 5 in a row
```

### Daily Completion
```js
if (userCompletedDailyPlan) {
  awardXP(100);  // Bonus for completing day's plan
}
```

---

## UI Feedback - XPToast Component

Show visual feedback when XP is earned:

### Setup
```jsx
import XPToast from '@/components/XPToast';
import { useState } from 'react';

export default function MyPage() {
  const [showXP, setShowXP] = useState(false);
  const [lastXP, setLastXP] = useState(0);

  const handleReward = (amount) => {
    awardXP(amount);
    setLastXP(amount);
    setShowXP(true);  // Trigger display
  };

  return (
    <>
      <XPToast amount={lastXP} show={showXP} onDone={() => setShowXP(false)} />
      {/* Your content */}
    </>
  );
}
```

### XPToast Props
- `amount` (number) - XP amount to display
- `show` (boolean) - Whether to show the toast
- `onDone` (function) - Callback when toast finishes animating

---

## Examples by Module

### ✅ Grammar Exercises
```jsx
// In GrammarPractice component
const handleSubmit = () => {
  const correct = selectedAnswer === exercise.correct_answer;
  
  if (correct) {
    const xpAmount = exercise.xp_reward || 10;
    awardXP(xpAmount);
    setLastXP(xpAmount);
    setShowXP(true);
  }
};
```

### ✅ Vocabulary Flashcards
```jsx
// In Vocabulary component
const handleFlashcardAnswer = (correct) => {
  if (correct) {
    awardXP(10);  // 10 XP per correct flashcard
    setLastXP(10);
    setShowXP(true);
  }
};
```

### 📖 Reading Exercises (Ready to Implement)
```jsx
// In Reading component
const handleAnswerQuestion = (correct) => {
  if (correct) {
    const xp = exercise.difficulty === 'hard' ? 15 : 10;
    awardXP(xp);
    setLastXP(xp);
    setShowXP(true);
  }
};
```

### 🎧 Listening Activities (Ready to Implement)
```jsx
// In Listening component
const handleListeningAnswer = (correct) => {
  if (correct) {
    awardXP(15);  // Listening = 15 XP per exercise
    setLastXP(15);
    setShowXP(true);
  }
};
```

### ✍️ Writing Submission Feedback (Ready to Implement)
```jsx
// In WritingFeedback component
const handleFeedbackReview = () => {
  // Award XP when student sees feedback
  awardXP(40);  // 40 XP for reviewing feedback
  setLastXP(40);
  setShowXP(true);
};
```

### 🎤 Speaking Tasks (Ready to Implement)
```jsx
// In Speaking component
const handleRecordingComplete = (correct) => {
  if (correct) {
    awardXP(20);  // 20 XP per speaking exercise
    setLastXP(20);
    setShowXP(true);
  }
};
```

### 🌍 Mediation Tasks (Ready to Implement)
```jsx
// In Mediation component
const handleMediationAnswer = (correct) => {
  if (correct) {
    awardXP(18);  // 18 XP per mediation exercise
    setLastXP(18);
    setShowXP(true);
  }
};
```

### 📋 Daily Plan (Ready to Implement)
```jsx
// In DailyPlan component
const markSessionComplete = (sessionIndex) => {
  // Award XP per session
  awardXP(30);  // 30 XP per daily plan session
  
  // Bonus for completing entire day
  if (allSessionsComplete) {
    awardXP(100);  // 100 XP bonus for completing day
  }
};
```

### 🏫 Exam Prep (Ready to Implement)
```jsx
// In ExamPrepSession component
const handleSessionComplete = () => {
  const examXP = sessions.length * 25;  // 25 XP per session
  awardXP(examXP);
  setLastXP(examXP);
  setShowXP(true);
};
```

---

## Database Persistence

The `useXP` hook automatically handles all database updates:

```
User Profile → UserProfile Entity
├── xp: number (total XP)
├── level: number (current level, 1-10)
├── streak: number (days in a row)
└── last_active: date (last activity date)
```

When you call `awardXP(amount)`:
1. ✅ Calculates new XP total
2. ✅ Checks for level up
3. ✅ Updates streak if applicable
4. ✅ Saves to database
5. ✅ Invalidates query cache
6. ✅ Component automatically re-renders

**No manual database calls needed!**

---

## Level System

### Current Levels (10 Total)
```
Level 1:  Anfänger       (0 XP)     🌱
Level 2:  Lernende       (100 XP)   📚
Level 3:  Fortschritt    (250 XP)   ⬆️
Level 4:  Kompetent      (450 XP)   ✅
Level 5:  Talentiert     (700 XP)   ⭐
Level 6:  Meister        (1000 XP)  🎯
Level 7:  Experte        (1350 XP)  🏆
Level 8:  Profi          (1750 XP)  👑
Level 9:  Champion       (2200 XP)  💎
Level 10: Legende        (2700 XP)  🔥
```

### Accessing Level Information
```jsx
import { getLevelFromXP, getLevelName } from '@/lib/utils';

const level = getLevelFromXP(profile.xp);  // Returns 1-10
const levelName = getLevelName(level);     // Returns German name
```

---

## Best Practices

### ✅ DO:
- Award XP after **confirmed correctness**
- Show toast notification for **immediate feedback**
- Use **difficulty-scaled rewards** (harder = more XP)
- Award **bonuses for streaks** and completion
- **Persist to database** (useXP handles this)
- **Log attempts** to ExerciseAttempt entity (for analytics)

### ❌ DON'T:
- Award XP for **viewing content** (only for answers/actions)
- Award XP **multiple times** for same action
- Use **very high/low** values (stick to 8-50 range)
- Manually update profile XP (useXP does this)
- **Forget setShowXP(true)** after awardXP (no visual feedback!)

---

## Logging Exercise Attempts

It's good practice to also log attempts for analytics:

```jsx
const logAttempt = useMutation({
  mutationFn: (data) => base44.entities.ExerciseAttempt.create(data),
});

const handleAnswer = (correct) => {
  // Log the attempt
  logAttempt.mutate({
    user_email: user.email,
    exercise_id: exercise.id,
    skill_area: 'grammar',  // or 'vocabulary', 'reading', etc.
    topic_key: exercise.topic_key,
    grade: profile.grade,
    is_correct: correct,
    user_answer: selected,
    correct_answer: exercise.correct_answer,
    attempt_date: new Date().toISOString().split("T")[0],
    xp_earned: correct ? 12 : 0,  // Track XP in attempt
  });

  // Award XP if correct
  if (correct) {
    awardXP(12);
    setShowXP(true);
  }
};
```

---

## Testing Your Implementation

### Manual Test Checklist
- [ ] XP awarded after correct answer
- [ ] Toast notification displays
- [ ] XP value appears in toast
- [ ] Toast auto-dismisses after 3 seconds
- [ ] Profile XP increases in database
- [ ] Level increases when threshold hit
- [ ] Streak updates on daily activities
- [ ] Other users don't see your XP (user-scoped)

### Console Test
```js
// Open console after awardXP()
// Check network tab for UserProfile update
// Verify response includes new xp, level, streak values
```

---

## Common Issues & Fixes

### Issue: XP not showing
**Fix:** Did you call `setShowXP(true)` after `awardXP()`?
```jsx
awardXP(10);
setShowXP(true);  // ← Add this!
```

### Issue: Toast shows but XP not saved
**Fix:** Ensure user & profile are loaded
```jsx
if (!user || !profile) return;  // ← Add guard
awardXP(10);
```

### Issue: Level not updating
**Fix:** useXP automatically calculates level from XP
```jsx
// This is automatic – just use getLevelFromXP()
const level = getLevelFromXP(profile.xp);
```

### Issue: Duplicate XP awards
**Fix:** Use flag to prevent double-clicking
```jsx
const answeringRef = useRef(false);

const handleAnswer = () => {
  if (answeringRef.current) return;  // ← Prevent double-click
  answeringRef.current = true;
  
  awardXP(10);
  
  setTimeout(() => { answeringRef.current = false; }, 200);
};
```

---

## Next Steps

1. **Review existing implementations** (Grammar, Vocabulary)
2. **Pick a module** to integrate (Reading, Listening, Writing, etc.)
3. **Follow the pattern** shown in examples
4. **Test thoroughly** before deploying
5. **Monitor analytics** to ensure XP is being awarded

---

## Questions?

Refer to:
- `lib/useXP.js` - Hook implementation
- `components/XPToast.jsx` - Toast component
- `pages/Grammar.jsx` - Full example
- `pages/Vocabulary.jsx` - Another example

All implementations use the same pattern – just copy and adapt!