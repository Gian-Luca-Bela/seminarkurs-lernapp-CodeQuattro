import { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';
import {
  LayoutDashboard, BookOpen, Pencil, Headphones, Mic, BookMarked,
  Settings, BarChart3, Calendar, Target, ChevronLeft, ChevronRight,
  LogOut, Menu, X, GraduationCap, Zap, ArrowLeftRight
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const NAV_ITEMS = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/daily-plan', icon: Calendar, label: 'Tagesplan' },
  { path: '/free-learn', icon: Target, label: 'Freies Lernen' },
  { path: '/vocabulary', icon: BookMarked, label: 'Vokabeln' },
  { path: '/grammar', icon: GraduationCap, label: 'Grammatik' },
  { path: '/reading', icon: BookOpen, label: 'Lesen' },
  { path: '/writing', icon: Pencil, label: 'Schreiben' },
  { path: '/listening', icon: Headphones, label: 'Hören' },
  { path: '/speaking', icon: Mic, label: 'Sprechen' },
  { path: '/mediation', icon: ArrowLeftRight, label: 'Mediation' },
  { path: '/progress', icon: BarChart3, label: 'Fortschritt' },
  { path: '/exams', icon: Zap, label: 'Prüfungen' },
  { path: '/settings', icon: Settings, label: 'Profil' },
];

export default function Layout() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const { currentUser } = useAuth();

  const handleLogout = () => {
    base44.auth.logout();
  };

  const firstName = currentUser?.full_name?.split(' ')[0] || 'Schüler';

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed lg:static inset-y-0 left-0 z-50 flex flex-col bg-white border-r border-border transition-all duration-300 ease-in-out",
        collapsed ? "w-16" : "w-60",
        mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Logo */}
        <div className={cn(
          "flex items-center h-16 px-4 border-b border-border shrink-0",
          collapsed ? "justify-center" : "justify-between"
        )}>
          {!collapsed && (
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-brand-gradient flex items-center justify-center">
                <span className="text-white font-bold text-sm">LR</span>
              </div>
              <span className="font-extrabold text-base tracking-tight text-foreground">
                Lingo<span className="text-primary">Route</span>
                <span className="text-xs font-semibold text-muted-foreground ml-1">BW</span>
              </span>
            </Link>
          )}
          {collapsed && (
            <div className="w-8 h-8 rounded-lg bg-brand-gradient flex items-center justify-center">
              <span className="text-white font-bold text-sm">LR</span>
            </div>
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="hidden lg:flex p-1.5 rounded-md hover:bg-muted text-muted-foreground transition-colors"
          >
            {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-0.5">
          {NAV_ITEMS.map((item) => {
            const active = location.pathname === item.path ||
              (item.path !== '/' && location.pathname.startsWith(item.path));
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setMobileOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150",
                  active
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground",
                  collapsed && "justify-center px-2"
                )}
                title={collapsed ? item.label : undefined}
              >
                <item.icon size={18} className="shrink-0" />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* User area */}
        <div className={cn("p-3 border-t border-border", collapsed && "px-2")}>
          {!collapsed && (
            <div className="flex items-center gap-2 px-2 py-2 rounded-lg bg-muted/50 mb-2">
              <div className="w-7 h-7 rounded-full bg-brand-gradient flex items-center justify-center text-white text-xs font-bold shrink-0">
                {firstName[0]?.toUpperCase()}
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-foreground truncate">{firstName}</p>
                <p className="text-xs text-muted-foreground truncate">{currentUser?.email}</p>
              </div>
            </div>
          )}
          <button
            onClick={handleLogout}
            className={cn(
              "flex items-center gap-2 w-full px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors",
              collapsed && "justify-center px-2"
            )}
            title={collapsed ? "Abmelden" : undefined}
          >
            <LogOut size={16} />
            {!collapsed && <span>Abmelden</span>}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar (mobile) */}
        <header className="lg:hidden flex items-center justify-between h-14 px-4 border-b border-border bg-white shrink-0">
          <button
            onClick={() => setMobileOpen(true)}
            className="p-2 rounded-md hover:bg-muted text-muted-foreground"
          >
            <Menu size={20} />
          </button>
          <Link to="/" className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-brand-gradient flex items-center justify-center">
              <span className="text-white font-bold text-xs">LR</span>
            </div>
            <span className="font-extrabold text-sm">Lingo<span className="text-primary">Route</span> <span className="text-muted-foreground text-xs">BW</span></span>
          </Link>
          <div className="w-9" />
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}