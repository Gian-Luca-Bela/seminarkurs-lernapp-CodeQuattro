/**
 * Premium empty state component used across all modules.
 */
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export default function EmptyState({
  icon: Icon,
  emoji,
  title,
  description,
  actionLabel,
  actionTo,
  onAction,
  mascot = false,
}) {
  return (
    <div className="flex flex-col items-center justify-center py-14 px-6 text-center">
      {/* Icon / emoji */}
      <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-secondary to-brand-blue-light flex items-center justify-center mb-5 shadow-sm">
        {emoji ? (
          <span className="text-3xl">{emoji}</span>
        ) : Icon ? (
          <Icon className="w-8 h-8 text-primary" />
        ) : null}
      </div>

      {/* Mascot hint if requested */}
      {mascot && (
        <div className="flex items-center gap-2 mb-4 px-4 py-2 rounded-full bg-amber-50 border border-amber-200">
          <span className="text-base">🦉</span>
          <span className="text-xs font-semibold text-amber-700">Leo ist bereit!</span>
        </div>
      )}

      <h3 className="text-base font-black text-foreground mb-2">{title}</h3>
      {description && (
        <p className="text-sm text-muted-foreground max-w-xs leading-relaxed">{description}</p>
      )}

      {(actionLabel && actionTo) && (
        <Button asChild className="mt-6 rounded-xl font-bold gap-2">
          <Link to={actionTo}>{actionLabel}</Link>
        </Button>
      )}
      {(actionLabel && onAction) && (
        <Button onClick={onAction} className="mt-6 rounded-xl font-bold gap-2">
          {actionLabel}
        </Button>
      )}
    </div>
  );
}