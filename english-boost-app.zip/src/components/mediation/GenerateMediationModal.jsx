import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const DIRECTIONS = [
  { value: "de-en", label: "🇩🇪 Deutsch → 🇬🇧 Englisch", source: "de", target: "en" },
  { value: "en-de", label: "🇬🇧 Englisch → 🇩🇪 Deutsch", source: "en", target: "de" },
];

const DIFFICULTIES = [
  { value: "easy", label: "Einfach", color: "text-green-700 bg-green-50 border-green-200" },
  { value: "medium", label: "Mittel", color: "text-yellow-700 bg-yellow-50 border-yellow-200" },
  { value: "hard", label: "Schwer", color: "text-red-700 bg-red-50 border-red-200" },
];

const EXAMPLE_TOPICS = [
  "Klimawandel und Jugendliche",
  "Schulalltag in Deutschland",
  "Soziale Medien und Gesundheit",
  "Sportveranstaltungen",
  "Reisen und Kultur",
  "Umweltschutz",
];

export default function GenerateMediationModal({ open, onClose, grade, onGenerate }) {
  const [customTopic, setCustomTopic] = useState("");
  const [direction, setDirection] = useState("de-en");
  const [difficulty, setDifficulty] = useState("medium");
  const [generating, setGenerating] = useState(false);

  const canGenerate = customTopic.trim().length > 3;
  const selectedDir = DIRECTIONS.find(d => d.value === direction);

  const handleGenerate = async () => {
    if (!canGenerate) return;
    setGenerating(true);
    await onGenerate({
      topic: customTopic.trim(),
      source_lang: selectedDir.source,
      target_lang: selectedDir.target,
      difficulty,
    });
    setGenerating(false);
    onClose();
    setCustomTopic("");
    setDirection("de-en");
    setDifficulty("medium");
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Eigene Mediationsaufgabe generieren
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-1">
          <div>
            <p className="text-sm font-semibold mb-2">1. Thema eingeben</p>
            <Input
              placeholder="z.B. 'Klimawandel und Jugendliche'…"
              value={customTopic}
              onChange={e => setCustomTopic(e.target.value)}
              className="text-sm mb-2"
            />
            <div className="flex flex-wrap gap-1.5">
              {EXAMPLE_TOPICS.map(t => (
                <button key={t} onClick={() => setCustomTopic(t)}
                  className="text-xs px-2.5 py-1 rounded-full border bg-white border-border hover:border-primary/50 hover:bg-primary/5 transition-all">
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="text-sm font-semibold mb-2">2. Richtung wählen</p>
            <div className="space-y-2">
              {DIRECTIONS.map(d => (
                <button key={d.value} onClick={() => setDirection(d.value)}
                  className={cn(
                    "w-full text-left px-4 py-2.5 rounded-xl border text-sm font-medium transition-all",
                    direction === d.value ? "border-primary bg-primary/10 text-primary" : "border-border bg-card hover:border-primary/30"
                  )}>
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="text-sm font-semibold mb-2">3. Schwierigkeit</p>
            <div className="flex gap-2">
              {DIFFICULTIES.map(d => (
                <button key={d.value} onClick={() => setDifficulty(d.value)}
                  className={cn(
                    "flex-1 py-2 rounded-xl border text-sm font-semibold transition-all",
                    difficulty === d.value ? d.color : "border-border bg-card text-muted-foreground hover:border-primary/30"
                  )}>
                  {d.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex gap-3 pt-2">
          <Button variant="outline" onClick={onClose} className="flex-1">Abbrechen</Button>
          <Button onClick={handleGenerate} disabled={!canGenerate || generating} className="flex-1 gap-2">
            {generating ? <><Loader2 className="w-4 h-4 animate-spin" />Wird generiert...</> : <><Sparkles className="w-4 h-4" />Generieren</>}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}