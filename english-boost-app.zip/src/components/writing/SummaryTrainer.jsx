/**
 * SummaryTrainer – dedicated 6-step summary training flow.
 * read → mark ideas → avoid details → write → compare checklist → feedback
 */
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { base44 } from "@/api/base44Client";
import { cn } from "@/lib/utils";
import { Check, X, Sparkles, BookOpen, ArrowRight, Brain, Star, Image as ImageIcon, Trash2 } from "lucide-react";

const STEPS = ["Text lesen", "Notizen machen", "Regeln beachten", "Zusammenfassung", "Checkliste", "Feedback"];

const SUMMARY_RULES = [
  { rule: "✅ Nur Hauptaussagen übernehmen – keine Details", correct: true },
  { rule: "✅ Eigene Worte verwenden (Paraphrase!)", correct: true },
  { rule: "✅ Neutral bleiben – keine eigene Meinung", correct: true },
  { rule: "✅ Simple Present verwenden", correct: true },
  { rule: "❌ Keine Beispiele aus dem Text", correct: false },
  { rule: "❌ Keine wörtlichen Zitate", correct: false },
  { rule: "❌ Kein eigenes Fazit", correct: false },
];

export default function SummaryTrainer({ sourceText, textTitle, minWords = 60, maxWords = 100, onDone }) {
  const [step, setStep] = useState(0);
  const [notes, setNotes] = useState("");
  const [summary, setSummary] = useState("");
  const [checked, setChecked] = useState([]);
  const [feedback, setFeedback] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  const wordCount = summary.trim().split(/\s+/).filter(w => w.length > 0).length;

  const toggleCheck = (idx) => {
    setChecked(prev => prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx]);
  };

  const handleImageUpload = async (file) => {
    if (!file) return;
    setUploadingImage(true);
    try {
      const res = await base44.integrations.Core.UploadFile({ file });
      setUploadedImage(res.file_url);
    } finally {
      setUploadingImage(false);
    }
  };

  const generateFeedback = async () => {
    setGenerating(true);
    setStep(5);
    try {
      const res = await base44.functions.invoke("anthropicAI", {
        task: "summary_feedback",
        payload: {
          summary: uploadedImage ? null : summary,
          image_url: uploadedImage || null,
          sourceText,
          textTitle,
        }
      });
      setFeedback(res.data);
    } catch {
      setFeedback({
        overall: "Feedback konnte nicht geladen werden. Bitte versuche es erneut.",
        tip: "Merke: Eine Summary ist ca. 1/3 des Originals, im Simple Present, mit eigenen Worten und OHNE eigene Meinung.",
        score: null,
      });
    }
    setGenerating(false);
  };

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Step indicator */}
      <div className="flex gap-1 overflow-x-auto pb-1">
        {STEPS.map((s, i) => (
          <div key={s} className={cn("flex-shrink-0 px-2.5 py-1 rounded-full text-xs font-semibold transition-all",
            i === step ? "bg-primary text-white" : i < step ? "bg-green-100 text-green-700" : "bg-secondary text-muted-foreground")}>
            {i < step ? "✓ " : ""}{s}
          </div>
        ))}
      </div>

      {/* Step 0: Read */}
      {step === 0 && (
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><BookOpen className="w-4 h-4" />Text lesen</CardTitle></CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-3">Lies den Text aufmerksam. Überlege: Was sind die <strong>Hauptaussagen</strong>?</p>
            <div className="bg-secondary/50 rounded-xl p-4 text-sm leading-relaxed max-h-64 overflow-y-auto">
              {sourceText || "Kein Text geladen."}
            </div>
            <Button onClick={() => setStep(1)} className="mt-4 w-full">Ich habe gelesen →</Button>
          </CardContent>
        </Card>
      )}

      {/* Step 1: Notes */}
      {step === 1 && (
        <div className="space-y-3">
          <details className="group">
            <summary className="cursor-pointer flex items-center gap-2 p-3 rounded-xl bg-secondary/60 border border-border text-sm font-semibold select-none hover:bg-secondary transition-colors">
              <BookOpen className="w-4 h-4 text-primary flex-shrink-0" />
              Originaltext nochmal lesen
              <span className="ml-auto text-xs text-muted-foreground group-open:hidden">▼ aufklappen</span>
              <span className="ml-auto text-xs text-muted-foreground hidden group-open:inline">▲ zuklappen</span>
            </summary>
            <div className="mt-2 bg-secondary/50 rounded-xl p-4 text-sm leading-relaxed max-h-56 overflow-y-auto border border-border">
              {sourceText || "Kein Text geladen."}
            </div>
          </details>
          <Card>
            <CardHeader><CardTitle className="text-base">📝 Notizen machen</CardTitle></CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">Schreibe in eigenen Worten auf, was die <strong>Hauptaussagen</strong> des Textes sind. Was ist wichtig, was ist nur ein Detail?</p>
              <Textarea
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="z.B. – Der Text handelt von ... &#10;– Hauptpunkt 1: ...&#10;– Hauptpunkt 2: ..."
                className="min-h-36 resize-none text-sm"
              />
              <div className="flex gap-2 mt-4">
                <Button variant="outline" onClick={() => setStep(0)}>← Zurück</Button>
                <Button onClick={() => setStep(2)} className="flex-1">Weiter →</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step 2: Rules reminder */}
      {step === 2 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Summary-Regeln beachten</CardTitle></CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-3">Diese Regeln gelten für jede Summary:</p>
            <div className="space-y-2">
              {SUMMARY_RULES.map((r, i) => (
                <div key={i} className={cn("flex items-center gap-2 p-2 rounded-lg text-sm",
                  r.correct ? "bg-green-50 text-green-800" : "bg-red-50 text-red-800")}>
                  {r.correct ? <Check className="w-4 h-4 flex-shrink-0" /> : <X className="w-4 h-4 flex-shrink-0" />}
                  {r.rule}
                </div>
              ))}
            </div>
            <div className="flex gap-2 mt-4">
              <Button variant="outline" onClick={() => setStep(1)}>← Zurück</Button>
              <Button onClick={() => setStep(3)} className="flex-1">Verstanden – Schreiben →</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Write */}
      {step === 3 && (
        <div className="space-y-3">
          {/* Collapsible: original text */}
          <details className="group">
            <summary className="cursor-pointer flex items-center gap-2 p-3 rounded-xl bg-secondary/60 border border-border text-sm font-semibold select-none hover:bg-secondary transition-colors">
              <BookOpen className="w-4 h-4 text-primary flex-shrink-0" />
              Originaltext anzeigen
              <span className="ml-auto text-xs text-muted-foreground group-open:hidden">▼ aufklappen</span>
              <span className="ml-auto text-xs text-muted-foreground hidden group-open:inline">▲ zuklappen</span>
            </summary>
            <div className="mt-2 bg-secondary/50 rounded-xl p-4 text-sm leading-relaxed max-h-56 overflow-y-auto border border-border">
              {sourceText || "Kein Text geladen."}
            </div>
          </details>

          {/* Collapsible: my notes */}
          {notes.trim() && (
            <details className="group">
              <summary className="cursor-pointer flex items-center gap-2 p-3 rounded-xl bg-primary/5 border border-primary/20 text-sm font-semibold select-none hover:bg-primary/10 transition-colors">
                <span className="text-primary">📝</span>
                Meine Notizen
                <span className="ml-auto text-xs text-muted-foreground group-open:hidden">▼ aufklappen</span>
                <span className="ml-auto text-xs text-muted-foreground hidden group-open:inline">▲ zuklappen</span>
              </summary>
              <div className="mt-2 p-3 rounded-xl bg-primary/5 border border-primary/20 text-sm whitespace-pre-line text-primary">
                {notes}
              </div>
            </details>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center justify-between">
                Summary schreiben
                <span className={cn("text-xs font-normal", wordCount < minWords ? "text-muted-foreground" : wordCount > maxWords ? "text-destructive" : "text-primary")}>
                  {wordCount} / {minWords}–{maxWords} Wörter
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground mb-2">Schreibe auf Englisch. Nutze deine Notizen als Stütze. Eigene Worte!</p>
              {uploadedImage ? (
                <div className="space-y-3">
                  <div className="relative border-2 border-primary/30 rounded-lg overflow-hidden bg-primary/5">
                    <img src={uploadedImage} alt="Handschriftliche Summary" className="w-full h-auto" />
                    <button onClick={() => setUploadedImage(null)}
                      className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-lg hover:bg-red-600">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setStep(2)}>← Zurück</Button>
                    <Button onClick={() => setStep(4)} className="flex-1">Zur Checkliste →</Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <Textarea value={summary} onChange={e => setSummary(e.target.value)}
                    placeholder='The article "..." deals with the topic of ...' className="min-h-40 resize-none" />
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setStep(2)}>← Zurück</Button>
                    <Button onClick={() => setStep(4)} className="flex-1" disabled={wordCount < 20}>Zur Checkliste →</Button>
                    <label>
                      <input type="file" accept="image/*" onChange={e => handleImageUpload(e.target.files?.[0])}
                        disabled={uploadingImage} className="hidden" />
                      <Button variant="outline" className="cursor-pointer" disabled={uploadingImage} asChild>
                        <span className="flex items-center gap-2">
                          <ImageIcon className="w-4 h-4" />
                          {uploadingImage ? "Lädt..." : "Foto"}
                        </span>
                      </Button>
                    </label>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step 4: Checklist */}
      {step === 4 && (
        <div className="space-y-3">
          {/* Collapsible: my summary (editable) or image */}
          <details className="group">
            <summary className="cursor-pointer flex items-center gap-2 p-3 rounded-xl bg-secondary/60 border border-border text-sm font-semibold select-none hover:bg-secondary transition-colors">
              <span>📝</span>
              Meine Summary ansehen &amp; bearbeiten
              <span className="ml-auto text-xs font-normal text-muted-foreground">
                {uploadedImage ? "📷 Handschriftlich" : `${wordCount} Wörter`}
              </span>
            </summary>
            <div className="mt-2">
              {uploadedImage ? (
                <img src={uploadedImage} alt="Handschriftliche Summary" className="w-full h-auto rounded-lg border border-border" />
              ) : (
                <Textarea value={summary} onChange={e => setSummary(e.target.value)}
                  className="min-h-32 resize-none text-sm" />
              )}
            </div>
          </details>

          <Card>
            <CardHeader><CardTitle className="text-base">Checkliste prüfen</CardTitle></CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">Überprüfe deine Summary:</p>
              <div className="space-y-2 mb-4">
                {["Ich habe den Text NICHT abgeschrieben.", "Ich verwende Simple Present.", "Ich bringe keine eigene Meinung.", "Ich nenne Hauptaussagen, keine Beispiele.", "Ich verwende eigene Formulierungen."].map((item, i) => (
                  <label key={i} className="flex items-start gap-2 cursor-pointer p-2 rounded-lg hover:bg-secondary/50">
                    <input type="checkbox" className="accent-primary mt-0.5" checked={checked.includes(i)} onChange={() => toggleCheck(i)} />
                    <span className="text-sm">{item}</span>
                  </label>
                ))}
              </div>
              <div className="flex gap-2 mt-4">
                <Button variant="outline" onClick={() => setStep(3)}>← Zurück</Button>
              </div>
              <Button onClick={generateFeedback} disabled={generating || (checked.length < 3 && !uploadedImage)} className="w-full gap-2 mt-2" size="lg">
                <Sparkles className="w-4 h-4" />
                {generating ? "KI analysiert..." : "KI-Feedback erhalten"}
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step 5: Feedback */}
      {step === 5 && (
        <div className="space-y-3 animate-fade-in">
          {generating ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Sparkles className="w-8 h-8 text-primary mx-auto mb-3 animate-pulse" />
                <p className="text-sm font-medium">KI analysiert deine Summary…</p>
              </CardContent>
            </Card>
          ) : feedback ? (
            <>
              {feedback.score != null && (
                <Card className="border-primary/30 bg-primary/5">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="text-4xl font-bold text-primary">{feedback.score}/5</div>
                    <div>
                      <p className="font-semibold">Gesamtbewertung</p>
                      <div className="flex gap-0.5 mt-1">
                        {Array(5).fill(0).map((_, i) => (
                          <Star key={i} className={cn("w-4 h-4", i < feedback.score ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground")} />
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              {[
                { key: "main_idea", label: "Hauptidee" },
                { key: "own_words", label: "Eigene Worte" },
                { key: "neutral", label: "Neutraler Ton" },
                { key: "tense", label: "Zeitform" },
                { key: "length", label: "Länge" },
              ].map(({ key, label }) => feedback[key] && (
                <Card key={key}><CardContent className="p-4">
                  <h4 className="font-semibold text-sm mb-1">{label}</h4>
                  <p className="text-sm text-muted-foreground">{feedback[key]}</p>
                </CardContent></Card>
              ))}
              {feedback.strengths?.length > 0 && (
                <Card className="border-green-200 bg-green-50">
                  <CardContent className="p-4">
                    <h4 className="font-semibold text-green-700 mb-2">✅ Stärken</h4>
                    <ul className="space-y-1">
                      {feedback.strengths.map((s, i) => (
                        <li key={i} className="text-sm text-green-800 flex items-start gap-2">
                          <Check className="w-4 h-4 mt-0.5 flex-shrink-0" />{s}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}
              {feedback.improvements?.length > 0 && (
                <Card className="border-orange-200 bg-orange-50">
                  <CardContent className="p-4">
                    <h4 className="font-semibold text-orange-700 mb-2">💡 Verbesserungsvorschläge</h4>
                    <ul className="space-y-1">
                      {feedback.improvements.map((s, i) => (
                        <li key={i} className="text-sm text-orange-800 flex items-start gap-2">
                          <ArrowRight className="w-4 h-4 mt-0.5 flex-shrink-0" />{s}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}
              {feedback.overall && (
                <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
                  <CardContent className="p-4 flex gap-3">
                    <span className="text-2xl">🦉</span>
                    <p className="text-sm text-amber-800 italic">{feedback.overall}</p>
                  </CardContent>
                </Card>
              )}
              {feedback.tip && (
                <Card className="border-blue-200 bg-blue-50">
                  <CardContent className="p-3 flex gap-2">
                    <Brain className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-blue-800"><strong>Merke:</strong> {feedback.tip}</p>
                  </CardContent>
                </Card>
              )}
              <Button variant="outline" onClick={() => setStep(4)} className="w-full">← Zurück zur Checkliste</Button>
              <Button onClick={onDone} className="w-full">Fertig ✓</Button>
            </>
          ) : null}
        </div>
      )}
    </div>
  );
}