/**
 * GenreGuide – shows full pedagogical guidance for a writing genre.
 * Purpose, tone, structure, phrases, common mistakes, checklist, starter sentences.
 */
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { SKILL_MAP } from "@/lib/skillMap";
import { ChevronDown, ChevronRight, Target, Users, MessageSquare, AlignLeft, Lightbulb, X, Check, ArrowRight } from "lucide-react";

const writing = SKILL_MAP.writing;

export function getGenreDetails(genreKey) {
  const sub = writing.subskills.find(s => s.key === genreKey);
  return sub?.details || null;
}

function Section({ icon: Icon, title, children, colorClass = "bg-secondary" }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="border border-border rounded-xl overflow-hidden">
      <button onClick={() => setOpen(!open)} className={cn("w-full flex items-center gap-2 p-3 text-left font-semibold text-sm", colorClass)}>
        <Icon className="w-4 h-4 flex-shrink-0" />
        <span className="flex-1">{title}</span>
        {open ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
      </button>
      {open && <div className="p-3 bg-background">{children}</div>}
    </div>
  );
}

export default function GenreGuide({ genreKey }) {
  const details = getGenreDetails(genreKey);
  if (!details) return null;

  return (
    <div className="space-y-3">
      {details.purpose && (
        <Section icon={Target} title="Zweck (Purpose)" colorClass="bg-blue-50 text-blue-800">
          <p className="text-sm">{details.purpose}</p>
        </Section>
      )}
      {details.target_reader && (
        <Section icon={Users} title="Zielgruppe (Target Reader)" colorClass="bg-purple-50 text-purple-800">
          <p className="text-sm">{details.target_reader}</p>
        </Section>
      )}
      {details.tone && (
        <Section icon={MessageSquare} title="Ton & Register (Tone)" colorClass="bg-yellow-50 text-yellow-800">
          <p className="text-sm">{details.tone}</p>
        </Section>
      )}
      {details.structure?.length > 0 && (
        <Section icon={AlignLeft} title="Struktur (Structure)" colorClass="bg-green-50 text-green-800">
          <ol className="space-y-1">
            {details.structure.map((s, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                <span className="font-bold text-primary w-5 flex-shrink-0">{i + 1}.</span>{s}
              </li>
            ))}
          </ol>
        </Section>
      )}
      {details.useful_phrases?.length > 0 && (
        <Section icon={Lightbulb} title="Nützliche Phrasen (Useful Phrases)" colorClass="bg-indigo-50 text-indigo-800">
          <div className="space-y-1">
            {details.useful_phrases.map((p, i) => (
              <div key={i} className="text-sm text-muted-foreground flex items-start gap-1">
                <span className="text-indigo-500 flex-shrink-0">→</span>{p}
              </div>
            ))}
          </div>
        </Section>
      )}
      {details.formal_vs_informal?.length > 0 && (
        <Section icon={ArrowRight} title="Formell vs. Informell" colorClass="bg-orange-50 text-orange-800">
          <div className="space-y-1">
            {details.formal_vs_informal.map((item, i) => (
              <p key={i} className="text-xs font-mono">{item}</p>
            ))}
          </div>
        </Section>
      )}
      {details.common_mistakes_de?.length > 0 && (
        <Section icon={X} title="Typische Fehler (Common Mistakes)" colorClass="bg-red-50 text-red-800">
          <ul className="space-y-1">
            {details.common_mistakes_de.map((m, i) => (
              <li key={i} className="text-sm text-red-800 flex items-start gap-2">
                <X className="w-3.5 h-3.5 mt-0.5 flex-shrink-0 text-red-500" />{m}
              </li>
            ))}
          </ul>
        </Section>
      )}
      {details.starter_sentences_de?.length > 0 && (
        <Section icon={ArrowRight} title="Einstiegssätze (Starter Sentences)" colorClass="bg-teal-50 text-teal-800">
          <ul className="space-y-2">
            {details.starter_sentences_de.map((s, i) => (
              <li key={i} className="text-sm bg-teal-50 border border-teal-200 rounded-lg p-2 font-mono">{s}</li>
            ))}
          </ul>
        </Section>
      )}
      {details.checklist?.length > 0 && (
        <Section icon={Check} title="Checkliste vor dem Abgeben" colorClass="bg-green-50 text-green-800">
          <ul className="space-y-1">
            {details.checklist.map((item, i) => (
              <label key={i} className="flex items-start gap-2 cursor-pointer">
                <input type="checkbox" className="accent-primary mt-0.5" />
                <span className="text-sm">{item}</span>
              </label>
            ))}
          </ul>
        </Section>
      )}
    </div>
  );
}