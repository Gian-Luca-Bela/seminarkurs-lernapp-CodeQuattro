import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";

const GENRES = [
  { key: "comment", label: "Kommentar" },
  { key: "summary", label: "Summary" },
  { key: "blog_post", label: "Blog Post" },
  { key: "formal_email", label: "Formeller Brief/Email" },
  { key: "informal_email", label: "Informelle Email" },
  { key: "discussion", label: "Diskussion/Erörterung" },
  { key: "article", label: "Artikel" },
  { key: "report", label: "Bericht" },
  { key: "letter", label: "Brief" },
  { key: "creative", label: "Creative Writing" },
  { key: "characterisation", label: "Characterisation" },
];

const DIFFICULTIES = [
  { key: "easy", label: "Einfach", color: "bg-green-100 text-green-700 border-green-200" },
  { key: "medium", label: "Mittel", color: "bg-yellow-100 text-yellow-700 border-yellow-200" },
  { key: "hard", label: "Schwer", color: "bg-red-100 text-red-700 border-red-200" },
];

const NO_TOPIC_GENRES = ["informal_email", "letter"];

const GENRE_TOPICS = {
  comment: ["Should schools ban smartphones?", "Is homework actually useful?", "Should the voting age be lowered to 16?", "Are zoos ethical?", "Should school start later?"],
  summary: ["A text about climate change", "An article about social media", "A report on healthy eating", "A text about technology and learning"],
  blog_post: ["My perfect weekend", "A place I would love to visit", "Technology in everyday life", "My favourite hobby and why I love it"],
  formal_email: ["Requesting info about a school exchange", "Applying for a summer internship", "Asking for work experience", "Requesting a refund for a product"],
  discussion: ["Advantages and disadvantages of social media", "City vs. countryside living", "Should school uniforms be mandatory?", "Technology: blessing or curse?"],
  article: ["The importance of learning languages", "Young people and the environment", "Sport and health", "How AI is changing our lives"],
  report: ["A school trip to London", "Survey results on smartphone use", "An event at school or in your town", "Sport facilities in your area"],
  creative: ["A day in the life of a time traveller", "An unexpected encounter", "The last tree on Earth", "A letter from the future"],
  characterisation: ["A shy student who becomes a hero", "A teacher who changes a student's life", "A young activist fighting for justice", "A traveller who has seen the world"],
};

export default function GenerateWritingModal({ open, onClose, grade, onGenerate }) {
  const [selectedGenre, setSelectedGenre] = useState(null);
  const [customTopic, setCustomTopic] = useState("");
  const [selectedDifficulty, setSelectedDifficulty] = useState("medium");
  const [loading, setLoading] = useState(false);

  const showTopicInput = selectedGenre && !NO_TOPIC_GENRES.includes(selectedGenre);
  const canGenerate = !!selectedGenre;

  const handleGenerate = async () => {
    if (!canGenerate) return;
    setLoading(true);
    await onGenerate(selectedGenre, selectedDifficulty, showTopicInput ? customTopic.trim() : "");
    setLoading(false);
    setCustomTopic("");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Schreibaufgabe generieren</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 pt-1">
          <div>
            <p className="text-sm font-semibold mb-2">Textsorte wählen</p>
            <div className="grid grid-cols-2 gap-2">
              {GENRES.map(g => (
                <button key={g.key} onClick={() => setSelectedGenre(g.key)}
                  className={cn(
                    "px-3 py-2 rounded-xl border text-sm font-medium text-left transition-all",
                    selectedGenre === g.key
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-card hover:border-primary/40 hover:bg-primary/5"
                  )}>
                  {g.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="text-sm font-semibold mb-2">Schwierigkeit</p>
            <div className="flex gap-2">
              {DIFFICULTIES.map(d => (
                <button key={d.key} onClick={() => setSelectedDifficulty(d.key)}
                  className={cn(
                    "flex-1 py-2 rounded-xl border text-sm font-semibold transition-all",
                    selectedDifficulty === d.key ? d.color : "border-border bg-card text-muted-foreground hover:border-primary/30"
                  )}>
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          {showTopicInput && (
            <div>
              <p className="text-sm font-semibold mb-2">Thema wählen (optional)</p>
              {GENRE_TOPICS[selectedGenre] && (
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {GENRE_TOPICS[selectedGenre].map(t => (
                    <button key={t} onClick={() => setCustomTopic(t)}
                      className={cn(
                        "text-xs px-2.5 py-1 rounded-full border transition-all",
                        customTopic === t
                          ? "bg-primary text-white border-primary"
                          : "bg-white border-border hover:border-primary/50 hover:bg-primary/5"
                      )}>
                      {t}
                    </button>
                  ))}
                </div>
              )}
              <Input
                placeholder="Oder eigenes Thema eingeben…"
                value={customTopic}
                onChange={e => setCustomTopic(e.target.value)}
                className="text-sm"
              />
            </div>
          )}

          <Button onClick={handleGenerate} disabled={!canGenerate || loading} className="w-full gap-2">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "✨"}
            {loading ? "Wird generiert..." : "Aufgabe generieren"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}