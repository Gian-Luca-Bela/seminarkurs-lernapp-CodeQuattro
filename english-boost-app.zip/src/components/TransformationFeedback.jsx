/**
 * TransformationFeedback – AI-powered feedback for sentence transformation exercises.
 * Shows nuanced result: correct / mostly correct / meaning ok / incorrect.
 */
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle2, AlertCircle, Info, Loader2, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { evaluateTransformation } from "@/lib/answerEvaluator";

const RESULT_CONFIG = {
  correct: {
    icon: CheckCircle2,
    color: "bg-green-50 border-green-200",
    iconColor: "text-green-600",
    textColor: "text-green-800",
    label: "Richtig! ✅",
  },
  mostly_correct: {
    icon: Info,
    color: "bg-blue-50 border-blue-200",
    iconColor: "text-blue-600",
    textColor: "text-blue-800",
    label: "Fast richtig 👍",
  },
  meaning_ok: {
    icon: AlertCircle,
    color: "bg-amber-50 border-amber-200",
    iconColor: "text-amber-600",
    textColor: "text-amber-800",
    label: "Sinn verstanden, Grammatik prüfen ⚠️",
  },
  incorrect: {
    icon: AlertCircle,
    color: "bg-red-50 border-red-200",
    iconColor: "text-red-600",
    textColor: "text-red-800",
    label: "Noch nicht ganz ✗",
  },
};

export default function TransformationFeedback({ exercise, userAnswer, onContinue, onMarkCorrect }) {
  const [evaluation, setEvaluation] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    evaluateTransformation({
      question: exercise.question,
      userAnswer,
      correctAnswer: exercise.correct_answer,
      correctAnswers: exercise.correct_answers || [],
      exerciseType: exercise.type,
      hint: exercise.hint,
    }).then(result => {
      if (!cancelled) {
        setEvaluation(result);
        setLoading(false);
      }
    });
    return () => { cancelled = true; };
  }, [userAnswer, exercise.id]);

  if (loading) {
    return (
      <div className="mt-4 p-4 rounded-xl bg-secondary/50 border border-border flex items-center gap-3">
        <Loader2 className="w-4 h-4 animate-spin text-primary flex-shrink-0" />
        <span className="text-sm text-muted-foreground">Antwort wird bewertet…</span>
      </div>
    );
  }

  const config = RESULT_CONFIG[evaluation?.result] || RESULT_CONFIG.incorrect;
  const Icon = config.icon;
  const isAccepted = evaluation?.result === "correct" || evaluation?.result === "mostly_correct";

  return (
    <div className={cn("mt-4 p-4 rounded-xl border animate-fade-in", config.color)}>
      <div className="flex items-start gap-2 mb-2">
        <Icon className={cn("w-5 h-5 flex-shrink-0 mt-0.5", config.iconColor)} />
        <div className="flex-1">
          <p className={cn("font-black text-sm", config.textColor)}>{config.label}</p>
          {evaluation?.feedback && (
            <p className={cn("text-xs mt-1 leading-relaxed", config.textColor)}>{evaluation.feedback}</p>
          )}
          {!isAccepted && exercise.correct_answer && (
            <div className="mt-2 p-2 rounded-lg bg-white/70 border border-white/80">
              <p className="text-xs font-semibold text-foreground">Musterlösung:</p>
              <p className="text-sm font-medium text-foreground mt-0.5">{exercise.correct_answer}</p>
            </div>
          )}
          {exercise.explanation && (
            <p className={cn("text-xs mt-2 italic", config.textColor)}>{exercise.explanation}</p>
          )}
        </div>
      </div>

      {/* If meaning_ok or mostly_correct – offer to manually mark as correct */}
      {(evaluation?.result === "meaning_ok" || evaluation?.result === "mostly_correct") && onMarkCorrect && (
        <div className="flex gap-2 mt-3">
          <Button size="sm" variant="outline" onClick={() => onMarkCorrect(false)} className="flex-1 text-xs">
            Nein, zählt als falsch
          </Button>
          <Button size="sm" onClick={() => onMarkCorrect(true)} className="flex-1 text-xs bg-green-600 hover:bg-green-700 text-white border-0">
            Ja, zählt als richtig
          </Button>
        </div>
      )}

      {(evaluation?.result === "correct" || evaluation?.result === "incorrect") && (
        <Button size="sm" onClick={onContinue} className="mt-3 gap-1.5 w-full rounded-xl">
          Weiter <ArrowRight className="w-3.5 h-3.5" />
        </Button>
      )}
    </div>
  );
}