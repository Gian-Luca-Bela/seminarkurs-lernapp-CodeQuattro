/**
 * MySavedSets – shows the student's saved vocabulary sets (from VocabScan or manual saves).
 * Lets them re-practice any saved set directly.
 */
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { BookOpen, Play, ChevronRight, Layers, Camera } from "lucide-react";

export default function MySavedSets({ user }) {
  const [practicing, setPracticing] = useState(null); // SavedVocabSet object
  const [quizIndex, setQuizIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [score, setScore] = useState({ correct: 0, wrong: 0 });
  const [done, setDone] = useState(false);

  const { data: sets = [], isLoading } = useQuery({
    queryKey: ["saved-vocab-sets", user?.email],
    queryFn: () => base44.entities.SavedVocabSet.filter({ user_email: user?.email, is_active: true }, "-created_date", 20),
    enabled: !!user?.email,
  });

  if (isLoading || sets.length === 0) return null;

  // ── Flashcard practice ─────────────────────────────────────────────────────
  if (practicing) {
    const words = practicing.words || [];
    const w = words[quizIndex % words.length];

    if (done) {
      const pct = Math.round((score.correct / words.length) * 100);
      return (
        <div className="p-4 max-w-lg mx-auto text-center animate-pop-in pt-8">
          <div className="text-5xl mb-3">{pct >= 80 ? "🏆" : pct >= 50 ? "👍" : "💪"}</div>
          <h2 className="text-2xl font-black mb-1">{pct}%</h2>
          <p className="text-muted-foreground mb-1">{score.correct} von {words.length} richtig</p>
          <div className="flex gap-3 mt-6 justify-center">
            <Button variant="outline" onClick={() => { setQuizIndex(0); setScore({ correct: 0, wrong: 0 }); setDone(false); setFlipped(false); }} className="rounded-xl">Nochmal</Button>
            <Button onClick={() => { setPracticing(null); setDone(false); }} className="rounded-xl">← Zurück</Button>
          </div>
        </div>
      );
    }

    const next = (correct) => {
      setScore(s => ({ ...s, correct: s.correct + (correct ? 1 : 0), wrong: s.wrong + (correct ? 0 : 1) }));
      setFlipped(false);
      if (quizIndex + 1 >= words.length) setDone(true);
      else setQuizIndex(i => i + 1);
    };

    return (
      <div className="p-4 max-w-lg mx-auto animate-fade-in">
        <div className="flex items-center justify-between mb-4">
          <Button variant="ghost" size="sm" onClick={() => setPracticing(null)}>← Beenden</Button>
          <span className="text-sm font-bold text-muted-foreground">{quizIndex + 1} / {words.length}</span>
        </div>
        <div className="h-1.5 bg-secondary rounded-full mb-5 overflow-hidden">
          <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${(quizIndex / words.length) * 100}%` }} />
        </div>
        <p className="text-xs font-black text-primary uppercase tracking-wider mb-3 text-center">{practicing.name}</p>
        <div
          className={cn("min-h-48 rounded-2xl border-2 p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all mb-4",
            flipped ? "border-primary bg-primary/5" : "border-border hover:border-primary/30")}
          onClick={() => setFlipped(f => !f)}
        >
          {!flipped ? (
            <>
              <p className="text-3xl font-black mb-2">{w?.word}</p>
              <p className="text-xs text-muted-foreground uppercase tracking-wider">Tippen zum Aufdecken</p>
            </>
          ) : (
            <>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Übersetzung</p>
              <p className="text-2xl font-black text-primary">{w?.translation_de}</p>
            </>
          )}
        </div>
        {flipped && (
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => next(false)} className="flex-1 border-red-200 text-red-600 hover:bg-red-50 font-bold">✗ Noch nicht</Button>
            <Button onClick={() => next(true)} className="flex-1 font-bold">✓ Gewusst!</Button>
          </div>
        )}
      </div>
    );
  }

  // ── Set list ───────────────────────────────────────────────────────────────
  return (
    <div className="mb-6">
      <div className="section-header mb-3">
        <h2 className="text-sm font-black text-foreground uppercase tracking-wider flex items-center gap-2">
          <Layers className="w-4 h-4 text-primary" />Meine Vokabelsets
        </h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {sets.map(set => (
          <Card key={set.id} className="border border-border hover:border-primary/30 transition-all">
            <CardContent className="p-3 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 flex items-center justify-center flex-shrink-0">
                {set.source === "vocab_scan" ? <Camera className="w-4 h-4 text-emerald-600" /> : <BookOpen className="w-4 h-4 text-emerald-600" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-sm truncate">{set.name}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-xs text-muted-foreground">{set.words?.length || 0} Wörter</span>
                  {set.source === "vocab_scan" && <Badge className="bg-emerald-100 text-emerald-700 border-0 text-[10px] font-bold px-1.5 py-0">Scan</Badge>}
                </div>
              </div>
              <Button
                size="sm"
                onClick={() => { setPracticing(set); setQuizIndex(0); setFlipped(false); setScore({ correct: 0, wrong: 0 }); setDone(false); }}
                className="flex-shrink-0 gap-1.5 font-bold text-xs h-8 brand-gradient text-white border-0"
              >
                <Play className="w-3.5 h-3.5" />Üben
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}