import { useState } from "react";
import { SKILL_MAP } from "@/lib/skillMap";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { ChevronDown, ChevronRight, BookOpen, GraduationCap, Volume2, FileText, Headphones, PenLine, Mic, ArrowLeftRight, Layers } from "lucide-react";

const ICONS = { BookOpen, GraduationCap, Volume2, FileText, Headphones, PenLine, Mic, ArrowLeftRight, Layers };

const COLOR_MAP = {
  green:  { bg: "bg-green-50",  border: "border-green-200", badge: "bg-green-100 text-green-700", dot: "bg-green-500", text: "text-green-700" },
  blue:   { bg: "bg-blue-50",   border: "border-blue-200",  badge: "bg-blue-100 text-blue-700",   dot: "bg-blue-500",  text: "text-blue-700"  },
  red:    { bg: "bg-red-50",    border: "border-red-200",   badge: "bg-red-100 text-red-700",     dot: "bg-red-500",   text: "text-red-700"   },
  purple: { bg: "bg-purple-50", border: "border-purple-200",badge: "bg-purple-100 text-purple-700",dot:"bg-purple-500",text:"text-purple-700" },
  orange: { bg: "bg-orange-50", border: "border-orange-200",badge: "bg-orange-100 text-orange-700",dot:"bg-orange-500",text:"text-orange-700"},
  pink:   { bg: "bg-pink-50",   border: "border-pink-200",  badge: "bg-pink-100 text-pink-700",   dot: "bg-pink-500",  text: "text-pink-700"  },
  yellow: { bg: "bg-yellow-50", border: "border-yellow-200",badge: "bg-yellow-100 text-yellow-700",dot:"bg-yellow-500",text:"text-yellow-700"},
  teal:   { bg: "bg-teal-50",   border: "border-teal-200",  badge: "bg-teal-100 text-teal-700",   dot: "bg-teal-500",  text: "text-teal-700"  },
  indigo: { bg: "bg-indigo-50", border: "border-indigo-200",badge: "bg-indigo-100 text-indigo-700",dot:"bg-indigo-500",text:"text-indigo-700"},
};

export default function SkillMap({ compact = false, highlightSkills = [] }) {
  const [expanded, setExpanded] = useState({});
  const skills = Object.entries(SKILL_MAP);

  const toggle = (key) => setExpanded(prev => ({ ...prev, [key]: !prev[key] }));

  if (compact) {
    return (
      <div className="grid grid-cols-2 gap-2">
        {skills.map(([key, skill]) => {
          const c = COLOR_MAP[skill.color] || COLOR_MAP.blue;
          const Icon = ICONS[skill.icon] || BookOpen;
          const highlighted = highlightSkills.includes(key);
          return (
            <div key={key} className={cn("flex items-center gap-2 p-2 rounded-lg border", c.bg, c.border, highlighted && "ring-2 ring-offset-1 ring-primary")}>
              <Icon className={cn("w-4 h-4", c.text)} />
              <span className="text-xs font-semibold text-foreground">{skill.labelDe}</span>
              {highlighted && <span className="ml-auto text-xs text-primary font-bold">●</span>}
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {skills.map(([key, skill]) => {
        const c = COLOR_MAP[skill.color] || COLOR_MAP.blue;
        const Icon = ICONS[skill.icon] || BookOpen;
        const isOpen = expanded[key];
        const highlighted = highlightSkills.includes(key);
        return (
          <Card key={key} className={cn("border", c.border, highlighted && "ring-2 ring-primary")}>
            <button
              className={cn("w-full flex items-center gap-3 p-4 text-left", c.bg, "rounded-xl")}
              onClick={() => toggle(key)}
            >
              <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", c.badge)}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <span className="font-bold text-sm">{skill.labelDe}</span>
                <span className="ml-2 text-xs text-muted-foreground">({skill.label})</span>
              </div>
              <Badge className={cn("text-xs border-0 mr-2", c.badge)}>{skill.subskills.length} Teilbereiche</Badge>
              {isOpen ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
            </button>
            {isOpen && (
              <CardContent className="pt-0 pb-3 px-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 mt-2">
                  {skill.subskills.map(sub => (
                    <div key={sub.key} className="flex items-center gap-2 p-2 rounded-lg bg-background border border-border/50">
                      <div className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", c.dot)} />
                      <div>
                        <p className="text-xs font-medium">{sub.label}</p>
                        <p className="text-xs text-muted-foreground">{sub.labelEn}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            )}
          </Card>
        );
      })}
    </div>
  );
}