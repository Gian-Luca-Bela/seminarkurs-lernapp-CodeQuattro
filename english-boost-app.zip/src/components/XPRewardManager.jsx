/**
 * XP Reward Manager
 * Manages XP reward notifications across the entire app
 * Shows polished, non-intrusive feedback when XP is earned
 */

import { useState, useCallback } from "react";
import { Zap, TrendingUp, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";

export function XPRewardProvider({ children }) {
  const [rewards, setRewards] = useState([]);

  const showReward = useCallback((amount, options = {}) => {
    const id = Math.random().toString(36).substr(2, 9);
    const {
      levelUp = false,
      newLevel = null,
      message = `+${amount} XP`,
      duration = 3000,
    } = options;

    const reward = { id, amount, levelUp, newLevel, message, duration };

    setRewards((prev) => [...prev, reward]);

    // Auto-remove after duration
    setTimeout(() => {
      setRewards((prev) => prev.filter((r) => r.id !== id));
    }, duration);

    return id;
  }, []);

  return (
    <>
      {children({ showReward })}
      <XPRewardDisplay rewards={rewards} />
    </>
  );
}

function XPRewardDisplay({ rewards }) {
  return (
    <div className="fixed bottom-6 right-6 pointer-events-none space-y-2 z-50">
      {rewards.map((reward) => (
        <XPToastCard key={reward.id} reward={reward} />
      ))}
    </div>
  );
}

function XPToastCard({ reward }) {
  return (
    <div
      className={cn(
        "animate-pop-in flex items-center gap-3 px-4 py-3 rounded-2xl shadow-lg pointer-events-auto",
        reward.levelUp
          ? "bg-gradient-to-r from-yellow-400 to-orange-500 text-white"
          : "bg-gradient-to-r from-green-400 to-emerald-500 text-white"
      )}
    >
      {reward.levelUp ? (
        <>
          <Trophy className="w-5 h-5 flex-shrink-0" />
          <div>
            <p className="font-black text-sm">Level Up!</p>
            <p className="text-xs opacity-90">Level {reward.newLevel}</p>
          </div>
        </>
      ) : (
        <>
          <Zap className="w-5 h-5 flex-shrink-0" />
          <p className="font-bold text-sm">{reward.message}</p>
        </>
      )}
    </div>
  );
}

/**
 * Hook to use XP rewards in any component
 */
export function useXPReward() {
  // This will be provided by context in a full implementation
  // For now, return a simple callback that integrates with XPToast
  return {
    awardXP: (amount, options) => {
      // Component will handle this via the provider
      return amount;
    },
  };
}