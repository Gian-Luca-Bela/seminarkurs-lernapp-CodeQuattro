/**
 * AILoadingState — shared, animated loading screen for all AI generation steps.
 *
 * Props:
 *  title        string   — main heading e.g. "Aufgaben werden erstellt…"
 *  steps        string[] — ordered status messages to cycle through
 *  icon         node     — icon element (defaults to Sparkles)
 *  contextLines string[] — optional small context chips below the spinner
 */
import { useState, useEffect } from "react";
import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

export default function AILoadingState({ title, steps = [], icon, contextLines = [] }) {
  const [activeStep, setActiveStep] = useState(0);
  const [dots, setDots] = useState("");

  // Cycle through step labels every ~1.8 s
  useEffect(() => {
    if (steps.length <= 1) return;
    const id = setInterval(() => {
      setActiveStep(s => (s + 1) % steps.length);
    }, 1800);
    return () => clearInterval(id);
  }, [steps.length]);

  // Animate trailing dots
  useEffect(() => {
    const id = setInterval(() => {
      setDots(d => (d.length >= 3 ? "" : d + "."));
    }, 500);
    return () => clearInterval(id);
  }, []);

  const currentStep = steps[activeStep] || "";

  return (
    <div className="flex flex-col items-center justify-center min-h-[55vh] gap-5 px-4 animate-fade-in">
      {/* Icon badge */}
      <div className="relative">
        <div className="w-16 h-16 rounded-2xl brand-gradient flex items-center justify-center shadow-lg">
          {icon ?? <Sparkles className="w-8 h-8 text-white" />}
        </div>
        {/* Pulsing ring */}
        <span className="absolute inset-0 rounded-2xl animate-pulse-ring pointer-events-none" />
      </div>

      {/* Spinner */}
      <div className="relative w-10 h-10">
        <div className="absolute inset-0 rounded-full border-4 border-primary/15" />
        <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-primary animate-spin" />
      </div>

      {/* Title */}
      <div className="text-center max-w-xs">
        <p className="font-black text-base text-foreground">{title}{dots}</p>

        {/* Step text — fades between messages */}
        {steps.length > 0 && (
          <p
            key={activeStep}
            className="text-sm text-muted-foreground mt-2 animate-fade-up"
          >
            {currentStep}
          </p>
        )}
      </div>

      {/* Step progress pills */}
      {steps.length > 1 && (
        <div className="flex items-center gap-1.5">
          {steps.map((_, i) => (
            <span
              key={i}
              className={cn(
                "rounded-full transition-all duration-500",
                i === activeStep
                  ? "w-5 h-2 bg-primary"
                  : i < activeStep
                  ? "w-2 h-2 bg-primary/40"
                  : "w-2 h-2 bg-border"
              )}
            />
          ))}
        </div>
      )}

      {/* Context chips */}
      {contextLines.length > 0 && (
        <div className="flex flex-wrap justify-center gap-1.5 max-w-sm">
          {contextLines.map((line, i) => (
            <span
              key={i}
              className="text-xs bg-secondary text-muted-foreground px-2.5 py-1 rounded-full font-medium"
            >
              {line}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}