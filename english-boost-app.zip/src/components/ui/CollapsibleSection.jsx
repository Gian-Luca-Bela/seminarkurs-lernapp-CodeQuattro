import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";

/**
 * CollapsibleSection — reusable section header with count, progress, and collapse toggle.
 *
 * Props:
 *  title        string   — section title
 *  count        number   — item count shown next to title
 *  countLabel   string   — e.g. "Wörter" or "Themen"
 *  progress     number?  — 0–100 progress percentage (omit to hide bar)
 *  progressLabel string? — e.g. "72% gelernt"
 *  icon         string?  — emoji shown left of title
 *  dotColor     string?  — tailwind bg-* class for the colored dot
 *  badge        node?    — optional extra badge rendered in header
 *  defaultOpen  boolean  — defaults to true
 *  children     node
 */
export default function CollapsibleSection({
  title,
  count,
  countLabel = "Einträge",
  progress,
  progressLabel,
  icon,
  dotColor,
  badge,
  defaultOpen = true,
  children,
  className,
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className={cn("rounded-2xl border border-border bg-card overflow-hidden", className)}>
      {/* Header row */}
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-secondary/40 transition-colors text-left"
      >
        {dotColor && (
          <span className={cn("w-2.5 h-2.5 rounded-full flex-shrink-0", dotColor)} />
        )}
        {icon && !dotColor && (
          <span className="text-base flex-shrink-0">{icon}</span>
        )}

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-black text-sm text-foreground">{title}</span>
            <span className="text-xs text-muted-foreground font-medium bg-secondary px-2 py-0.5 rounded-full">
              {count} {countLabel}
            </span>
            {badge}
          </div>

          {progress !== undefined && (
            <div className="flex items-center gap-2 mt-1.5">
              <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                <div
                  className={cn(
                    "h-full rounded-full transition-all",
                    progress >= 80 ? "bg-primary" : progress >= 50 ? "bg-amber-400" : "bg-muted-foreground/40"
                  )}
                  style={{ width: `${progress}%` }}
                />
              </div>
              {progressLabel && (
                <span className="text-[10px] text-muted-foreground font-medium flex-shrink-0">{progressLabel}</span>
              )}
            </div>
          )}
        </div>

        <div className="flex-shrink-0 text-muted-foreground">
          {open ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </div>
      </button>

      {/* Content */}
      {open && (
        <div className="border-t border-border/60 p-4">
          {children}
        </div>
      )}
    </div>
  );
}