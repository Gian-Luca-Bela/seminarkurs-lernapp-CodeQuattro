import { useState } from "react";
import { Link, useLocation, Outlet } from "react-router-dom";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard, BookOpen, GraduationCap, FileText, Headphones,
  PenLine, Mic, ArrowLeftRight, BarChart3, CalendarCheck, User, Settings,
  ChevronLeft, ChevronRight, Menu, LogOut, Zap, Flame, Map, Trophy, Shield, Database, Camera
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

const NAV_ITEMS = [
  { path: "/",           icon: LayoutDashboard, label: "Dashboard",          section: "main",    primary: false },
  { path: "/daily-plan", icon: CalendarCheck,   label: "Tagesplan",          section: "main",    primary: true  },
  { path: "/vocabulary", icon: BookOpen,        label: "Vokabeln",           section: "learn",   color: "text-emerald-600" },
  { path: "/grammar",    icon: GraduationCap,   label: "Grammatik",          section: "learn",   color: "text-blue-600" },
  { path: "/reading",    icon: FileText,        label: "Lesen",              section: "learn",   color: "text-violet-600" },
  { path: "/writing",    icon: PenLine,         label: "Schreiben",          section: "learn",   color: "text-rose-500" },
  { path: "/listening",  icon: Headphones,      label: "Hören",              section: "learn",   color: "text-orange-500" },
  { path: "/speaking",   icon: Mic,             label: "Sprechen",           section: "learn",   color: "text-yellow-500" },
  { path: "/mediation",  icon: ArrowLeftRight,  label: "Mediation",          section: "learn",   color: "text-teal-600" },
  { path: "/vocab-trainer", icon: Zap,          label: "Vokabel-Trainer",    section: "learn",   color: "text-teal-600" },
  { path: "/vocab-scan",    icon: Camera,        label: "Vokabeln scannen",   section: "learn",   color: "text-emerald-500" },
  { path: "/test-mode",  icon: Shield,          label: "Klausur-Vorbereitung", section: "learn", color: "text-red-600" },
  { path: "/skill-map",  icon: Map,             label: "Kompetenzmap",       section: "account" },
  { path: "/progress",   icon: BarChart3,       label: "Fortschritt",        section: "account" },
  { path: "/exams",      icon: Trophy,          label: "Tests",              section: "account" },
  { path: "/profile",    icon: User,            label: "Profil",             section: "account" },
  { path: "/settings",   icon: Settings,        label: "Einstellungen",      section: "account", primary: false },
  { path: "/seed-data",  icon: Database,        label: "Demo-Daten laden",   section: "account" },
];

const SECTION_LABELS = { main: "Übersicht", learn: "Lernbereiche", account: "Mein Konto" };

export default function AppLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];
  const xpPercent = Math.min(((profile?.xp || 0) % 100), 100);

  const NavContent = ({ onClose }) => (
    <div className="flex flex-col h-full bg-card">
      {/* Logo */}
      <div className={cn(
        "flex items-center gap-3 px-4 py-4 border-b border-border/60",
        collapsed && "justify-center px-3"
      )}>
        <div className="w-9 h-9 rounded-2xl brand-gradient flex items-center justify-center flex-shrink-0 shadow-sm">
          <span className="text-white font-black text-sm tracking-tight">EB</span>
        </div>
        {!collapsed && (
          <div>
            <p className="font-black text-[15px] text-foreground leading-none tracking-tight">English Boost</p>
          </div>
        )}
      </div>

      {/* User card */}
      {!collapsed && profile && (
        <div className="mx-3 mt-3 p-3 rounded-2xl bg-gradient-to-br from-secondary/80 to-brand-blue-light/60 border border-border/40">
          <div className="flex items-center gap-2.5 mb-2.5">
            <div className="w-8 h-8 rounded-full brand-gradient flex items-center justify-center text-white text-xs font-black shadow-sm">
              {profile.level || 1}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[13px] font-bold text-foreground truncate leading-none">
                {user?.full_name?.split(" ")[0] || "Schüler(in)"}
              </p>
              <p className="text-[11px] text-muted-foreground mt-0.5">Klasse {profile.grade}</p>
            </div>
            <div className="flex items-center gap-1 text-[12px] font-bold text-brand-orange">
              <Flame className="w-3.5 h-3.5" />
              {profile.streak || 0}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-1.5 bg-white/60 rounded-full overflow-hidden">
              <div
                className="h-full brand-gradient-lime rounded-full transition-all duration-500"
                style={{ width: `${xpPercent}%` }}
              />
            </div>
            <span className="text-[11px] text-muted-foreground font-semibold flex items-center gap-0.5">
              <Zap className="w-3 h-3 text-brand-yellow" />{profile.xp || 0}
            </span>
          </div>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-0.5">
        {["main", "learn", "account"].map(section => {
          const items = NAV_ITEMS.filter(i => i.section === section);
          return (
            <div key={section} className="mb-2">
              {!collapsed && (
                <p className="text-[10px] font-bold text-muted-foreground/70 uppercase tracking-widest px-3 py-1.5">
                  {SECTION_LABELS[section]}
                </p>
              )}
              {items.map(item => {
                const Icon = item.icon;
                const active = location.pathname === item.path;
                const isPrimary = item.primary;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={onClose}
                    title={collapsed ? item.label : undefined}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] font-semibold transition-all duration-150 group",
                      active
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : isPrimary
                          ? "bg-primary/10 text-primary hover:bg-primary/20"
                          : "text-muted-foreground hover:text-foreground hover:bg-muted",
                      collapsed && "justify-center px-2.5"
                    )}
                  >
                    <Icon className={cn(
                      "w-[18px] h-[18px] flex-shrink-0 transition-transform group-hover:scale-110",
                      active ? "text-primary-foreground" : item.color || ""
                    )} />
                    {!collapsed && <span className="truncate">{item.label}</span>}
                    {!collapsed && isPrimary && !active && (
                      <span className="ml-auto text-[10px] font-bold bg-primary text-white px-1.5 py-0.5 rounded-full">
                        Heute
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>
          );
        })}
      </nav>

      {/* Footer */}
      <div className={cn("p-3 border-t border-border/50", collapsed && "px-2")}>
        <button
          onClick={() => base44.auth.logout()}
          className={cn(
            "flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-[13px] font-semibold",
            "text-muted-foreground hover:text-destructive hover:bg-destructive/8 transition-all",
            collapsed && "justify-center px-2.5"
          )}
        >
          <LogOut className="w-[18px] h-[18px] flex-shrink-0" />
          {!collapsed && <span>Abmelden</span>}
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className={cn(
        "hidden md:flex flex-col border-r border-border/60 transition-all duration-300 flex-shrink-0 relative",
        collapsed ? "w-[60px]" : "w-[232px]"
      )}>
        <NavContent onClose={() => {}} />
        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed(c => !c)}
          className={cn(
            "absolute top-1/2 -translate-y-1/2 right-0 translate-x-1/2 z-20",
            "w-5 h-8 bg-card border border-border/70 rounded-full",
            "flex items-center justify-center text-muted-foreground hover:text-primary",
            "transition-all hover:border-primary/30 shadow-sm"
          )}
        >
          {collapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
        </button>
      </aside>

      {/* Mobile overlay drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="absolute left-0 top-0 bottom-0 w-64 shadow-2xl z-50">
            <NavContent onClose={() => setMobileOpen(false)} />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        {/* Mobile top bar */}
        <header className="md:hidden flex items-center justify-between px-4 py-3 border-b border-border/60 bg-card/95 backdrop-blur-sm sticky top-0 z-30">
          <button
            onClick={() => setMobileOpen(true)}
            className="p-3 -m-1 rounded-xl hover:bg-muted transition-colors focus-ring"
            aria-label="Menu öffnen"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl brand-gradient flex items-center justify-center shadow-sm">
              <span className="text-white font-black text-[11px]">EB</span>
            </div>
            <span className="font-black text-sm tracking-tight">English Boost</span>
          </div>
          {profile && (
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-brand-orange flex items-center gap-0.5">
                <Flame className="w-3.5 h-3.5" />{profile.streak || 0}
              </span>
            </div>
          )}
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}