/**
 * RichFeedback – shown after a wrong answer in exercise mode.
 * Shows: what's wrong, why, the rule, a corrected example, and a mini follow-up.
 */
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { AlertCircle, CheckCircle2, Lightbulb, BookOpen, ArrowRight } from "lucide-react";

export default function RichFeedback({ exercise, userAnswer, onContinue }) {
  const [miniAnswer, setMiniAnswer] = useState("");
  const [miniSubmitted, setMiniSubmitted] = useState(false);
  const isCorrect = userAnswer === exercise.correct_answer ||
    (exercise.correct_answers && exercise.correct_answers.includes(userAnswer));

  if (isCorrect) {
    return (
      <div className="mt-4 p-4 rounded-xl bg-green-50 border border-green-200 animate-fade-in">
        <div className="flex items-center gap-2 mb-2">
          <CheckCircle2 className="w-5 h-5 text-green-600" />
          <span className="font-bold text-green-800">Richtig! Sehr gut! ✅</span>
        </div>
        {exercise.explanation && (
          <p className="text-sm text-green-700 mt-1">{exercise.explanation}</p>
        )}
        <Button onClick={onContinue} className="mt-3 w-full" size="sm">Weiter →</Button>
      </div>
    );
  }

  // Wrong answer – rich feedback
  const miniQuestion = exercise.mini_followup;

  return (
    <div className="mt-4 space-y-3 animate-fade-in">
      {/* What was wrong */}
      <div className="p-4 rounded-xl bg-red-50 border border-red-200">
        <div className="flex items-start gap-2 mb-2">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-red-800">Das war noch nicht ganz richtig.</p>
            <p className="text-sm text-red-700 mt-1">
              Deine Antwort: <span className="font-semibold line-through">{userAnswer || "–"}</span>
              {" → "}
              Richtig wäre: <span className="font-semibold text-green-700">{exercise.correct_answer}</span>
            </p>
          </div>
        </div>
      </div>

      {/* Why it's wrong + the rule */}
      {exercise.explanation && (
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-2">
              <BookOpen className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-blue-800 text-sm mb-1">Die Regel:</p>
                <p className="text-sm text-blue-700">{exercise.explanation}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Corrected example */}
      {exercise.hint && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="p-3">
            <div className="flex items-start gap-2">
              <Lightbulb className="w-4 h-4 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-yellow-800 text-xs mb-1">Merkhilfe:</p>
                <p className="text-sm text-yellow-700">{exercise.hint}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Mini follow-up */}
      {miniQuestion && !miniSubmitted && (
        <Card className="border-purple-200 bg-purple-50">
          <CardContent className="p-4">
            <p className="text-sm font-semibold text-purple-800 mb-2">
              🎯 Mini-Übung: {miniQuestion.question}
            </p>
            {miniQuestion.type === "multiple_choice" ? (
              <div className="space-y-1.5">
                {miniQuestion.options.map(opt => (
                  <button key={opt} onClick={() => { setMiniAnswer(opt); setMiniSubmitted(true); }}
                    className="w-full text-left text-sm p-2 rounded-lg border-2 border-purple-200 bg-white hover:border-purple-400 transition-all">
                    {opt}
                  </button>
                ))}
              </div>
            ) : (
              <div className="flex gap-2">
                <input value={miniAnswer} onChange={e => setMiniAnswer(e.target.value)}
                  placeholder="Deine Antwort..." className="flex-1 p-2 rounded-lg border-2 border-purple-200 text-sm outline-none focus:border-purple-400" />
                <Button size="sm" onClick={() => setMiniSubmitted(true)} disabled={!miniAnswer}>OK</Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {miniQuestion && miniSubmitted && (
        <Card className={cn("border", miniAnswer === miniQuestion.correct_answer ? "border-green-200 bg-green-50" : "border-orange-200 bg-orange-50")}>
          <CardContent className="p-3">
            <p className={cn("text-sm font-semibold", miniAnswer === miniQuestion.correct_answer ? "text-green-700" : "text-orange-700")}>
              {miniAnswer === miniQuestion.correct_answer ? "✅ Mini-Übung richtig!" : `Noch mal versuchen – richtig wäre: ${miniQuestion.correct_answer}`}
            </p>
          </CardContent>
        </Card>
      )}

      <Button onClick={onContinue} className="w-full" variant="outline">
        Weiter <ArrowRight className="w-4 h-4 ml-1" />
      </Button>
    </div>
  );
}