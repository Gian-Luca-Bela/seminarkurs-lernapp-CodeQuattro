/**
 * MetacognitionPrompt – shown after selected exercises.
 * Asks short reflection questions to build learning awareness.
 */
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Brain } from "lucide-react";

const QUESTIONS = [
  { id: "difficulty", question: "Was fiel dir bei dieser Aufgabe schwer?", options: ["Die Grammatikregel", "Die Vokabeln", "Das Verstehen der Frage", "Nichts – war einfach!"] },
  { id: "confidence", question: "Fühlst du dich sicher genug für einen Test zu diesem Thema?", options: ["Ja, sehr sicher!", "Eher ja", "Noch nicht ganz", "Nein, ich brauche mehr Übung"] },
  { id: "more_practice", question: "Möchtest du mehr von dieser Art Aufgabe üben?", options: ["Ja, sehr gern!", "Vielleicht später", "Nein, ich bin zufrieden"] },
  { id: "why_difficult", question: "Warum war das schwierig?", options: ["Das Thema kenne ich noch nicht gut", "Ich war unkonzentriert", "Die Aufgabe war unklar", "Ich habe die Regel vergessen"] },
];

export default function MetacognitionPrompt({ exerciseScore, totalExercises, onDone }) {
  const [responses, setResponses] = useState({});
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);

  // Show only 2 reflection questions per session
  const selectedQuestions = [QUESTIONS[0], exerciseScore < totalExercises * 0.6 ? QUESTIONS[3] : QUESTIONS[1]];
  const current = selectedQuestions[step];

  const handleSelect = (answer) => {
    const updated = { ...responses, [current.id]: answer };
    setResponses(updated);
    if (step < selectedQuestions.length - 1) {
      setStep(s => s + 1);
    } else {
      setDone(true);
    }
  };

  if (done) {
    const wantsMorePractice = Object.values(responses).some(r => r?.includes("mehr Übung") || r?.includes("noch nicht"));
    return (
      <Card className="border-purple-200 bg-purple-50 animate-fade-in">
        <CardContent className="p-5">
          <div className="flex items-start gap-3">
            <span className="text-2xl">🧠</span>
            <div>
              <p className="font-bold text-purple-800 mb-1">Danke für deine Reflexion!</p>
              {wantsMorePractice ? (
                <p className="text-sm text-purple-700">Das Thema kommt in deinem nächsten Tagesplan wieder vor. Weitermachen ist der Schlüssel! 💪</p>
              ) : (
                <p className="text-sm text-purple-700">Toll! Du kennst deine Stärken und Schwächen – das ist schon die halbe Miete! 🎯</p>
              )}
              <Button onClick={onDone} size="sm" className="mt-3">Weiter</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-purple-200 bg-purple-50 animate-fade-in">
      <CardContent className="p-5">
        <div className="flex items-start gap-2 mb-4">
          <Brain className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-bold text-purple-600 uppercase tracking-wide mb-1">Kurze Reflexion ({step + 1}/{selectedQuestions.length})</p>
            <p className="font-semibold text-purple-900 text-sm">{current.question}</p>
          </div>
        </div>
        <div className="space-y-2">
          {current.options.map(opt => (
            <button key={opt} onClick={() => handleSelect(opt)}
              className="w-full text-left p-3 rounded-lg border-2 border-purple-200 bg-white text-sm hover:border-purple-400 hover:bg-purple-50 transition-all font-medium">
              {opt}
            </button>
          ))}
        </div>
        <button onClick={onDone} className="mt-3 text-xs text-muted-foreground hover:text-foreground transition-colors">
          Überspringen
        </button>
      </CardContent>
    </Card>
  );
}