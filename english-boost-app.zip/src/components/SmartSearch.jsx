// ─── SmartSearch – keyword/topic/filter search across all content types ─────────
import { useState, useMemo, useRef, useEffect } from "react";
import { createPortal } from "react-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Search, BookOpen, GraduationCap, FileText, PenLine, X, Filter } from "lucide-react";

const SKILL_ICONS = {
  vocabulary: BookOpen,
  grammar: GraduationCap,
  reading: FileText,
  writing: PenLine,
};

const SKILL_COLORS = {
  vocabulary: "bg-emerald-100 text-emerald-700",
  grammar: "bg-blue-100 text-blue-700",
  reading: "bg-violet-100 text-violet-700",
  writing: "bg-rose-100 text-rose-700",
  listening: "bg-orange-100 text-orange-700",
};

const DIFFICULTY_COLORS = { easy: "bg-green-100 text-green-700", medium: "bg-yellow-100 text-yellow-700", hard: "bg-red-100 text-red-700" };
const DIFFICULTY_LABELS = { easy: "Einfach", medium: "Mittel", hard: "Schwer" };

export default function SmartSearch({ className }) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [filters, setFilters] = useState({ grade: "all", difficulty: "all", exam_relevant: false });
  const [showFilters, setShowFilters] = useState(false);
  const [dropdownStyle, setDropdownStyle] = useState({});
  const containerRef = useRef(null);
  const inputRef = useRef(null);

  const { data: words = [] } = useQuery({ queryKey: ["vocabulary"], queryFn: () => base44.entities.VocabularyItem.list("-created_date", 200) });
  const { data: lessons = [] } = useQuery({ queryKey: ["grammar-lessons-all"], queryFn: () => base44.entities.GrammarLesson.list("-order", 100) });
  const { data: exercises = [] } = useQuery({ queryKey: ["exercises-all"], queryFn: () => base44.entities.Exercise.list("-created_date", 200) });
  const { data: readings = [] } = useQuery({ queryKey: ["reading-texts"], queryFn: () => base44.entities.ReadingText.list("-created_date", 50) });
  const { data: prompts = [] } = useQuery({ queryKey: ["writing-prompts"], queryFn: () => base44.entities.WritingPrompt.list("-created_date", 50) });

  // Recalculate dropdown position whenever it opens
  useEffect(() => {
    if (open && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      setDropdownStyle({
        position: "fixed",
        top: rect.bottom + 6,
        left: rect.left,
        width: rect.width,
        zIndex: 9999,
      });
    }
  }, [open, query]);

  // Close on outside click
  useEffect(() => {
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const results = useMemo(() => {
    if (!query || query.length < 2) return [];
    const q = query.toLowerCase();
    const all = [];

    words.filter(w =>
      (w.word?.toLowerCase().includes(q) || w.translation_de?.toLowerCase().includes(q) || w.theme?.toLowerCase().includes(q)) &&
      (filters.grade === "all" || w.grade === filters.grade || w.grade === "both") &&
      (filters.difficulty === "all" || w.difficulty === filters.difficulty)
    ).slice(0, 5).forEach(w => all.push({ type: "vocabulary", id: w.id, title: w.word, subtitle: w.translation_de, badge: w.theme, difficulty: w.difficulty, grade: w.grade, path: "/vocabulary" }));

    lessons.filter(l =>
      (l.title_de?.toLowerCase().includes(q) || l.topic_key?.toLowerCase().includes(q)) &&
      (filters.grade === "all" || l.grade === filters.grade || l.grade === "both") &&
      (filters.difficulty === "all" || l.difficulty === filters.difficulty)
    ).slice(0, 4).forEach(l => all.push({ type: "grammar", id: l.id, title: l.title_de, subtitle: l.title_en, badge: `Klasse ${l.grade}`, difficulty: l.difficulty, grade: l.grade, path: "/grammar" }));

    exercises.filter(e =>
      (e.title?.toLowerCase().includes(q) || e.question?.toLowerCase().includes(q) || e.topic_key?.toLowerCase().includes(q)) &&
      (filters.grade === "all" || e.grade === filters.grade || e.grade === "both") &&
      (filters.difficulty === "all" || e.difficulty === filters.difficulty) &&
      (!filters.exam_relevant || e.exam_relevant)
    ).slice(0, 4).forEach(e => all.push({ type: e.skill_area || "grammar", id: e.id, title: e.title, subtitle: e.question?.slice(0, 60) + "...", badge: e.skill_area, difficulty: e.difficulty, grade: e.grade, path: `/${e.skill_area || "grammar"}` }));

    readings.filter(r =>
      (r.title?.toLowerCase().includes(q) || r.topic?.toLowerCase().includes(q)) &&
      (filters.grade === "all" || r.grade === filters.grade || r.grade === "both") &&
      (filters.difficulty === "all" || r.difficulty === filters.difficulty)
    ).slice(0, 3).forEach(r => all.push({ type: "reading", id: r.id, title: r.title, subtitle: r.topic, badge: r.text_type, difficulty: r.difficulty, grade: r.grade, path: "/reading" }));

    prompts.filter(p =>
      (p.title?.toLowerCase().includes(q) || p.genre?.toLowerCase().includes(q)) &&
      (filters.grade === "all" || p.grade === filters.grade || p.grade === "both") &&
      (filters.difficulty === "all" || p.difficulty === filters.difficulty) &&
      (!filters.exam_relevant || p.exam_relevant)
    ).slice(0, 3).forEach(p => all.push({ type: "writing", id: p.id, title: p.title, subtitle: p.genre, badge: p.genre, difficulty: p.difficulty, grade: p.grade, path: "/writing" }));

    return all.slice(0, 15);
  }, [query, words, lessons, exercises, readings, prompts, filters]);

  const showDropdown = open && query.length >= 2;

  const dropdown = showDropdown ? (
    <div
      style={dropdownStyle}
      className="bg-card border border-border rounded-2xl shadow-2xl overflow-hidden max-h-96 overflow-y-auto"
    >
      {results.length === 0 ? (
        <div className="p-4 text-center text-sm text-muted-foreground">Keine Ergebnisse für „{query}"</div>
      ) : (
        <>
          <div className="px-3 py-2 border-b border-border/60 bg-secondary/40">
            <p className="text-xs font-bold text-muted-foreground">{results.length} Ergebnisse</p>
          </div>
          {results.map((r, idx) => {
            const Icon = SKILL_ICONS[r.type] || Search;
            return (
              <Link
                key={`${r.type}-${r.id}-${idx}`}
                to={r.path}
                onClick={() => { setOpen(false); setQuery(""); }}
                className="flex items-center gap-3 px-3 py-3 hover:bg-secondary/70 active:bg-secondary transition-colors border-b border-border/30 last:border-0 cursor-pointer"
              >
                <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0", SKILL_COLORS[r.type] || "bg-secondary")}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold truncate">{r.title}</p>
                  {r.subtitle && <p className="text-xs text-muted-foreground truncate">{r.subtitle}</p>}
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  {r.difficulty && r.difficulty !== "all" && (
                    <span className={cn("text-xs px-1.5 py-0.5 rounded-full font-bold", DIFFICULTY_COLORS[r.difficulty])}>{DIFFICULTY_LABELS[r.difficulty]}</span>
                  )}
                  {r.grade && <Badge variant="outline" className="text-xs">{r.grade}</Badge>}
                </div>
              </Link>
            );
          })}
        </>
      )}
    </div>
  ) : null;

  return (
    <div ref={containerRef} className={cn("relative", className)}>
      <div className="relative flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <Input
            ref={inputRef}
            value={query}
            onChange={e => { setQuery(e.target.value); setOpen(true); }}
            onFocus={() => setOpen(true)}
            placeholder="Suche Vokabeln, Grammatik, Texte..."
            className="pl-9 pr-8"
          />
          {query && (
            <button
              onMouseDown={e => { e.preventDefault(); setQuery(""); setOpen(false); }}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <Button variant="outline" size="icon" onClick={() => setShowFilters(f => !f)} className={cn("flex-shrink-0", showFilters && "bg-primary/10 border-primary/40")}>
          <Filter className="w-4 h-4" />
        </Button>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="mt-2 p-3 bg-card border border-border rounded-2xl flex flex-wrap gap-2 animate-fade-up">
          <div className="flex gap-1.5">
            {["all", "8", "9"].map(g => (
              <button key={g} onClick={() => setFilters(f => ({ ...f, grade: g }))}
                className={cn("px-2.5 py-1 rounded-full text-xs font-bold transition-all border", filters.grade === g ? "bg-primary text-white border-primary" : "border-border text-muted-foreground")}>
                {g === "all" ? "Alle" : `Kl. ${g}`}
              </button>
            ))}
          </div>
          <div className="flex gap-1.5">
            {["all", "easy", "medium", "hard"].map(d => (
              <button key={d} onClick={() => setFilters(f => ({ ...f, difficulty: d }))}
                className={cn("px-2.5 py-1 rounded-full text-xs font-bold transition-all border", filters.difficulty === d ? "bg-primary text-white border-primary" : "border-border text-muted-foreground")}>
                {d === "all" ? "Alle Niveaus" : DIFFICULTY_LABELS[d]}
              </button>
            ))}
          </div>
          <button onClick={() => setFilters(f => ({ ...f, exam_relevant: !f.exam_relevant }))}
            className={cn("px-2.5 py-1 rounded-full text-xs font-bold border transition-all", filters.exam_relevant ? "bg-red-500 text-white border-red-500" : "border-border text-muted-foreground")}>
            ⭐ Testrelevant
          </button>
        </div>
      )}

      {/* Portal dropdown – rendered at document.body level to avoid overflow/z-index issues */}
      {typeof document !== "undefined" && createPortal(dropdown, document.body)}
    </div>
  );
}