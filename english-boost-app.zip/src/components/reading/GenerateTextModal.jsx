import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";

const CLASS8_TOPICS = [
  { label: "Kids in America", topic: "Kids in America – teen life and school", textType: "article" },
  { label: "New York City", topic: "City of dreams: New York", textType: "narrative" },
  { label: "Thanksgiving", topic: "Thanksgiving – an American holiday", textType: "factual" },
  { label: "Werbung / Ads", topic: "Advertisements and consumer culture", textType: "article" },
  { label: "Schulregeln", topic: "School rules – dos and don'ts", textType: "dialogue" },
  { label: "Pacific Northwest", topic: "The Pacific Northwest – nature and people", textType: "report" },
  { label: "Internet & Hoaxes", topic: "Internet hoaxes and fake news", textType: "article" },
  { label: "Native Americans", topic: "Native Americans – history and present", textType: "factual" },
  { label: "American Inventions", topic: "A nation invents itself – American inventions", textType: "factual" },
  { label: "Travel texts", topic: "Travel to the USA – blog and guide", textType: "blog_post" },
];

const CLASS9_TOPICS = [
  { label: "World Englishes", topic: "English as a global language – different varieties worldwide", textType: "article" },
  { label: "Australia", topic: "G'day Australia – life, culture and landscape Down Under", textType: "factual" },
  { label: "South Africa", topic: "South Africa – rainbow nation, languages and diversity", textType: "report" },
  { label: "India & English", topic: "English in India – history, use and importance today", textType: "article" },
  { label: "Tolerance & Respect", topic: "The language of tolerance and respect – diversity in society", textType: "article" },
  { label: "Food & Lifestyle", topic: "The good life? – food culture, health and lifestyle choices", textType: "blog_post" },
  { label: "California Dreaming", topic: "California dreaming – Hollywood, nature and the American Dream", textType: "narrative" },
  { label: "Cause & Effect", topic: "Cause and effect – environmental and social issues in California", textType: "report" },
  { label: "Letters to Editor", topic: "Letters to the editor – argumentative writing and having a voice", textType: "letter" },
  { label: "Short Films", topic: "A short film – analysing film language and narrative", textType: "article" },
];

const DIFFICULTIES = [
  { value: "easy", label: "Einfach", color: "text-green-700 bg-green-50 border-green-200" },
  { value: "medium", label: "Mittel", color: "text-yellow-700 bg-yellow-50 border-yellow-200" },
  { value: "hard", label: "Schwer", color: "text-red-700 bg-red-50 border-red-200" },
];

export default function GenerateTextModal({ open, onClose, grade, onGenerate }) {
  const [selectedTopic, setSelectedTopic] = useState(null);
  const [customTopic, setCustomTopic] = useState("");
  const [selectedDifficulty, setSelectedDifficulty] = useState("medium");
  const [generating, setGenerating] = useState(false);

  const topics = grade === "9" ? CLASS9_TOPICS : CLASS8_TOPICS;
  const canGenerate = selectedTopic || customTopic.trim().length > 3;

  const handleGenerate = async () => {
    if (!canGenerate) return;
    setGenerating(true);
    const topicObj = customTopic.trim()
      ? { topic: customTopic.trim(), textType: "article" }
      : selectedTopic;
    await onGenerate(topicObj, selectedDifficulty);
    setGenerating(false);
    onClose();
    setSelectedTopic(null);
    setCustomTopic("");
    setSelectedDifficulty("medium");
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Eigenen Text generieren – Klasse {grade}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div>
            <p className="text-sm font-semibold mb-2">1. Thema wählen</p>
            <div className="flex flex-wrap gap-2 mb-3">
              {topics.map(t => (
                <button key={t.label}
                  onClick={() => { setSelectedTopic(t); setCustomTopic(""); }}
                  className={cn(
                    "text-xs px-3 py-1.5 rounded-full border transition-all",
                    selectedTopic?.label === t.label && !customTopic
                      ? "bg-primary text-white border-primary"
                      : "bg-white border-border hover:border-primary/50 hover:bg-primary/5"
                  )}>
                  {t.label}
                </button>
              ))}
            </div>
            <Input
              placeholder="Oder eigenes Thema eingeben…"
              value={customTopic}
              onChange={e => { setCustomTopic(e.target.value); if (e.target.value) setSelectedTopic(null); }}
              className="text-sm"
            />
          </div>

          <div>
            <p className="text-sm font-semibold mb-2">2. Schwierigkeitsstufe wählen</p>
            <div className="flex gap-2">
              {DIFFICULTIES.map(d => (
                <button key={d.value}
                  onClick={() => setSelectedDifficulty(d.value)}
                  className={cn(
                    "flex-1 py-2 rounded-xl border text-sm font-semibold transition-all",
                    selectedDifficulty === d.value ? d.color : "bg-white border-border hover:bg-secondary"
                  )}>
                  {d.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex gap-3 pt-2">
          <Button variant="outline" onClick={onClose} className="flex-1">Abbrechen</Button>
          <Button onClick={handleGenerate} disabled={!canGenerate || generating} className="flex-1 gap-2">
            {generating ? <><Loader2 className="w-4 h-4 animate-spin" />Wird generiert...</> : <><Sparkles className="w-4 h-4" />Generieren</>}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}