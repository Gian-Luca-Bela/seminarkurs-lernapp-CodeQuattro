import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trash2, RefreshCw, FileText, PenLine, Headphones, Mic, ArrowLeftRight, Star } from "lucide-react";
import { cn } from "@/lib/utils";

const SKILL_CONFIG = {
  writing:   { label: "Schreiben",  icon: PenLine,       color: "bg-pink-100 text-pink-700",   route: "/writing" },
  reading:   { label: "Lesen",      icon: FileText,      color: "bg-violet-100 text-violet-700", route: "/reading" },
  listening: { label: "Hören",      icon: Headphones,    color: "bg-blue-100 text-blue-700",   route: "/listening" },
  speaking:  { label: "Sprechen",   icon: Mic,           color: "bg-yellow-100 text-yellow-700", route: "/speaking" },
  mediation: { label: "Mediation",  icon: ArrowLeftRight, color: "bg-teal-100 text-teal-700",  route: "/mediation" },
};

export default function CompletedTasksTab({ completedTasks, onDelete, onStar }) {
  const navigate = useNavigate();
  const [filterStarred, setFilterStarred] = useState(false);

  const displayed = filterStarred ? completedTasks.filter(t => t.starred) : completedTasks;

  if (completedTasks.length === 0) {
    return (
      <div className="py-16 text-center">
        <p className="text-3xl mb-3">📭</p>
        <p className="font-semibold text-sm">Noch keine abgeschlossenen Aufgaben.</p>
        <p className="text-xs text-muted-foreground mt-1">Schließe Aufgaben in den Lernbereichen ab – sie erscheinen hier.</p>
      </div>
    );
  }

  const starredCount = completedTasks.filter(t => t.starred).length;

  const grouped = Object.entries(SKILL_CONFIG)
    .map(([type, config]) => ({ type, config, tasks: displayed.filter(t => t.task_type === type) }))
    .filter(g => g.tasks.length > 0);

  return (
    <div className="space-y-6">
      {/* Filter bar */}
      <div className="flex items-center gap-2">
        <button onClick={() => setFilterStarred(false)}
          className={cn("px-3 py-1.5 rounded-lg text-xs font-semibold transition-all", !filterStarred ? "bg-primary text-white" : "bg-secondary text-muted-foreground hover:text-foreground")}>
          Alle ({completedTasks.length})
        </button>
        <button onClick={() => setFilterStarred(true)}
          className={cn("px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1", filterStarred ? "bg-yellow-400 text-white" : "bg-secondary text-muted-foreground hover:text-foreground")}>
          <Star className="w-3 h-3" />Favoriten ({starredCount})
        </button>
        <span className="ml-auto text-xs text-muted-foreground">Max. 100 · ⭐ nie gelöscht</span>
      </div>

      {displayed.length === 0 && (
        <div className="py-10 text-center">
          <p className="text-2xl mb-2">⭐</p>
          <p className="text-sm text-muted-foreground">Keine Favoriten vorhanden.</p>
        </div>
      )}

      {grouped.map(({ type, config, tasks }) => {
        const Icon = config.icon;
        return (
          <div key={type}>
            <div className="flex items-center gap-2 mb-3">
              <span className={cn("w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0", config.color)}>
                <Icon className="w-4 h-4" />
              </span>
              <h3 className="font-bold text-sm">{config.label}</h3>
              <Badge variant="secondary" className="text-xs ml-auto">{tasks.length}</Badge>
            </div>
            <div className="space-y-2">
              {tasks.map(task => (
                <Card key={task.id} className="border-border/50">
                  <CardContent className="p-3 flex items-center justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{task.task_title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">✅ {task.completed_date}</p>
                    </div>
                    <div className="flex gap-2 flex-shrink-0 items-center">
                      <button onClick={() => onStar(task.id, !task.starred)}
                        className={cn("w-7 h-7 flex items-center justify-center rounded-lg transition-colors", task.starred ? "text-yellow-500 hover:text-yellow-600" : "text-muted-foreground hover:text-yellow-400")}>
                        <Star className={cn("w-4 h-4", task.starred && "fill-yellow-400")} />
                      </button>
                      <Button size="sm" variant="outline" className="h-7 text-xs gap-1"
                        onClick={() => navigate(config.route, { state: { taskId: task.task_id, noXP: true } })}>
                        <RefreshCw className="w-3 h-3" />Wiederholen
                      </Button>
                      <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:bg-destructive/10"
                        onClick={() => onDelete(task.id)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}