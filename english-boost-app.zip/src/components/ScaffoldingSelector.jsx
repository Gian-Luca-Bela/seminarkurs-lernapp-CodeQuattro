/**
 * ScaffoldingSelector – lets the student choose their difficulty tier.
 * with_help / normal / challenge
 */
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { SCAFFOLDING_TIERS } from "@/lib/skillMap";

export default function ScaffoldingSelector({ selected, onChange, grade }) {
  return (
    <div className="space-y-2">
      <p className="text-sm font-semibold text-muted-foreground">Schwierigkeitsstufe wählen:</p>
      <div className="grid grid-cols-3 gap-2">
        {Object.values(SCAFFOLDING_TIERS).map(tier => (
          <button key={tier.key} onClick={() => onChange(tier.key)}
            className={cn(
              "p-3 rounded-xl border-2 text-left transition-all",
              selected === tier.key
                ? "border-primary bg-primary/5 shadow-sm"
                : "border-border hover:border-primary/40 bg-background"
            )}>
            <div className="text-xl mb-1">{tier.icon}</div>
            <p className="text-xs font-bold">{tier.label}</p>
            <p className="text-xs text-muted-foreground leading-snug">{tier.description}</p>
            {grade === "8" && tier.key === "with_help" && (
              <span className="text-xs text-primary font-medium">Empfohlen</span>
            )}
            {grade === "9" && tier.key === "challenge" && (
              <span className="text-xs text-primary font-medium">Empfohlen</span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}