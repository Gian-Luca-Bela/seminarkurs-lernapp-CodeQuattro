import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Zap, CheckCircle2, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import XPToast from "@/components/XPToast";
import { useXP } from "@/lib/useXP";

const SKILL_ICONS = {
  vocabulary: "📖",
  grammar: "🎓",
  reading: "📰",
  listening: "🎧",
  writing: "✍️",
  speaking: "🗣️",
  mediation: "🔄"
};

const SKILL_LABELS = {
  vocabulary: "Vokabeln",
  grammar: "Grammatik",
  reading: "Lesen",
  listening: "Hören",
  writing: "Schreiben",
  speaking: "Sprechen",
  mediation: "Sprachmittlung"
};

export default function DailyChallengeWidget({ user, profile }) {
  const [showXP, setShowXP] = useState(false);
  const [lastXP, setLastXP] = useState(0);
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const queryClient = useQueryClient();
  const { awardXP } = useXP(user, profile);

  const today = new Date().toISOString().split("T")[0];

  const { data: todayChallenge } = useQuery({
    queryKey: ["daily-challenge", user?.email, today],
    queryFn: () =>
      base44.entities.DailyChallenge.filter({
        user_email: user?.email,
        challenge_date: today,
      }),
    enabled: !!user?.email,
  });

  const challenge = todayChallenge?.[0];
  const isCompleted = challenge?.completed;

  const { data: challengeStreak = 0 } = useQuery({
    queryKey: ["challenge-streak", user?.email],
    queryFn: async () => {
      const attempts = await base44.entities.DailyChallenge.filter({
        user_email: user?.email,
      });
      let streak = 0;
      let checkDate = new Date();
      const sorted = attempts
        ?.sort((a, b) => new Date(b.completed_date) - new Date(a.completed_date))
        .filter(a => a.completed);
      
      for (const attempt of sorted || []) {
        const attemptDate = new Date(attempt.completed_date);
        if (
          checkDate.getFullYear() === attemptDate.getFullYear() &&
          checkDate.getMonth() === attemptDate.getMonth() &&
          checkDate.getDate() === attemptDate.getDate()
        ) {
          streak++;
          checkDate.setDate(checkDate.getDate() - 1);
        } else {
          break;
        }
      }
      return streak;
    },
    enabled: !!user?.email,
  });

  const completeMutation = useMutation({
    mutationFn: (data) =>
      base44.entities.DailyChallenge.update(challenge.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["daily-challenge", user?.email, today],
      });
      queryClient.invalidateQueries({
        queryKey: ["challenge-streak", user?.email],
      });
      queryClient.invalidateQueries({ queryKey: ["user-profile", user?.email] });
    },
  });

  if (!challenge) {
    return (
      <div className="rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-black text-sm flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-purple-100 flex items-center justify-center">
              ⚡
            </div>
            Tägliche Herausforderung
          </h2>
          <Badge variant="secondary" className="text-xs">
            {challengeStreak} 🔥
          </Badge>
        </div>
        <p className="text-xs text-muted-foreground mb-3">
          Keine Herausforderung für heute verfügbar. Bald wird eine generiert!
        </p>
      </div>
    );
  }

  const handleSubmit = () => {
    if (!selected || submitted) return;
    const correct = selected === challenge.correct_answer;
    const xpEarned = correct ? challenge.xp_reward : Math.floor(challenge.xp_reward / 3);
    awardXP(xpEarned);
    setLastXP(xpEarned);
    setShowXP(true);
    setSubmitted(true);
    completeMutation.mutate({
      completed: true,
      completed_date: today,
      xp_reward: xpEarned,
    });
  };

  if (isCompleted) {
    return (
      <div className="rounded-2xl border border-green-200 bg-green-50 p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-black text-sm flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-green-100 flex items-center justify-center">
              ✅
            </div>
            Herausforderung erledigt!
          </h2>
          <Badge className="bg-green-500 text-white text-xs">
            {challengeStreak} 🔥
          </Badge>
        </div>
        <p className="text-sm text-green-700 font-bold mb-1">
          +{challenge.xp_reward} XP verdient
        </p>
        <p className="text-xs text-green-600">
          Morgen wartet eine neue Herausforderung. Streak gehalten! 🎉
        </p>
      </div>
    );
  }

  return (
    <>
      <XPToast amount={lastXP} show={showXP} onDone={() => setShowXP(false)} />
      <div className="rounded-2xl border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50 p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-black text-sm flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-purple-100 flex items-center justify-center">
              ⚡
            </div>
            Tägliche Herausforderung
          </h2>
          <Badge variant="secondary" className="text-xs">
            {challengeStreak} 🔥
          </Badge>
        </div>

        <div className="bg-white rounded-xl p-4 mb-3 border border-border/50">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-lg">{SKILL_ICONS[challenge.skill_area]}</span>
            <span className="text-xs font-bold text-muted-foreground">
              {SKILL_LABELS[challenge.skill_area]}
            </span>
          </div>
          <p className="font-bold text-sm mb-3">{challenge.question}</p>
          {challenge.context && (
            <p className="text-xs text-muted-foreground italic mb-3">
              "{challenge.context}"
            </p>
          )}
        </div>

        {challenge.options && challenge.options.length > 0 ? (
          <div className="space-y-2 mb-4">
            {challenge.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => !submitted && setSelected(opt)}
                className={cn(
                  "w-full p-3 rounded-xl border-2 text-left text-sm font-medium transition-all",
                  submitted
                    ? opt === challenge.correct_answer
                      ? "border-green-500 bg-green-50 text-green-800"
                      : opt === selected
                      ? "border-red-400 bg-red-50"
                      : "border-border opacity-40"
                    : selected === opt
                    ? "border-primary bg-primary/8"
                    : "border-border hover:border-primary/40"
                )}
              >
                {opt}
              </button>
            ))}
          </div>
        ) : null}

        {submitted ? (
          <div className={cn("p-3 rounded-xl text-sm font-bold", 
            selected === challenge.correct_answer 
              ? "bg-green-50 text-green-700"
              : "bg-red-50 text-red-700"
          )}>
            {selected === challenge.correct_answer
              ? `✓ Richtig! +${challenge.xp_reward} XP`
              : `✗ Leider falsch! +${Math.floor(challenge.xp_reward / 3)} XP für's Mitmachen`}
          </div>
        ) : (
          <Button
            onClick={handleSubmit}
            disabled={!selected}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold gap-2 rounded-xl"
          >
            <Zap className="w-4 h-4" />
            Absenden (+{challenge.xp_reward} XP)
          </Button>
        )}
      </div>
    </>
  );
}