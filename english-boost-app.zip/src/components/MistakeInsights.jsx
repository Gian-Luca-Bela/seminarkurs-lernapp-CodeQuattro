/**
 * MistakeInsights – recurring error patterns, surfaced inline.
 */
import { useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { AlertTriangle, ArrowRight, TrendingDown } from "lucide-react";
import { MISTAKE_PATTERNS } from "@/lib/skillMap";

function detectPatterns(attempts) {
  if (!attempts || attempts.length === 0) return [];
  const wrong = attempts.filter(a => !a.is_correct);
  const detected = [];

  for (const pattern of MISTAKE_PATTERNS) {
    const matches = wrong.filter(a =>
      (pattern.skill && a.skill_area === pattern.skill) ||
      (pattern.trigger_topics && pattern.trigger_topics.includes(a.topic_key))
    );
    if (matches.length >= 2) {
      detected.push({ ...pattern, count: matches.length });
    }
  }
  return detected.sort((a, b) => b.count - a.count).slice(0, 3);
}

const SKILL_PATHS = {
  grammar: "/grammar", vocabulary: "/vocabulary", reading: "/reading",
  writing: "/writing", listening: "/listening",
};

export default function MistakeInsights({ attempts, compact = false }) {
  const patterns = useMemo(() => detectPatterns(attempts), [attempts]);
  if (patterns.length === 0) return null;

  if (compact) {
    return (
      <div className="space-y-2">
        {patterns.map(p => (
          <div key={p.key} className="flex items-center gap-3 p-3 rounded-xl bg-orange-50 border border-orange-200">
            <TrendingDown className="w-4 h-4 text-orange-500 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-orange-800">{p.label}</p>
              <p className="text-xs text-orange-600 truncate mt-0.5">{p.feedback_de}</p>
            </div>
            <Badge className="bg-orange-100 text-orange-700 border-0 text-xs font-bold flex-shrink-0">{p.count}×</Badge>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-orange-200 bg-orange-50 overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2.5 px-4 py-3 border-b border-orange-200/70 bg-orange-100/60">
        <AlertTriangle className="w-4 h-4 text-orange-600" />
        <p className="text-sm font-black text-orange-800">Wiederkehrende Fehler</p>
        <Badge className="ml-auto bg-orange-200 text-orange-700 border-0 text-xs font-bold">
          {patterns.length} Muster
        </Badge>
      </div>

      <div className="p-3 space-y-2.5">
        {patterns.map(p => (
          <div key={p.key} className="flex items-start gap-3 bg-white rounded-xl p-3.5 border border-orange-100 shadow-sm">
            <div className="w-8 h-8 rounded-xl bg-orange-100 flex items-center justify-center flex-shrink-0">
              <TrendingDown className="w-4 h-4 text-orange-600" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-sm font-bold text-foreground">{p.label}</p>
                <Badge className="bg-orange-100 text-orange-700 border-0 text-[11px] font-bold">{p.count}× falsch</Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{p.feedback_de}</p>
              {SKILL_PATHS[p.skill] && (
                <Button asChild variant="ghost" size="sm" className="mt-2 h-7 text-xs font-bold text-primary px-0 hover:bg-transparent">
                  <Link to={SKILL_PATHS[p.skill]}>Jetzt üben <ArrowRight className="w-3 h-3 ml-1" /></Link>
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}