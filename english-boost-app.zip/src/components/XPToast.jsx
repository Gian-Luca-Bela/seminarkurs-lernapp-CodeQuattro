import { useEffect, useState } from "react";
import { Zap } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Animated "+XP" notification with floating particles.
 * Usage: <XPToast amount={15} show={showXP} onDone={() => setShowXP(false)} />
 */
export default function XPToast({ amount, show, onDone }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (show) {
      setVisible(true);
      const t = setTimeout(() => {
        setVisible(false);
        onDone?.();
      }, 1800);
      return () => clearTimeout(t);
    }
  }, [show]);

  if (!visible) return null;

  return (
    <div className={cn(
      "fixed bottom-24 left-1/2 -translate-x-1/2 z-50",
      "flex items-center gap-2 px-5 py-3 rounded-full shadow-xl",
      "bg-gradient-to-r from-primary to-primary/80 text-primary-foreground font-black text-base",
      "animate-pop-in"
    )}>
      <Zap className="w-5 h-5 animate-pulse" />
      +{amount} XP
    </div>
  );
}