import { Link } from "react-router-dom";
import { ArrowRight, AlertTriangle, TrendingDown, Flame, Lightbulb, Target, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const TYPE_CONFIG = {
  exam:         { icon: Calendar,      bg: "bg-red-50",    border: "border-red-200",    text: "text-red-700",    btn: "bg-red-500 hover:bg-red-600 text-white" },
  weak_area:    { icon: TrendingDown,  bg: "bg-orange-50", border: "border-orange-200", text: "text-orange-700", btn: "bg-orange-500 hover:bg-orange-600 text-white" },
  streak:       { icon: Flame,         bg: "bg-amber-50",  border: "border-amber-200",  text: "text-amber-700",  btn: "bg-amber-500 hover:bg-amber-600 text-white" },
  profile_weak: { icon: Target,        bg: "bg-blue-50",   border: "border-blue-200",   text: "text-blue-700",   btn: "bg-blue-500 hover:bg-blue-600 text-white" },
  confidence:   { icon: Lightbulb,     bg: "bg-purple-50", border: "border-purple-200", text: "text-purple-700", btn: "bg-purple-500 hover:bg-purple-600 text-white" },
  general:      { icon: Target,        bg: "bg-primary/5", border: "border-primary/20", text: "text-primary",    btn: "brand-gradient text-white" },
};

export default function RecommendationPanel({ recommendations = [], compact = false }) {
  if (recommendations.length === 0) return null;

  if (compact) {
    return (
      <div className="space-y-2">
        {recommendations.slice(0, 3).map(rec => {
          const cfg = TYPE_CONFIG[rec.type] || TYPE_CONFIG.general;
          const Icon = cfg.icon;
          return (
            <Link key={rec.id} to={rec.path} className={cn("flex items-center gap-3 p-3 rounded-xl border transition-all hover:opacity-90", cfg.bg, cfg.border)}>
              <Icon className={cn("w-4 h-4 flex-shrink-0", cfg.text)} />
              <div className="flex-1 min-w-0">
                <p className={cn("text-xs font-black truncate", cfg.text)}>{rec.title}</p>
                <p className="text-xs text-muted-foreground truncate">{rec.subtitle}</p>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
            </Link>
          );
        })}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="section-header">
        <h2 className="text-sm font-black text-foreground uppercase tracking-wider">Empfehlungen für dich</h2>
      </div>
      {recommendations.map((rec, idx) => {
        const cfg = TYPE_CONFIG[rec.type] || TYPE_CONFIG.general;
        const Icon = cfg.icon;
        return (
          <div key={rec.id} className={cn("flex items-center gap-4 p-4 rounded-2xl border", cfg.bg, cfg.border, "animate-fade-up")} style={{ animationDelay: `${idx * 60}ms` }}>
            <div className={cn("w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0", cfg.bg)}>
              <Icon className={cn("w-4 h-4", cfg.text)} />
            </div>
            <div className="flex-1 min-w-0">
              <p className={cn("text-sm font-black", cfg.text)}>{rec.title}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{rec.subtitle}</p>
            </div>
            <Button asChild size="sm" className={cn("text-xs font-bold rounded-xl flex-shrink-0", cfg.btn)}>
              <Link to={rec.path}>{rec.action}</Link>
            </Button>
          </div>
        );
      })}
    </div>
  );
}