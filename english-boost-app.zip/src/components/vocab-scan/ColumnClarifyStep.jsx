// ─── Step 1b: Ask user which column is English ────────────────────────────────
import { Button } from "@/components/ui/button";
import { HelpCircle } from "lucide-react";

export default function ColumnClarifyStep({ col1Label, col2Label, sample = [], onDone }) {
  return (
    <div className="p-4 max-w-lg mx-auto animate-fade-up">
      <div className="text-center mb-6 pt-4">
        <div className="w-14 h-14 rounded-2xl bg-yellow-100 flex items-center justify-center mx-auto mb-3">
          <HelpCircle className="w-7 h-7 text-yellow-600" />
        </div>
        <h2 className="text-xl font-black mb-1">Welche Spalte ist Englisch?</h2>
        <p className="text-sm text-muted-foreground">Die KI ist sich nicht sicher. Tippe auf die richtige Spalte.</p>
      </div>

      {/* Preview table */}
      {sample.length > 0 && (
        <div className="rounded-2xl border border-border overflow-hidden mb-6">
          <div className="grid grid-cols-2 divide-x divide-border">
            <div className="p-3 bg-muted/50 text-center text-xs font-bold text-muted-foreground uppercase tracking-wider">
              {col1Label || "Spalte 1"}
            </div>
            <div className="p-3 bg-muted/50 text-center text-xs font-bold text-muted-foreground uppercase tracking-wider">
              {col2Label || "Spalte 2"}
            </div>
          </div>
          {sample.map((p, i) => (
            <div key={i} className="grid grid-cols-2 divide-x divide-border border-t border-border">
              <div className="p-3 text-sm">{p.col1 || <span className="text-muted-foreground italic">–</span>}</div>
              <div className="p-3 text-sm">{p.col2 || <span className="text-muted-foreground italic">–</span>}</div>
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 gap-3">
        <button
          onClick={() => onDone(false)}
          className="p-4 rounded-2xl border-2 border-border hover:border-primary hover:bg-primary/5 transition-all text-left active:scale-[0.98]"
        >
          <p className="font-black text-sm mb-0.5">🇬🇧 Spalte 1 ist Englisch</p>
          <p className="text-xs text-muted-foreground">„{col1Label || "Spalte 1"}" enthält die englischen Wörter</p>
        </button>
        <button
          onClick={() => onDone(true)}
          className="p-4 rounded-2xl border-2 border-border hover:border-primary hover:bg-primary/5 transition-all text-left active:scale-[0.98]"
        >
          <p className="font-black text-sm mb-0.5">🇬🇧 Spalte 2 ist Englisch</p>
          <p className="text-xs text-muted-foreground">„{col2Label || "Spalte 2"}" enthält die englischen Wörter</p>
        </button>
      </div>
    </div>
  );
}