// ─── Step 3: Choose what to do with the scanned vocabulary ───────────────────
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle2, BookOpen, ArrowLeftRight, Layers, Search, Save, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

const ACTIONS = [
  {
    id: "de_en",
    icon: "🇩🇪 → 🇬🇧",
    label: "Deutsch → Englisch abfragen",
    desc: "Sieh das deutsche Wort, tippe das englische",
    color: "border-blue-200 hover:border-blue-400 hover:bg-blue-50",
    activeColor: "border-blue-500 bg-blue-50",
  },
  {
    id: "en_de",
    icon: "🇬🇧 → 🇩🇪",
    label: "Englisch → Deutsch abfragen",
    desc: "Sieh das englische Wort, tippe das deutsche",
    color: "border-emerald-200 hover:border-emerald-400 hover:bg-emerald-50",
    activeColor: "border-emerald-500 bg-emerald-50",
  },
  {
    id: "flashcard",
    icon: "🃏",
    label: "Karteikarten",
    desc: "Flip-Karten durch alle Wörter",
    color: "border-violet-200 hover:border-violet-400 hover:bg-violet-50",
    activeColor: "border-violet-500 bg-violet-50",
  },
  {
    id: "explore",
    icon: "🔍",
    label: "Wörter nachschlagen",
    desc: "Zum Vokabel-Browser gehen",
    color: "border-orange-200 hover:border-orange-400 hover:bg-orange-50",
    activeColor: "border-orange-500 bg-orange-50",
  },
  {
    id: "save",
    icon: "💾",
    label: "Nur speichern",
    desc: "Vokabelset für später speichern",
    color: "border-border hover:border-primary/40 hover:bg-primary/5",
    activeColor: "border-primary bg-primary/5",
  },
];

export default function ActionSelectStep({ pairs, setName, savedSetId, onSetSaved }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(!!savedSetId);
  const [selectedAction, setSelectedAction] = useState(null);
  const [quizMode, setQuizMode] = useState(null); // "de_en" | "en_de" | "flashcard"
  const [quizIndex, setQuizIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [input, setInput] = useState("");
  const [checked, setChecked] = useState(false);
  const [score, setScore] = useState({ correct: 0, wrong: 0 });

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });

  const saveSet = async () => {
    if (saved || saving) return;
    setSaving(true);
    // Save each pair as a VocabularyItem with a theme matching the set name
    await Promise.all(
      pairs.map(p =>
        base44.entities.VocabularyItem.create({
          word: p.en,
          translation_de: p.de,
          grade: "both",
          theme: setName,
          definition_en: "",
        })
      )
    );
    // Also save a SavedVocabSet record so the student can retrieve it later
    if (user?.email) {
      await base44.entities.SavedVocabSet.create({
        user_email: user.email,
        name: setName,
        source: "vocab_scan",
        words: pairs.map(p => ({ word: p.en, translation_de: p.de })),
      });
      queryClient.invalidateQueries({ queryKey: ["saved-vocab-sets", user.email] });
    }
    setSaving(false);
    setSaved(true);
    queryClient.invalidateQueries({ queryKey: ["vocabulary"] });
  };

  const handleAction = async (actionId) => {
    setSelectedAction(actionId);

    if (actionId === "save") {
      await saveSet();
      return;
    }
    if (actionId === "explore") {
      await saveSet();
      navigate("/vocabulary");
      return;
    }
    if (["de_en", "en_de", "flashcard"].includes(actionId)) {
      setQuizMode(actionId);
      setQuizIndex(0);
      setFlipped(false);
      setInput("");
      setChecked(false);
      setScore({ correct: 0, wrong: 0 });
    }
  };

  // ── Quiz / Flashcard inline mode ─────────────────────────────────────────────
  if (quizMode) {
    const shuffled = [...pairs].sort(() => Math.random() - 0.5);
    const w = shuffled[quizIndex % shuffled.length];
    const total = shuffled.length;

    if (quizMode === "flashcard") {
      const next = () => { setFlipped(false); setQuizIndex(i => i + 1); };
      const done = quizIndex >= total;
      if (done) return <QuizDone score={score} total={total} onRestart={() => { setQuizIndex(0); setScore({ correct: 0, wrong: 0 }); }} onBack={() => setQuizMode(null)} />;
      return (
        <div className="p-4 max-w-lg mx-auto animate-fade-up">
          <QuizHeader label="Karteikarten" index={quizIndex} total={total} onBack={() => setQuizMode(null)} />
          <div className="cursor-pointer" onClick={() => setFlipped(f => !f)}>
            <div className={cn("min-h-52 rounded-2xl border-2 p-8 flex flex-col items-center justify-center text-center transition-all mb-4",
              flipped ? "border-primary bg-primary/5" : "border-border hover:border-primary/30")}>
              {!flipped ? (
                <>
                  <p className="text-3xl font-black mb-1">{w.en}</p>
                  <p className="text-xs text-muted-foreground mt-3 uppercase tracking-wider">Tippen zum Aufdecken</p>
                </>
              ) : (
                <>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Übersetzung</p>
                  <p className="text-2xl font-black text-primary">{w.de}</p>
                </>
              )}
            </div>
          </div>
          {flipped && (
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => { setScore(s => ({ ...s, wrong: s.wrong + 1 })); next(); }} className="flex-1 border-red-200 text-red-600 hover:bg-red-50 rounded-xl font-bold">✗ Noch nicht</Button>
              <Button onClick={() => { setScore(s => ({ ...s, correct: s.correct + 1 })); next(); }} className="flex-1 rounded-xl font-bold">✓ Gewusst!</Button>
            </div>
          )}
        </div>
      );
    }

    // de_en / en_de quiz
    const question = quizMode === "de_en" ? w.de : w.en;
    const answer = quizMode === "de_en" ? w.en : w.de;
    const isCorrect = checked && input.trim().toLowerCase() === answer.toLowerCase();
    const next = () => { setInput(""); setChecked(false); setQuizIndex(i => i + 1); };
    const done = quizIndex >= total;
    if (done) return <QuizDone score={score} total={total} onRestart={() => { setQuizIndex(0); setScore({ correct: 0, wrong: 0 }); }} onBack={() => setQuizMode(null)} />;

    return (
      <div className="p-4 max-w-lg mx-auto animate-fade-up">
        <QuizHeader label={quizMode === "de_en" ? "Deutsch → Englisch" : "Englisch → Deutsch"} index={quizIndex} total={total} onBack={() => setQuizMode(null)} />
        <div className="bg-card border-2 border-border rounded-2xl p-6 mb-4 text-center">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">
            {quizMode === "de_en" ? "Wie heißt das auf Englisch?" : "Wie heißt das auf Deutsch?"}
          </p>
          <p className="text-3xl font-black">{question}</p>
        </div>
        {!checked ? (
          <>
            <input
              autoFocus
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && input && setChecked(true) && setScore(s => ({ ...s, [input.trim().toLowerCase() === answer.toLowerCase() ? "correct" : "wrong"]: s[input.trim().toLowerCase() === answer.toLowerCase() ? "correct" : "wrong"] + 1 }))}
              placeholder="Antwort eingeben..."
              className="w-full px-4 py-3 rounded-xl border-2 border-border focus:border-primary outline-none text-base mb-3"
            />
            <Button className="w-full rounded-xl font-bold" disabled={!input} onClick={() => { setChecked(true); setScore(s => ({ ...s, [input.trim().toLowerCase() === answer.toLowerCase() ? "correct" : "wrong"]: s[input.trim().toLowerCase() === answer.toLowerCase() ? "correct" : "wrong"] + 1 })); }}>
              Prüfen
            </Button>
          </>
        ) : (
          <div className={cn("p-4 rounded-2xl border", isCorrect ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200")}>
            <p className={cn("font-black text-sm mb-1", isCorrect ? "text-green-700" : "text-red-700")}>
              {isCorrect ? "✓ Richtig!" : "✗ Nicht ganz"}
            </p>
            {!isCorrect && <p className="text-sm text-red-700 mb-1">Richtig: <strong>{answer}</strong></p>}
            <Button size="sm" onClick={next} className="mt-2 rounded-xl">Weiter →</Button>
          </div>
        )}
      </div>
    );
  }

  // ── Action selection screen ───────────────────────────────────────────────────
  return (
    <div className="p-4 max-w-lg mx-auto animate-fade-up">
      <div className="text-center mb-6 pt-4">
        <div className="text-4xl mb-2">🎉</div>
        <h2 className="text-xl font-black mb-1">{pairs.length} Wörter bereit!</h2>
        <p className="text-sm text-muted-foreground">„{setName}" – was möchtest du jetzt machen?</p>
      </div>

      {saved && (
        <div className="flex items-center gap-2 p-3 rounded-xl bg-green-50 border border-green-200 text-sm text-green-700 font-medium mb-4">
          <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
          Gespeichert unter „{setName}"
        </div>
      )}

      <div className="space-y-2.5 mb-6">
        {ACTIONS.map(a => (
          <button
            key={a.id}
            onClick={() => handleAction(a.id)}
            disabled={saving && a.id === "save"}
            className={cn(
              "w-full flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all active:scale-[0.98]",
              selectedAction === a.id ? a.activeColor : a.color
            )}
          >
            <span className="text-2xl">{a.icon}</span>
            <div className="flex-1">
              <p className="font-black text-sm">{a.label}</p>
              <p className="text-xs text-muted-foreground">{a.desc}</p>
            </div>
            {saving && a.id === "save" ? (
              <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
            ) : (
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

function QuizHeader({ label, index, total, onBack }) {
  return (
    <div className="mb-5">
      <div className="flex items-center justify-between mb-3">
        <Button variant="ghost" size="sm" onClick={onBack} className="text-muted-foreground gap-1">← Beenden</Button>
        <span className="text-sm text-muted-foreground font-medium">{index + 1} / {total}</span>
      </div>
      <p className="text-xs font-black text-primary uppercase tracking-wider mb-2">{label}</p>
      <div className="h-1.5 bg-secondary rounded-full">
        <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${(index / total) * 100}%` }} />
      </div>
    </div>
  );
}

function QuizDone({ score, total, onRestart, onBack }) {
  const pct = Math.round((score.correct / total) * 100);
  return (
    <div className="p-4 max-w-lg mx-auto text-center animate-pop-in pt-12">
      <div className="text-5xl mb-3">{pct >= 80 ? "🏆" : pct >= 50 ? "👍" : "💪"}</div>
      <h2 className="text-2xl font-black mb-1">{pct}%</h2>
      <p className="text-muted-foreground mb-1">{score.correct} von {total} richtig</p>
      <div className="flex gap-3 mt-6 justify-center">
        <Button variant="outline" onClick={onRestart} className="rounded-xl gap-2">Nochmal</Button>
        <Button onClick={onBack} className="rounded-xl gap-2">← Zurück</Button>
      </div>
    </div>
  );
}