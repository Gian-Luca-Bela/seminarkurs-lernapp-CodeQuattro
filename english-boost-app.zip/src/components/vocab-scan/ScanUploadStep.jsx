// ─── Step 1: Scan or Upload image(s) → OCR via LLM ───────────────────────────
import { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { extractVocabFromImages } from "@/lib/ai/generators";
import { Button } from "@/components/ui/button";
import { Camera, ImagePlus, X, Loader2, AlertCircle, RefreshCw } from "lucide-react";
import AILoadingState from "@/components/AILoadingState";
import { cn } from "@/lib/utils";

export default function ScanUploadStep({ onDone }) {
  const [images, setImages] = useState([]); // [{ file, previewUrl, uploadedUrl }]
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const fileInputRef = useRef();
  const cameraInputRef = useRef();

  const addFiles = (files) => {
    const newImgs = Array.from(files).map(file => ({
      file,
      previewUrl: URL.createObjectURL(file),
      uploadedUrl: null,
    }));
    setImages(prev => [...prev, ...newImgs].slice(0, 4)); // max 4 images
    setError(null);
  };

  const removeImage = (idx) => {
    setImages(prev => prev.filter((_, i) => i !== idx));
  };

  const analyze = async () => {
    if (images.length === 0) return;
    setLoading(true);
    setError(null);

    try {
      // Upload all images
      const uploaded = await Promise.all(
        images.map(async (img) => {
          if (img.uploadedUrl) return img.uploadedUrl;
          const { file_url } = await base44.integrations.Core.UploadFile({ file: img.file });
          return file_url;
        })
      );

      const result = await extractVocabFromImages(uploaded);

      if (!result?.pairs?.length) {
        setError("Keine Vokabelpaare erkannt. Bitte ein klareres Bild versuchen.");
        setLoading(false);
        return;
      }

      const needsClarify = !result.confident;

      // Map to en/de if confident
      let pairs;
      if (result.confident) {
        pairs = result.pairs.map(p => ({
          en: result.col1_language === "en" ? p.col1 : p.col2,
          de: result.col1_language === "de" ? p.col1 : p.col2,
        })).filter(p => p.en || p.de);
      } else {
        pairs = result.pairs.filter(p => p.col1 || p.col2);
      }

      onDone({
        pairs,
        needsClarify,
        col1Label: result.col1_sample_label,
        col2Label: result.col2_sample_label,
      });
    } catch (e) {
      setError("Analyse fehlgeschlagen. Bitte erneut versuchen.");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-4 max-w-lg mx-auto">
        <AILoadingState
          title="Vokabelliste wird erkannt"
          icon={<Camera className="w-8 h-8 text-white" />}
          steps={[
            `${images.length} ${images.length === 1 ? "Bild wird" : "Bilder werden"} hochgeladen…`,
            "Text wird erkannt (OCR)…",
            "Spalten werden analysiert…",
            "Vokabelpaare werden extrahiert…",
            "Ergebnis wird aufbereitet…",
          ]}
          contextLines={[`${images.length} ${images.length === 1 ? "Bild" : "Bilder"} ausgewählt`]}
        />
      </div>
    );
  }

  return (
    <div className="p-4 max-w-lg mx-auto animate-fade-up">
      <div className="text-center mb-6 pt-4">
        <div className="w-16 h-16 rounded-2xl bg-emerald-100 flex items-center justify-center mx-auto mb-3">
          <Camera className="w-8 h-8 text-emerald-600" />
        </div>
        <h2 className="text-xl font-black mb-1">Vokabelliste scannen</h2>
        <p className="text-sm text-muted-foreground">Mach ein Foto deiner Vokabelliste oder lade ein Bild hoch – die KI erkennt die Wörter automatisch.</p>
      </div>

      {/* Upload buttons */}
      <div className="grid grid-cols-2 gap-3 mb-5">
        <button
          onClick={() => cameraInputRef.current?.click()}
          className="flex flex-col items-center gap-2 p-5 rounded-2xl border-2 border-dashed border-emerald-300 bg-emerald-50 hover:bg-emerald-100 transition-all active:scale-95"
        >
          <Camera className="w-7 h-7 text-emerald-600" />
          <span className="text-sm font-bold text-emerald-700">Kamera</span>
          <span className="text-xs text-emerald-600/70">Foto aufnehmen</span>
        </button>
        <button
          onClick={() => fileInputRef.current?.click()}
          className="flex flex-col items-center gap-2 p-5 rounded-2xl border-2 border-dashed border-border hover:border-primary/40 hover:bg-primary/5 transition-all active:scale-95"
        >
          <ImagePlus className="w-7 h-7 text-muted-foreground" />
          <span className="text-sm font-bold">Galerie</span>
          <span className="text-xs text-muted-foreground">Bild auswählen</span>
        </button>
      </div>

      <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={e => addFiles(e.target.files)} />
      <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={e => addFiles(e.target.files)} />

      {/* Preview grid */}
      {images.length > 0 && (
        <div className="grid grid-cols-2 gap-2 mb-4">
          {images.map((img, i) => (
            <div key={i} className="relative rounded-xl overflow-hidden border border-border aspect-[4/3] bg-muted">
              <img src={img.previewUrl} alt="" className="w-full h-full object-cover" />
              <button
                onClick={() => removeImage(i)}
                className="absolute top-1.5 right-1.5 w-6 h-6 bg-black/60 rounded-full flex items-center justify-center hover:bg-black/80"
              >
                <X className="w-3.5 h-3.5 text-white" />
              </button>
              <div className="absolute bottom-1.5 left-1.5 bg-black/60 rounded-full px-2 py-0.5 text-white text-[10px] font-bold">
                Bild {i + 1}
              </div>
            </div>
          ))}
          {images.length < 4 && (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="aspect-[4/3] rounded-xl border-2 border-dashed border-border hover:border-primary/40 flex flex-col items-center justify-center gap-1 text-muted-foreground hover:text-primary transition-all"
            >
              <ImagePlus className="w-6 h-6" />
              <span className="text-xs">Weiteres Bild</span>
            </button>
          )}
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200 mb-4">
          <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      {/* Tip */}
      {images.length === 0 && (
        <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-sm text-blue-800 mb-4">
          <p className="font-bold mb-1">💡 Tipp für beste Ergebnisse</p>
          <ul className="space-y-1 text-xs text-blue-700 list-disc list-inside">
            <li>Gutes Licht, kein Schatten auf dem Text</li>
            <li>Seite möglichst gerade fotografieren</li>
            <li>Beide Spalten müssen sichtbar sein</li>
            <li>Bis zu 4 Bilder gleichzeitig möglich</li>
          </ul>
        </div>
      )}

      <Button
        className="w-full rounded-2xl font-bold h-12 text-base gap-2"
        disabled={images.length === 0}
        onClick={analyze}
      >
        <Camera className="w-5 h-5" />
        Jetzt erkennen ({images.length} {images.length === 1 ? "Bild" : "Bilder"})
      </Button>
    </div>
  );
}