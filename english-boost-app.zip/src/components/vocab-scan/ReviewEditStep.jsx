// ─── Step 2: Review & edit detected vocabulary pairs ─────────────────────────
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, ArrowLeftRight, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

export default function ReviewEditStep({ initialPairs, onDone }) {
  const [pairs, setPairs] = useState(
    initialPairs.map((p, i) => ({ ...p, id: i }))
  );
  const [setName, setSetName] = useState("");
  const [nextId, setNextId] = useState(initialPairs.length);

  const update = (id, field, value) => {
    setPairs(prev => prev.map(p => p.id === id ? { ...p, [field]: value } : p));
  };

  const remove = (id) => {
    setPairs(prev => prev.filter(p => p.id !== id));
  };

  const addRow = () => {
    setPairs(prev => [...prev, { id: nextId, en: "", de: "" }]);
    setNextId(n => n + 1);
  };

  const swapAll = () => {
    setPairs(prev => prev.map(p => ({ ...p, en: p.de, de: p.en })));
  };

  const validPairs = pairs.filter(p => p.en?.trim() && p.de?.trim());

  return (
    <div className="p-4 max-w-lg mx-auto animate-fade-up pb-32">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pt-2">
        <div>
          <h2 className="text-lg font-black">Überprüfen & bearbeiten</h2>
          <p className="text-xs text-muted-foreground">{pairs.length} erkannte Paare · {validPairs.length} vollständig</p>
        </div>
        <button
          onClick={swapAll}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-border text-xs font-bold hover:bg-muted transition-all"
        >
          <ArrowLeftRight className="w-3.5 h-3.5" />
          Spalten tauschen
        </button>
      </div>

      {/* Set name */}
      <div className="mb-4">
        <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1.5 block">
          Name des Vokabelsets
        </label>
        <input
          type="text"
          value={setName}
          onChange={e => setSetName(e.target.value)}
          placeholder="z. B. Unit 3 – Environment"
          className="w-full px-3 py-2.5 rounded-xl border border-border focus:border-primary outline-none text-sm bg-card transition-colors"
        />
      </div>

      {/* Column headers */}
      <div className="grid grid-cols-[1fr_1fr_32px] gap-2 mb-1 px-1">
        <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
          🇬🇧 Englisch
        </div>
        <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
          🇩🇪 Deutsch
        </div>
        <div />
      </div>

      {/* Pairs list */}
      <div className="space-y-2 mb-3">
        {pairs.map((p, idx) => (
          <div
            key={p.id}
            className={cn(
              "grid grid-cols-[1fr_1fr_32px] gap-2 items-center p-2 rounded-xl border transition-all",
              (!p.en?.trim() || !p.de?.trim()) ? "border-yellow-300 bg-yellow-50" : "border-border bg-card"
            )}
          >
            <input
              type="text"
              value={p.en}
              onChange={e => update(p.id, "en", e.target.value)}
              placeholder="English..."
              className="text-sm px-2.5 py-1.5 rounded-lg border border-border focus:border-primary outline-none bg-background w-full"
            />
            <input
              type="text"
              value={p.de}
              onChange={e => update(p.id, "de", e.target.value)}
              placeholder="Deutsch..."
              className="text-sm px-2.5 py-1.5 rounded-lg border border-border focus:border-primary outline-none bg-background w-full"
            />
            <button
              onClick={() => remove(p.id)}
              className="w-8 h-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-red-500 hover:bg-red-50 transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Add row */}
      <button
        onClick={addRow}
        className="w-full py-2.5 rounded-xl border-2 border-dashed border-border hover:border-primary/40 hover:bg-primary/5 text-sm text-muted-foreground hover:text-primary font-medium flex items-center justify-center gap-2 transition-all mb-6"
      >
        <Plus className="w-4 h-4" />
        Zeile hinzufügen
      </button>

      {/* Incomplete warning */}
      {pairs.length > validPairs.length && (
        <div className="p-3 rounded-xl bg-yellow-50 border border-yellow-200 text-xs text-yellow-800 mb-4">
          ⚠️ {pairs.length - validPairs.length} unvollständige Paare werden beim Speichern ignoriert.
        </div>
      )}

      {/* Submit */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background/95 backdrop-blur-sm border-t border-border">
        <Button
          className="w-full max-w-lg mx-auto flex rounded-2xl font-bold h-12 text-base gap-2"
          disabled={validPairs.length === 0}
          onClick={() => onDone(validPairs, setName || `Vokabelset ${new Date().toLocaleDateString("de-DE")}`)}
        >
          <CheckCircle2 className="w-5 h-5" />
          {validPairs.length} Paare bestätigen →
        </Button>
      </div>
    </div>
  );
}