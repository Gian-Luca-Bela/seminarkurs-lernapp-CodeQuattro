/**
 * Mascot "Leo" – reusable widget for tips, celebrations, and feedback.
 * Variants: tip | celebrate | warn
 */
import { cn } from "@/lib/utils";

const CONFIG = {
  tip: {
    bg: "bg-gradient-to-br from-amber-50 to-yellow-50",
    border: "border-amber-200",
    textHead: "text-amber-700",
    textBody: "text-amber-800",
    emoji: "🦉",
  },
  celebrate: {
    bg: "bg-gradient-to-br from-green-50 to-emerald-50",
    border: "border-green-200",
    textHead: "text-green-700",
    textBody: "text-green-800",
    emoji: "🎉",
  },
  warn: {
    bg: "bg-gradient-to-br from-orange-50 to-red-50",
    border: "border-orange-200",
    textHead: "text-orange-700",
    textBody: "text-orange-800",
    emoji: "⚠️",
  },
  route: {
    bg: "bg-gradient-to-br from-primary/8 to-brand-blue-light/60",
    border: "border-primary/20",
    textHead: "text-primary",
    textBody: "text-foreground",
    emoji: "🗺️",
  },
};

export default function Mascot({ variant = "tip", title, message, className }) {
  const c = CONFIG[variant] || CONFIG.tip;

  return (
    <div className={cn("flex items-start gap-3 rounded-2xl border p-4", c.bg, c.border, className)}>
      <div className="text-2xl flex-shrink-0 mt-0.5">{c.emoji}</div>
      <div>
        {title && (
          <p className={cn("text-xs font-black uppercase tracking-wider mb-1", c.textHead)}>{title}</p>
        )}
        <p className={cn("text-sm leading-relaxed font-medium", c.textBody)}>{message}</p>
      </div>
    </div>
  );
}