import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { generateExamPlan } from "@/lib/ai/generators";
import { cn, getDaysUntil, formatDate } from "@/lib/utils";
import {
  ArrowLeft, Sparkles, Clock, BookOpen, Zap, AlertTriangle,
  CheckCircle2, Brain, Target, Calendar, RefreshCw,
  ChevronDown, ChevronUp, Trophy, Play, Flame, Star
} from "lucide-react";
import AILoadingState from "@/components/AILoadingState";
import TopicPracticeSession from "@/components/exams/TopicPracticeSession";

const PHASE_CONFIG = {
  foundation:       { label: "Grundlagen aufbauen",         color: "bg-blue-50 border-blue-200 text-blue-800",     dot: "bg-blue-400",    icon: "🏗️" },
  grammar_focus:    { label: "Grammatik-Fokus",              color: "bg-violet-50 border-violet-200 text-violet-800", dot: "bg-violet-400",  icon: "📚" },
  vocab_focus:      { label: "Vokabel-Fokus",                color: "bg-emerald-50 border-emerald-200 text-emerald-800", dot: "bg-emerald-400", icon: "💬" },
  writing_practice: { label: "Schreiben üben",               color: "bg-orange-50 border-orange-200 text-orange-800", dot: "bg-orange-400",  icon: "✍️" },
  weak_area:        { label: "Schwächen gezielt stärken",    color: "bg-red-50 border-red-200 text-red-700",        dot: "bg-red-400",     icon: "🎯" },
  mixed_review:     { label: "Gemischte Wiederholung",       color: "bg-yellow-50 border-yellow-200 text-yellow-800", dot: "bg-yellow-400",  icon: "🔄" },
  mini_simulation:  { label: "Mini-Simulation",              color: "bg-purple-50 border-purple-200 text-purple-800", dot: "bg-purple-400",  icon: "🎲" },
  final_revision:   { label: "Letzte Revision",              color: "bg-green-50 border-green-200 text-green-800",  dot: "bg-green-500",   icon: "✅" },
};

const DAILY_TIMES = [10, 15, 20, 30, 45, 60];

// ── Urgency helper ────────────────────────────────────────────────────────────
function urgencyLabel(days) {
  if (days <= 1) return { label: "Heute / Morgen!", cls: "bg-red-500 text-white" };
  if (days <= 3) return { label: `${days} Tage`, cls: "bg-red-100 text-red-700" };
  if (days <= 7) return { label: `${days} Tage`, cls: "bg-orange-100 text-orange-700" };
  return { label: `${days} Tage`, cls: "bg-secondary text-secondary-foreground" };
}

export default function ExamPrepPlan({ exam: examProp, profile, onBack }) {
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expandedDay, setExpandedDay] = useState(0);
  const [practiceDay, setPracticeDay] = useState(null);
  const [dailyMinutes, setDailyMinutes] = useState(examProp.daily_minutes || 20);
  const [savedPlanId, setSavedPlanId] = useState(null);
  const queryClient = useQueryClient();

  const exam = { ...examProp, daily_minutes: dailyMinutes };
  const daysLeft = getDaysUntil(exam.exam_date);
  const totalStudyMinutes = daysLeft * dailyMinutes;
  const urgency = urgencyLabel(daysLeft);

  // Load existing saved plan for this exam
  const { data: savedPlans, isLoading: isLoadingSaved } = useQuery({
    queryKey: ["study-plan", examProp.id, profile?.user_email],
    queryFn: () => base44.entities.StudyPlan.filter({ exam_id: examProp.id, user_email: profile?.user_email }),
    enabled: !!examProp.id && !!profile?.user_email,
  });

  // When saved plan is loaded, restore it
  useEffect(() => {
    if (savedPlans && savedPlans.length > 0) {
      const existing = savedPlans[0];
      if (existing.daily_tasks) {
        // Reconstruct plan object from saved daily_tasks
        setPlan({
          overview: existing.title,
          daily_plan: existing.daily_tasks,
          key_focus_areas: [],
          encouragement: null,
        });
        setSavedPlanId(existing.id);
      }
    }
  }, [savedPlans]);

  // ── "Today" detection ────────────────────────────────────────────────────────
  // The plan is generated from today, so day_number 1 = today
  const todayDay = plan?.daily_plan?.[0];

  if (practiceDay !== null) {
    return (
      <TopicPracticeSession
        exam={exam}
        dayInfo={practiceDay}
        phase={practiceDay?.phase}
        onBack={() => setPracticeDay(null)}
      />
    );
  }

  // ── Save plan to DB ───────────────────────────────────────────────────────────
  const savePlanToDB = async (planData) => {
    const payload = {
      user_email: profile?.user_email,
      exam_id: examProp.id,
      title: planData.overview || `Plan: ${exam.title}`,
      daily_tasks: planData.daily_plan || [],
      is_active: true,
    };
    if (savedPlanId) {
      await base44.entities.StudyPlan.update(savedPlanId, payload);
    } else {
      const created = await base44.entities.StudyPlan.create(payload);
      setSavedPlanId(created.id);
    }
    queryClient.invalidateQueries({ queryKey: ["study-plan", examProp.id] });
  };

  // ── Generate ─────────────────────────────────────────────────────────────────
  const generatePlan = async () => {
    setLoading(true);
    setPlan(null);

    try {
      const result = await generateExamPlan({ exam, profile, daysLeft, dailyMinutes });
      setPlan(result);
      setExpandedDay(0);
      await savePlanToDB(result);
    } catch {
      // Minimal fallback
      const days = Math.max(1, daysLeft);
      const phases = days <= 2 ? ["mixed_review","final_revision"]
        : days <= 4 ? ["foundation","weak_area","mixed_review","final_revision"]
        : ["foundation","grammar_focus","vocab_focus","writing_practice","weak_area","mixed_review","mini_simulation","final_revision"];
      const buildTasks = (phaseKey, i) => {
        const isLast = i === days - 1;
        const g = exam.grammar_topics?.[0] || "Grammatik";
        const v = exam.vocab_themes?.[0] || "Vokabeln";
        const w = exam.writing_formats?.[0] || "Blog Post";
        const base = Math.round(dailyMinutes / 4);
        if (isLast) return [
          { title: "Alles überblicken", description: "Alle Grammatikregeln nochmal durchgehen", duration_minutes: Math.round(dailyMinutes * 0.3), type: "grammar" },
          { title: "Vokabel-Schnelltest", description: "Alle Vokabeln testen – nur die schwierigen nochmal", duration_minutes: Math.round(dailyMinutes * 0.3), type: "vocabulary" },
          { title: "Entspannen", description: "Kein neues Material – ausruhen und selbstbewusst sein!", duration_minutes: Math.round(dailyMinutes * 0.4), type: "other" },
        ];
        if (phaseKey === "grammar_focus") return [
          { title: `Übungen: ${g}`, description: `Lückentext und Satzumformung zu ${g}`, duration_minutes: base * 2, type: "grammar" },
          { title: "Fehlerkorrektur", description: "Typische Fehler erkennen und korrigieren", duration_minutes: base, type: "grammar" },
          { title: "Vokabeln", description: `Vokabeln zu ${v} wiederholen`, duration_minutes: base, type: "vocabulary" },
        ];
        if (phaseKey === "vocab_focus") return [
          { title: "Karteikarten", description: `Alle Vokabeln zu ${v} wiederholen`, duration_minutes: base, type: "vocabulary" },
          { title: "Vokabeln im Kontext", description: "Vokabeln in eigenen Sätzen verwenden", duration_minutes: base, type: "vocabulary" },
          { title: "Grammatik-Auffrischung", description: `Kurze Wiederholung: ${g}`, duration_minutes: base, type: "grammar" },
          { title: "Leseverstehen", description: "Einen kurzen Text lesen und Fragen beantworten", duration_minutes: base, type: "reading" },
        ];
        if (phaseKey === "writing_practice") return [
          { title: `Schreiben: ${w}`, description: `Übe das Format: ${w}. Struktur, Phrasen, Länge.`, duration_minutes: Math.round(dailyMinutes * 0.5), type: "writing" },
          { title: "Nützliche Phrasen", description: "Wichtige Formulierungen für den Aufsatz lernen", duration_minutes: Math.round(dailyMinutes * 0.2), type: "writing" },
          { title: "Grammatik im Text", description: "Einen Aufsatz auf Grammatikfehler prüfen", duration_minutes: Math.round(dailyMinutes * 0.3), type: "grammar" },
        ];
        if (phaseKey === "mixed_review") return [
          { title: "Grammatik Mix", description: `Gemischte Übungen: ${g}`, duration_minutes: base, type: "grammar" },
          { title: "Vokabel-Test", description: `${v} – Selbsttest`, duration_minutes: base, type: "vocabulary" },
          { title: "Leseverstehen", description: "Kurzer Text mit Fragen", duration_minutes: base, type: "reading" },
          { title: "Schreiben", description: `Kurzen ${w} verfassen`, duration_minutes: base, type: "writing" },
        ];
        if (phaseKey === "mini_simulation") return [
          { title: "Leseverstehen", description: "Text lesen und Fragen auf Zeit beantworten", duration_minutes: Math.round(dailyMinutes * 0.25), type: "reading" },
          { title: "Grammatik-Test", description: "Gemischter Grammatiktest", duration_minutes: Math.round(dailyMinutes * 0.25), type: "grammar" },
          { title: `Schreiben: ${w}`, description: "Vollständigen Text schreiben", duration_minutes: Math.round(dailyMinutes * 0.35), type: "writing" },
          { title: "Selbst-Korrektur", description: "Eigenen Text nochmal überprüfen", duration_minutes: Math.round(dailyMinutes * 0.15), type: "other" },
        ];
        // default / foundation / weak_area
        return [
          { title: `Grammatik: ${g}`, description: `Grundlagen und Übungen zu ${g}`, duration_minutes: base, type: "grammar" },
          { title: `Vokabeln: ${v}`, description: "Karteikarten und Kontext-Übungen", duration_minutes: base, type: "vocabulary" },
          { title: "Leseverstehen", description: "Englischen Text lesen und verstehen", duration_minutes: base, type: "reading" },
          { title: "Notizen machen", description: "Lernzettel anlegen / ergänzen", duration_minutes: base, type: "other" },
        ];
      };
      const fallbackPlan = {
        overview: `${daysLeft} Tage bis "${exam.title}". Tägliche Lernzeit: ${dailyMinutes} Min. – Multi-Skill-Vorbereitung mit Grammatik, Vokabeln, Leseverstehen und Schreiben.`,
        key_focus_areas: [...(exam.grammar_topics||[]).slice(0,3), ...(exam.vocab_themes||[]).slice(0,2), ...(exam.writing_formats||[]).slice(0,1)],
        daily_plan: Array.from({ length: Math.min(days, 10) }, (_, i) => {
          const phase = phases[Math.min(i, phases.length - 1)];
          return {
            day_number: i + 1,
            date_label: `Tag ${i + 1}`,
            phase,
            daily_goal: i === days - 1 ? "Letzte Revision – alles nochmal überblicken!" :
              phase === "writing_practice" ? `Schreiben üben: ${exam.writing_formats?.[0] || "Aufsatz"}` :
              phase === "vocab_focus" ? `Vokabel-Fokus: ${exam.vocab_themes?.[0] || "alle Themen"}` :
              phase === "grammar_focus" ? `Grammatik-Fokus: ${exam.grammar_topics?.[0] || "alle Themen"}` :
              `Gemischte Vorbereitung: Grammatik + Vokabeln + Leseverstehen`,
            tasks: buildTasks(phase, i),
            tip: i === days - 1 ? "Keine neuen Themen mehr – ruhig bleiben!" :
              i % 3 === 0 ? "Nach 20 Min eine kurze Pause einlegen." :
              "Laut vorlesen hilft beim Merken!"
          };
        }),
        weak_area_strategy: exam.weak_areas?.length ? `Fokus auf: ${exam.weak_areas.join(", ")} – nutze den KI-Übungsmodus für gezielte Aufgaben.` : "Nutze den Auto-Lernmodus für adaptive Übungen in deinen Schwachbereichen.",
        last_day_advice: "Nur leichte Wiederholung am Abend vorher. Gut schlafen ist wichtiger als noch stundenlang büffeln.",
        encouragement: "Du hast einen Plan – das ist schon die halbe Miete. 💪"
      };
      setPlan(fallbackPlan);
      await savePlanToDB(fallbackPlan);
    }
    setLoading(false);
  };

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-in">
      <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground mb-5 group">
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        Zurück zu meinen Tests
      </button>

      {/* ── Exam header banner ─────────────────────────────────────────────── */}
      <div className="rounded-2xl brand-gradient p-5 text-white mb-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-white/70 text-xs font-bold uppercase tracking-wider mb-1">KI-Vorbereitungsplan</p>
            <h1 className="text-xl font-black leading-snug">{exam.title}</h1>
            <p className="text-white/80 text-sm mt-1">{formatDate(exam.exam_date)}</p>
          </div>
          <div className={cn("rounded-xl px-3 py-2 text-center font-black flex-shrink-0", daysLeft <= 3 ? "bg-red-500/80 text-white" : "bg-white/20 text-white")}>
            <div className="text-3xl leading-none">{daysLeft}</div>
            <div className="text-[11px] opacity-80">Tage</div>
          </div>
        </div>
        <div className="flex flex-wrap gap-1.5 mt-3">
          {exam.grammar_topics?.slice(0, 3).map(t => <span key={t} className="text-xs bg-white/20 px-2 py-0.5 rounded-full">{t}</span>)}
          {exam.vocab_themes?.slice(0, 2).map(t => <span key={t} className="text-xs bg-white/20 px-2 py-0.5 rounded-full">{t}</span>)}
          {exam.writing_formats?.slice(0, 1).map(t => <span key={t} className="text-xs bg-white/20 px-2 py-0.5 rounded-full">{t}</span>)}
        </div>
      </div>

      {/* ── Loading saved plan ───────────────────────────────────────────────── */}
      {isLoadingSaved && !plan && !loading && (
        <div className="flex items-center justify-center py-12">
          <div className="w-6 h-6 border-4 border-border border-t-primary rounded-full animate-spin" />
          <span className="ml-3 text-sm text-muted-foreground">Gespeicherter Plan wird geladen…</span>
        </div>
      )}

      {/* ── Planning params (editable before generating) ───────────────────── */}
      {!plan && !loading && !isLoadingSaved && (
        <Card className="mb-5">
          <CardContent className="p-4 space-y-4">
            <h3 className="font-black text-sm flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />Lernplan konfigurieren
            </h3>

            {/* Days & time summary */}
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-secondary rounded-xl p-3 text-center">
                <div className="text-xl font-black">{daysLeft}</div>
                <div className="text-xs text-muted-foreground mt-0.5">Tage bis Test</div>
              </div>
              <div className="bg-secondary rounded-xl p-3 text-center">
                <div className="text-xl font-black">{dailyMinutes}</div>
                <div className="text-xs text-muted-foreground mt-0.5">Min / Tag</div>
              </div>
              <div className="bg-secondary rounded-xl p-3 text-center">
                <div className="text-xl font-black">{Math.round(totalStudyMinutes / 60 * 10) / 10}</div>
                <div className="text-xs text-muted-foreground mt-0.5">Stunden total</div>
              </div>
            </div>

            {/* Adjust daily minutes */}
            <div>
              <p className="text-xs font-bold text-muted-foreground mb-2">Tägliche Lernzeit anpassen:</p>
              <div className="flex flex-wrap gap-2">
                {DAILY_TIMES.map(t => (
                  <button key={t} onClick={() => setDailyMinutes(t)}
                    className={cn("px-3 py-1.5 rounded-xl text-sm border-2 font-bold transition-all",
                      dailyMinutes === t ? "border-primary bg-primary text-white" : "border-border hover:border-primary/40 bg-card")}>
                    {t} Min
                  </button>
                ))}
              </div>
            </div>

            {/* Topics recap */}
            {(exam.grammar_topics?.length > 0 || exam.vocab_themes?.length > 0 || exam.weak_areas?.length > 0) && (
              <div className="pt-1 border-t border-border space-y-1.5">
                {exam.grammar_topics?.length > 0 && (
                  <p className="text-xs text-muted-foreground"><span className="font-bold text-foreground">Grammatik:</span> {exam.grammar_topics.join(", ")}</p>
                )}
                {exam.vocab_themes?.length > 0 && (
                  <p className="text-xs text-muted-foreground"><span className="font-bold text-foreground">Vokabeln:</span> {exam.vocab_themes.join(", ")}</p>
                )}
                {exam.weak_areas?.length > 0 && (
                  <p className="text-xs text-red-600"><span className="font-bold">⚠️ Schwächen:</span> {exam.weak_areas.join(", ")}</p>
                )}
              </div>
            )}

            <Button onClick={generatePlan} size="lg" className="w-full brand-gradient text-white border-0 font-black gap-2">
              <Sparkles className="w-4 h-4" />
              Plan für {daysLeft} Tage · {dailyMinutes} Min/Tag generieren
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ── Loading ──────────────────────────────────────────────────────────── */}
      {loading && (
        <AILoadingState
          title="Vorbereitungsplan wird erstellt"
          steps={[
            "Prüfungsthemen werden analysiert…",
            "Schwache Bereiche werden berücksichtigt…",
            "Tagesplan wird strukturiert…",
            "Lernphasen werden verteilt…",
            "Plan wird finalisiert…",
          ]}
          contextLines={[
            `${daysLeft} Tage bis zum Test`,
            `${dailyMinutes} Min / Tag`,
            exam.grammar_topics?.length ? `${exam.grammar_topics.length} Grammatikthemen` : null,
            exam.vocab_themes?.length ? `${exam.vocab_themes.length} Vokabelthemen` : null,
          ].filter(Boolean)}
        />
      )}

      {/* ── Plan ──────────────────────────────────────────────────────────────── */}
      {plan && (
        <div className="space-y-4">
          {/* Overview */}
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-4">
              <p className="text-sm leading-relaxed">{plan.overview}</p>
              {plan.exam_profile && <p className="text-xs text-muted-foreground mt-2 italic">{plan.exam_profile}</p>}
            </CardContent>
          </Card>

          {/* Stats row */}
          <div className="grid grid-cols-4 gap-2">
            <div className="bg-card border border-border rounded-xl p-3 text-center">
              <Calendar className="w-4 h-4 text-primary mx-auto mb-1" />
              <div className="text-sm font-black">{plan.daily_plan?.length || daysLeft}</div>
              <div className="text-xs text-muted-foreground">Tage</div>
            </div>
            <div className="bg-card border border-border rounded-xl p-3 text-center">
              <Clock className="w-4 h-4 text-violet-500 mx-auto mb-1" />
              <div className="text-sm font-black">{dailyMinutes}</div>
              <div className="text-xs text-muted-foreground">Min/Tag</div>
            </div>
            <div className="bg-card border border-border rounded-xl p-3 text-center">
              <Flame className="w-4 h-4 text-orange-500 mx-auto mb-1" />
              <div className="text-sm font-black">{Math.round(totalStudyMinutes / 60 * 10) / 10}h</div>
              <div className="text-xs text-muted-foreground">Gesamt</div>
            </div>
            <div className="bg-card border border-border rounded-xl p-3 text-center">
              <AlertTriangle className="w-4 h-4 text-red-500 mx-auto mb-1" />
              <div className="text-sm font-black">{exam.weak_areas?.length || 0}</div>
              <div className="text-xs text-muted-foreground">Schwächen</div>
            </div>
          </div>

          {/* Key focus areas */}
          {plan.key_focus_areas?.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <h3 className="font-black text-sm mb-2 flex items-center gap-2">
                  <Target className="w-4 h-4 text-primary" />Schwerpunkte dieser Vorbereitung
                </h3>
                <div className="flex flex-wrap gap-2">
                  {plan.key_focus_areas.map((t, i) => (
                    <Badge key={i} className="bg-primary/10 text-primary border-0 text-xs font-bold">{t}</Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* TODAY highlight */}
          {todayDay && (
            <Card className={cn("border-2", PHASE_CONFIG[todayDay.phase]?.color || "border-primary/30 bg-primary/5")}>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Star className="w-4 h-4 text-amber-500" />
                  <span className="font-black text-sm">Aufgabe für heute</span>
                  <Badge className="bg-amber-100 text-amber-700 border-0 text-[10px] font-bold ml-auto">{PHASE_CONFIG[todayDay.phase]?.icon} {PHASE_CONFIG[todayDay.phase]?.label}</Badge>
                </div>
                <p className="text-sm font-bold mb-3">{todayDay.daily_goal}</p>
                <div className="space-y-1.5 mb-3">
                  {todayDay.tasks?.map((task, j) => (
                    <div key={j} className="flex items-center gap-2 text-xs">
                      <div className="w-4 h-4 rounded-full bg-current/10 flex items-center justify-center flex-shrink-0">
                        <span className="font-black" style={{ fontSize: 9 }}>{j + 1}</span>
                      </div>
                      <span className="font-medium flex-1">{task.title}</span>
                      <span className="text-muted-foreground flex-shrink-0 flex items-center gap-0.5">
                        <Clock className="w-3 h-3" />{task.duration_minutes} Min
                      </span>
                    </div>
                  ))}
                </div>
                <Button onClick={() => setPracticeDay(todayDay)} size="sm" className="w-full brand-gradient text-white border-0 font-bold gap-1.5">
                  <Play className="w-3.5 h-3.5" />Heutige Aufgaben jetzt üben
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Phase timeline bar */}
          {plan.daily_plan?.length > 1 && (
            <div>
              <p className="text-xs font-black text-muted-foreground uppercase tracking-wider mb-2">Phasen-Übersicht</p>
              <div className="flex rounded-xl overflow-hidden h-5 gap-0.5">
                {plan.daily_plan.map((day, i) => {
                  const cfg = PHASE_CONFIG[day.phase] || PHASE_CONFIG.mixed_review;
                  return (
                    <div
                      key={i}
                      title={`Tag ${i + 1}: ${cfg.label}`}
                      className={cn("flex-1 flex items-center justify-center", cfg.dot)}
                    >
                      {plan.daily_plan.length <= 14 && (
                        <span className="text-[9px] text-white font-black">{i + 1}</span>
                      )}
                    </div>
                  );
                })}
              </div>
              <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2">
                {Object.entries(PHASE_CONFIG).filter(([key]) => plan.daily_plan.some(d => d.phase === key)).map(([key, cfg]) => (
                  <span key={key} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                    <span className={cn("w-2.5 h-2.5 rounded-sm inline-block", cfg.dot)} />
                    {cfg.icon} {cfg.label}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Daily plan */}
          <div>
            <h3 className="font-black text-sm uppercase tracking-wider mb-3 flex items-center gap-2">
              <Calendar className="w-4 h-4" />Tagesplan
            </h3>
            <div className="space-y-2">
              {plan.daily_plan?.map((day, i) => {
                const phaseConfig = PHASE_CONFIG[day.phase] || PHASE_CONFIG.mixed_review;
                const isExpanded = expandedDay === i;
                const isToday = i === 0;
                const totalMins = day.tasks?.reduce((s, t) => s + (t.duration_minutes || 0), 0) || dailyMinutes;
                const isFinal = day.phase === "final_revision" || day.is_final_revision;

                return (
                  <Card key={i} className={cn("border-2 transition-all",
                    isToday && !isExpanded ? "border-primary/40 bg-primary/5" :
                    isExpanded ? phaseConfig.color : "border-border bg-card")}>
                    <CardContent className="p-0">
                      <button
                        onClick={() => setExpandedDay(isExpanded ? -1 : i)}
                        className="w-full p-4 text-left flex items-center gap-3"
                      >
                        <div className={cn("w-9 h-9 rounded-xl flex items-center justify-center text-base flex-shrink-0 font-black border",
                          isToday ? "brand-gradient text-white border-primary" :
                          isExpanded ? "bg-white/80 border-current" : "bg-secondary border-border")}>
                          {isFinal ? "✅" : i + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-black text-sm">{day.date_label || `Tag ${day.day_number}`}</span>
                            {isToday && <Badge className="bg-amber-100 text-amber-700 border-0 text-[10px] font-bold">Heute</Badge>}
                            <span className="text-xs">{phaseConfig.icon} {phaseConfig.label}</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{day.daily_goal}</p>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" />{totalMins} Min
                          </span>
                          {isExpanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                        </div>
                      </button>

                      {isExpanded && (
                        <div className="px-4 pb-4 space-y-3">
                          <div className="p-3 rounded-xl bg-white/60 border border-current/10">
                            <p className="text-sm font-bold">{day.daily_goal}</p>
                          </div>

                          {/* Task list with time bar */}
                          <div className="space-y-2">
                            {day.tasks?.map((task, j) => {
                              const pct = Math.round(((task.duration_minutes || 0) / totalMins) * 100);
                              return (
                                <div key={j} className="p-3 rounded-xl bg-white/50 border border-current/10">
                                  <div className="flex items-start gap-3">
                                    <div className="w-6 h-6 rounded-full bg-current/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                                      <span className="text-[10px] font-black">{j + 1}</span>
                                    </div>
                                    <div className="flex-1">
                                      <div className="flex items-center justify-between gap-2">
                                        <p className="font-bold text-sm">{task.title}</p>
                                        <span className="text-xs opacity-70 flex-shrink-0 flex items-center gap-0.5">
                                          <Clock className="w-3 h-3" />{task.duration_minutes} Min
                                        </span>
                                      </div>
                                      <p className="text-xs opacity-75 mt-0.5">{task.description}</p>
                                      <div className="mt-1.5 h-1 bg-current/10 rounded-full overflow-hidden">
                                        <div className="h-full bg-current/30 rounded-full" style={{ width: `${pct}%` }} />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>

                          {day.tip && (
                            <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-50 border border-amber-200">
                              <span className="text-base flex-shrink-0">💡</span>
                              <p className="text-xs text-amber-800">{day.tip}</p>
                            </div>
                          )}
                          <Button
                            onClick={() => setPracticeDay(day)}
                            className="w-full gap-2 font-bold brand-gradient text-white border-0 mt-1"
                            size="sm"
                          >
                            <Play className="w-3.5 h-3.5" />Aufgaben zu diesem Tag üben
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Weak area strategy */}
          {plan.weak_area_strategy && (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-4">
                <h3 className="font-black text-sm text-red-800 mb-2 flex items-center gap-2">
                  <Zap className="w-4 h-4" />Strategie für deine Schwächen
                </h3>
                <p className="text-sm text-red-800">{plan.weak_area_strategy}</p>
              </CardContent>
            </Card>
          )}

          {/* Last day advice */}
          {plan.last_day_advice && (
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="p-4">
                <h3 className="font-black text-sm text-yellow-800 mb-2">⚡ Am Tag vor dem Test</h3>
                <p className="text-sm text-yellow-800">{plan.last_day_advice}</p>
              </CardContent>
            </Card>
          )}

          {/* Encouragement */}
          {plan.encouragement && (
            <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
              <CardContent className="p-4 flex gap-3 items-start">
                <span className="text-2xl">🦉</span>
                <p className="text-sm text-amber-800 italic leading-relaxed">{plan.encouragement}</p>
              </CardContent>
            </Card>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <Button variant="outline" onClick={async () => {
              if (savedPlanId) {
                await base44.entities.StudyPlan.delete(savedPlanId);
                setSavedPlanId(null);
                queryClient.invalidateQueries({ queryKey: ["study-plan", examProp.id] });
              }
              setPlan(null);
              setExpandedDay(-1);
            }} className="flex-1 gap-2">
              <RefreshCw className="w-4 h-4" />Neu konfigurieren
            </Button>
            <Button onClick={generatePlan} disabled={loading} className="flex-1 gap-2 brand-gradient text-white border-0 font-bold">
              <Sparkles className="w-4 h-4" />Plan neu generieren
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}