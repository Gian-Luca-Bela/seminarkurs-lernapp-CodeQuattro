/**
 * TopicPracticeSession – full multi-skill exam preparation session.
 * Generates a real mixed set of exercises covering grammar, vocabulary,
 * reading, writing, listening, mediation — not just grammar.
 */
import { useState, useRef, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";
import { generateTopicExercises } from "@/lib/ai/generators";
import { cn } from "@/lib/utils";
import {
  ArrowLeft, Sparkles, CheckCircle2, XCircle, ArrowRight,
  Trophy, RotateCcw, ChevronRight, Upload, X, BookOpen,
  PenLine, Headphones, Globe, MessageSquare, GraduationCap, Play, Pause, Volume2, SkipForward
} from "lucide-react";
import AILoadingState from "@/components/AILoadingState";

// ── helpers ──────────────────────────────────────────────────────────────────
const normalize = (s = "") => s.trim().toLowerCase().replace(/[''`]/g, "'").replace(/\s+/g, " ");

function scoreColor(pct) {
  if (pct >= 80) return "text-green-700";
  if (pct >= 50) return "text-yellow-700";
  return "text-red-700";
}

function playListeningAudio(text, onPlayStart, onPlayEnd) {
  try {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = 0.95;
    utterance.pitch = 1;
    utterance.volume = 1;
    
    // Select a natural-sounding voice if available
    const voices = window.speechSynthesis.getVoices();
    const englishVoice = voices.find(v => v.lang.startsWith('en-') && v.name.includes('Google')) || 
                         voices.find(v => v.lang.startsWith('en-')) ||
                         voices[0];
    if (englishVoice) utterance.voice = englishVoice;
    
    utterance.onstart = onPlayStart;
    utterance.onend = onPlayEnd;
    
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.error('Audio playback failed:', err);
    throw err;
  }
}

const SKILL_CONFIG = {
  grammar:    { label: "Grammatik",       icon: <GraduationCap className="w-3.5 h-3.5" />, color: "bg-violet-100 text-violet-800 border-violet-200" },
  vocabulary: { label: "Vokabeln",        icon: <BookOpen className="w-3.5 h-3.5" />,       color: "bg-emerald-100 text-emerald-800 border-emerald-200" },
  reading:    { label: "Leseverstehen",   icon: <BookOpen className="w-3.5 h-3.5" />,       color: "bg-blue-100 text-blue-800 border-blue-200" },
  writing:    { label: "Schreiben",       icon: <PenLine className="w-3.5 h-3.5" />,        color: "bg-orange-100 text-orange-800 border-orange-200" },
  listening:  { label: "Hörverstehen",   icon: <Headphones className="w-3.5 h-3.5" />,     color: "bg-pink-100 text-pink-800 border-pink-200" },
  mediation:  { label: "Sprachmittlung", icon: <Globe className="w-3.5 h-3.5" />,          color: "bg-cyan-100 text-cyan-800 border-cyan-200" },
  speaking:   { label: "Sprechen",        icon: <MessageSquare className="w-3.5 h-3.5" />,  color: "bg-yellow-100 text-yellow-800 border-yellow-200" },
};

// Detect skill from topic string or exercise type
function detectSkill(ex) {
  if (!ex) return null;
  const topic = (ex.topic || "").toLowerCase();
  const type  = (ex.type  || "").toLowerCase();
  if (topic.includes("lese") || topic.includes("reading")) return "reading";
  if (topic.includes("hör") || topic.includes("listening") || topic.includes("transkript")) return "listening";
  if (topic.includes("schreib") || topic.includes("writing") || type === "open_question") return "writing";
  if (topic.includes("sprach") || topic.includes("mediation") || topic.includes("mittlung")) return "mediation";
  if (topic.includes("vokab") || topic.includes("vocab") || topic.includes("wort")) return "vocabulary";
  if (topic.includes("sprechen") || topic.includes("speaking")) return "speaking";
  return "grammar";
}

// Skill section selector options
const SKILL_SECTIONS = [
  { key: "all",       label: "Gemischt (alle Skills)", icon: "🎯" },
  { key: "grammar",   label: "Grammatik",              icon: "📚" },
  { key: "vocabulary",label: "Vokabeln",               icon: "💬" },
  { key: "reading",   label: "Leseverstehen",          icon: "📖" },
  { key: "writing",   label: "Schreiben",              icon: "✍️" },
  { key: "listening", label: "Hörverstehen",          icon: "🎧" },
  { key: "mediation", label: "Sprachmittlung",        icon: "🌍" },
];

const TASK_COUNTS = [6, 10, 15, 20];

// ── Main component ────────────────────────────────────────────────────────────
export default function TopicPracticeSession({ exam, dayInfo, phase, onBack }) {
  const [step, setStep] = useState("config"); // config | loading | quiz | results
  const [exercises, setExercises] = useState([]);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [userText, setUserText] = useState("");
  const [revealed, setRevealed] = useState(false);
  const [customTopics, setCustomTopics] = useState("");
  const [uploadedText, setUploadedText] = useState("");
  const [uploadName, setUploadName] = useState("");
  const [skillFocus, setSkillFocus] = useState("all");
  const [taskCount, setTaskCount] = useState(10);
  const [listeningPlaying, setListeningPlaying] = useState(false);
  const [listeningSkipped, setListeningSkipped] = useState(false);
  const [evaluatingWriting, setEvaluatingWriting] = useState(false);
  const fileRef = useRef();
  const audioRef = useRef();

  const grammarTopics  = exam.grammar_topics  || [];
  const vocabThemes    = exam.vocab_themes    || [];
  const writingFormats = exam.writing_formats || [];
  const allTopics = [...grammarTopics, ...vocabThemes, ...writingFormats];

  // ── File upload ────────────────────────────────────────────────────────────
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadName(file.name);
    const text = await file.text();
    setUploadedText(text.slice(0, 4000));
  };

  // ── Generate exercises ─────────────────────────────────────────────────────
  const generateExercises = async () => {
    setStep("loading");
    const focusTopics = customTopics.trim()
      ? customTopics.split("\n").map(s => s.trim()).filter(Boolean)
      : allTopics;

    try {
      const exs = await generateTopicExercises({
        exam, dayInfo, phase, focusTopics, uploadedText,
        skillFocus: skillFocus === "all" ? null : skillFocus,
        taskCount,
      });
      setExercises(exs);
      setCurrent(0);
      setAnswers([]);
      setSelected(null);
      setUserText("");
      setRevealed(false);
      setStep("quiz");
    } catch {
      setStep("config");
    }
  };

  // ── Quiz logic ─────────────────────────────────────────────────────────────
  const ex = exercises[current];
  const isOpenQuestion = ex?.type === "open_question";
  const isMC = ex && ex.type === "multiple_choice";
  const exSkill = detectSkill(ex);
  const hasReadingText = !!(ex?.reading_text && ex.reading_text.trim().length > 0);
  // For reading fill_blank: user types answer, evaluated by AI
  const isReadingFillBlank = exSkill === "reading" && ex?.type === "fill_blank" && hasReadingText;
  // isTextType: needs a text input field (not multiple choice buttons)
  const isTextType = (ex && !isMC && (ex.type === "fill_blank" || ex.type === "sentence_transformation" || ex.type === "error_correction" || ex.type === "translation" || isOpenQuestion)) || isReadingFillBlank;

  const checkAnswer = async () => {
      const userAns = isMC ? selected : userText;
      let isCorrect, feedback;

      if (isOpenQuestion || isReadingFillBlank || (isTextType && !isMC)) {
        // Writing / text-input tasks: evaluate with AI
        setEvaluatingWriting(true);
        try {
          const evaluation = await base44.functions.invoke('evaluateWriting', {
            question: ex.question,
            student_answer: userText.trim(),
            model_solution: ex.correct_answer || "",
            skill: exSkill
          });
          feedback = evaluation.data;
          isCorrect = feedback.result === "correct" || feedback.result === "mostly_correct";
        } catch (err) {
          feedback = { result: "submitted", details: "Bewertung konnte nicht geladen werden" };
          isCorrect = true;
        }
        setEvaluatingWriting(false);
      } else {
        // Multiple choice (including reading MC): immediate exact check
        const correct = normalize(ex.correct_answer);
        const userNorm = normalize(userAns || "");
        isCorrect = userNorm === correct;
        feedback = null;
      }

      setAnswers(prev => [...prev, {
        question: ex.question, userAns, correctAns: ex.correct_answer,
        isCorrect, explanation: ex.explanation, topic: ex.topic, skill: exSkill, isOpenQuestion, feedback
      }]);
      setRevealed(true);
    };

  const next = () => {
    if (current + 1 >= exercises.length) {
      setStep("results");
    } else {
      setCurrent(c => c + 1);
      setSelected(null);
      setUserText("");
      setRevealed(false);
    }
  };

  const restart = () => {
    setCurrent(0); setAnswers([]); setSelected(null);
    setUserText(""); setRevealed(false); setStep("quiz");
  };

  // ── Score & skill breakdown ────────────────────────────────────────────────
   // Note: Open questions (writing tasks) are not scored - they are self-evaluated
   const correctCount = answers.filter(a => a.isCorrect && !a.isOpenQuestion).length;
   const scorableCount = answers.filter(a => !a.isOpenQuestion).length;
   const pct = scorableCount > 0 ? Math.round((correctCount / scorableCount) * 100) : 100;

  const skillBreakdown = useMemo(() => {
    const map = {};
    answers.forEach(a => {
      const sk = a.skill || "grammar";
      if (!map[sk]) map[sk] = { correct: 0, total: 0 };
      map[sk].total++;
      if (a.isCorrect) map[sk].correct++;
    });
    return map;
  }, [answers]);

  // ── CONFIG ─────────────────────────────────────────────────────────────────
  if (step === "config") {
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground mb-5 group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          Zurück zum Plan
        </button>

        <h2 className="text-xl font-black mb-1">Klausur-Vorbereitung</h2>
        <p className="text-sm text-muted-foreground mb-5">
          Wähle deinen Fokus – die KI erstellt eine echte Multi-Skill-Übungseinheit aus deinen Prüfungsthemen.
        </p>

        {/* Skill focus selector */}
        <Card className="mb-4">
          <CardContent className="p-4">
            <p className="text-xs font-black text-muted-foreground uppercase tracking-wider mb-3">Welchen Bereich möchtest du üben?</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {SKILL_SECTIONS.map(s => (
                <button
                  key={s.key}
                  onClick={() => setSkillFocus(s.key)}
                  className={cn(
                    "p-2.5 rounded-xl border-2 text-left text-sm font-medium transition-all",
                    skillFocus === s.key
                      ? "border-primary bg-primary/10 text-primary font-bold"
                      : "border-border hover:border-primary/40 bg-card"
                  )}
                >
                  <span className="text-base mr-1">{s.icon}</span>
                  <span className="text-xs">{s.label}</span>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Task count selector */}
        <Card className="mb-4">
          <CardContent className="p-4">
            <p className="text-xs font-black text-muted-foreground uppercase tracking-wider mb-3">Wie viele Aufgaben?</p>
            <div className="flex gap-2">
              {TASK_COUNTS.map(n => (
                <button key={n} onClick={() => setTaskCount(n)}
                  className={cn("flex-1 py-2 rounded-xl border-2 text-sm font-bold transition-all",
                    taskCount === n ? "border-primary bg-primary text-white" : "border-border hover:border-primary/40 bg-card")}>
                  {n}
                </button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {taskCount} Aufgaben · ca. {taskCount * 3}–{taskCount * 5} Minuten
            </p>
          </CardContent>
        </Card>

        {/* Topics preview */}
        {allTopics.length > 0 && (
          <Card className="mb-4">
            <CardContent className="p-4">
              <p className="text-xs font-black text-muted-foreground uppercase tracking-wider mb-2">Deine Prüfungsthemen</p>
              <div className="flex flex-wrap gap-1.5">
                {grammarTopics.map(t => <Badge key={t} className="bg-violet-100 text-violet-800 border-0 text-xs">{t}</Badge>)}
                {vocabThemes.map(t => <Badge key={t} className="bg-emerald-100 text-emerald-800 border-0 text-xs">{t}</Badge>)}
                {writingFormats.map(t => <Badge key={t} className="bg-orange-100 text-orange-800 border-0 text-xs">{t}</Badge>)}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Custom topics */}
        <Card className="mb-4">
          <CardContent className="p-4">
            <p className="text-sm font-bold mb-1">Eigene Themen <span className="font-normal text-muted-foreground">(optional)</span></p>
            <p className="text-xs text-muted-foreground mb-2">Eines pro Zeile – z.B. genau was dein Lehrer angekündigt hat.</p>
            <textarea
              value={customTopics}
              onChange={e => setCustomTopics(e.target.value)}
              placeholder={"Passive Voice\nPast Perfect\nVokabeln: Unit 5\nBlog Post schreiben"}
              className="w-full min-h-[80px] text-sm rounded-xl border border-input px-3 py-2 bg-background resize-none focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </CardContent>
        </Card>

        {/* File upload */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <p className="text-sm font-bold mb-1">Lernmaterial hochladen <span className="font-normal text-muted-foreground">(optional)</span></p>
            <p className="text-xs text-muted-foreground mb-3">Lade einen Lernzettel hoch – die KI baut Aufgaben daraus.</p>
            {uploadName ? (
              <div className="flex items-center gap-2 p-2 bg-primary/5 rounded-xl border border-primary/20">
                <span className="text-sm font-medium text-primary flex-1 truncate">📄 {uploadName}</span>
                <button onClick={() => { setUploadName(""); setUploadedText(""); }} className="text-muted-foreground hover:text-destructive">
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => fileRef.current?.click()}
                className="w-full border-2 border-dashed border-border rounded-xl p-4 text-sm text-muted-foreground hover:border-primary/40 hover:text-primary transition-colors flex items-center justify-center gap-2"
              >
                <Upload className="w-4 h-4" />Textdatei hochladen (.txt)
              </button>
            )}
            <input ref={fileRef} type="file" accept=".txt,.md" className="hidden" onChange={handleFileUpload} />
          </CardContent>
        </Card>

        {dayInfo?.daily_goal && (
          <div className="p-3 bg-primary/5 border border-primary/20 rounded-xl text-sm text-primary font-medium mb-5">
            🎯 Tagesziel: {dayInfo.daily_goal}
          </div>
        )}

        <Button onClick={generateExercises} size="lg" className="w-full brand-gradient text-white border-0 font-black gap-2">
          <Sparkles className="w-5 h-5" />
          {taskCount} Aufgaben generieren · {SKILL_SECTIONS.find(s => s.key === skillFocus)?.label}
        </Button>
      </div>
    );
  }

  // ── LOADING ────────────────────────────────────────────────────────────────
  if (step === "loading") {
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto">
        <AILoadingState
          title="Klausur-Vorbereitung wird generiert"
          steps={[
            "Prüfungsthemen werden analysiert…",
            "Skill-Bereiche werden verteilt…",
            skillFocus === "reading" ? "Lesetexte werden formuliert…" :
            skillFocus === "writing" ? "Schreibaufgaben werden erstellt…" :
            skillFocus === "listening" ? "Hörtexte werden simuliert…" :
            "Aufgaben werden formuliert…",
            "Musterlösungen werden erstellt…",
            "Abwechslungsreiche Übungen werden finalisiert…",
          ]}
          contextLines={[
            `${taskCount} Aufgaben`,
            SKILL_SECTIONS.find(s => s.key === skillFocus)?.label || "Gemischt",
            ...grammarTopics.slice(0, 2),
            uploadName ? `📄 ${uploadName}` : null,
          ].filter(Boolean)}
        />
      </div>
    );
  }

  // ── RESULTS ────────────────────────────────────────────────────────────────
  if (step === "results") {
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
        <div className="text-center mb-6">
          <div className="text-5xl mb-2">{pct >= 80 ? "🏆" : pct >= 50 ? "💪" : "📚"}</div>
          <h2 className="text-2xl font-black">{correctCount} / {scorableCount} richtig</h2>
          <p className={cn("text-xl font-black mt-1", scoreColor(pct))}>{pct}%</p>
          <p className="text-sm text-muted-foreground mt-2">
            {pct >= 80 ? "Ausgezeichnet! Du bist gut vorbereitet." : pct >= 50 ? "Guter Ansatz – noch ein bisschen Übung!" : "Weiter üben – du schaffst das!"}
          </p>
        </div>

        {/* Skill breakdown */}
        {Object.keys(skillBreakdown).length > 1 && (
          <Card className="mb-5">
            <CardContent className="p-4">
              <p className="text-xs font-black text-muted-foreground uppercase tracking-wider mb-3">Ergebnis nach Kompetenzbereich</p>
              <div className="space-y-2">
                {Object.entries(skillBreakdown).map(([sk, data]) => {
                  const cfg = SKILL_CONFIG[sk] || SKILL_CONFIG.grammar;
                  const skPct = data.total > 0 ? Math.round((data.correct / data.total) * 100) : null;
                  return (
                    <div key={sk} className="flex items-center gap-3">
                      <Badge className={cn("text-xs border flex-shrink-0", cfg.color)}>{cfg.label}</Badge>
                      {skPct !== null ? (
                        <>
                          <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                            <div className={cn("h-full rounded-full", skPct >= 80 ? "bg-green-500" : skPct >= 50 ? "bg-yellow-500" : "bg-red-400")}
                              style={{ width: `${skPct}%` }} />
                          </div>
                          <span className="text-xs font-bold w-14 text-right">{data.correct}/{data.total} ({skPct}%)</span>
                        </>
                      ) : (
                        <span className="text-xs text-muted-foreground flex-1">Schreibaufgabe – selbst bewertet</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Answer review */}
         <div className="space-y-3 mb-6">
           {answers.map((a, i) => (
             <Card key={i} className={cn("border-2", 
               a.isOpenQuestion ? (a.feedback?.result === "correct" ? "border-green-200 bg-green-50" : "border-blue-200 bg-blue-50") :
               a.isCorrect ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50")}>
               <CardContent className="p-4">
                 <div className="flex items-start gap-2">
                   {a.isOpenQuestion
                     ? (a.feedback?.result === "correct" ? <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" /> : <PenLine className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />)
                     : a.isCorrect
                       ? <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                       : <XCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />}
                   <div className="flex-1 min-w-0">
                     <div className="flex items-center gap-2 flex-wrap mb-0.5">
                       {a.topic && <p className="text-xs font-bold text-muted-foreground">{a.topic}</p>}
                       {a.skill && SKILL_CONFIG[a.skill] && (
                         <Badge className={cn("text-[10px] border", SKILL_CONFIG[a.skill].color)}>{SKILL_CONFIG[a.skill].label}</Badge>
                       )}
                     </div>
                     <p className="text-sm font-bold leading-snug">{a.question}</p>
                     {a.isOpenQuestion ? (
                       <div className="mt-1.5 space-y-1.5">
                         <div>
                           <p className="text-xs font-semibold text-slate-700">Deine Antwort:</p>
                           <p className="text-xs text-slate-800 mt-0.5">{a.userAns || "(keine Eingabe)"}</p>
                         </div>
                         {a.feedback && (
                           <div className={cn("pt-1.5 border-t", a.feedback.result === "correct" ? "border-green-300" : "border-blue-300")}>
                             <p className="text-xs font-bold">{a.feedback.result === "correct" ? "✓ Sehr gut!" : "🦁 Leos Feedback:"}</p>
                             <p className="text-xs mt-0.5">{a.feedback.feedback_de}</p>
                           </div>
                         )}
                       </div>
                     ) : !a.isCorrect && (
                       <div className="mt-1.5 space-y-1">
                         <div>
                           <p className="text-xs text-red-700 font-semibold">Deine Antwort:</p>
                           <p className="text-xs font-mono text-red-800">{a.userAns || "(leer)"}</p>
                         </div>
                         <div>
                           <p className="text-xs text-green-700 font-semibold">Richtig:</p>
                           <p className="text-xs font-mono text-green-800">{a.correctAns}</p>
                         </div>
                         {a.skill === "grammar" && a.explanation && (
                           <div className="pt-1 border-t border-red-300">
                             <p className="text-xs font-bold text-red-700">Grammatik:</p>
                             <p className="text-xs text-red-800 mt-0.5">{a.explanation}</p>
                           </div>
                         )}
                       </div>
                     )}
                     {a.explanation && a.skill !== "grammar" && <p className="text-xs text-muted-foreground mt-1.5 italic">💡 {a.explanation}</p>}
                   </div>
                 </div>
               </CardContent>
             </Card>
           ))}
         </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <Button variant="outline" onClick={restart} className="gap-2 flex-1">
            <RotateCcw className="w-4 h-4" />Nochmal
          </Button>
          <Button onClick={() => setStep("config")} className="gap-2 flex-1 brand-gradient text-white border-0 font-bold">
            <Sparkles className="w-4 h-4" />Neue Übungen generieren
          </Button>
        </div>
        <Button variant="ghost" onClick={onBack} className="w-full mt-2 text-muted-foreground">
          Zurück zum Plan
        </Button>
      </div>
    );
  }

  // ── QUIZ ───────────────────────────────────────────────────────────────────
  const progress = (current / exercises.length) * 100;
  const correctSoFar = answers.filter(a => a.isCorrect).length;
  const exSkillCfg = SKILL_CONFIG[exSkill];

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          Abbrechen
        </button>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-muted-foreground">{current + 1} / {exercises.length}</span>
          <span className="text-xs font-bold text-green-600">{correctSoFar} ✓</span>
        </div>
      </div>

      {/* Progress bar */}
      <div className="w-full h-2 bg-secondary rounded-full mb-5 overflow-hidden">
        <div className="h-full brand-gradient rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
      </div>

      {/* Exercise card */}
      <Card className="mb-4">
        <CardContent className="p-5">
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            {ex?.topic && (
              <Badge className="bg-primary/10 text-primary border-0 text-xs font-bold">{ex.topic}</Badge>
            )}
            {exSkillCfg && (
              <Badge className={cn("text-xs border", exSkillCfg.color)}>
                <span className="flex items-center gap-1">{exSkillCfg.icon}{exSkillCfg.label}</span>
              </Badge>
            )}
          </div>

          {/* Reading text block – shown for all reading exercises */}
          {hasReadingText && exSkill === "reading" && (
            <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <BookOpen className="w-4 h-4 text-blue-600" />
                <p className="text-xs font-bold text-blue-800">Lesetext – lies den Text sorgfältig durch</p>
              </div>
              <div className="max-h-56 overflow-y-auto pr-1">
                <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-line">{ex.reading_text}</p>
              </div>
            </div>
          )}

          {/* Mediation source text – shown for mediation exercises */}
          {exSkill === "mediation" && ex?.context_text && ex.context_text.trim().length > 0 && (
            <div className="mb-4 p-4 bg-cyan-50 border border-cyan-200 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <Globe className="w-4 h-4 text-cyan-600" />
                <p className="text-xs font-bold text-cyan-800">Ausgangstext – gib den Inhalt sinngemäß auf Englisch wieder</p>
              </div>
              <div className="max-h-48 overflow-y-auto pr-1">
                <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-line">{ex.context_text}</p>
              </div>
            </div>
          )}

          {exSkill === "listening" && !listeningSkipped ? (
            <div className="mb-4 p-4 bg-gradient-to-r from-pink-50 to-rose-50 rounded-xl border border-pink-200">
              <div className="flex items-center gap-2 mb-2">
                <Headphones className="w-4 h-4 text-pink-600" />
                <p className="text-xs font-bold text-pink-800">Hörverstehen – Audio abspielen</p>
              </div>
              <p className="text-xs text-pink-700 mb-3">
                Höre den Text an und beantworte die Frage.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    try {
                      playListeningAudio(ex.question, () => setListeningPlaying(true), () => setListeningPlaying(false));
                    } catch {
                      alert("Audio konnte nicht abgespielt werden");
                    }
                  }}
                  disabled={listeningPlaying}
                  className="flex-1 px-3 py-2 bg-pink-600 text-white rounded-lg text-xs font-bold hover:bg-pink-700 disabled:opacity-50 flex items-center justify-center gap-1"
                >
                  {listeningPlaying ? <><Pause className="w-3 h-3" /> Wird abgespielt...</> : <><Play className="w-3 h-3" /> Audio abspielen</>}
                </button>
                <button
                  onClick={() => setListeningSkipped(true)}
                  className="px-3 py-2 bg-pink-100 text-pink-700 rounded-lg text-xs font-bold hover:bg-pink-200 flex items-center gap-1"
                >
                  <SkipForward className="w-3 h-3" /> Überspringen
                </button>
              </div>
            </div>
          ) : null}

          <p className="font-black text-base leading-snug mb-4 whitespace-pre-line">{exSkill === "listening" && !listeningSkipped ? "Beantworte folgende Frage zum gehörten Text:" : ex?.question}</p>

          {/* Multiple choice – but NOT for reading fill_blank */}
          {isMC && !isReadingFillBlank && ex?.options && (
            <div className="space-y-2">
              {ex.options.map((opt, i) => {
                let cls = "answer-btn";
                if (revealed) {
                  if (normalize(opt) === normalize(ex.correct_answer)) cls += " answer-btn-correct";
                  else if (selected === opt && normalize(opt) !== normalize(ex.correct_answer)) cls += " answer-btn-wrong";
                } else if (selected === opt) {
                  cls += " answer-btn-selected";
                }
                return (
                  <button key={i} className={cls} disabled={revealed} onClick={() => setSelected(opt)}>
                    <span className="font-bold text-muted-foreground mr-2">{String.fromCharCode(65 + i)}.</span>
                    {opt}
                  </button>
                );
              })}
            </div>
          )}

          {/* Source text for writing open_question (summary etc.) – not mediation (already shown above) */}
          {isOpenQuestion && exSkill !== "mediation" && ex?.context_text && ex.context_text.trim().length > 0 && (
            <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <BookOpen className="w-4 h-4 text-blue-600" />
                <p className="text-xs font-bold text-blue-800">📄 Ausgangstext – lies den Text und schreibe eine Zusammenfassung</p>
              </div>
              <div className="max-h-48 overflow-y-auto pr-1">
                <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-line">{ex.context_text}</p>
              </div>
            </div>
          )}

          {/* Open writing task */}
          {isOpenQuestion && (
            <div>
              <p className="text-xs text-muted-foreground mb-2">✍️ Schreibe deinen Text unten. Leo bewertet ihn für dich.</p>
              <textarea
                value={userText}
                onChange={e => setUserText(e.target.value)}
                disabled={revealed || evaluatingWriting}
                placeholder="Schreibe hier deinen Text…"
                className="w-full min-h-[120px] text-sm rounded-xl border-2 border-input px-3 py-2 bg-background resize-none focus:outline-none focus:border-primary disabled:opacity-75"
              />
              {revealed && (
                <div className="mt-3 space-y-3">
                  {answers[answers.length - 1]?.feedback && (
                    <div className={cn("p-3 rounded-xl border", 
                      answers[answers.length - 1].feedback.result === "correct" ? "bg-green-50 border-green-200" :
                      answers[answers.length - 1].feedback.result === "mostly_correct" ? "bg-blue-50 border-blue-200" :
                      "bg-yellow-50 border-yellow-200")}>
                      <p className="text-xs font-bold mb-1">🦁 Leos Bewertung:</p>
                      <p className="text-sm mb-1.5">{answers[answers.length - 1].feedback.feedback_de || answers[answers.length - 1].feedback.details}</p>
                      {answers[answers.length - 1].feedback.improvements && (
                        <p className="text-xs text-muted-foreground mt-2">💡 {answers[answers.length - 1].feedback.improvements}</p>
                      )}
                    </div>
                  )}
                  {ex?.correct_answer && (
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                      <p className="text-xs font-bold text-slate-800 mb-1">📝 Beispiel-Lösung:</p>
                      <p className="text-sm text-slate-900 whitespace-pre-line">{ex.correct_answer}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Text input for other types */}
          {isTextType && !isOpenQuestion && (
            <div>
              <textarea
                value={userText}
                onChange={e => setUserText(e.target.value)}
                disabled={revealed || evaluatingWriting}
                placeholder="Deine Antwort eingeben…"
                className="w-full min-h-[80px] text-sm rounded-xl border-2 border-input px-3 py-2 bg-background resize-none focus:outline-none focus:border-primary disabled:opacity-75"
              />
              {revealed && (
                <div className={cn("mt-3 p-3 rounded-xl border space-y-2",
                  answers[answers.length - 1]?.feedback?.result === "correct"
                    ? "bg-green-50 border-green-200" : "bg-blue-50 border-blue-200")}>
                  <div>
                    <p className="text-xs font-bold text-foreground">Deine Antwort:</p>
                    <p className="text-sm mt-0.5">{userText}</p>
                  </div>
                  {answers[answers.length - 1]?.feedback && (
                    <div className="pt-2 border-t border-current/30">
                      <p className="text-xs font-bold text-foreground">🦁 Leos Bewertung:</p>
                      <p className="text-sm mt-0.5">{answers[answers.length - 1].feedback.feedback_de || answers[answers.length - 1].feedback.details}</p>
                      {answers[answers.length - 1].feedback.improvements && (
                        <p className="text-xs text-muted-foreground mt-1">💡 {answers[answers.length - 1].feedback.improvements}</p>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Explanation */}
          {revealed && ex?.explanation && (
            <div className="mt-3 p-3 rounded-xl bg-secondary/60 border border-border">
              <p className="text-xs text-muted-foreground">💡 {ex.explanation}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Actions */}
      {!revealed ? (
        <Button
          onClick={checkAnswer}
          disabled={
            evaluatingWriting ||
            (isMC && !selected) ||
            (isTextType && !isOpenQuestion && !userText.trim()) ||
            (isOpenQuestion && userText.trim().length < 5)
          }
          className="w-full font-bold brand-gradient text-white border-0"
        >
          {evaluatingWriting ? "Leo bewertet..." : isOpenQuestion ? "Fertig – Leo bewertet" : isReadingFillBlank ? "Antwort prüfen (Leo)" : "Antwort prüfen"}
        </Button>
      ) : (
        <Button onClick={next} className="w-full gap-2 font-bold brand-gradient text-white border-0">
          {current + 1 >= exercises.length
            ? <><Trophy className="w-4 h-4" />Ergebnisse sehen</>
            : <>Weiter <ChevronRight className="w-4 h-4" /></>}
        </Button>
      )}
    </div>
  );
}