import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Target, BookMarked, GraduationCap, BookOpen, Pencil, Headphones, Mic, ArrowLeftRight, Volume2, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const SKILL_CARDS = [
  {
    path: '/vocabulary',
    icon: BookMarked,
    label: 'Vokabeln',
    description: 'Wörter lernen, Karteikarten, Quiz',
    color: 'text-green-700',
    bg: 'bg-green-50',
    border: 'border-green-200',
    options: ['Karteikarten', 'Englisch→Deutsch', 'Deutsch→Englisch', 'Definition schreiben', 'Lückentext', 'Kollokationen', 'False Friends']
  },
  {
    path: '/grammar',
    icon: GraduationCap,
    label: 'Grammatik',
    description: 'Regeln, Übungen, Fehlerkorrektur',
    color: 'text-blue-700',
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    options: ['Erklärung lesen', 'Multiple Choice', 'Lückentext', 'Fehlerkorrektur', 'Satztransformation', 'Mini-Test']
  },
  {
    path: '/reading',
    icon: BookOpen,
    label: 'Lesen',
    description: 'Texte verstehen und analysieren',
    color: 'text-purple-700',
    bg: 'bg-purple-50',
    border: 'border-purple-200',
    options: ['Kurztext', 'Längentext', 'Hauptidee finden', 'Detailfragen', 'True/False', 'Belege finden']
  },
  {
    path: '/writing',
    icon: Pencil,
    label: 'Schreiben',
    description: 'Texte verfassen mit Leitfaden',
    color: 'text-orange-700',
    bg: 'bg-orange-50',
    border: 'border-orange-200',
    options: ['Blog Post', 'Summary', 'Formal Email', 'Informal Email', 'Comment', 'Discussion']
  },
  {
    path: '/listening',
    icon: Headphones,
    label: 'Hören',
    description: 'Hörverständnis trainieren',
    color: 'text-pink-700',
    bg: 'bg-pink-50',
    border: 'border-pink-200',
    options: ['Kurzdialog', 'Interview', 'Bericht', 'Präsentation', 'Diktat', 'Notizen machen']
  },
  {
    path: '/speaking',
    icon: Mic,
    label: 'Sprechen',
    description: 'Mündliche Aufgaben & Prompts',
    color: 'text-yellow-700',
    bg: 'bg-yellow-50',
    border: 'border-yellow-200',
    options: ['Bildbeschreibung', 'Opinion Task', 'Rollenspiel', 'Mini-Präsentation', 'Satzbautraining']
  },
  {
    path: '/mediation',
    icon: ArrowLeftRight,
    label: 'Mediation',
    description: 'Sprachmittlung DE↔EN',
    color: 'text-teal-700',
    bg: 'bg-teal-50',
    border: 'border-teal-200',
    options: ['DE→EN Bedeutungsübertragung', 'EN→DE Zusammenfassung', 'Zielgruppenorientierung', 'Schlüsselinformationen']
  },
  {
    path: '/vocabulary',
    icon: Volume2,
    label: 'Aussprache',
    description: 'Pronunciation & Intonation',
    color: 'text-indigo-700',
    bg: 'bg-indigo-50',
    border: 'border-indigo-200',
    options: ['Minimal Pairs', 'Wortbetonung', 'Satzmelodie', 'TH-Laut', 'W/V-Unterschied', 'Schattieren']
  },
];

const FILTER_OPTIONS = {
  grade: ['Alle', 'Klasse 8', 'Klasse 9'],
  difficulty: ['Alle', 'Leicht', 'Mittel', 'Schwer'],
  duration: ['Alle', '5 Min.', '10 Min.', '20 Min.', '30 Min.'],
  mode: ['Alle', 'Ohne KI', 'Mit KI-Feedback'],
};

export default function FreeLearn() {
  const [filters, setFilters] = useState({ grade: 'Alle', difficulty: 'Alle', duration: 'Alle', mode: 'Alle' });
  const [expandedCard, setExpandedCard] = useState(null);

  return (
    <div className="min-h-screen bg-background p-4 md:p-6 lg:p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-extrabold text-foreground flex items-center gap-2">
            <Target className="text-primary" size={28} /> Freies Lernen
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Du entscheidest – wähle genau das, was du üben möchtest.
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl border border-border shadow-sm p-4 mb-6">
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-3">Filter</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {Object.entries(FILTER_OPTIONS).map(([key, options]) => (
              <div key={key}>
                <label className="text-xs text-muted-foreground font-medium block mb-1 capitalize">
                  {key === 'grade' ? 'Klasse' : key === 'difficulty' ? 'Schwierigk.' : key === 'duration' ? 'Dauer' : 'Modus'}
                </label>
                <select
                  value={filters[key]}
                  onChange={e => setFilters(prev => ({ ...prev, [key]: e.target.value }))}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-border bg-background text-xs font-medium focus:outline-none focus:ring-2 focus:ring-primary/30"
                >
                  {options.map(opt => <option key={opt}>{opt}</option>)}
                </select>
              </div>
            ))}
          </div>
        </div>

        {/* Skill grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {SKILL_CARDS.map((card, i) => {
            const isExpanded = expandedCard === i;
            return (
              <motion.div
                key={card.label}
                layout
                className={cn(
                  "bg-white rounded-2xl border shadow-sm overflow-hidden transition-all",
                  isExpanded ? "ring-2 ring-primary/30" : "hover:shadow-md hover:-translate-y-0.5",
                  card.border
                )}
              >
                <button
                  className="w-full text-left p-4"
                  onClick={() => setExpandedCard(isExpanded ? null : i)}
                >
                  <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center mb-3", card.bg)}>
                    <card.icon size={20} className={card.color} />
                  </div>
                  <h3 className={cn("font-bold text-sm mb-0.5", isExpanded ? "text-primary" : "text-foreground")}>{card.label}</h3>
                  <p className="text-xs text-muted-foreground">{card.description}</p>
                </button>

                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="border-t border-border px-4 pb-4 pt-3"
                  >
                    <p className="text-xs font-bold text-muted-foreground mb-2 uppercase tracking-wide">Übungstypen</p>
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {card.options.map(opt => (
                        <span key={opt} className={cn("text-xs px-2 py-1 rounded-full font-medium cursor-pointer hover:opacity-80 transition-opacity", card.bg, card.color)}>
                          {opt}
                        </span>
                      ))}
                    </div>
                    <Link
                      to={card.path}
                      className="flex items-center justify-center gap-1.5 bg-primary text-primary-foreground w-full py-2 rounded-xl text-xs font-bold hover:bg-primary/90 transition-colors"
                    >
                      Jetzt üben <ChevronRight size={13} />
                    </Link>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* Suggest section */}
        <div className="mt-6 bg-gradient-to-br from-yellow-50 to-orange-50 rounded-2xl border border-yellow-100 p-5">
          <div className="flex items-start gap-3">
            <div className="text-2xl">🦉</div>
            <div>
              <p className="font-bold text-sm text-yellow-800 mb-1">Rudi's Tipp für freies Lernen</p>
              <p className="text-sm text-yellow-900 leading-relaxed">
                Nicht sicher, womit du anfangen sollst? Geh zu deinem <strong>Fortschritt</strong> und schau, welcher Bereich die niedrigste Prozentzahl hat – genau dort lohnt sich Übung am meisten!
              </p>
              <Link to="/progress" className="inline-flex items-center gap-1 mt-2 text-xs font-bold text-yellow-700 hover:underline">
                Zum Fortschritt <ChevronRight size={12} />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}