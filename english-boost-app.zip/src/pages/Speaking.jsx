import { useState, useRef, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useCompletedTasks } from "@/lib/useCompletedTasks";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Mic, Square, ChevronRight, Clock, Zap, Star, Check, ArrowRight, Sparkles, RefreshCw, Loader2, Volume2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { base44 } from "@/api/base44Client";
import { useXP } from "@/lib/useXP";
import { calculateSpeakingXP } from "@/lib/xpSystem";
import XPToast from "@/components/XPToast";

const USEFUL_PHRASES = [
  { category: "Meinung äußern", phrases: ["In my opinion...", "I believe that...", "I think...", "As I see it...", "From my perspective..."] },
  { category: "Begründen", phrases: ["This is because...", "The reason is...", "One example of this is...", "For instance..."] },
  { category: "Gegenargument", phrases: ["On the other hand...", "However, one could argue...", "While it's true that...", "Nevertheless..."] },
  { category: "Schluss", phrases: ["In conclusion...", "To sum up...", "All in all...", "Taking everything into account..."] },
  { category: "Zeit gewinnen", phrases: ["That's an interesting question...", "Let me think for a moment...", "What I mean is...", "In other words..."] },
];

const MIC_HINTS = {
  permission: {
    color: "red",
    title: "🎙️ Mikrofonzugriff wurde blockiert",
    body: (
      <ol className="list-decimal list-inside space-y-1 mt-1">
        <li>Klicke auf das <strong>Schloss-Symbol 🔒</strong> links in der Adresszeile.</li>
        <li>Stelle das Mikrofon auf <strong>„Erlauben"</strong>.</li>
        <li>Lade die Seite neu und versuche es erneut.</li>
      </ol>
    ),
  },
  notfound: {
    color: "yellow",
    title: "⚠️ Kein Mikrofon gefunden",
    body: <p className="mt-1">Schließe ein Mikrofon oder Headset an und versuche es erneut.</p>,
  },
  other: {
    color: "yellow",
    title: "⚠️ Mikrofon konnte nicht geöffnet werden",
    body: <p className="mt-1">Prüfe, ob ein anderes Programm das Mikrofon gerade verwendet.</p>,
  },
};

export default function Speaking() {
  const [selected, setSelected] = useState(null);
  const [phase, setPhase] = useState("prep"); // prep | record | review | analyzing | done
  const [recording, setRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioUrl, setAudioUrl] = useState(null);
  const [pronunciationScore, setPronunciationScore] = useState(null);
  const [transcript, setTranscript] = useState("");
  const [feedback, setFeedback] = useState(null);
  const [showPhrases, setShowPhrases] = useState(false);
  const [showXP, setShowXP] = useState(false);
  const [lastXP, setLastXP] = useState(0);
  const [triggeringDaily, setTriggeringDaily] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [micError, setMicError] = useState(null); // null | 'permission' | 'notfound' | 'other'
  const [analyzeError, setAnalyzeError] = useState(null);
  const location = useLocation();
  const repeatTaskId = location.state?.taskId;
  const [isRepeatMode, setIsRepeatMode] = useState(false);
  const autoSelectedRef = useRef(false);
  const [wordInput, setWordInput] = useState("");
  const [wordCorrection, setWordCorrection] = useState(null); // {corrected, is_english, recognized, note}
  const [wordLoading, setWordLoading] = useState(false);

  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];
  const effectiveGrade = profile?.grade || "8";
  const { awardXP } = useXP(user, profile);

  const { completedTasks, markComplete } = useCompletedTasks(user?.email);
  const completedIds = new Set(completedTasks.filter(c => c.task_type === 'speaking').map(c => c.task_id));

  const { data: dbPrompts = [], isLoading } = useQuery({
    queryKey: ["speaking-prompts", effectiveGrade],
    queryFn: () => base44.entities.SpeakingPrompt.list("-created_date", 60),
  });

  useEffect(() => {
    if (repeatTaskId && dbPrompts.length > 0 && !autoSelectedRef.current) {
      const prompt = dbPrompts.find(p => p.id === repeatTaskId);
      if (prompt) {
        autoSelectedRef.current = true;
        setIsRepeatMode(true);
        setSelected(prompt);
        setPhase("prep");
      }
    }
  }, [repeatTaskId, dbPrompts]);

  const today = new Date().toISOString().split("T")[0];
  const gradeFiltered = dbPrompts.filter(p => (p.grade === effectiveGrade || p.grade === "both") && !completedIds.has(p.id));
  const todayPrompts = gradeFiltered.filter(p => p.generated_date === today);
  const olderPrompts = gradeFiltered.filter(p => p.generated_date !== today);

  const startRecording = async () => {
    setMicError(null);
    chunksRef.current = [];
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      mr.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      mr.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        const url = URL.createObjectURL(blob);
        setAudioBlob(blob);
        setAudioUrl(url);
        stream.getTracks().forEach(t => t.stop());
        setPhase("review");
      };
      mediaRecorderRef.current = mr;
      mr.start();
      setRecording(true);
    } catch (err) {
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        setMicError("permission");
      } else if (err.name === "NotFoundError") {
        setMicError("notfound");
      } else {
        setMicError("other");
      }
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setRecording(false);
  };

  const handleTriggerDaily = async () => {
    setTriggeringDaily(true);
    try {
      await base44.functions.invoke("dailyContentGenerator", {});
      queryClient.invalidateQueries({ queryKey: ["speaking-prompts", effectiveGrade] });
    } finally {
      setTriggeringDaily(false);
    }
  };

  const handleAnalyze = async () => {
    if (!audioBlob || pronunciationScore == null) return;
    setPhase("analyzing");
    setTranscribing(true);
    setAnalyzeError(null);
    try {
      const file = new File([audioBlob], "speaking.webm", { type: "audio/webm" });
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const transcriptText = await base44.integrations.Core.TranscribeAudio({ audio_url: file_url });
      setTranscript(transcriptText);
      setTranscribing(false);
      const res = await base44.functions.invoke("anthropicAI", {
        task: "speaking_feedback",
        payload: {
          transcript: transcriptText,
          promptText: selected.prompt_text,
          promptType: selected.speaking_type,
          grade: effectiveGrade,
          pronunciation_self_score: pronunciationScore,
        }
      });
      setFeedback(res.data);
      const xp = calculateSpeakingXP(res.data?.score);
      if (xp > 0 && !isRepeatMode) awardXP(xp);
      setLastXP(isRepeatMode ? 0 : xp);
      setShowXP(!isRepeatMode && xp > 0);
      setPhase("done");
      if (!isRepeatMode) markComplete({ taskId: selected.id, taskType: 'speaking', taskTitle: selected.title });
    } catch (err) {
      setTranscribing(false);
      setAnalyzeError(err?.message || "Unbekannter Fehler");
      setPhase("review");
    }
  };

  const handleBack = () => {
    if (recording) stopRecording();
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setSelected(null);
    setPhase("prep");
    setAudioBlob(null);
    setAudioUrl(null);
    setPronunciationScore(null);
    setTranscript("");
    setFeedback(null);
    setRecording(false);
    setMicError(null);
    setIsRepeatMode(false);
  };

  const speakWord = (word) => {
    const clean = word.replace(/[^a-zA-Z' -]/g, '').trim();
    if (!clean) return;
    window.speechSynthesis.cancel();
    const utt = new SpeechSynthesisUtterance(clean);
    utt.lang = 'en-US';
    utt.rate = 0.85;
    window.speechSynthesis.speak(utt);
  };

  const handleWordLookup = async () => {
    const w = wordInput.trim();
    if (!w) return;
    // Speak immediately – don't wait for API
    speakWord(w);
    setWordLoading(true);
    setWordCorrection(null);
    const res = await base44.functions.invoke("anthropicAI", {
      task: "correct_english_word",
      payload: { word: w }
    });
    const result = res.data;
    setWordCorrection(result);
    setWordLoading(false);
    // Re-speak with corrected spelling if different
    if (result.recognized && result.corrected && result.corrected !== w) {
      speakWord(result.corrected);
    }
  };

  const handleRetry = () => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioBlob(null);
    setAudioUrl(null);
    setPronunciationScore(null);
    setTranscript("");
    setFeedback(null);
    setMicError(null);
    setPhase("record");
  };

  if (selected) {
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
        <XPToast amount={lastXP} show={showXP} onDone={() => setShowXP(false)} />
        <Button variant="ghost" onClick={handleBack} className="mb-4">← Zurück</Button>

        <div className="flex items-start justify-between gap-2 mb-4">
          <h1 className="text-xl font-bold">{selected.title}</h1>
          <Badge variant="secondary">{selected.speaking_type}</Badge>
        </div>

        {selected.image_url && (
          <div className="mb-4 rounded-2xl overflow-hidden border border-border shadow-sm">
            <img src={selected.image_url} alt="Bildbeschreibung" className="w-full object-cover max-h-64 md:max-h-80" />
            <div className="bg-secondary/50 px-3 py-1.5">
              <span className="text-xs text-muted-foreground">🖼️ Bild für Bildbeschreibung</span>
            </div>
          </div>
        )}

        <Card className="mb-4 border-primary/20 bg-primary/5">
          <CardContent className="p-4">
            <p className="text-sm font-medium mb-2 text-primary">Aufgabe:</p>
            <p className="text-sm leading-relaxed">{selected.prompt_text}</p>
            <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
              <Clock className="w-3.5 h-3.5" />
              <span>Ziel: ca. {Math.floor((selected.time_seconds || 90) / 60)}:{String((selected.time_seconds || 90) % 60).padStart(2, '0')} Minuten</span>
            </div>
          </CardContent>
        </Card>

        {/* PREP */}
        {phase === "prep" && (
          <div className="space-y-4">
            {selected.tips?.length > 0 && (
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-2 text-sm">Tipps für diese Aufgabe:</h3>
                  <ul className="space-y-1.5">
                    {selected.tips.map((tip, i) => (
                      <li key={i} className="text-sm flex items-start gap-2 text-muted-foreground">
                        <span className="text-primary font-bold mt-0.5">→</span>{tip}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}
            <Card>
              <CardContent className="p-3">
                <button className="flex items-center justify-between w-full text-sm font-medium" onClick={() => setShowPhrases(!showPhrases)}>
                  <span>Nützliche Phrasen anzeigen</span>
                  <span>{showPhrases ? "▲" : "▼"}</span>
                </button>
                {showPhrases && (
                  <div className="mt-3 space-y-3">
                    {(selected.useful_phrases?.length > 0
                      ? [{ category: "Aufgaben-Phrasen", phrases: selected.useful_phrases }, ...USEFUL_PHRASES]
                      : USEFUL_PHRASES
                    ).map(cat => (
                      <div key={cat.category}>
                        <p className="text-xs text-muted-foreground font-semibold uppercase mb-1">{cat.category}</p>
                        <div className="flex flex-wrap gap-1.5">
                          {cat.phrases.map(p => <Badge key={p} variant="outline" className="text-xs">{p}</Badge>)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            <Button onClick={() => setPhase("record")} className="w-full gap-2" size="lg">
              <Mic className="w-5 h-5" /> Aufnahme starten
            </Button>
          </div>
        )}

        {/* RECORD */}
        {phase === "record" && (
          <div className="space-y-4">
            {/* Mic permission hint – shown before recording starts */}
            {!recording && !micError && (
              <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-sm text-blue-800 flex items-start gap-2">
                <span className="text-base flex-shrink-0">💡</span>
                <span>
                  Der Browser fragt nach der <strong>Mikrofon-Berechtigung</strong>.
                  Klicke im Popup oben auf <strong>„Erlauben"</strong>, damit die Aufnahme starten kann.
                </span>
              </div>
            )}

            {/* Error states */}
            {micError && (() => {
              const hint = MIC_HINTS[micError];
              const colors = hint.color === "red"
                ? "bg-red-50 border-red-200 text-red-800"
                : "bg-yellow-50 border-yellow-200 text-yellow-800";
              return (
                <div className={`p-4 rounded-2xl border text-sm ${colors}`}>
                  <p className="font-semibold">{hint.title}</p>
                  {hint.body}
                </div>
              );
            })()}

            <Card className={cn("transition-all", recording && "border-2 border-destructive")}>
              <CardContent className="p-6 text-center">
                <button
                  onClick={recording ? stopRecording : startRecording}
                  className={cn(
                    "w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 transition-all",
                    recording ? "bg-destructive text-white shadow-lg animate-pulse-ring" : "bg-primary/10 text-primary hover:bg-primary/20"
                  )}
                >
                  {recording ? <Square className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
                </button>
                <p className="font-semibold">{recording ? "🔴 Aufnahme läuft – sprich jetzt!" : "Klicke, um aufzunehmen"}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {recording ? "Drücke das Symbol, um die Aufnahme zu beenden." : "Deine Stimme wird aufgenommen. Sprich auf Englisch."}
                </p>
                {recording && (
                  <div className="flex justify-center gap-0.5 mt-3">
                    {Array(7).fill(0).map((_, i) => (
                      <div key={i} className="w-1.5 bg-destructive rounded-full animate-bounce" style={{ height: `${10 + (i % 4) * 7}px`, animationDelay: `${i * 0.08}s` }} />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* REVIEW – listen back + pronunciation self-rating */}
        {phase === "review" && audioUrl && (
          <div className="space-y-4 animate-fade-in">
            <Card className="border-primary/30 bg-primary/5">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Volume2 className="w-4 h-4 text-primary" />
                  <p className="text-sm font-semibold">Hör dir deine Aufnahme an:</p>
                </div>
                <audio controls src={audioUrl} className="w-full" />
                <p className="text-xs text-muted-foreground mt-2">Achte besonders auf deine Aussprache und Intonation.</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <p className="text-sm font-semibold mb-1">Wie war deine Aussprache?</p>
                <p className="text-xs text-muted-foreground mb-3">Bewerte dich ehrlich – Leo bewertet alles andere. (1 = sehr schwach, 5 = sehr gut)</p>
                <div className="flex gap-2 justify-center">
                  {[1, 2, 3, 4, 5].map(n => (
                    <button key={n} onClick={() => setPronunciationScore(n)}
                      className={cn(
                        "w-11 h-11 rounded-full border-2 font-bold text-sm transition-all",
                        pronunciationScore === n
                          ? "bg-primary text-white border-primary scale-110"
                          : "border-border hover:border-primary hover:bg-primary/10"
                      )}>
                      {n}
                    </button>
                  ))}
                </div>
                {pronunciationScore && (
                  <p className="text-xs text-center mt-2 text-primary font-medium">
                    {["", "Noch viel zu üben", "Einige Probleme", "Ganz okay", "Gut", "Sehr gut! 🎉"][pronunciationScore]}
                  </p>
                )}
              </CardContent>
            </Card>

            {analyzeError && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">
                <p className="font-semibold">⚠️ Fehler bei der KI-Analyse</p>
                <p className="mt-0.5 text-xs">{analyzeError}</p>
                <p className="mt-1 text-xs">Versuche es nochmal – manchmal dauert die Analyse etwas länger.</p>
              </div>
            )}
            <div className="flex gap-3">
              <Button variant="outline" onClick={handleRetry} className="flex-1 gap-2">
                <Mic className="w-4 h-4" /> Nochmal aufnehmen
              </Button>
              <Button onClick={handleAnalyze} disabled={pronunciationScore == null} className="flex-1 gap-2">
                <Sparkles className="w-4 h-4" /> Leo-Feedback erhalten
              </Button>
            </div>
          </div>
        )}

        {/* ANALYZING */}
        {phase === "analyzing" && (
          <Card>
            <CardContent className="p-8 text-center">
              <Sparkles className="w-8 h-8 text-primary mx-auto mb-3 animate-pulse" />
              <p className="font-semibold">{transcribing ? "Audio wird transkribiert…" : "Leo analysiert deine Antwort…"}</p>
              <p className="text-xs text-muted-foreground mt-1">Das dauert einen Moment.</p>
            </CardContent>
          </Card>
        )}

        {/* DONE – Feedback */}
        {phase === "done" && feedback && (
          <div className="space-y-3 animate-fade-in">
            {feedback.score != null && (
              <Card className="border-primary/30 bg-primary/5">
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="text-4xl font-bold text-primary">{feedback.score}/5</div>
                  <div>
                    <p className="font-semibold">Gesamtbewertung</p>
                    <div className="flex gap-0.5 mt-1">
                      {Array(5).fill(0).map((_, i) => (
                        <Star key={i} className={cn("w-4 h-4", i < feedback.score ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground")} />
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {transcript && (
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs font-semibold text-muted-foreground mb-2">📝 Transkript deiner Antwort:</p>
                  <p className="text-sm leading-relaxed italic text-muted-foreground mb-3">"{transcript}"</p>
                  {audioUrl && <audio controls src={audioUrl} className="w-full mb-3" />}
                  <div className="pt-3 border-t border-border">
                    <p className="text-xs font-semibold text-muted-foreground mb-1.5">🔍 Englisches Wort vorhören:</p>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="z.B. furthermore"
                        value={wordInput}
                        onChange={e => { setWordInput(e.target.value); setWordCorrection(null); }}
                        onKeyDown={e => { if (e.key === 'Enter') handleWordLookup(); }}
                        className="flex-1 px-3 py-1.5 text-sm border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/30 bg-background"
                      />
                      <button
                        onClick={handleWordLookup}
                        disabled={wordLoading || !wordInput.trim()}
                        className="px-3 py-1.5 text-sm bg-primary text-white rounded-lg hover:bg-primary/90 transition-all disabled:opacity-50">
                        {wordLoading ? "..." : "🔊 Vorhören"}
                      </button>
                    </div>
                    {wordCorrection && (
                      <div className={`mt-2 p-2 rounded-lg text-xs ${
                        !wordCorrection.recognized ? 'bg-red-50 border border-red-200 text-red-700'
                        : wordCorrection.corrected !== wordInput.trim() ? 'bg-yellow-50 border border-yellow-200 text-yellow-800'
                        : 'bg-green-50 border border-green-200 text-green-700'
                      }`}>
                        {!wordCorrection.recognized
                          ? `❌ Nicht erkennbar: "${wordInput}" konnte nicht identifiziert werden.`
                          : !wordCorrection.is_english
                          ? `⚠️ Kein englisches Wort: ${wordCorrection.note || 'Bitte ein englisches Wort eingeben.'}`
                          : wordCorrection.corrected !== wordInput.trim()
                          ? `✏️ Korrigiert zu: "${wordCorrection.corrected}"${wordCorrection.note ? ` – ${wordCorrection.note}` : ''}`
                          : `✅ "${wordCorrection.corrected}" ist korrekt geschrieben.`
                        }
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {pronunciationScore != null && (
              <Card>
                <CardContent className="p-4">
                  <h4 className="font-semibold text-sm mb-1">Aussprache (Selbsteinschätzung)</h4>
                  <div className="flex items-center gap-2">
                    <div className="flex gap-0.5">
                      {Array(5).fill(0).map((_, i) => (
                        <Star key={i} className={cn("w-4 h-4", i < pronunciationScore ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground")} />
                      ))}
                    </div>
                    <span className="text-sm text-muted-foreground">{pronunciationScore}/5</span>
                  </div>
                  {feedback.pronunciation && <p className="text-sm text-muted-foreground mt-2">{feedback.pronunciation}</p>}
                </CardContent>
              </Card>
            )}

            {[
              { key: "fluency", label: "Flüssigkeit" },
              { key: "vocabulary", label: "Vokabular" },
              { key: "grammar", label: "Grammatik" },
              { key: "task_achievement", label: "Aufgabenerfüllung" },
            ].map(({ key, label }) => feedback[key] && (
              <Card key={key}><CardContent className="p-4">
                <h4 className="font-semibold text-sm mb-1">{label}</h4>
                <p className="text-sm text-muted-foreground">{feedback[key]}</p>
              </CardContent></Card>
            ))}

            {feedback.strengths?.length > 0 && (
              <Card className="border-green-200 bg-green-50">
                <CardContent className="p-4">
                  <h4 className="font-semibold text-green-700 mb-2">✅ Stärken</h4>
                  <ul className="space-y-1">
                    {feedback.strengths.map((s, i) => (
                      <li key={i} className="text-sm text-green-800 flex items-start gap-2"><Check className="w-4 h-4 mt-0.5 flex-shrink-0" />{s}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            {feedback.improvements?.length > 0 && (
              <Card className="border-orange-200 bg-orange-50">
                <CardContent className="p-4">
                  <h4 className="font-semibold text-orange-700 mb-2">💡 Verbesserungsvorschläge</h4>
                  <ul className="space-y-1">
                    {feedback.improvements.map((s, i) => (
                      <li key={i} className="text-sm text-orange-800 flex items-start gap-2"><ArrowRight className="w-4 h-4 mt-0.5 flex-shrink-0" />{s}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            {feedback.encouragement && (
              <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
                <CardContent className="p-4 flex gap-3">
                  <span className="text-2xl">🦉</span>
                  <p className="text-sm text-amber-800 italic">{feedback.encouragement}</p>
                </CardContent>
              </Card>
            )}

            <div className="flex items-center justify-center gap-1.5 text-sm font-semibold text-amber-600">
              <Zap className="w-4 h-4" />{lastXP > 0 ? `+${lastXP} XP verdient` : "Weiter üben für XP!"}
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={handleRetry} className="flex-1">Nochmal üben</Button>
              <Button onClick={handleBack} className="flex-1">Zurück zur Übersicht</Button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-black flex items-center gap-2.5">
          <span className="w-9 h-9 rounded-2xl bg-yellow-100 flex items-center justify-center">
            <Mic className="w-5 h-5 text-yellow-600" />
          </span>
          Sprechen
        </h1>
        <p className="text-muted-foreground text-sm mt-1 ml-12">Sprich auf Englisch – Leo bewertet deine Antwort</p>
      </div>

      <div className="mb-4 flex items-center justify-between gap-2">
        <span className="text-xs font-semibold text-muted-foreground px-3 py-1.5 bg-secondary rounded-xl">
          Klasse {effectiveGrade} · Täglich 3 neue Aufgaben
        </span>
        {todayPrompts.length === 0 && (
          <Button size="sm" variant="outline" onClick={handleTriggerDaily} disabled={triggeringDaily} className="gap-1.5 text-xs">
            {triggeringDaily ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
            Heute generieren
          </Button>
        )}
      </div>

      <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 mb-5 flex items-start gap-3">
        <span className="text-lg flex-shrink-0">🦉</span>
        <p className="text-sm text-amber-800"><strong>So funktioniert's:</strong> Nimm dich auf, hör dir die Aufnahme an, bewerte deine Aussprache selbst – und Leo bewertet Flüssigkeit, Grammatik, Vokabular und Aufgabenerfüllung.</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Array(4).fill(0).map((_, i) => <div key={i} className="h-32 bg-secondary rounded-2xl animate-pulse" />)}
        </div>
      ) : gradeFiltered.length === 0 ? (
        <div className="flex flex-col items-center py-16 text-center">
          <div className="w-16 h-16 rounded-3xl bg-yellow-50 flex items-center justify-center mb-4 border border-yellow-100">
            <Mic className="w-8 h-8 text-yellow-400" />
          </div>
          <p className="font-black text-sm mb-1">Noch keine Sprechaufgaben</p>
          <p className="text-xs text-muted-foreground max-w-xs">Klicke auf „Heute generieren", um die heutigen 3 Aufgaben zu erstellen.</p>
        </div>
      ) : (
        <>
          {todayPrompts.length > 0 && (
            <div className="mb-6">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Heute</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {todayPrompts.map(p => <SpeakingCard key={p.id} prompt={p} onClick={() => { setSelected(p); setPhase("prep"); }} />)}
              </div>
            </div>
          )}
          {olderPrompts.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Frühere Aufgaben</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {olderPrompts.map(p => <SpeakingCard key={p.id} prompt={p} onClick={() => { setSelected(p); setPhase("prep"); }} />)}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function SpeakingCard({ prompt, onClick }) {
  return (
    <Card className="card-hover cursor-pointer border-border/50" onClick={onClick}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-bold">{prompt.title}</h3>
          <Badge variant="secondary" className="text-xs whitespace-nowrap">{prompt.speaking_type}</Badge>
        </div>
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{prompt.prompt_text}</p>
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Badge variant="outline" className="text-xs">Klasse {prompt.grade}</Badge>
            {prompt.difficulty && <Badge variant="outline" className="text-xs">{prompt.difficulty}</Badge>}
          </div>
          <span className="flex items-center gap-1 text-xs"><Clock className="w-3.5 h-3.5" />{Math.floor((prompt.time_seconds || 90) / 60)} Min</span>
          <ChevronRight className="w-4 h-4" />
        </div>
      </CardContent>
    </Card>
  );
}