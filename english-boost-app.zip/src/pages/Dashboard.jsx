import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { getGreeting, getLevelName, getXPForNextLevel, getDaysUntil, formatDate } from "@/lib/utils";
import { SKILL_COLORS, MASCOT_MESSAGES } from "@/lib/constants";
import {
  Zap, Flame, Star, Target, BookOpen, GraduationCap, FileText, PenLine,
  ChevronRight, Trophy, Calendar, TrendingUp, Play, Sparkles, Map,
  AlertTriangle, CheckCircle2, Headphones, Mic, ArrowLeftRight, Shield, Brain,
  Clock, BarChart2, RotateCcw, ArrowRight
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { generateRecommendations } from "@/lib/recommendations";
import DailyChallengeWidget from "@/components/DailyChallengeWidget";

const SKILL_LABELS = {
  vocabulary: "Vokabeln",
  grammar: "Grammatik",
  reading: "Lesen",
  writing: "Schreiben",
  listening: "Hören",
  speaking: "Sprechen",
  mediation: "Sprachmittlung",
};

const QUICK_ACCESS = [
  { label: "Vokabeln",        path: "/vocabulary",     icon: BookOpen,      bg: "bg-emerald-50",  text: "text-emerald-600", border: "border-emerald-100" },
  { label: "Grammatik",       path: "/grammar",         icon: GraduationCap, bg: "bg-blue-50",     text: "text-blue-600",    border: "border-blue-100" },
  { label: "Lesen",           path: "/reading",         icon: FileText,      bg: "bg-violet-50",   text: "text-violet-600",  border: "border-violet-100" },
  { label: "Schreiben",       path: "/writing",         icon: PenLine,       bg: "bg-rose-50",     text: "text-rose-500",    border: "border-rose-100" },
  { label: "Hören",           path: "/listening",       icon: Headphones,    bg: "bg-orange-50",   text: "text-orange-500",  border: "border-orange-100" },
  { label: "Sprechen",        path: "/speaking",        icon: Mic,           bg: "bg-yellow-50",   text: "text-yellow-600",  border: "border-yellow-100" },
  { label: "Vokabel-Trainer", path: "/vocab-trainer",   icon: Zap,           bg: "bg-teal-50",     text: "text-teal-600",    border: "border-teal-100" },
  { label: "Test-Modus",      path: "/test-mode",       icon: Shield,        bg: "bg-red-50",      text: "text-red-600",     border: "border-red-100" },
  { label: "Auto-Lernen",     path: "/auto-learn",      icon: Brain,         bg: "bg-purple-50",   text: "text-purple-600",  border: "border-purple-100" },
];

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function getMascotMessage(accuracy, streak, totalAttempts, weakAreas) {
  const hour = new Date().getHours();
  const skillLabels = { vocabulary: "Vokabeln", grammar: "Grammatik", reading: "Lesen", writing: "Schreiben", listening: "Hören", speaking: "Sprechen", mediation: "Sprachmittlung" };

  // New user
  if (totalAttempts === 0) {
    return pick([
      "Hallo! Ich bin Leo 🦉 Starte deine erste Übung – ich begleite dich auf deinem Weg zum Englisch-Profi!",
      "Hey, schön dass du da bist! Klick auf eine Übung und leg los – dein erster XP wartet! ⭐",
      "Willkommen! Der beste Zeitpunkt anzufangen ist jetzt. Versprochen: Es macht Spaß. 🚀",
    ]);
  }

  // Long streak
  if (streak >= 14) {
    return pick([
      `${streak} Tage am Stück – das ist keine Motivation mehr, das ist Disziplin. Respect! 🏆`,
      `Unglaublich: ${streak} Tage Streak! Du bist jetzt offiziell in einer anderen Liga. 🔥`,
      `${streak} Tage ohne Pause – das Gehirn baut gerade richtig stabile Verbindungen. So geht Lernen! 🧠`,
    ]);
  }
  if (streak >= 7) {
    return pick([
      `Wow, ${streak} Tage in Folge! Du bist absolut on fire 🔥 Beständigkeit ist dein Superpower!`,
      `${streak} Tage Streak – das ist mehr als die meisten je schaffen. Mach weiter! 💪`,
      `Eine volle Woche Englisch üben! Dein zukünftiges Ich wird sich bedanken. ⭐`,
    ]);
  }

  // No streak today
  if (streak === 0) {
    return pick([
      "Hey, heute noch nicht geübt? Schon 5 Minuten reichen, um deinen Streak zu starten! 💪",
      "Streak auf 0 – kein Problem! Fang jetzt an und du bist heute schon wieder dabei. 🔄",
      "Noch keine Session heute? Dein Streak wartet auf dich – nur kurz einloggen reicht! ⏱️",
      "Der heutige Leo-Tipp: Auch 10 Fragen zählen. Starte jetzt! 🦉",
    ]);
  }

  // Low accuracy
  if (accuracy < 50 && totalAttempts >= 5) {
    return pick([
      `Noch viel Luft nach oben – aber das ist okay! Fokussiere auf deine Schwachstellen, dann wird's besser. Du schaffst das! 🎯`,
      `${accuracy}% – da geht noch mehr! Probier den Auto-Lernmodus: Er hilft dir gezielt bei den Schwächen. 📈`,
      `Fehler sind normal. Das Wichtige: Du übst. Beim nächsten Mal wird's besser! 💡`,
      `Manches braucht einfach mehr Wiederholungen. Starte eine neue Session – der Knoten löst sich bald! 🔓`,
    ]);
  }

  // High accuracy
  if (accuracy >= 80 && totalAttempts >= 5) {
    return pick([
      `${accuracy}% Genauigkeit – richtig stark! Herausforderung gefällig? Probier mal den Test-Modus! 🏆`,
      `Wow, ${accuracy}% – das ist Profi-Niveau! Bist du schon auf 'Schwer' umgestiegen? 🔥`,
      `${accuracy}% richtig – das Fundament sitzt. Jetzt noch die Schwächen feinschleifen! ✏️`,
      `Beeindruckend! ${accuracy}% ist sehr gut. Zeit für die nächste Schwierigkeitsstufe? 🚀`,
    ]);
  }

  // Weak area detected
  if (weakAreas.length > 0 && weakAreas[0].accuracy < 60) {
    const skill = skillLabels[weakAreas[0].skill] || weakAreas[0].skill;
    return pick([
      `Ich sehe, dass ${skill} noch Übung braucht. Starte dort eine Session – kleine Schritte zählen! 📈`,
      `${skill} ist deine aktuelle Schwäche – aber das lässt sich ändern! Eine gezielte Session reicht oft. 🎯`,
      `Tipp von Leo: ${skill} gezielt üben bringt die meisten Punkte. Nur 10 Minuten! ⏱️`,
    ]);
  }

  // Time-of-day greetings
  if (hour < 9) {
    return pick([
      "Guten Morgen! Lernen vor der Schule – das bleibt am besten hängen. 🌅",
      "Frühaufsteher? Perfekt! Morgens ist das Gehirn am aufnahmefähigsten. 🧠",
    ]);
  }
  if (hour >= 21) {
    return pick([
      "Abendliche Session – läuft! Schlaf danach festigt alles im Langzeitgedächtnis. 🌙",
      "Spätlerner? Kein Problem – Hauptsache, du bist dabei! 🦉",
    ]);
  }

  // Fallback: random tip from the general pool, but truly random
  return pick(MASCOT_MESSAGES);
}

// Compute weak areas from recent attempts
function computeWeakAreas(attempts = []) {
  const bySkill = {};
  attempts.forEach(a => {
    const s = a.skill_area;
    if (!s) return;
    if (!bySkill[s]) bySkill[s] = { correct: 0, total: 0 };
    bySkill[s].total++;
    if (a.is_correct) bySkill[s].correct++;
  });
  return Object.entries(bySkill)
    .filter(([, v]) => v.total >= 2)
    .map(([skill, v]) => ({ skill, accuracy: Math.round((v.correct / v.total) * 100), total: v.total }))
    .sort((a, b) => a.accuracy - b.accuracy);
}

// Compute skill accuracy for the progress bar grid
function computeSkillStats(attempts = []) {
  const bySkill = {};
  attempts.forEach(a => {
    const s = a.skill_area;
    if (!s) return;
    if (!bySkill[s]) bySkill[s] = { correct: 0, total: 0 };
    bySkill[s].total++;
    if (a.is_correct) bySkill[s].correct++;
  });
  return bySkill;
}

export default function Dashboard() {
  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];

  const { data: exams } = useQuery({
    queryKey: ["exams", user?.email],
    queryFn: () => base44.entities.UpcomingExam.filter({ user_email: user?.email, is_active: true }),
    enabled: !!user?.email,
  });
  const { data: attempts } = useQuery({
    queryKey: ["recent-attempts", user?.email],
    queryFn: () => base44.entities.ExerciseAttempt.filter({ user_email: user?.email }, "-created_date", 30),
    enabled: !!user?.email,
  });

  const firstName = user?.full_name?.split(" ")[0] || "Schüler(in)";
  const greeting = getGreeting();
  const xpData = getXPForNextLevel(profile?.xp || 0);
  const levelName = getLevelName(profile?.level || 1);

  const totalAttempts = attempts?.length || 0;
  const correctAttempts = attempts?.filter(a => a.is_correct).length || 0;
  const accuracy = totalAttempts > 0 ? Math.round((correctAttempts / totalAttempts) * 100) : 0;

  const weakAreas = computeWeakAreas(attempts || []);
  const skillStats = computeSkillStats(attempts || []);

  const upcomingExam = exams?.sort((a, b) => new Date(a.exam_date) - new Date(b.exam_date))
    .find(e => getDaysUntil(e.exam_date) >= 0);
  const daysUntilExam = upcomingExam ? getDaysUntil(upcomingExam.exam_date) : null;
  const examUrgent = daysUntilExam !== null && daysUntilExam <= 5;

  const recommendations = generateRecommendations({ profile, attempts: attempts || [], exams: exams || [] });
  // "Unfinished practice" = last recommended skill areas not yet done today
  const todayTasks = recommendations.slice(0, 3);

  // Detect recent wrong answers for "retry" suggestion
  const recentWrong = attempts?.filter(a => !a.is_correct).slice(0, 3) || [];
  const recentSkillsWrong = [...new Set(recentWrong.map(a => a.skill_area).filter(Boolean))];

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto space-y-5 animate-fade-up">

      {/* ── Hero Banner ───────────────────────────────── */}
      <div className="relative overflow-hidden rounded-3xl brand-gradient p-5 md:p-7 text-white shadow-lg">
        <svg className="absolute right-0 top-0 h-full opacity-10 pointer-events-none" viewBox="0 0 240 200" fill="none">
          <path d="M200 0 Q180 60 200 100 Q220 140 180 200" stroke="white" strokeWidth="3" fill="none" strokeDasharray="8 6"/>
          <circle cx="200" cy="100" r="8" fill="white" opacity="0.6"/>
          <path d="M220 0 Q260 80 220 200" stroke="white" strokeWidth="1.5" fill="none" opacity="0.5"/>
        </svg>
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="text-white/75 text-sm font-semibold mb-0.5">{greeting},</p>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">{firstName}! 👋</h1>
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              {profile?.grade && (
                <span className="text-xs font-bold bg-white/20 text-white px-2.5 py-0.5 rounded-full border border-white/30">
                  Klasse {profile.grade}
                </span>
              )}
              <span className="text-xs font-bold bg-white/20 text-white px-2.5 py-0.5 rounded-full border border-white/30">
                {levelName}
              </span>
            </div>
          </div>
          <div className="flex flex-col gap-2 sm:items-end">
            <div className="flex items-center gap-4">
              <div className="text-center">
                <p className="text-xl font-black flex items-center gap-1 justify-center">
                  <Flame className="w-5 h-5 text-orange-300" />{profile?.streak || 0}
                </p>
                <p className="text-white/65 text-[11px] font-semibold">Streak</p>
              </div>
              <div className="w-px h-7 bg-white/20" />
              <div className="text-center">
                <p className="text-xl font-black flex items-center gap-1 justify-center">
                  <Zap className="w-5 h-5 text-yellow-300" />{profile?.xp || 0}
                </p>
                <p className="text-white/65 text-[11px] font-semibold">XP</p>
              </div>
              <div className="w-px h-7 bg-white/20" />
              <div className="text-center">
                <p className="text-xl font-black flex items-center gap-1 justify-center">
                  <Star className="w-5 h-5 text-yellow-300" />{profile?.level || 1}
                </p>
                <p className="text-white/65 text-[11px] font-semibold">Level</p>
              </div>
            </div>
            <div className="w-full sm:w-48">
              <div className="flex justify-between text-[10px] text-white/60 mb-1 font-semibold">
                <span>Level {profile?.level || 1}</span>
                <span>{xpData.current}/{xpData.next} XP</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                <div className="h-full bg-white/80 rounded-full transition-all duration-700" style={{ width: `${xpData.progress}%` }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── LEO MASCOT ────────────────────────────────── */}
      <div className="flex items-start gap-3 px-1 animate-fade-up stagger-1">
        <div className="w-10 h-10 rounded-2xl bg-amber-100 flex items-center justify-center text-xl flex-shrink-0 shadow-sm border border-amber-200">
          🦉
        </div>
        <div className="flex-1">
          <p className="text-[11px] font-black text-amber-700 uppercase tracking-wider mb-0.5">Leo sagt</p>
          <div className="mascot-bubble">
            <p className="text-sm text-amber-900 leading-relaxed font-medium">{getMascotMessage(accuracy, profile?.streak || 0, totalAttempts, weakAreas)}</p>
          </div>
        </div>
      </div>

      {/* ── DAILY CHALLENGE ───────────────────────────── */}
      {user && (
        <div className="animate-fade-up stagger-2">
          <DailyChallengeWidget user={user} profile={profile} />
        </div>
      )}

      {/* ── URGENT EXAM BANNER (only when ≤5 days) ───── */}
      {upcomingExam && examUrgent && (
        <div className="rounded-2xl border-2 border-red-300 bg-red-50 p-4 flex items-center gap-4 animate-fade-up">
          <div className="w-12 h-12 rounded-2xl bg-red-100 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-6 h-6 text-red-500" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-black text-red-800 text-sm">{upcomingExam.title}</p>
            <p className="text-xs text-red-600 mt-0.5">
              {daysUntilExam === 0 ? "Heute! Letzte Wiederholung." : daysUntilExam === 1 ? "Morgen früh! Jetzt noch üben." : `Noch ${daysUntilExam} Tage – intensiv vorbereiten!`}
            </p>
          </div>
          <Button asChild size="sm" className="bg-red-500 hover:bg-red-600 text-white border-0 font-bold gap-1.5 flex-shrink-0">
            <Link to="/exams"><Sparkles className="w-3.5 h-3.5" />Plan öffnen</Link>
          </Button>
        </div>
      )}

      {/* ── Main grid ─────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* ────────── LEFT: main column ────────── */}
        <div className="lg:col-span-2 space-y-5">

          {/* TODAY'S TASKS */}
          <div className="rounded-2xl border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-brand-blue-light/30 p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-black text-sm flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl brand-gradient flex items-center justify-center">
                  <Target className="w-3.5 h-3.5 text-white" />
                </div>
                Aufgaben für heute
              </h2>
              <Button asChild variant="ghost" size="sm" className="h-7 text-xs font-bold text-primary">
                <Link to="/daily-plan">Tagesplan <ArrowRight className="w-3 h-3 ml-0.5" /></Link>
              </Button>
            </div>
            {todayTasks.length > 0 ? (
              <div className="space-y-2">
                {todayTasks.map((rec, i) => (
                  <Link
                    key={i}
                    to={rec.path || "/daily-plan"}
                    className="flex items-center gap-3 p-3 rounded-xl bg-white border border-border hover:border-primary/30 hover:bg-primary/5 transition-all group"
                  >
                    <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 text-base">
                      {rec.icon || "📘"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate">{rec.title}</p>
                      <p className="text-xs text-muted-foreground truncate">{rec.reason}</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary flex-shrink-0 transition-colors" />
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-4">
                <CheckCircle2 className="w-8 h-8 text-primary mx-auto mb-2" />
                <p className="text-sm font-bold text-primary">Alle Aufgaben erledigt!</p>
                <p className="text-xs text-muted-foreground">Starte eine neue Session in Auto-Lernen.</p>
              </div>
            )}
            <Button asChild className="w-full brand-gradient text-white border-0 font-bold gap-2 mt-3 rounded-xl">
              <Link to="/auto-learn"><Brain className="w-4 h-4" />Auto-Lernmodus starten</Link>
            </Button>
          </div>

          {/* WEAK AREAS */}
          {weakAreas.length > 0 ? (
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-black text-sm flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-red-100 flex items-center justify-center">
                    <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
                  </div>
                  Deine Schwächen
                </h2>
                <Button asChild variant="ghost" size="sm" className="h-7 text-xs font-bold text-primary">
                  <Link to="/progress">Details <ChevronRight className="w-3 h-3 ml-0.5" /></Link>
                </Button>
              </div>
              <div className="space-y-2.5">
                {weakAreas.slice(0, 4).map(({ skill, accuracy: acc, total }) => {
                  const path = skill === "vocabulary" ? "/vocabulary" : skill === "grammar" ? "/grammar" : `/${skill}`;
                  return (
                    <Link key={skill} to={path} className="block group">
                      <div className="flex items-center gap-3">
                        <span className="text-xs font-bold text-muted-foreground w-24 flex-shrink-0 truncate">
                          {SKILL_LABELS[skill] || skill}
                        </span>
                        <div className="flex-1 h-2.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className={cn("h-full rounded-full transition-all",
                              acc < 50 ? "bg-red-400" : acc < 70 ? "bg-orange-400" : "bg-primary")}
                            style={{ width: `${acc}%` }}
                          />
                        </div>
                        <span className={cn("text-xs font-black w-9 text-right flex-shrink-0",
                          acc < 50 ? "text-red-500" : acc < 70 ? "text-orange-500" : "text-primary")}>
                          {acc}%
                        </span>
                      </div>
                    </Link>
                  );
                })}
              </div>
              {recentSkillsWrong.length > 0 && (
                <div className="mt-3 pt-3 border-t border-border">
                  <p className="text-xs text-muted-foreground mb-2 font-medium">Zuletzt falsch beantwortet:</p>
                  <div className="flex flex-wrap gap-1.5">
                    {recentSkillsWrong.map(s => (
                      <Badge key={s} className="bg-red-50 text-red-600 border-red-200 text-xs">
                        {SKILL_LABELS[s] || s}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              <Button asChild size="sm" variant="outline" className="w-full mt-3 gap-1.5 font-bold text-xs">
                <Link to="/auto-learn"><RotateCcw className="w-3.5 h-3.5" />Schwächen jetzt üben</Link>
              </Button>
            </div>
          ) : (
            <div className="rounded-2xl border border-border bg-card p-5">
              <h2 className="font-black text-sm flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded-xl bg-primary/10 flex items-center justify-center">
                  <BarChart2 className="w-3.5 h-3.5 text-primary" />
                </div>
                Fortschritt
              </h2>
              <p className="text-sm text-muted-foreground">
                {totalAttempts === 0
                  ? "Noch keine Übungen gemacht. Starte deine erste Session!"
                  : "Mach mehr Übungen, um deine Stärken und Schwächen zu sehen."}
              </p>
              <Button asChild className="w-full mt-3 brand-gradient text-white border-0 font-bold gap-2 rounded-xl">
                <Link to="/auto-learn"><Play className="w-4 h-4" />Erste Übung starten</Link>
              </Button>
            </div>
          )}

          {/* RECENT PROGRESS */}
          {totalAttempts > 0 && (
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-black text-sm flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-emerald-100 flex items-center justify-center">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                  </div>
                  Letzter Fortschritt
                </h2>
                <Button asChild variant="ghost" size="sm" className="h-7 text-xs font-bold text-primary">
                  <Link to="/progress">Alle <ChevronRight className="w-3 h-3 ml-0.5" /></Link>
                </Button>
              </div>
              <div className="grid grid-cols-3 gap-3 mb-3">
                <div className="bg-secondary rounded-xl p-3 text-center">
                  <div className="text-xl font-black">{totalAttempts}</div>
                  <div className="text-[11px] text-muted-foreground mt-0.5">Aufgaben</div>
                </div>
                <div className="bg-secondary rounded-xl p-3 text-center">
                  <div className={cn("text-xl font-black", accuracy >= 80 ? "text-primary" : accuracy >= 60 ? "text-orange-500" : "text-red-500")}>
                    {accuracy}%
                  </div>
                  <div className="text-[11px] text-muted-foreground mt-0.5">Genauigkeit</div>
                </div>
                <div className="bg-secondary rounded-xl p-3 text-center">
                  <div className="text-xl font-black text-amber-500">{correctAttempts}</div>
                  <div className="text-[11px] text-muted-foreground mt-0.5">Richtig</div>
                </div>
              </div>
              <Progress value={accuracy} className="h-2 rounded-full" />
              <p className="text-xs text-muted-foreground mt-2 text-center">
                {accuracy >= 80 ? "Super – weiter so! 🎉" : accuracy >= 60 ? "Guter Fortschritt – fokussiere auf deine Schwächen!" : "Öfter üben hilft – starte eine kurze Session!"}
              </p>
            </div>
          )}

          {/* QUICK ACCESS */}
          <div>
            <h2 className="text-xs font-black text-muted-foreground uppercase tracking-wider mb-3">Lernbereiche</h2>
            <div className="grid grid-cols-4 sm:grid-cols-5 gap-2.5">
              {QUICK_ACCESS.map(item => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`group flex flex-col items-center gap-2 p-3 rounded-2xl border ${item.border} ${item.bg} card-hover text-center`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-white/80 flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                      <Icon className={`w-4 h-4 ${item.text}`} />
                    </div>
                    <span className={`text-[10px] font-bold ${item.text} leading-tight`}>{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </div>
        </div>

        {/* ────────── RIGHT: sidebar ────────── */}
        <div className="space-y-4">

          {/* UPCOMING EXAM (non-urgent) */}
          {upcomingExam && !examUrgent ? (
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center gap-2 mb-3">
                <Calendar className="w-4 h-4 text-primary" />
                <p className="text-xs font-black uppercase tracking-wider text-muted-foreground">Nächster Test</p>
              </div>
              <p className="font-black text-sm">{upcomingExam.title}</p>
              <p className="text-xs text-muted-foreground mt-0.5 mb-3">{formatDate(upcomingExam.exam_date)}</p>
              <div className="flex items-center justify-between">
                <Badge className="bg-secondary text-secondary-foreground font-bold text-xs">
                  In {daysUntilExam} Tagen
                </Badge>
                <Button variant="ghost" size="sm" className="h-7 text-xs font-bold text-primary" asChild>
                  <Link to="/exams">Vorbereiten <ChevronRight className="w-3 h-3 ml-0.5" /></Link>
                </Button>
              </div>
              {/* mini day bar */}
              <div className="mt-3 pt-3 border-t border-border">
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: `${Math.max(5, 100 - (daysUntilExam / 30) * 100)}%` }} />
                </div>
                <p className="text-[10px] text-muted-foreground mt-1">Vorbereitungsfortschritt</p>
              </div>
            </div>
          ) : !upcomingExam ? (
            <div className="rounded-2xl border-2 border-dashed border-border/60 p-4 text-center">
              <Trophy className="w-7 h-7 text-muted-foreground/50 mx-auto mb-2" />
              <p className="text-xs text-muted-foreground mb-2.5 font-medium">Bald ein Test?</p>
              <Button variant="outline" size="sm" className="text-xs h-7 rounded-xl font-bold" asChild>
                <Link to="/exams">Eintragen</Link>
              </Button>
            </div>
          ) : null}

          {/* UNFINISHED PRACTICE hint */}
          {recentWrong.length > 0 && (
            <div className="rounded-2xl border border-orange-200 bg-orange-50 p-4">
              <div className="flex items-center gap-2 mb-2">
                <RotateCcw className="w-4 h-4 text-orange-500" />
                <p className="text-xs font-black uppercase tracking-wider text-orange-700">Noch offen</p>
              </div>
              <p className="text-sm font-bold text-orange-800 mb-1">{recentWrong.length} falsche Antworten</p>
              <p className="text-xs text-orange-700 mb-3">Wiederhole diese Themen, um sie zu festigen.</p>
              <div className="flex flex-wrap gap-1.5 mb-3">
                {recentSkillsWrong.map(s => (
                  <Badge key={s} className="bg-orange-100 text-orange-700 border-orange-200 text-xs">{SKILL_LABELS[s] || s}</Badge>
                ))}
              </div>
              <Button asChild size="sm" className="w-full bg-orange-500 hover:bg-orange-600 text-white border-0 font-bold gap-1.5">
                <Link to="/auto-learn"><RotateCcw className="w-3.5 h-3.5" />Jetzt wiederholen</Link>
              </Button>
            </div>
          )}

          {/* SKILL MAP teaser */}
          <Link
            to="/skill-map"
            className="flex items-center gap-3 rounded-2xl border border-border bg-card p-4 card-hover group"
          >
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Map className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold">Kompetenzmap</p>
              <p className="text-xs text-muted-foreground mt-0.5">Alle Bereiche im Blick</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
          </Link>

        </div>
      </div>
    </div>
  );
}