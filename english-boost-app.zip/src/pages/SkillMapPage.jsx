import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import SkillMap from "@/components/SkillMap";
import MistakeInsights from "@/components/MistakeInsights";
import { Map, Brain, Target } from "lucide-react";
import { GRADE_PROFILES } from "@/lib/skillMap";

export default function SkillMapPage() {
  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const { data: attempts } = useQuery({
    queryKey: ["recent-attempts", user?.email],
    queryFn: () => base44.entities.ExerciseAttempt.filter({ user_email: user?.email }, "-created_date", 50),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];
  const gradeProfile = GRADE_PROFILES[profile?.grade || "8"];

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto animate-fade-in space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2"><Map className="w-6 h-6 text-primary" />Kompetenzmap</h1>
        <p className="text-muted-foreground text-sm mt-0.5">Alle Lernbereiche und Teilkompetenzen im Überblick</p>
      </div>

      {/* Grade info */}
      {gradeProfile && (
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Brain className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-sm">Klasse {profile?.grade || "8"} – Lernprofil</p>
                <p className="text-sm text-muted-foreground mt-1">{gradeProfile.description}</p>
                <p className="text-xs text-muted-foreground mt-1 italic">{gradeProfile.tone}</p>
                <div className="flex flex-wrap gap-1 mt-2">
                  {gradeProfile.topics.map(t => <Badge key={t} variant="outline" className="text-xs">{t}</Badge>)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Weak areas highlight */}
      {profile?.weak_areas?.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-2">
              <Target className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-orange-800 text-sm mb-1">Deine Schwerpunkte laut Profil:</p>
                <div className="flex flex-wrap gap-1">
                  {profile.weak_areas.map(area => (
                    <Badge key={area} className="bg-orange-100 text-orange-700 border-orange-200 text-xs">{area}</Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Mistake-based insights */}
      <MistakeInsights attempts={attempts} />

      {/* Full skill map */}
      <div>
        <h2 className="text-base font-bold mb-3">Alle Kompetenzbereiche</h2>
        <p className="text-sm text-muted-foreground mb-4">Klicke auf einen Bereich, um die Teilkompetenzen zu sehen. Orange markierte Bereiche sind deine aktuellen Schwerpunkte.</p>
        <SkillMap highlightSkills={profile?.weak_areas || []} />
      </div>
    </div>
  );
}