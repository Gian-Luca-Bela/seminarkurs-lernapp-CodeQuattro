import { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { useCompletedTasks } from "@/lib/useCompletedTasks";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeftRight, ChevronRight, Sparkles, Check, Loader2, RefreshCw, Zap, Plus } from "lucide-react";
import GenerateMediationModal from "@/components/mediation/GenerateMediationModal";
import { cn } from "@/lib/utils";
import { base44 } from "@/api/base44Client";
import { calculateMediationXP } from "@/lib/xpSystem";
import { DIFFICULTY_COLORS, DIFFICULTY_LABELS } from "@/lib/constants";

export default function Mediation() {
  const [selected, setSelected] = useState(null);
  const [response, setResponse] = useState("");
  const [feedback, setFeedback] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [triggeringDaily, setTriggeringDaily] = useState(false);
  const [showKey, setShowKey] = useState(false);
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [generatingCustom, setGeneratingCustom] = useState(false);

  const queryClient = useQueryClient();

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const effectiveGrade = profiles?.[0]?.grade || "8";

  const location = useLocation();
  const repeatTaskId = location.state?.taskId;
  const [isRepeatMode, setIsRepeatMode] = useState(false);
  const autoSelectedRef = useRef(false);
  const { completedTasks, markComplete } = useCompletedTasks(user?.email);
  const completedIds = new Set(completedTasks.filter(c => c.task_type === 'mediation').map(c => c.task_id));

  const { data: tasks = [], isLoading } = useQuery({
    queryKey: ["mediation-tasks", effectiveGrade],
    queryFn: () => base44.entities.MediationTask.list("-created_date", 60),
  });

  const today = new Date().toISOString().split("T")[0];
  const filtered = tasks.filter(t => (t.grade === effectiveGrade || t.grade === "both") && !completedIds.has(t.id));

  useEffect(() => {
    if (repeatTaskId && tasks.length > 0 && !autoSelectedRef.current) {
      const task = tasks.find(t => t.id === repeatTaskId);
      if (task) {
        autoSelectedRef.current = true;
        setIsRepeatMode(true);
        setSelected(task);
      }
    }
  }, [repeatTaskId, tasks]);
  const todayTasks = filtered.filter(t => t.generated_date === today);
  const olderTasks = filtered.filter(t => t.generated_date !== today);

  const handleTriggerDaily = async () => {
    setTriggeringDaily(true);
    try {
      await base44.functions.invoke("dailyContentGenerator", {});
      queryClient.invalidateQueries({ queryKey: ["mediation-tasks", effectiveGrade] });
    } finally {
      setTriggeringDaily(false);
    }
  };

  const handleGenerateCustom = async ({ topic, source_lang, target_lang, difficulty }) => {
    setGeneratingCustom(true);
    try {
      await base44.functions.invoke("dailyContentGenerator", {
        single: { type: "mediation", topic, source_lang, target_lang, grade: effectiveGrade, difficulty }
      });
      queryClient.invalidateQueries({ queryKey: ["mediation-tasks", effectiveGrade] });
    } finally {
      setGeneratingCustom(false);
    }
  };

  const handleFeedback = async () => {
    setGenerating(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an English teacher evaluating a mediation task by a German Gymnasium student (grade ${selected.grade}).

Task: ${selected.task}
Source text: ${selected.source_text}
Student's mediation: ${response}

Evaluate the mediation on:
1. Meaning transfer: Did they convey the key information correctly?
2. Natural language: Is it natural English (not a word-for-word translation)?
3. Audience awareness: Is it appropriate for ${selected.target_audience}?
4. Missing information: What important points were left out?
5. Good elements: What did they do well?

Give feedback in German. Be encouraging and specific.`,
        response_json_schema: {
          type: "object",
          properties: {
            meaning_transfer: { type: "string" },
            natural_language: { type: "string" },
            audience: { type: "string" },
            missing: { type: "array", items: { type: "string" } },
            well_done: { type: "array", items: { type: "string" } },
            overall: { type: "string" }
          }
        }
      });
      setFeedback(result);
      if (!isRepeatMode) markComplete({ taskId: selected.id, taskType: 'mediation', taskTitle: selected.title });
    } catch {
      setFeedback({
        meaning_transfer: "Du hast die wichtigsten Informationen übertragen.",
        natural_language: "Achte darauf, natürliche englische Ausdrücke zu verwenden statt wörtlich zu übersetzen.",
        audience: "Die Zielgruppe wurde angemessen berücksichtigt.",
        missing: selected.key_points?.slice(1) || [],
        well_done: ["Du hast einen sinnvollen Einstieg gewählt", "Die grundlegende Information ist vorhanden"],
        overall: "Gute Arbeit! Mediation ist eine wichtige Fertigkeit. Mit Übung wirst du immer besser darin, Informationen natürlich zu übertragen."
      });
    }
    setGenerating(false);
  };

  if (selected) {
    return (
      <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-in">
        <Button variant="ghost" onClick={() => { setSelected(null); setResponse(""); setFeedback(null); setShowKey(false); setIsRepeatMode(false); }} className="mb-4">← Zurück</Button>

        <div className="flex items-start justify-between gap-2 mb-4">
          <h1 className="text-xl font-bold">{selected.title}</h1>
          <div className="flex items-center gap-1 text-xs font-semibold text-muted-foreground">
            {selected.source_lang === "de" ? "🇩🇪 DE" : "🇬🇧 EN"}
            <ArrowLeftRight className="w-3.5 h-3.5 mx-1" />
            {selected.target_lang === "en" ? "🇬🇧 EN" : "🇩🇪 DE"}
          </div>
        </div>

        <Card className="mb-4 bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <p className="text-xs font-semibold text-blue-700 uppercase mb-1">Situation</p>
            <p className="text-sm text-blue-800">{selected.context}</p>
          </CardContent>
        </Card>

        <Card className="mb-4">
          <CardContent className="p-4">
            <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">
              Ausgangstext ({selected.source_lang === "de" ? "Deutsch" : "Englisch"})
            </p>
            <p className="text-sm leading-relaxed whitespace-pre-line">{selected.source_text}</p>
          </CardContent>
        </Card>

        <Card className="mb-4 border-primary/20 bg-primary/5">
          <CardContent className="p-4">
            <p className="text-xs font-semibold text-primary uppercase mb-1">Deine Aufgabe</p>
            <p className="text-sm">{selected.task}</p>
          </CardContent>
        </Card>

        {!feedback && (
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium mb-1">Deine Mediation ({selected.target_lang === "en" ? "auf Englisch" : "auf Deutsch"}):</p>
              <Textarea value={response} onChange={e => setResponse(e.target.value)} className="min-h-32 resize-none"
                placeholder={`Schreibe deine Mediation auf ${selected.target_lang === "en" ? "Englisch" : "Deutsch"}...`} />
            </div>
            <div className="p-3 rounded-xl bg-yellow-50 border border-yellow-200 text-xs text-yellow-800">
              <strong>Wichtig:</strong> Übersetze NICHT Satz für Satz! Übertrage die Bedeutung in natürlicher Sprache, passend für {selected.target_audience}.
            </div>
            {selected.useful_phrases?.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground mb-1">Nützliche Ausdrücke:</p>
                <div className="flex flex-wrap gap-1.5">
                  {selected.useful_phrases.map(p => <Badge key={p} variant="outline" className="text-xs">{p}</Badge>)}
                </div>
              </div>
            )}
            <Button onClick={handleFeedback} disabled={response.length < 20 || generating} className="w-full gap-2">
              <Sparkles className="w-4 h-4" />{generating ? "KI analysiert..." : "KI-Feedback erhalten"}
            </Button>
          </div>
        )}

        {feedback && (
          <div className="space-y-4">
            {feedback.well_done?.length > 0 && (
              <Card className="border-green-200 bg-green-50">
                <CardContent className="p-4">
                  <h4 className="font-semibold text-green-700 mb-2">✅ Das hast du gut gemacht</h4>
                  {feedback.well_done.map((s, i) => <p key={i} className="text-sm text-green-800 flex items-start gap-2"><Check className="w-4 h-4 mt-0.5" />{s}</p>)}
                </CardContent>
              </Card>
            )}
            {[
              { key: "meaning_transfer", label: "Bedeutungsübertragung" },
              { key: "natural_language", label: "Natürliche Sprache" },
              { key: "audience", label: "Zielgruppenangemessenheit" },
            ].map(({ key, label }) => feedback[key] && (
              <Card key={key}>
                <CardContent className="p-4">
                  <h4 className="font-semibold text-sm mb-1">{label}</h4>
                  <p className="text-sm text-muted-foreground">{feedback[key]}</p>
                </CardContent>
              </Card>
            ))}
            {feedback.missing?.length > 0 && (
              <Card className="border-orange-200 bg-orange-50">
                <CardContent className="p-4">
                  <h4 className="font-semibold text-orange-700 mb-1">💡 Vergessene Punkte</h4>
                  {feedback.missing.map((s, i) => <p key={i} className="text-sm text-orange-800">• {s}</p>)}
                </CardContent>
              </Card>
            )}
            {feedback.overall && (
              <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
                <CardContent className="p-4 flex gap-3">
                  <span className="text-2xl">🦉</span>
                  <p className="text-sm text-amber-800">{feedback.overall}</p>
                </CardContent>
              </Card>
            )}
            <div className="space-y-3">
              <div className="flex items-center justify-center gap-1.5 text-sm font-semibold text-amber-600">
                <Zap className="w-4 h-4" />
                +{calculateMediationXP(feedback.well_done?.length > 0 ? 4 : 2, selected.difficulty || 'medium')} XP
              </div>
              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setFeedback(null)} className="flex-1">Nochmal versuchen</Button>
                <Button onClick={() => { setSelected(null); setResponse(""); setFeedback(null); }} className="flex-1">Zurück</Button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto animate-fade-in">
      <div className="mb-5">
        <h1 className="text-2xl font-black flex items-center gap-2.5">
          <span className="w-9 h-9 rounded-2xl bg-teal-100 flex items-center justify-center">
            <ArrowLeftRight className="w-5 h-5 text-teal-600" />
          </span>
          Mediation
        </h1>
        <p className="text-muted-foreground text-sm mt-1 ml-12">Inhalte zwischen Deutsch und Englisch sinngemäß übertragen</p>
      </div>

      <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200 mb-5">
        <div className="flex items-start gap-3">
          <span className="text-lg flex-shrink-0">💡</span>
          <div>
            <p className="text-sm font-bold text-teal-800 mb-0.5">Was ist Mediation?</p>
            <p className="text-sm text-teal-700">Du überträgst Informationen aus einem Text sinngemäß – <em>nicht</em> Wort für Wort – in die andere Sprache, angepasst an dein Gegenüber. Das ist eine Pflichtaufgabe in Klassenarbeiten der Klasse 8 und 9.</p>
          </div>
        </div>
      </div>

      <div className="mb-4 flex items-center justify-between gap-2">
        <span className="text-xs font-semibold text-muted-foreground px-3 py-1.5 bg-secondary rounded-xl">
          Klasse {effectiveGrade} · Täglich 3 neue Aufgaben
        </span>
        <div className="flex gap-2">
          {todayTasks.length === 0 && (
            <Button size="sm" variant="outline" onClick={handleTriggerDaily} disabled={triggeringDaily} className="gap-1.5 text-xs">
              {triggeringDaily ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
              Heute generieren
            </Button>
          )}
          <Button size="sm" onClick={() => setShowGenerateModal(true)} className="gap-1.5 text-xs">
            <Plus className="w-3 h-3" /> Eigene Aufgabe
          </Button>
        </div>
      </div>

      {generatingCustom && (
        <div className="mb-4 p-3 rounded-xl bg-primary/5 border border-primary/20 flex items-center gap-2 text-sm text-primary">
          <Loader2 className="w-4 h-4 animate-spin" /> Aufgabe wird generiert...
        </div>
      )}

      <GenerateMediationModal
        open={showGenerateModal}
        onClose={() => setShowGenerateModal(false)}
        grade={effectiveGrade}
        onGenerate={handleGenerateCustom}
      />

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Array(3).fill(0).map((_, i) => <div key={i} className="h-32 bg-secondary rounded-2xl animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center py-16 text-center">
          <div className="w-16 h-16 rounded-3xl bg-teal-50 flex items-center justify-center mb-4 border border-teal-100">
            <ArrowLeftRight className="w-8 h-8 text-teal-400" />
          </div>
          <p className="font-black text-sm mb-1">Noch keine Mediationsaufgaben</p>
          <p className="text-xs text-muted-foreground max-w-xs">Klicke auf „Heute generieren" um die heutigen 3 Aufgaben zu erstellen.</p>
        </div>
      ) : (
        <>
          {todayTasks.length > 0 && (
            <div className="mb-6">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Heute</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {todayTasks.map(task => <MediationCard key={task.id} task={task} onClick={() => setSelected(task)} />)}
              </div>
            </div>
          )}
          {olderTasks.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Frühere Aufgaben</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {olderTasks.map(task => <MediationCard key={task.id} task={task} onClick={() => setSelected(task)} />)}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function MediationCard({ task, onClick }) {
  return (
    <Card className="card-hover cursor-pointer border-border/50" onClick={onClick}>
      <CardContent className="p-4">
        <h3 className="font-bold mb-2">{task.title}</h3>
        <div className="flex items-center gap-1 text-xs font-semibold text-muted-foreground mb-2">
          {task.source_lang === "de" ? "🇩🇪 Deutsch" : "🇬🇧 Englisch"}
          <ArrowLeftRight className="w-3 h-3 mx-1" />
          {task.target_lang === "en" ? "🇬🇧 Englisch" : "🇩🇪 Deutsch"}
        </div>
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{task.context}</p>
        <div className="flex items-center justify-between">
          <div className="flex gap-1.5">
            <Badge variant="outline" className="text-xs">Klasse {task.grade}</Badge>
            {task.difficulty && (
              <span className={cn("text-xs px-2 py-0.5 rounded-full", DIFFICULTY_COLORS[task.difficulty])}>
                {DIFFICULTY_LABELS[task.difficulty]}
              </span>
            )}
          </div>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </div>
      </CardContent>
    </Card>
  );
}