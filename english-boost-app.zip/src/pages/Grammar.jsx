import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { GraduationCap, Check, X, Lightbulb, BookOpen, RotateCcw, Zap, Brain, ArrowLeft, AlertTriangle } from "lucide-react";
import CollapsibleSection from "@/components/ui/CollapsibleSection";
import { DIFFICULTY_COLORS, DIFFICULTY_LABELS } from "@/lib/constants";
import ScaffoldingSelector from "@/components/ScaffoldingSelector";
import RichFeedback from "@/components/RichFeedback";
import MetacognitionPrompt from "@/components/MetacognitionPrompt";
import XPToast from "@/components/XPToast";
import { useXP } from "@/lib/useXP";
import TransformationFeedback from "@/components/TransformationFeedback";

const DIFFICULTY_ORDER = { easy: 0, medium: 1, hard: 2 };

const DIFFICULTY_DISPLAY = {
  easy: { label: "Grundlagen", emoji: "🟢", color: "bg-green-100 text-green-700 border-green-200" },
  medium: { label: "Mittel", emoji: "🟡", color: "bg-yellow-100 text-yellow-700 border-yellow-200" },
  hard: { label: "Fortgeschritten", emoji: "🔴", color: "bg-red-100 text-red-700 border-red-200" },
};

const TOPIC_COLORS = [
  "border-l-blue-400 bg-blue-50/40",
  "border-l-violet-400 bg-violet-50/40",
  "border-l-emerald-400 bg-emerald-50/40",
  "border-l-orange-400 bg-orange-50/40",
  "border-l-rose-400 bg-rose-50/40",
  "border-l-teal-400 bg-teal-50/40",
  "border-l-amber-400 bg-amber-50/40",
  "border-l-cyan-400 bg-cyan-50/40",
];

export default function Grammar() {
  const [selectedGrade, setSelectedGrade] = useState("8");
  const [selectedLesson, setSelectedLesson] = useState(null);
  const [practiceMode, setPracticeMode] = useState(false);
  const [scaffolding, setScaffolding] = useState("normal");

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];
  const grade = profile?.grade || selectedGrade;

  const { data: lessons = [], isLoading } = useQuery({
    queryKey: ["grammar-lessons", grade],
    queryFn: () => base44.entities.GrammarLesson.list("-order", 80),
  });

  const displayLessons = lessons
    .filter(l => l.grade === grade || l.grade === "both")
    .sort((a, b) => (DIFFICULTY_ORDER[a.difficulty] ?? 1) - (DIFFICULTY_ORDER[b.difficulty] ?? 1));

  const handleBack = () => {
    setPracticeMode(false);
    setSelectedLesson(null);
  };

  if (practiceMode && selectedLesson) {
    return <GrammarPractice lesson={selectedLesson} scaffolding={scaffolding} grade={grade} onBack={handleBack} />;
  }

  if (selectedLesson) {
    return (
      <GrammarLessonDetail
        lesson={selectedLesson}
        grade={grade}
        scaffolding={scaffolding}
        setScaffolding={setScaffolding}
        onBack={() => setSelectedLesson(null)}
        onPractice={() => setPracticeMode(true)}
      />
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-black flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-2xl bg-blue-100 flex items-center justify-center flex-shrink-0">
              <GraduationCap className="w-5 h-5 text-blue-600" />
            </span>
            Grammatik
          </h1>
          <p className="text-muted-foreground text-sm mt-1 ml-12">
            {displayLessons.length} Themen · Erklärungen, Signalwörter & Übungen
          </p>
        </div>
        <Badge className="bg-blue-100 text-blue-700 border-0 font-bold text-sm">Klasse {grade}</Badge>
      </div>

      {/* Grade toggle (if no profile) */}
      {!profile?.grade && (
        <div className="flex gap-2 mb-6">
          {["8", "9"].map(g => (
            <button key={g} onClick={() => setSelectedGrade(g)}
              className={cn("px-4 py-2 rounded-xl font-semibold text-sm transition-all border",
                selectedGrade === g ? "bg-primary text-white border-primary shadow-sm" : "bg-card text-muted-foreground border-border hover:border-primary/40")}>
              Klasse {g}
            </button>
          ))}
        </div>
      )}

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {Array(6).fill(0).map((_, i) => <div key={i} className="h-24 bg-secondary rounded-2xl animate-pulse" />)}
        </div>
      ) : displayLessons.length === 0 ? (
        <div className="flex flex-col items-center py-16 text-center">
          <div className="w-16 h-16 rounded-3xl bg-blue-50 flex items-center justify-center mb-4 border border-blue-100">
            <GraduationCap className="w-8 h-8 text-blue-300" />
          </div>
          <p className="font-black text-sm text-foreground mb-1">Noch keine Grammatiklektionen</p>
          <p className="text-xs text-muted-foreground max-w-xs">Lade Demo-Daten unter „Demo-Daten" in der Seitenleiste.</p>
        </div>
      ) : (() => {
        // Group by difficulty
        const groups = [
          { key: "easy",   label: "Grundlagen",    dot: "bg-green-400",  icon: "🟢", lessons: displayLessons.filter(l => l.difficulty === "easy") },
          { key: "medium", label: "Mittelstufe",       dot: "bg-amber-400",  icon: "🟡", lessons: displayLessons.filter(l => l.difficulty === "medium") },
          { key: "hard",   label: "Fortgeschritten", dot: "bg-red-400", icon: "🔴", lessons: displayLessons.filter(l => l.difficulty === "hard") },
        ].filter(g => g.lessons.length > 0);

        const highRelevanceCount = (grp) => grp.lessons.filter(l => l.test_relevance === "high").length;

        return (
          <div className="space-y-3">
            {groups.map((grp, idx) => (
              <CollapsibleSection
                key={grp.key}
                title={grp.label}
                count={grp.lessons.length}
                countLabel="Themen"
                dotColor={grp.dot}
                defaultOpen={idx === 0}
                badge={
                  highRelevanceCount(grp) > 0 ? (
                    <span className="text-[10px] font-bold text-red-600 bg-red-50 px-1.5 py-0.5 rounded-full border border-red-200">
                      {highRelevanceCount(grp)} testrelevant
                    </span>
                  ) : null
                }
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {grp.lessons.map((lesson, i) => (
                    <LessonCard
                      key={lesson.id}
                      lesson={lesson}
                      colorClass={TOPIC_COLORS[i % TOPIC_COLORS.length]}
                      onClick={() => setSelectedLesson(lesson)}
                    />
                  ))}
                </div>
              </CollapsibleSection>
            ))}
          </div>
        );
      })()}
    </div>
  );
}

function LessonCard({ lesson, colorClass, onClick }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full text-left p-4 rounded-2xl border-2 border-l-4 transition-all duration-150 group",
        "hover:shadow-md hover:-translate-y-0.5 bg-card",
        colorClass
      )}
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <h3 className="font-bold text-sm leading-snug flex-1">{lesson.title_de}</h3>
        <div className="flex flex-col items-end gap-1 flex-shrink-0">
          {lesson.test_relevance === "high" && (
            <span className="text-[10px] font-bold text-red-600 bg-red-50 px-1.5 py-0.5 rounded-full border border-red-200 whitespace-nowrap">Testrelevant</span>
          )}
          {lesson.difficulty && (
            <span className={cn("text-[10px] px-1.5 py-0.5 rounded-full font-semibold", DIFFICULTY_COLORS[lesson.difficulty])}>
              {DIFFICULTY_LABELS[lesson.difficulty]}
            </span>
          )}
        </div>
      </div>
      {lesson.title_en && (
        <p className="text-xs text-muted-foreground italic mb-2">{lesson.title_en}</p>
      )}
      {lesson.signal_words?.length > 0 && (
        <p className="text-xs text-muted-foreground line-clamp-1">
          🔑 {Array.isArray(lesson.signal_words) ? lesson.signal_words[0] : lesson.signal_words}
        </p>
      )}
    </button>
  );
}

function GrammarLessonDetail({ lesson, grade, scaffolding, setScaffolding, onBack, onPractice }) {
  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-in">
      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors mb-5 group"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        Zurück zur Übersicht
      </button>

      {/* Title */}
      <div className="flex items-start justify-between gap-4 mb-5">
        <div>
          <h1 className="text-2xl font-black">{lesson.title_de}</h1>
          {lesson.title_en && <p className="text-muted-foreground text-sm mt-1 italic">{lesson.title_en}</p>}
        </div>
        <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
          {lesson.test_relevance === "high" && (
            <Badge className="bg-red-50 text-red-700 border border-red-200 font-bold text-xs">⚠️ Testrelevant</Badge>
          )}
          <Badge className="bg-blue-100 text-blue-700 border-0 font-bold text-xs">Klasse {lesson.grade}</Badge>
          {lesson.difficulty && (
            <span className={cn("text-xs px-2 py-0.5 rounded-full font-semibold", DIFFICULTY_COLORS[lesson.difficulty])}>
              {DIFFICULTY_LABELS[lesson.difficulty]}
            </span>
          )}
        </div>
      </div>

      <div className="space-y-4">
        {/* Explanation */}
        {lesson.explanation_de && (
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-5">
              <h3 className="font-bold text-primary mb-2 flex items-center gap-2 text-sm">
                <BookOpen className="w-4 h-4" />Erklärung
              </h3>
              <p className="text-sm leading-relaxed whitespace-pre-line">{lesson.explanation_de}</p>
            </CardContent>
          </Card>
        )}

        {/* Memory trick */}
        {lesson.memory_trick && (
          <Card className="border-yellow-200 bg-yellow-50">
            <CardContent className="p-4">
              <h3 className="font-bold text-yellow-800 mb-2 flex items-center gap-2 text-sm">
                <Lightbulb className="w-4 h-4" />Merkhilfe
              </h3>
              <p className="text-sm text-yellow-800 whitespace-pre-line">{lesson.memory_trick}</p>
            </CardContent>
          </Card>
        )}

        {/* Examples */}
        {lesson.examples?.length > 0 && (
          <Card>
            <CardContent className="p-4">
              <h3 className="font-bold mb-3 text-sm">Beispiele</h3>
              <div className="space-y-3">
                {lesson.examples.map((ex, i) => (
                  <div key={i} className="border-l-4 border-primary/30 pl-3 py-0.5">
                    <p className="font-medium text-sm">🇬🇧 {ex.en}</p>
                    {ex.de && <p className="text-muted-foreground text-sm">🇩🇪 {ex.de}</p>}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Signal words */}
        {lesson.signal_words?.length > 0 && (
          <Card className="border-blue-100 bg-blue-50/50">
            <CardContent className="p-4">
              <h3 className="font-bold mb-3 text-sm text-blue-800">🔑 Signalwörter</h3>
              <div className="space-y-1.5">
                {lesson.signal_words.map((sw, i) => (
                  <p key={i} className="text-sm text-blue-800 bg-white/80 rounded-lg px-3 py-2">{sw}</p>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Counter examples */}
        {lesson.counter_examples?.length > 0 && (
          <Card className="border-destructive/20 bg-destructive/5">
            <CardContent className="p-4">
              <h3 className="font-bold text-destructive mb-3 flex items-center gap-2 text-sm">
                <X className="w-4 h-4" />Häufige Fehler
              </h3>
              <div className="space-y-2">
                {lesson.counter_examples.map((ex, i) => (
                  <p key={i} className="text-sm font-mono bg-white/60 rounded p-2">{ex}</p>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Checklist */}
        {lesson.checklist?.length > 0 && (
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-4">
              <h3 className="font-bold text-green-800 mb-3 flex items-center gap-2 text-sm">
                <Check className="w-4 h-4" />Checkliste vor dem Test
              </h3>
              <ul className="space-y-1.5">
                {lesson.checklist.map((item, i) => (
                  <li key={i} className="text-sm text-green-800 flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />{item}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        {/* Scaffolding selector */}
        <Card>
          <CardContent className="p-4">
            <ScaffoldingSelector selected={scaffolding} onChange={setScaffolding} grade={grade} />
          </CardContent>
        </Card>

        <Button onClick={onPractice} className="w-full gap-2 brand-gradient text-white border-0 shadow-sm font-black" size="lg">
          <Zap className="w-4 h-4" />
          Jetzt üben – {scaffolding === "with_help" ? "Mit Hilfe" : scaffolding === "challenge" ? "Challenge" : "Normal"}
        </Button>
      </div>
    </div>
  );
}

function GrammarPractice({ lesson, scaffolding, grade, onBack }) {
  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];
  const { awardXP } = useXP(user, profile);
  const queryClient = useQueryClient();
  const [qIndex, setQIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const [showMeta, setShowMeta] = useState(false);
  const [showXP, setShowXP] = useState(false);
  const [lastXP, setLastXP] = useState(0);

  const { data: allExercises = [] } = useQuery({
    queryKey: ["grammar-exercises", lesson.topic_key],
    queryFn: () => base44.entities.Exercise.filter({ topic_key: lesson.topic_key, skill_area: "grammar" }),
  });

  const exercises = allExercises.filter(ex => {
    if (scaffolding === "with_help") return ex.difficulty === "easy" || ex.difficulty === "medium";
    if (scaffolding === "challenge") return ex.difficulty === "medium" || ex.difficulty === "hard";
    return true;
  });

  const logAttempt = useMutation({
    mutationFn: (data) => base44.entities.ExerciseAttempt.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["recent-attempts"] }),
  });

  const current = exercises[qIndex];

  const handleSubmit = () => {
    if (!selected || !current) return;
    // Multiple choice: immediate exact check
    if (current.type === "multiple_choice") {
      const correct = selected === current.correct_answer;
      setSubmitted(true);
      if (correct) setScore(s => s + 1);
      const xpAmount = correct ? (current.xp_reward || 10) : 0;
      if (user) {
        logAttempt.mutate({
          user_email: user.email, exercise_id: current.id, skill_area: "grammar",
          topic_key: lesson.topic_key, grade: lesson.grade, is_correct: correct,
          user_answer: selected, correct_answer: current.correct_answer,
          attempt_date: new Date().toISOString().split("T")[0], xp_earned: xpAmount,
        });
        if (correct) { awardXP(xpAmount); setLastXP(xpAmount); setShowXP(true); }
      }
    } else {
      // All text-input types: just submit, AI evaluation happens in TransformationFeedback
      setSubmitted(true);
    }
  };

  // Called by TransformationFeedback after AI evaluation resolves
  const handleAIResult = (isAccepted) => {
    if (user) {
      const xpAmount = isAccepted ? (current.xp_reward || 10) : 0;
      logAttempt.mutate({
        user_email: user.email, exercise_id: current.id, skill_area: "grammar",
        topic_key: lesson.topic_key, grade: lesson.grade, is_correct: isAccepted,
        user_answer: selected, correct_answer: current.correct_answer,
        attempt_date: new Date().toISOString().split("T")[0], xp_earned: xpAmount,
      });
      if (isAccepted) { setScore(s => s + 1); awardXP(xpAmount); setLastXP(xpAmount); setShowXP(true); }
    }
    handleNext();
  };

  const handleNext = () => {
    if (qIndex < exercises.length - 1) {
      setQIndex(i => i + 1);
      setSelected(null);
      setSubmitted(false);
    } else {
      setDone(true);
    }
  };

  if (exercises.length === 0) {
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground mb-5">
          <ArrowLeft className="w-4 h-4" /> Zurück
        </button>
        <Card><CardContent className="p-8 text-center">
          <GraduationCap className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="font-bold mb-1">Noch keine Übungen für dieses Thema</p>
          <p className="text-sm text-muted-foreground">Kommen bald hinzu!</p>
        </CardContent></Card>
      </div>
    );
  }

  if (done && showMeta) {
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
        <MetacognitionPrompt exerciseScore={score} totalExercises={exercises.length} onDone={onBack} />
      </div>
    );
  }

  if (done) {
    const pct = Math.round((score / exercises.length) * 100);
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
        <Card className="text-center overflow-hidden">
          <div className={`h-2 w-full ${pct === 100 ? "bg-gradient-to-r from-green-400 to-emerald-500" : pct >= 60 ? "bg-gradient-to-r from-yellow-400 to-amber-500" : "bg-gradient-to-r from-red-400 to-rose-500"}`} />
          <CardContent className="p-8">
            <div className="text-5xl mb-4">{pct === 100 ? "🏆" : pct >= 60 ? "👍" : "💪"}</div>
            <h2 className="text-2xl font-black mb-1">{score} / {exercises.length} richtig</h2>
            <p className="text-muted-foreground text-sm mb-6">
              {pct === 100 ? "Perfekte Runde!" : pct >= 80 ? "Sehr gut gemacht!" : pct >= 60 ? "Gut – wiederhole die Fehler nochmal." : "Lies die Erklärung nochmal durch – du schaffst das!"}
            </p>
            <div className="flex gap-3 justify-center flex-wrap">
              <Button variant="outline" onClick={onBack}><RotateCcw className="w-4 h-4 mr-2" />Zurück</Button>
              <Button onClick={() => { setQIndex(0); setSelected(null); setSubmitted(false); setScore(0); setDone(false); }}>
                <Zap className="w-4 h-4 mr-2" />Nochmal
              </Button>
              <Button variant="secondary" onClick={() => setShowMeta(true)}><Brain className="w-4 h-4 mr-2" />Reflexion</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
      <XPToast amount={lastXP} show={showXP} onDone={() => setShowXP(false)} />
      <div className="flex items-center justify-between mb-4">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" /> Zurück
        </button>
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded-full">
            {scaffolding === "with_help" ? "🟢 Mit Hilfe" : scaffolding === "challenge" ? "🔴 Challenge" : "🟡 Normal"}
          </span>
          <span className="text-sm text-muted-foreground font-semibold">{qIndex + 1} / {exercises.length}</span>
        </div>
      </div>
      <div className="w-full h-1.5 bg-secondary rounded-full mb-6">
        <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${(qIndex / exercises.length) * 100}%` }} />
      </div>

      <Card>
        <CardContent className="p-6">
          <Badge className={cn("mb-3 border-0", DIFFICULTY_COLORS[current.difficulty])}>{DIFFICULTY_LABELS[current.difficulty]}</Badge>
          <h2 className="text-base font-bold mb-2">{current.question}</h2>
          {current.context_text && (
            <p className="text-sm text-muted-foreground bg-secondary/50 rounded-lg p-3 mb-4 italic">{current.context_text}</p>
          )}

          {current.type === "multiple_choice" && current.options && (
            <div className="space-y-2">
              {current.options.map(opt => (
                <button key={opt} onClick={() => !submitted && setSelected(opt)}
                  className={cn("w-full p-3 rounded-xl border-2 text-left text-sm font-medium transition-all",
                    submitted
                      ? opt === current.correct_answer ? "border-green-500 bg-green-50 text-green-800"
                        : opt === selected ? "border-destructive bg-destructive/5 text-destructive" : "border-border opacity-50"
                      : selected === opt ? "border-primary bg-primary/5" : "border-border hover:border-primary/40")}>
                  {opt}
                </button>
              ))}
            </div>
          )}

          {(current.type === "fill_blank" || current.type === "error_correction" || current.type === "sentence_transformation") && !submitted && (
            <input
              className="w-full p-3 rounded-xl border-2 border-border focus:border-primary outline-none text-sm mt-2"
              placeholder={current.type === "error_correction" ? "Korrigierter Satz..." : "Deine Antwort..."}
              value={selected || ""}
              onChange={e => setSelected(e.target.value)}
            />
          )}

          {!submitted && current.hint && scaffolding === "with_help" && (
            <div className="mt-3 p-3 rounded-lg bg-yellow-50 border border-yellow-200 flex items-start gap-2">
              <Lightbulb className="w-4 h-4 text-yellow-600 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-yellow-800">{current.hint}</p>
            </div>
          )}

          {submitted && current.type !== "multiple_choice" ? (
            <TransformationFeedback
              exercise={current}
              userAnswer={selected}
              onContinue={handleNext}
              onMarkCorrect={(counted) => handleAIResult(counted)}
            />
          ) : submitted && current.type === "multiple_choice" ? (
            <RichFeedback exercise={current} userAnswer={selected} onContinue={handleNext} />
          ) : null}

          {!submitted && (
            <div className="flex gap-3 mt-4">
              <Button onClick={handleSubmit} disabled={!selected} className="flex-1">Antworten</Button>
              {current.hint && scaffolding !== "with_help" && (
                <Button variant="outline" onClick={() => alert(current.hint)} className="gap-1">
                  <Lightbulb className="w-4 h-4" />Tipp
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}