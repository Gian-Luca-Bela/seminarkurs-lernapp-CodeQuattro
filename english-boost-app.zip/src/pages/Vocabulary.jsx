import { useState, useMemo, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Search, BookOpen, ChevronRight, Zap, Check, X, ArrowLeft } from "lucide-react";
import CollapsibleSection from "@/components/ui/CollapsibleSection";
import { DIFFICULTY_COLORS, DIFFICULTY_LABELS } from "@/lib/constants";
import { shuffleArray } from "@/lib/utils";
import XPToast from "@/components/XPToast";
import { useXP } from "@/lib/useXP";
import MySavedSets from "@/components/vocabulary/MySavedSets";

const THEME_ORDER = [
  "AC1: Across cultures 1",
  "Unit 1: Introduction",
  "Unit 1: Station 1",
  "Unit 1: Station 2",
  "Unit 1: Story",
  "Unit 1: Skills",
  "AC2: Across cultures 2",
  "Unit 2: Introduction",
  "Unit 2: Station 2",
  "Unit 2: Station 5",
  "Unit 2: Story",
  "Unit 2: Skills",
  "TS1: Introduction",
  "TS1: Station 1",
  "AC3: Across cultures 3",
  "TS2: Introduction",
  "TS2: Station 1",
  "TS2: Station 2",
  "Unit 3: Introduction",
  "Unit 3: Station 1",
  "Unit 3: Station 2",
  "Unit 3: American History",
  "Unit 3: Story",
  "AC4: Across cultures 4",
  "Unit 4: Introduction",
  "Unit 4: Station 1",
  "Unit 4: Station 2",
  "Unit 4: Story",
  "TS3: Introduction",
  "TS3: Station 1A",
  "TS3: Station 1B",
];

const THEME_COLORS = [
  { color: "bg-blue-50 border-blue-200 text-blue-700", dot: "bg-blue-400" },
  { color: "bg-emerald-50 border-emerald-200 text-emerald-700", dot: "bg-emerald-400" },
  { color: "bg-violet-50 border-violet-200 text-violet-700", dot: "bg-violet-400" },
  { color: "bg-orange-50 border-orange-200 text-orange-700", dot: "bg-orange-400" },
  { color: "bg-rose-50 border-rose-200 text-rose-700", dot: "bg-rose-400" },
  { color: "bg-amber-50 border-amber-200 text-amber-700", dot: "bg-amber-400" },
  { color: "bg-cyan-50 border-cyan-200 text-cyan-700", dot: "bg-cyan-400" },
  { color: "bg-teal-50 border-teal-200 text-teal-700", dot: "bg-teal-400" },
  { color: "bg-indigo-50 border-indigo-200 text-indigo-700", dot: "bg-indigo-400" },
  { color: "bg-pink-50 border-pink-200 text-pink-700", dot: "bg-pink-400" },
  { color: "bg-lime-50 border-lime-200 text-lime-700", dot: "bg-lime-400" },
];

const themeStyle = (theme) => {
  const idx = THEME_ORDER.indexOf(theme);
  if (idx >= 0) return THEME_COLORS[idx % THEME_COLORS.length];
  return { color: "bg-secondary border-border text-muted-foreground", dot: "bg-muted-foreground" };
};

export default function Vocabulary() {
  const [search, setSearch] = useState("");
  const [selectedTheme, setSelectedTheme] = useState("Alle");
  const [selectedGrade, setSelectedGrade] = useState(null);
  const [selectedWord, setSelectedWord] = useState(null);
  const [flashcardMode, setFlashcardMode] = useState(false);
  const [flashcardIndex, setFlashcardIndex] = useState(0);
  const [flashcardFlipped, setFlashcardFlipped] = useState(false);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];

  useEffect(() => {
    if (profile?.grade) setSelectedGrade(profile.grade);
    else setSelectedGrade("8");
  }, [profile?.grade]);

  const { awardXP } = useXP(user, profile);
  const [showXP, setShowXP] = useState(false);
  const [lastXP, setLastXP] = useState(0);

  const { data: words = [], isLoading } = useQuery({
    queryKey: ["vocabulary"],
    queryFn: () => base44.entities.VocabularyItem.list("created_date", 1000),
  });

  // Derive ordered themes from insertion order (created_date ASC)
  const themes = useMemo(() => {
    const seen = new Set();
    const ordered = [];
    words.forEach(w => {
      if (w.theme && !seen.has(w.theme)) { seen.add(w.theme); ordered.push(w.theme); }
    });
    return ["Alle", ...ordered];
  }, [words]);

  const filtered = useMemo(() => words.filter(w => {
    const matchSearch = !search || w.word.toLowerCase().includes(search.toLowerCase()) || w.translation_de?.toLowerCase().includes(search.toLowerCase());
    const matchTheme = selectedTheme === "Alle" || w.theme === selectedTheme;
    const matchGrade = !selectedGrade || w.grade === selectedGrade || w.grade === "both";
    return matchSearch && matchTheme && matchGrade;
  }), [words, search, selectedTheme, selectedGrade]);

  // Stable shuffled deck – only reshuffled when flashcard mode is first entered,
  // not on every render. We store it in a ref so mutations/XP toasts never affect it.
  const flashcardDeckRef = useRef([]);
  const prevFilteredRef = useRef(null);

  // Rebuild deck only when entering flashcard mode fresh (flashcardIndex === 0 and filtered changed)
  if (flashcardMode && prevFilteredRef.current !== filtered) {
    flashcardDeckRef.current = shuffleArray([...filtered]);
    prevFilteredRef.current = filtered;
  }

  const flashcards = flashcardDeckRef.current;
  const currentCard = flashcards[flashcardIndex];

  const logAttempt = useMutation({
    mutationFn: (data) => base44.entities.ExerciseAttempt.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["recent-attempts"] }),
  });

  // Lock to prevent double-firing if the user clicks both buttons quickly
  const answeringRef = useRef(false);

  const handleFlashcardAnswer = (correct) => {
    if (answeringRef.current) return;
    answeringRef.current = true;

    // Capture card reference NOW before any state update
    const card = currentCard;

    if (user && card) {
      logAttempt.mutate({
        user_email: user.email,
        exercise_id: card.id,
        skill_area: "vocabulary",
        topic_key: card.theme,
        grade: card.grade,
        is_correct: correct,
        attempt_date: new Date().toISOString().split("T")[0],
        xp_earned: correct ? 10 : 0,
      });
      if (correct) {
        awardXP(10);
        setLastXP(10);
        setShowXP(true);
      }
    }

    // Small delay so the user sees the flipped state before switching
    setTimeout(() => {
      setFlashcardFlipped(false);
      if (flashcardIndex < flashcards.length - 1) {
        setFlashcardIndex(i => i + 1);
      } else {
        setFlashcardIndex(0);
        setFlashcardMode(false);
        prevFilteredRef.current = null; // allow reshuffle on next entry
      }
      answeringRef.current = false;
    }, 200);
  };

  // ── Flashcard Mode ──────────────────────────────────────
  if (flashcardMode && currentCard) {
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
        <XPToast amount={lastXP} show={showXP} onDone={() => setShowXP(false)} />
        <div className="flex items-center gap-3 mb-5">
          <Button variant="outline" size="sm" onClick={() => setFlashcardMode(false)} className="gap-1.5">
            <ArrowLeft className="w-4 h-4" /> Beenden
          </Button>
          <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${(flashcardIndex / flashcards.length) * 100}%` }} />
          </div>
          <span className="text-sm text-muted-foreground font-semibold whitespace-nowrap">{flashcardIndex + 1} / {flashcards.length}</span>
        </div>

        <div className="mb-4" onClick={() => !flashcardFlipped && setFlashcardFlipped(true)} style={{ cursor: flashcardFlipped ? "default" : "pointer" }}>
          <Card className={cn("min-h-56 flex flex-col items-center justify-center text-center p-8 transition-all duration-300 border-2 select-none",
            flashcardFlipped ? "border-primary bg-primary/5" : "border-border hover:border-primary/40")}>
            <CardContent className="p-0 w-full">
              {!flashcardFlipped ? (
                <div>
                  <div className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold mb-5 border", themeStyle(currentCard.theme).color)}>
                    <span className={cn("w-1.5 h-1.5 rounded-full", themeStyle(currentCard.theme).dot)} />
                    {currentCard.theme}
                  </div>
                  <p className="text-4xl font-bold mb-4">{currentCard.word}</p>
                  <p className="text-sm text-muted-foreground">Tippe, um die Übersetzung zu sehen →</p>
                </div>
              ) : (
                <div>
                  <p className="text-xs text-muted-foreground mb-3 uppercase tracking-wider">Lösung</p>
                  <p className="text-3xl font-bold text-primary mb-3">{currentCard.translation_de}</p>
                  {currentCard.example_sentence && (
                    <p className="text-muted-foreground italic text-sm mb-3">"{currentCard.example_sentence}"</p>
                  )}
                  {currentCard.is_false_friend && (
                    <div className="bg-red-50 border border-red-200 rounded-xl p-2.5 mt-2 text-xs text-red-700">
                      🚨 False Friend!
                    </div>
                  )}
                  {currentCard.common_mistake && !currentCard.is_false_friend && (
                    <div className="bg-orange-50 border border-orange-200 rounded-xl p-2.5 mt-2 text-xs text-orange-700">
                      ⚠️ {currentCard.common_mistake}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {flashcardFlipped && (
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => handleFlashcardAnswer(false)} className="flex-1 gap-2 border-destructive/30 text-destructive hover:bg-destructive/5 h-12">
              <X className="w-4 h-4" /> Noch nicht
            </Button>
            <Button onClick={() => handleFlashcardAnswer(true)} className="flex-1 gap-2 h-12">
              <Check className="w-4 h-4" /> Gewusst!
            </Button>
          </div>
        )}
      </div>
    );
  }

  // ── Word Detail ──────────────────────────────────────────
  if (selectedWord) {
    return <WordDetail word={selectedWord} onClose={() => setSelectedWord(null)} />;
  }

  // ── Main List ────────────────────────────────────────────
  const groupedByTheme = selectedTheme === "Alle" && !search
    ? themes.filter(t => t !== "Alle").reduce((acc, theme) => {
        const themeWords = filtered.filter(w => w.theme === theme);
        if (themeWords.length > 0) acc[theme] = themeWords;
        return acc;
      }, {})
    : null;

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-black flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-2xl bg-emerald-100 flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-5 h-5 text-emerald-600" />
            </span>
            Vokabeln
          </h1>
          <p className="text-muted-foreground text-sm mt-1 ml-12">{words.length} Wörter · mit Beispielen & Tipps</p>
        </div>
        <Button
          onClick={() => {
            prevFilteredRef.current = null; // force reshuffle
            setFlashcardIndex(0);
            setFlashcardFlipped(false);
            setFlashcardMode(true);
          }}
          disabled={filtered.length === 0}
          className="gap-2 rounded-xl font-bold shrink-0"
        >
          <Zap className="w-4 h-4" /> Karteikarten ({filtered.length})
        </Button>
      </div>

      {/* Saved sets */}
      <MySavedSets user={user} />

      {/* Filters */}
      <div className="space-y-3 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Wort oder Übersetzung suchen..." className="pl-9" />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1">
          {themes.map(t => (
            <button key={t} onClick={() => setSelectedTheme(t)}
              className={cn("px-3.5 py-1.5 rounded-full text-sm whitespace-nowrap transition-all border font-medium",
                selectedTheme === t
                  ? "bg-foreground text-background border-foreground"
                  : "bg-card text-muted-foreground border-border hover:text-foreground hover:border-border/80")}>
              {t}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {Array(6).fill(0).map((_, i) => <div key={i} className="h-28 bg-secondary rounded-2xl animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center py-16 text-center">
          <div className="w-16 h-16 rounded-3xl bg-emerald-50 flex items-center justify-center mb-4 border border-emerald-100">
            <BookOpen className="w-8 h-8 text-emerald-300" />
          </div>
          <p className="font-black text-sm text-foreground mb-1">Keine Wörter gefunden</p>
          <p className="text-xs text-muted-foreground max-w-xs">Probiere eine andere Suche oder lade Demo-Daten unter „Demo-Daten" in der Seitenleiste.</p>
        </div>
      ) : groupedByTheme ? (
        // Grouped view by theme → section — collapsible sections
        <div className="space-y-3">
          {Object.entries(groupedByTheme).map(([theme, themeWords], idx) => {
            const ts = themeStyle(theme);
            // Group by section within theme
            const sections = [];
            const sectionMap = {};
            themeWords.forEach(w => {
              const sec = w.section || "";
              if (!sectionMap[sec]) { sectionMap[sec] = []; sections.push(sec); }
              sectionMap[sec].push(w);
            });
            const hasMultipleSections = sections.filter(Boolean).length > 1;
            return (
              <CollapsibleSection
                key={theme}
                title={theme}
                count={themeWords.length}
                countLabel="Wörter"
                dotColor={ts.dot}
                defaultOpen={idx === 0}
              >
                {hasMultipleSections ? (
                  <div className="space-y-4">
                    {sections.map(sec => (
                      <div key={sec}>
                        {sec && <p className="text-sm font-black text-primary uppercase tracking-wider mb-3 ml-1 flex items-center gap-2"><span className="inline-block w-1 h-4 rounded-full bg-primary opacity-70"/>{sec}</p>}
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                          {sectionMap[sec].map(word => (
                            <WordCard key={word.id} word={word} onClick={() => setSelectedWord(word)} />
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {themeWords.map(word => (
                      <WordCard key={word.id} word={word} onClick={() => setSelectedWord(word)} />
                    ))}
                  </div>
                )}
              </CollapsibleSection>
            );
          })}
        </div>
      ) : (
        // Flat view (search/filter active)
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map(word => (
            <WordCard key={word.id} word={word} onClick={() => setSelectedWord(word)} />
          ))}
        </div>
      )}
    </div>
  );
}

function WordCard({ word, onClick }) {
  const ts = themeStyle(word.theme);
  return (
    <Card className="cursor-pointer border-border/60 hover:border-primary/30 hover:shadow-md transition-all duration-150 group" onClick={onClick}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2.5">
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-base leading-tight">{word.word}</h3>
            <p className="font-semibold text-primary text-sm mt-0.5">{word.translation_de}</p>
          </div>
          <div className="flex flex-col items-end gap-1 flex-shrink-0">
            {word.part_of_speech && (
              <Badge variant="outline" className="text-[11px] px-1.5 py-0">{word.part_of_speech}</Badge>
            )}
            {word.difficulty && (
              <span className={cn("text-[10px] px-1.5 py-0.5 rounded-full font-semibold", DIFFICULTY_COLORS[word.difficulty])}>
                {DIFFICULTY_LABELS[word.difficulty]}
              </span>
            )}
          </div>
        </div>
        {word.example_sentence && (
          <p className="text-xs text-muted-foreground line-clamp-1 italic mb-2.5">"{word.example_sentence}"</p>
        )}
        <div className="flex items-center justify-between">
          {word.theme && (
            <span className={cn("inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full border", ts.color)}>
              <span className={cn("w-1.5 h-1.5 rounded-full", ts.dot)} />
              {word.theme}
            </span>
          )}
          {word.is_false_friend && (
            <span className="text-[11px] font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded-full border border-red-200 ml-auto">
              False Friend
            </span>
          )}
          <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto group-hover:text-primary transition-colors" />
        </div>
      </CardContent>
    </Card>
  );
}

function WordDetail({ word, onClose }) {
  const ts = themeStyle(word.theme);
  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-in">
      {/* Back button */}
      <button
        onClick={onClose}
        className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors mb-5 group"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        Zurück zur Übersicht
      </button>

      {/* Word header */}
      <div className="bg-card border border-border rounded-2xl p-5 mb-4">
        <div className="flex items-start justify-between gap-4 mb-3">
          <div>
            <h1 className="text-3xl font-black">{word.word}</h1>
            <p className="text-2xl font-bold text-primary mt-1">{word.translation_de}</p>
          </div>
          <div className="flex flex-col items-end gap-1.5">
            {word.part_of_speech && <Badge variant="outline">{word.part_of_speech}</Badge>}
            {word.grade && <Badge className="bg-blue-100 text-blue-700 border-0 font-bold">Klasse {word.grade}</Badge>}
            {word.difficulty && <span className={cn("text-xs px-2 py-0.5 rounded-full font-semibold", DIFFICULTY_COLORS[word.difficulty])}>{DIFFICULTY_LABELS[word.difficulty]}</span>}
          </div>
        </div>
        {word.theme && (
          <span className={cn("inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full border", ts.color)}>
            <span className={cn("w-1.5 h-1.5 rounded-full", ts.dot)} />{word.theme}
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-4">
          {/* Definitions */}
          <Card>
            <CardContent className="p-4 space-y-3">
              <div>
                <p className="text-[10px] font-black text-muted-foreground uppercase tracking-wider mb-1">Englische Definition</p>
                <p className="text-sm leading-relaxed">{word.definition_en}</p>
              </div>
              {word.definition_de && (
                <div>
                  <p className="text-[10px] font-black text-muted-foreground uppercase tracking-wider mb-1">Deutsche Erklärung</p>
                  <p className="text-sm leading-relaxed">{word.definition_de}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Examples */}
          {word.example_sentence && (
            <Card className="border-primary/20 bg-primary/3">
              <CardContent className="p-4">
                <p className="text-[10px] font-black text-muted-foreground uppercase tracking-wider mb-2">Beispielsätze</p>
                <p className="italic text-sm leading-relaxed">"{word.example_sentence}"</p>
                {word.example_sentence_2 && <p className="italic text-sm leading-relaxed mt-2">"{word.example_sentence_2}"</p>}
              </CardContent>
            </Card>
          )}
        </div>

        <div className="space-y-4">
          {/* Synonyms / Antonyms */}
          {(word.synonyms?.length > 0 || word.antonyms?.length > 0) && (
            <Card>
              <CardContent className="p-4 space-y-3">
                {word.synonyms?.length > 0 && (
                  <div>
                    <p className="text-[10px] font-black text-muted-foreground uppercase tracking-wider mb-2">Synonyme</p>
                    <div className="flex flex-wrap gap-1.5">
                      {word.synonyms.map(s => <Badge key={s} className="bg-green-100 text-green-700 border-0 text-xs">{s}</Badge>)}
                    </div>
                  </div>
                )}
                {word.antonyms?.length > 0 && (
                  <div>
                    <p className="text-[10px] font-black text-muted-foreground uppercase tracking-wider mb-2">Antonyme</p>
                    <div className="flex flex-wrap gap-1.5">
                      {word.antonyms.map(a => <Badge key={a} className="bg-red-100 text-red-700 border-0 text-xs">{a}</Badge>)}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Collocations */}
          {word.collocations?.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <p className="text-[10px] font-black text-muted-foreground uppercase tracking-wider mb-2">Typische Verbindungen</p>
                <div className="flex flex-wrap gap-1.5">
                  {word.collocations.map(c => <Badge key={c} variant="secondary" className="text-xs">{c}</Badge>)}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Word family */}
          {word.word_family?.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <p className="text-[10px] font-black text-muted-foreground uppercase tracking-wider mb-2">Wortfamilie</p>
                <div className="flex flex-wrap gap-1.5">
                  {word.word_family.map(w => <Badge key={w} variant="outline" className="text-xs">{w}</Badge>)}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Common mistake */}
          {word.common_mistake && !word.is_false_friend && (
            <Card className="border-orange-200 bg-orange-50">
              <CardContent className="p-4">
                <p className="text-xs font-black text-orange-600 uppercase tracking-wider mb-1">⚠️ Typischer Fehler</p>
                <p className="text-sm text-orange-800">{word.common_mistake}</p>
              </CardContent>
            </Card>
          )}

          {/* False friend */}
          {word.is_false_friend && word.false_friend_note && (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-4">
                <p className="text-xs font-black text-red-600 uppercase tracking-wider mb-1">🚨 False Friend!</p>
                <p className="text-sm text-red-800">{word.false_friend_note}</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}