import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useTheme, THEMES } from "@/lib/ThemeContext";
import {
  Settings, GraduationCap, Clock, Brain, Target, Palette,
  Check, LogOut, CalendarCheck, Shield, TrendingUp, BarChart3
} from "lucide-react";

// ── Option definitions ────────────────────────────────────────────────────────

const GRADES = [
  { value: "8", label: "Klasse 8", desc: "Grundkurs Englisch 8" },
  { value: "9", label: "Klasse 9", desc: "Grundkurs Englisch 9" },
];

const DAILY_MINUTES_OPTIONS = [10, 15, 20, 30, 45, 60];

const LEARNING_STYLES = [
  { value: "gemischt",      label: "Gemischt",        emoji: "🎭", desc: "Abwechslung aus allem" },
  { value: "kurz_intensiv", label: "Kurz & intensiv", emoji: "⚡", desc: "Schnelle, kompakte Einheiten" },
  { value: "uebungen",      label: "Viele Übungen",   emoji: "🧩", desc: "Drill & Multiple-Choice" },
  { value: "kreativ",       label: "Kreativ",         emoji: "🎨", desc: "Texte & kreatives Schreiben" },
  { value: "schreiben",     label: "Schwerpunkt Schreiben", emoji: "✍️", desc: "Viel Schreiben & Feedback" },
];

const SKILL_AREAS = [
  { value: "vocabulary",  label: "Vokabeln",    emoji: "📚" },
  { value: "grammar",     label: "Grammatik",   emoji: "⚙️" },
  { value: "reading",     label: "Lesen",       emoji: "📖" },
  { value: "writing",     label: "Schreiben",   emoji: "✏️" },
  { value: "listening",   label: "Hören",       emoji: "🎧" },
  { value: "speaking",    label: "Sprechen",    emoji: "🗣️" },
  { value: "mediation",   label: "Mediation",   emoji: "🔄" },
];

const DIFFICULTY_OPTIONS = [
  { value: "easy",   label: "Leicht",  desc: "Einfache Aufgaben, mehr Hilfe", emoji: "🌱" },
  { value: "medium", label: "Mittel",  desc: "Ausgewogene Herausforderung",   emoji: "🔥" },
  { value: "hard",   label: "Schwer",  desc: "Anspruchsvoll, wenig Hilfe",    emoji: "🏆" },
];

const SCAFFOLDING_OPTIONS = [
  { value: 1, label: "Viel Unterstützung",    desc: "Immer Tipps & Hinweise", emoji: "🤝" },
  { value: 2, label: "Etwas Unterstützung",   desc: "Hinweise auf Anfrage",   emoji: "💡" },
  { value: 3, label: "Keine Unterstützung",   desc: "Eigenständig lösen",     emoji: "🦅" },
];

const DAILY_PLAN_STYLE_OPTIONS = [
  { value: "balanced",   label: "Ausgewogen",        desc: "Gleichmäßig alle Bereiche", emoji: "⚖️" },
  { value: "weak_focus", label: "Schwächen zuerst",  desc: "Mehr Zeit für Lücken",      emoji: "🎯" },
  { value: "exam_prep",  label: "Test-Vorbereitung", desc: "Klausur-orientiertes Üben", emoji: "📋" },
];

const GOALS = [
  { value: "test",         label: "Vokabeltest bestehen", emoji: "📝" },
  { value: "klassenarbeit", label: "Klassenarbeit vorbereiten", emoji: "📋" },
  { value: "langfristig",  label: "Langfristig verbessern", emoji: "📈" },
  { value: "luecken",      label: "Lücken schließen", emoji: "🎯" },
];

// ── Section wrapper ───────────────────────────────────────────────────────────

function Section({ icon: Icon, title, subtitle, children }) {
  return (
    <div className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
      <div className="flex items-start gap-3 px-5 py-4 border-b border-border/60 bg-muted/30">
        <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
          <Icon className="w-4 h-4 text-primary" />
        </div>
        <div>
          <h2 className="font-bold text-sm">{title}</h2>
          {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
        </div>
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

// ── Option button ─────────────────────────────────────────────────────────────

function OptionBtn({ selected, onClick, children, className }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "relative p-3 rounded-xl border-2 text-left transition-all",
        selected
          ? "border-primary bg-primary/5 text-primary"
          : "border-border hover:border-primary/40 hover:bg-muted/40",
        className
      )}
    >
      {selected && (
        <span className="absolute top-2 right-2 w-4 h-4 rounded-full bg-primary flex items-center justify-center">
          <Check className="w-2.5 h-2.5 text-white" />
        </span>
      )}
      {children}
    </button>
  );
}

// ── Tag toggle ────────────────────────────────────────────────────────────────

function TagToggle({ selected, onClick, emoji, label }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-1.5 px-3 py-2 rounded-xl border-2 text-sm font-medium transition-all",
        selected ? "border-primary bg-primary/5 text-primary" : "border-border hover:border-primary/30"
      )}
    >
      <span>{emoji}</span>
      <span>{label}</span>
      {selected && <Check className="w-3 h-3 ml-0.5" />}
    </button>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

export default function SettingsPage() {
  const queryClient = useQueryClient();
  const { themeId, setThemeId } = useTheme();

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles, isLoading } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];

  const [form, setForm] = useState(null);
  const [saved, setSaved] = useState(false);

  // Initialise form once profile loads
  if (profile && !form) {
    setForm({
      grade:             profile.grade             || "8",
      daily_minutes:     profile.daily_minutes     || 20,
      learning_style:    profile.learning_style    || "gemischt",
      weak_areas:        profile.weak_areas        || [],
      goals:             profile.goals             || [],
      preferred_difficulty: profile.preferred_difficulty || "medium",
      scaffolding_level: profile.scaffolding_level ?? 2,
      daily_plan_style:  profile.daily_plan_style  || "balanced",
      wants_daily_plan:  profile.wants_daily_plan  ?? true,
    });
  }

  const updateProfile = useMutation({
    mutationFn: (data) => base44.entities.UserProfile.update(profile.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-profile"] });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    },
  });

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));
  const toggleArr = (key, val) => setForm(f => ({
    ...f,
    [key]: f[key].includes(val) ? f[key].filter(v => v !== val) : [...f[key], val],
  }));

  if (isLoading || !form) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in pb-10">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold flex items-center gap-2">
            <Settings className="w-6 h-6 text-primary" />
            Einstellungen
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Personalisiere dein Lern-Erlebnis</p>
        </div>
        <Button
          onClick={() => updateProfile.mutate(form)}
          disabled={updateProfile.isPending}
          className={cn("gap-2 transition-all", saved && "bg-green-600 hover:bg-green-600")}
        >
          {saved ? <><Check className="w-4 h-4" />Gespeichert!</> : updateProfile.isPending ? "Speichern…" : "Speichern"}
        </Button>
      </div>

      <div className="space-y-4">

        {/* ── 1. Klasse ── */}
        <Section icon={GraduationCap} title="Klassenstufe" subtitle="Inhalte werden auf deine Klasse angepasst">
          <div className="grid grid-cols-2 gap-3">
            {GRADES.map(g => (
              <OptionBtn key={g.value} selected={form.grade === g.value} onClick={() => set("grade", g.value)}>
                <p className="font-bold text-sm">{g.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{g.desc}</p>
              </OptionBtn>
            ))}
          </div>
        </Section>

        {/* ── 2. Lernziele ── */}
        <Section icon={Target} title="Lernziele" subtitle="Was möchtest du erreichen? (Mehrfachauswahl)">
          <div className="flex flex-wrap gap-2">
            {GOALS.map(g => (
              <TagToggle
                key={g.value}
                selected={form.goals.includes(g.value)}
                onClick={() => toggleArr("goals", g.value)}
                emoji={g.emoji}
                label={g.label}
              />
            ))}
          </div>
        </Section>

        {/* ── 3. Tägliche Lernzeit ── */}
        <Section icon={Clock} title="Tägliche Lernzeit" subtitle="Wie viel Zeit hast du pro Tag?">
          <div className="grid grid-cols-3 gap-2">
            {DAILY_MINUTES_OPTIONS.map(min => (
              <OptionBtn
                key={min}
                selected={form.daily_minutes === min}
                onClick={() => set("daily_minutes", min)}
              >
                <p className="font-bold text-sm text-center">{min} Min.</p>
              </OptionBtn>
            ))}
          </div>
        </Section>

        {/* ── 4. Tagesplan ── */}
        <Section icon={CalendarCheck} title="Tagesplan-Stil" subtitle="Wie soll dein täglicher Lernplan aussehen?">
          <div className="flex items-center gap-3 p-3 rounded-xl border border-border bg-secondary/30 mb-3">
            <div className="flex-1">
              <p className="text-sm font-semibold">Täglicher Lernplan aktiv</p>
              <p className="text-xs text-muted-foreground">Dashboard zeigt dir täglich personalisierte Aufgaben</p>
            </div>
            <button
              onClick={() => set("wants_daily_plan", !form.wants_daily_plan)}
              className={cn(
                "relative w-11 h-6 rounded-full transition-colors flex-shrink-0",
                form.wants_daily_plan ? "bg-primary" : "bg-border"
              )}
            >
              <span className={cn(
                "absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform",
                form.wants_daily_plan && "translate-x-5"
              )} />
            </button>
          </div>
          {form.wants_daily_plan && (
            <div className="space-y-2">
              {DAILY_PLAN_STYLE_OPTIONS.map(opt => (
                <OptionBtn
                  key={opt.value}
                  selected={form.daily_plan_style === opt.value}
                  onClick={() => set("daily_plan_style", opt.value)}
                  className="w-full"
                >
                  <div className="flex items-center gap-3 pr-5">
                    <span className="text-xl">{opt.emoji}</span>
                    <div>
                      <p className="font-bold text-sm">{opt.label}</p>
                      <p className="text-xs text-muted-foreground">{opt.desc}</p>
                    </div>
                  </div>
                </OptionBtn>
              ))}
            </div>
          )}
        </Section>

        {/* ── 5. Lernstil ── */}
        <Section icon={Brain} title="Lernstil" subtitle="Wie möchtest du am liebsten üben?">
          <div className="space-y-2">
            {LEARNING_STYLES.map(s => (
              <OptionBtn
                key={s.value}
                selected={form.learning_style === s.value}
                onClick={() => set("learning_style", s.value)}
                className="w-full"
              >
                <div className="flex items-center gap-3 pr-5">
                  <span className="text-xl">{s.emoji}</span>
                  <div>
                    <p className="font-bold text-sm">{s.label}</p>
                    <p className="text-xs text-muted-foreground">{s.desc}</p>
                  </div>
                </div>
              </OptionBtn>
            ))}
          </div>
        </Section>

        {/* ── 6. Schwächen ── */}
        <Section icon={TrendingUp} title="Schwache Bereiche" subtitle="Wo willst du dich verbessern? (Mehrfachauswahl)">
          <div className="grid grid-cols-2 gap-2">
            {SKILL_AREAS.map(area => {
              const sel = form.weak_areas.includes(area.value);
              return (
                <button
                  key={area.value}
                  onClick={() => toggleArr("weak_areas", area.value)}
                  className={cn(
                    "flex items-center gap-2.5 p-3 rounded-xl border-2 text-sm font-medium transition-all",
                    sel ? "border-primary bg-primary/5 text-primary" : "border-border hover:border-primary/30"
                  )}
                >
                  <span className="text-base">{area.emoji}</span>
                  <span>{area.label}</span>
                  {sel && <Check className="w-3.5 h-3.5 ml-auto" />}
                </button>
              );
            })}
          </div>
        </Section>

        {/* ── 7. Schwierigkeitsgrad ── */}
        <Section icon={BarChart3} title="Aufgaben-Schwierigkeit" subtitle="Standard-Schwierigkeit für neue Aufgaben">
          <div className="grid grid-cols-3 gap-2">
            {DIFFICULTY_OPTIONS.map(opt => (
              <OptionBtn
                key={opt.value}
                selected={form.preferred_difficulty === opt.value}
                onClick={() => set("preferred_difficulty", opt.value)}
              >
                <div className="text-center">
                  <div className="text-2xl mb-1">{opt.emoji}</div>
                  <p className="font-bold text-xs">{opt.label}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5 leading-tight">{opt.desc}</p>
                </div>
              </OptionBtn>
            ))}
          </div>
        </Section>

        {/* ── 8. Unterstützungsniveau ── */}
        <Section icon={Shield} title="Unterstützungs-Niveau" subtitle="Wie viel Hilfe möchtest du bei Aufgaben?">
          <div className="space-y-2">
            {SCAFFOLDING_OPTIONS.map(opt => (
              <OptionBtn
                key={opt.value}
                selected={form.scaffolding_level === opt.value}
                onClick={() => set("scaffolding_level", opt.value)}
                className="w-full"
              >
                <div className="flex items-center gap-3 pr-5">
                  <span className="text-xl">{opt.emoji}</span>
                  <div>
                    <p className="font-bold text-sm">{opt.label}</p>
                    <p className="text-xs text-muted-foreground">{opt.desc}</p>
                  </div>
                </div>
              </OptionBtn>
            ))}
          </div>
        </Section>

        {/* ── 9. App-Design ── */}
        <Section icon={Palette} title="App-Design" subtitle="Wähle dein Farbschema">
          <div className="grid grid-cols-2 gap-2">
            {THEMES.map(theme => (
              <button
                key={theme.id}
                onClick={() => setThemeId(theme.id)}
                className={cn(
                  "p-3 rounded-xl border-2 text-left transition-all relative",
                  themeId === theme.id
                    ? "border-primary ring-2 ring-primary/20"
                    : "border-border hover:border-primary/40"
                )}
              >
                {theme.preview && (
                  <div className="flex gap-1 mb-2 rounded overflow-hidden">
                    {theme.preview.map((color, ci) => (
                      <div key={ci} className="h-4 flex-1 rounded-sm" style={{ backgroundColor: color }} />
                    ))}
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <span>{theme.emoji}</span>
                  <p className="font-bold text-xs">{theme.label}</p>
                  {themeId === theme.id && (
                    <div className="ml-auto w-4 h-4 rounded-full bg-primary flex items-center justify-center">
                      <Check className="w-2.5 h-2.5 text-white" />
                    </div>
                  )}
                </div>
                <p className="text-[10px] text-muted-foreground mt-0.5">{theme.desc}</p>
              </button>
            ))}
          </div>
        </Section>

        {/* ── Save button (bottom) ── */}
        <Button
          onClick={() => updateProfile.mutate(form)}
          disabled={updateProfile.isPending}
          className={cn("w-full h-12 text-base font-bold gap-2", saved && "bg-green-600 hover:bg-green-600")}
        >
          {saved
            ? <><Check className="w-5 h-5" />Einstellungen gespeichert!</>
            : updateProfile.isPending
              ? "Speichern…"
              : "Einstellungen speichern"}
        </Button>

        {/* ── Logout ── */}
        <button
          onClick={() => base44.auth.logout()}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-destructive/20 text-destructive text-sm font-semibold hover:bg-destructive/5 transition-colors"
        >
          <LogOut className="w-4 h-4" />Abmelden
        </button>

      </div>
    </div>
  );
}