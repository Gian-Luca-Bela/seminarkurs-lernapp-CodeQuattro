import { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { useCompletedTasks } from "@/lib/useCompletedTasks";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { FileText, ChevronRight, BookOpen, Check, X, Lightbulb, Clock, ArrowLeft, Sparkles, Plus, Loader2, RefreshCw, Zap } from "lucide-react";
import { MASCOT_WRONG_MESSAGES, MASCOT_CELEBRATE_MESSAGES } from "@/lib/constants";
import { calculateExerciseXP } from "@/lib/xpSystem";
import XPToast from "@/components/XPToast";
import { useXP } from "@/lib/useXP";
import { DIFFICULTY_COLORS, DIFFICULTY_LABELS } from "@/lib/constants";
import GenerateTextModal from "@/components/reading/GenerateTextModal";

const TEXT_TYPE_LABELS = {
  article: "Artikel", narrative: "Erzählung", dialogue: "Dialog",
  report: "Bericht", blog_post: "Blog Post", letter: "Brief",
  factual: "Sachtext", review: "Rezension"
};

export default function Reading() {
  const [selectedText, setSelectedText] = useState(null);
  const [readingMode, setReadingMode] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [triggeringDaily, setTriggeringDaily] = useState(false);

  const queryClient = useQueryClient();

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });

  const effectiveGrade = profiles?.[0]?.grade || "8";

  const location = useLocation();
  const repeatTaskId = location.state?.taskId;
  const [isRepeatMode, setIsRepeatMode] = useState(false);
  const autoSelectedRef = useRef(false);
  const { completedTasks, markComplete } = useCompletedTasks(user?.email);
  const completedIds = new Set(completedTasks.filter(c => c.task_type === 'reading').map(c => c.task_id));

  const { data: texts = [], isLoading } = useQuery({
    queryKey: ["reading-texts"],
    queryFn: () => base44.entities.ReadingText.list("-created_date", 50),
  });

  const CLASS8_TOPICS = [
    { label: "Kids in America", topic: "Kids in America – teen life and school", textType: "article" },
    { label: "New York City", topic: "City of dreams: New York", textType: "narrative" },
    { label: "Thanksgiving", topic: "Thanksgiving – an American holiday", textType: "factual" },
    { label: "Werbung / Ads", topic: "Advertisements and consumer culture", textType: "article" },
    { label: "Schulregeln", topic: "School rules – dos and don'ts", textType: "dialogue" },
    { label: "Pacific Northwest", topic: "The Pacific Northwest – nature and people", textType: "report" },
    { label: "Internet & Hoaxes", topic: "Internet hoaxes and fake news", textType: "article" },
    { label: "Native Americans", topic: "Native Americans – history and present", textType: "factual" },
    { label: "American Inventions", topic: "A nation invents itself – American inventions", textType: "factual" },
    { label: "Travel texts", topic: "Travel to the USA – blog and guide", textType: "blog_post" },
  ];

  const CLASS9_TOPICS = [
    { label: "World Englishes", topic: "English as a global language – different varieties worldwide", textType: "article" },
    { label: "Australia", topic: "G'day Australia – life, culture and landscape Down Under", textType: "factual" },
    { label: "South Africa", topic: "South Africa – rainbow nation, languages and diversity", textType: "report" },
    { label: "India & English", topic: "English in India – history, use and importance today", textType: "article" },
    { label: "Tolerance & Respect", topic: "The language of tolerance and respect – diversity in society", textType: "article" },
    { label: "Food & Lifestyle", topic: "The good life? – food culture, health and lifestyle choices", textType: "blog_post" },
    { label: "California Dreaming", topic: "California dreaming – Hollywood, nature and the American Dream", textType: "narrative" },
    { label: "Cause & Effect", topic: "Cause and effect – environmental and social issues in California", textType: "report" },
    { label: "Letters to Editor", topic: "Letters to the editor – argumentative writing and having a voice", textType: "letter" },
    { label: "Short Films", topic: "A short film – analysing film language and narrative", textType: "article" },
  ];

  const handleGenerateText = async (topicObj, difficulty) => {
    setGenerating(true);
    try {
      const res = await base44.functions.invoke("anthropicAI", {
        task: "generate_reading",
        payload: { topic: topicObj.topic, textType: topicObj.textType, grade: effectiveGrade, difficulty }
      });
      await base44.entities.ReadingText.create({ ...res.data, grade: effectiveGrade, content_type: "reading" });
      queryClient.invalidateQueries({ queryKey: ["reading-texts"] });
    } finally {
      setGenerating(false);
    }
  };

  const handleTriggerDaily = async () => {
    setTriggeringDaily(true);
    try {
      await base44.functions.invoke("dailyContentGenerator", {});
      queryClient.invalidateQueries({ queryKey: ["reading-texts"] });
    } finally {
      setTriggeringDaily(false);
    }
  };

  const today = new Date().toISOString().split("T")[0];
  useEffect(() => {
    if (repeatTaskId && texts.length > 0 && !autoSelectedRef.current) {
      const text = texts.find(t => t.id === repeatTaskId);
      if (text) {
        autoSelectedRef.current = true;
        setIsRepeatMode(true);
        setSelectedText(text);
        setReadingMode(true);
      }
    }
  }, [repeatTaskId, texts]);

  const filtered = texts.filter(t =>
    (t.grade === effectiveGrade || t.grade === "both") && t.content_type !== "listening" && !completedIds.has(t.id)
  );
  const todayTexts = filtered.filter(t => t.generated_date === today);
  const olderTexts = filtered.filter(t => t.generated_date !== today);

  if (readingMode && selectedText) {
    return <ReadingExercise text={selectedText} isRepeatMode={isRepeatMode} markComplete={markComplete} onBack={() => { setReadingMode(false); setSelectedText(null); setIsRepeatMode(false); }} />;
  }

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-black flex items-center gap-2.5">
          <span className="w-9 h-9 rounded-2xl bg-violet-100 flex items-center justify-center">
            <FileText className="w-5 h-5 text-violet-600" />
          </span>
          Lesen
        </h1>
        <p className="text-muted-foreground text-sm mt-1 ml-12">Authentische Texte – Leseverständnis, Vokabeln und Fragen</p>
      </div>

      <div className="mb-4 flex items-center justify-between gap-2">
        <span className="text-xs font-semibold text-muted-foreground px-3 py-1.5 bg-secondary rounded-xl">
          Klasse {effectiveGrade} · Täglich 3 neue Texte
        </span>
        <div className="flex gap-2">
          {todayTexts.length === 0 && (
            <Button size="sm" variant="outline" onClick={handleTriggerDaily} disabled={triggeringDaily} className="gap-1.5 text-xs">
              {triggeringDaily ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
              Heute generieren
            </Button>
          )}
          <Button size="sm" onClick={() => setShowGenerateModal(true)} className="gap-1.5 text-xs">
            <Plus className="w-3 h-3" /> Eigenen Text
          </Button>
        </div>
      </div>

      {generating && (
        <div className="mb-4 p-3 rounded-xl bg-primary/5 border border-primary/20 flex items-center gap-2 text-sm text-primary">
          <Loader2 className="w-4 h-4 animate-spin" /> Text wird generiert...
        </div>
      )}

      <GenerateTextModal
        open={showGenerateModal}
        onClose={() => setShowGenerateModal(false)}
        grade={effectiveGrade}
        onGenerate={handleGenerateText}
      />

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Array(4).fill(0).map((_, i) => <div key={i} className="h-40 bg-secondary rounded-2xl animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center py-16 text-center">
          <div className="w-16 h-16 rounded-3xl bg-violet-50 flex items-center justify-center mb-4 border border-violet-100">
            <FileText className="w-8 h-8 text-violet-400" />
          </div>
          <p className="font-black text-sm text-foreground mb-1">Noch keine Lesetexte</p>
          <p className="text-xs text-muted-foreground max-w-xs">Klicke auf „Heute generieren" um die heutigen 3 Texte zu erstellen.</p>
        </div>
      ) : (
        <>
          {todayTexts.length > 0 && (
            <div className="mb-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Heute</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                {todayTexts.map(text => <TextCard key={text.id} text={text} onClick={() => { setSelectedText(text); setReadingMode(true); }} />)}
              </div>
            </div>
          )}
          {olderTexts.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Frühere Texte</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {olderTexts.map(text => <TextCard key={text.id} text={text} onClick={() => { setSelectedText(text); setReadingMode(true); }} />)}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function TextCard({ text, onClick }) {
  return (
        <Card key={text.id} className="card-hover cursor-pointer border-border/50 overflow-hidden"
          onClick={onClick}>
          <CardContent className="p-0">
            {text.image_url && (
              <img src={text.image_url} alt={text.title} className="w-full h-36 object-cover" />
            )}
            <div className="p-4">
              <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className="font-bold leading-tight">{text.title}</h3>
                <Badge variant="secondary" className="text-xs whitespace-nowrap">{TEXT_TYPE_LABELS[text.text_type] || text.text_type}</Badge>
              </div>
              <div className="flex flex-wrap gap-1.5 mb-3">
                <Badge variant="outline" className="text-xs">Klasse {text.grade}</Badge>
                {text.difficulty && <span className={cn("text-xs px-2 py-0.5 rounded-full", DIFFICULTY_COLORS[text.difficulty])}>{DIFFICULTY_LABELS[text.difficulty]}</span>}
                {text.topic && <Badge variant="outline" className="text-xs">{text.topic}</Badge>}
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{text.word_count || Math.floor((text.body?.split(" ").length || 0) / 60 * 60)} Wörter</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>{text.questions?.length || 0} Fragen</span>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
  );
}



function ReadingExercise({ text, onBack, isRepeatMode = false, markComplete }) {
  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];
  const { awardXP } = useXP(user, profile);
  const [showXP, setShowXP] = useState(false);
  const [lastXP, setLastXP] = useState(0);
  const queryClient = useQueryClient();
  const [phase, setPhase] = useState("read");
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [aiFeedback, setAiFeedback] = useState(null);
  const [checkingAnswers, setCheckingAnswers] = useState(false);

  const logAttempt = useMutation({
    mutationFn: (data) => base44.entities.ExerciseAttempt.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["recent-attempts"] }),
  });

  const questions = text.questions || [];

  const hasOpenQuestions = questions.some(q => ["detail", "inference", "main_idea", "vocabulary", "author_attitude"].includes(q.type));

  const handleSubmitAnswers = async () => {
    setCheckingAnswers(true);
    setSubmitted(true);
    setPhase("results");
    if (!isRepeatMode && markComplete) markComplete({ taskId: text.id, taskType: 'reading', taskTitle: text.title });

    // Check MC and true/false locally
    questions.forEach((q, i) => {
      const userAns = answers[i] || "";
      const correct = q.correct === userAns || (typeof q.correct === "number" && answers[i] == q.correct) || (typeof q.correct === "boolean" && answers[i] === String(q.correct));
      if (user && (q.type === "multiple_choice" || q.type === "true_false")) {
        const xpEarned = calculateExerciseXP("exercise", text.difficulty || "medium", correct);
        logAttempt.mutate({
          user_email: user.email, exercise_id: text.id + "_q" + i,
          skill_area: "reading", topic_key: text.topic, grade: text.grade,
          is_correct: correct, user_answer: String(userAns), correct_answer: String(q.correct),
          attempt_date: new Date().toISOString().split("T")[0], xp_earned: xpEarned,
        });
        if (correct && !isRepeatMode) {
          awardXP(xpEarned);
          setLastXP(xpEarned);
          setShowXP(true);
        }
      }
    });

    // Use Claude for open questions
    if (hasOpenQuestions) {
      try {
        // Convert answers to readable text (MC: use option text, others: use raw answer)
        const answersArray = questions.map((q, i) => {
          const raw = answers[i];
          if (q.type === "multiple_choice" && q.options && raw !== undefined && raw !== "") {
            return q.options[raw] || String(raw);
          }
          return raw !== undefined ? String(raw) : "";
        });
        const res = await base44.functions.invoke("anthropicAI", {
          task: "check_reading_answers",
          payload: { questions, answers: answersArray, textBody: text.body, grade: text.grade || "8" }
        });
        setAiFeedback(res.data.results);
        res.data.results.forEach((fb) => {
          if (user && fb.is_correct && !isRepeatMode) {
            const xpEarned = calculateExerciseXP("exercise", text.difficulty || "medium", true);
            awardXP(xpEarned);
            setLastXP(xpEarned);
            setShowXP(true);
          }
        });
      } catch {
        // silently fall through — show model answers as fallback
      }
    }
    setCheckingAnswers(false);
  };

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto animate-fade-in">
      <XPToast amount={lastXP} show={showXP} onDone={() => setShowXP(false)} />
      <div className="flex items-center justify-between mb-4">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" /> Zurück
        </button>
        <div className="flex gap-2 items-center">
          {["read", "questions", "results"].map((p) => (
            <div key={p} className={cn("w-2.5 h-2.5 rounded-full transition-all", phase === p ? "bg-primary" : "bg-border")} />
          ))}
        </div>
      </div>

      {phase === "read" && (
        <div>
          <div className="flex items-start justify-between gap-4 mb-4">
            <div>
              <h1 className="text-2xl font-bold">{text.title}</h1>
              <div className="flex gap-2 mt-2">
                <Badge variant="secondary">{TEXT_TYPE_LABELS[text.text_type]}</Badge>
                <Badge variant="outline">Klasse {text.grade}</Badge>
                {text.difficulty && <span className={cn("text-xs px-2 py-1 rounded-full", DIFFICULTY_COLORS[text.difficulty])}>{DIFFICULTY_LABELS[text.difficulty]}</span>}
              </div>
            </div>
          </div>
          <Card className="mb-6">
            <CardContent className="p-6 prose prose-sm max-w-none">
              {text.body.split("\n\n").map((para, i) => (
                <p key={i} className="mb-4 leading-relaxed text-foreground">{para}</p>
              ))}
            </CardContent>
          </Card>
          {text.vocabulary_focus?.length > 0 && (
            <Card className="mb-4 border-blue-200 bg-blue-50">
              <CardContent className="p-4">
                <p className="text-xs font-semibold text-blue-700 uppercase tracking-wider mb-2">Wichtige Vokabeln</p>
                <div className="flex flex-wrap gap-1.5">
                  {text.vocabulary_focus.map(w => <Badge key={w} className="bg-blue-100 text-blue-700 border-0">{w}</Badge>)}
                </div>
              </CardContent>
            </Card>
          )}
          <Button onClick={() => setPhase("questions")} className="w-full gap-2" size="lg" disabled={questions.length === 0}>
            {questions.length === 0 ? "Keine Aufgaben vorhanden" : `Zu den Aufgaben (${questions.length})`}
          </Button>
        </div>
      )}

      {phase === "questions" && (
        <div>
          <h2 className="text-xl font-bold mb-4">Aufgaben zum Text</h2>
          <div className="space-y-4">
            {questions.map((q, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <p className="font-semibold text-sm mb-3">{i + 1}. {q.question}</p>
                  {q.type === "multiple_choice" && q.options && (
                    <div className="space-y-2">
                      {q.options.map((opt, j) => (
                        <label key={j} className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name={`q${i}`} value={j} checked={answers[i] == j} onChange={() => setAnswers(a => ({ ...a, [i]: j }))} className="accent-primary" />
                          <span className="text-sm">{opt}</span>
                        </label>
                      ))}
                    </div>
                  )}
                  {(q.type === "detail" || q.type === "inference" || q.type === "main_idea" || q.type === "vocabulary" || q.type === "author_attitude") && (
                    <textarea className="w-full p-3 rounded-xl border border-border text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary/30" rows={3} placeholder="Deine Antwort auf Englisch..." value={answers[i] || ""} onChange={e => setAnswers(a => ({ ...a, [i]: e.target.value }))} />
                  )}
                  {q.type === "true_false" && (
                    <div className="flex gap-3">
                      {["True", "False"].map(tf => (
                        <label key={tf} className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name={`q${i}`} value={String(tf === "True")} checked={answers[i] === String(tf === "True")} onChange={() => setAnswers(a => ({ ...a, [i]: String(tf === "True") }))} className="accent-primary" />
                          <span className="text-sm font-medium">{tf}</span>
                        </label>
                      ))}
                    </div>
                  )}
                  {q.type === "sequence" && (
                    <textarea className="w-full p-3 rounded-xl border border-border text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary/30" rows={2} placeholder="Reihenfolge: 1, 2, 3..." value={answers[i] || ""} onChange={e => setAnswers(a => ({ ...a, [i]: e.target.value }))} />
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="flex gap-3 mt-6">
            <Button variant="outline" onClick={() => setPhase("read")} className="gap-1.5"><ArrowLeft className="w-4 h-4" />Zum Text</Button>
            <Button onClick={handleSubmitAnswers} disabled={checkingAnswers} className="flex-1 gap-2">
            {checkingAnswers ? <><Loader2 className="w-4 h-4 animate-spin" />Wird bewertet...</> : "Antworten abgeben"}
          </Button>
          </div>
        </div>
      )}

      {phase === "results" && (
        <div>
          {(() => {
            // Count correct answers after feedback is ready
            const mcTfCorrect = questions.filter((q, i) => {
              if (["detail","inference","main_idea","vocabulary","author_attitude"].includes(q.type)) return false;
              return q.correct === answers[i] || (typeof q.correct === "number" && answers[i] == q.correct) || (typeof q.correct === "boolean" && answers[i] === String(q.correct));
            }).length;
            const openCorrect = aiFeedback ? aiFeedback.filter(f => f.is_correct).length : 0;
            const totalCorrect = mcTfCorrect + openCorrect;
            const totalQ = questions.length;
            const allCorrect = !checkingAnswers && totalQ > 0 && totalCorrect === totalQ;
            const hasWrong = !checkingAnswers && totalCorrect < totalQ;
            const leoMsg = checkingAnswers
              ? "Ich schaue mir deine Antworten gerade genau an..."
              : allCorrect
                ? MASCOT_CELEBRATE_MESSAGES[Math.floor(Math.random() * MASCOT_CELEBRATE_MESSAGES.length)]
                : hasWrong
                  ? MASCOT_WRONG_MESSAGES[Math.floor(Math.random() * MASCOT_WRONG_MESSAGES.length)]
                  : "Deine Antworten wurden bewertet.";
            const leoBg = checkingAnswers ? "from-amber-50 to-yellow-50 border-amber-200" : allCorrect ? "from-green-50 to-emerald-50 border-green-200" : "from-orange-50 to-red-50 border-orange-200";
            const leoTextHead = checkingAnswers ? "text-amber-800" : allCorrect ? "text-green-800" : "text-orange-800";
            const leoTextSub = checkingAnswers ? "text-amber-700" : allCorrect ? "text-green-700" : "text-orange-700";
            return (
              <div className={`flex items-center gap-3 mb-5 p-4 rounded-2xl bg-gradient-to-br border ${leoBg}`}>
                <span className="text-2xl">{checkingAnswers ? "🦉" : allCorrect ? "🎉" : "🦉"}</span>
                <div className="flex-1">
                  <p className={`font-black text-sm ${leoTextHead}`}>Leo sagt:</p>
                  <p className={`text-xs mt-0.5 ${leoTextSub}`}>{leoMsg}</p>
                </div>
                {checkingAnswers && <Loader2 className="w-5 h-5 animate-spin text-amber-600 ml-auto" />}
              </div>
            );
          })()}

          <h2 className="text-base font-black mb-4">Auswertung</h2>
          <div className="space-y-4">
            {questions.map((q, i) => {
              const fb = aiFeedback?.find(f => f.question_index === i);
              const isOpenQ = ["detail", "inference", "main_idea", "vocabulary", "author_attitude"].includes(q.type);
              const localCorrect = !isOpenQ && (q.correct === answers[i] || (typeof q.correct === "number" && answers[i] == q.correct) || (typeof q.correct === "boolean" && answers[i] === String(q.correct)));
              return (
                <Card key={i} className={cn(
                  fb ? (fb.is_correct ? "border-green-300" : "border-orange-300") :
                  (!isOpenQ ? (localCorrect ? "border-green-300" : "border-red-300") : "")
                )}>
                  <CardContent className="p-4">
                    <p className="font-semibold text-sm mb-2">{i + 1}. {q.question}</p>
                    {answers[i] !== undefined && answers[i] !== "" && (
                      <div className="mb-2 p-2 rounded-lg bg-secondary text-sm">
                        <span className="text-muted-foreground">Deine Antwort: </span>
                        <span>{q.type === "multiple_choice" ? q.options?.[answers[i]] : answers[i]}</span>
                      </div>
                    )}
                    {/* AI feedback for open questions */}
                    {fb && (
                      <div className={cn("p-3 rounded-lg text-sm mb-2", fb.is_correct ? "bg-green-50 border border-green-200" : "bg-orange-50 border border-orange-200")}>
                        <p className={cn("font-semibold mb-1", fb.is_correct ? "text-green-700" : "text-orange-700")}>
                          {fb.is_correct ? "✅" : "💡"} {fb.feedback_de}
                        </p>
                        <p className="text-xs text-muted-foreground">Musterlösung: {fb.model_answer}</p>
                      </div>
                    )}
                    {/* Local check for MC / true_false */}
                    {!isOpenQ && !fb && (
                      <div className={cn("p-2 rounded-lg text-sm", localCorrect ? "bg-green-50 border border-green-200" : "bg-red-50 border border-red-200")}>
                        <span className={cn("font-semibold", localCorrect ? "text-green-700" : "text-red-700")}>
                          {localCorrect ? "✅ Richtig!" : "❌ Falsch — "}
                        </span>
                        <span className={localCorrect ? "text-green-800" : "text-red-800"}>
                          {q.type === "multiple_choice" ? q.options?.[q.correct] : (typeof q.correct === "boolean" ? (q.correct ? "True" : "False") : q.correct)}
                        </span>
                      </div>
                    )}
                    {isOpenQ && !fb && !checkingAnswers && (
                      <div className="p-2 rounded-lg bg-green-50 border border-green-200 text-sm">
                        <span className="text-green-700 font-semibold">Musterlösung: </span>
                        <span className="text-green-800">{typeof q.correct === "string" ? q.correct : ""}</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
          <div className="space-y-3 mt-6">
            <div className="flex items-center justify-center gap-1.5 text-sm font-semibold text-amber-600">
              <Zap className="w-4 h-4" />
              +{questions.reduce((sum, q, i) => {
                const fb = aiFeedback?.find(f => f.question_index === i);
                const isOpenQ = ["detail", "inference", "main_idea", "vocabulary", "author_attitude"].includes(q.type);
                const localCorrect = !isOpenQ && (q.correct === answers[i] || (typeof q.correct === "number" && answers[i] == q.correct) || (typeof q.correct === "boolean" && answers[i] === String(q.correct)));
                if (isOpenQ && fb?.is_correct) return sum + calculateExerciseXP("exercise", text.difficulty || "medium", true);
                if (!isOpenQ && localCorrect) return sum + calculateExerciseXP("exercise", text.difficulty || "medium", true);
                return sum;
              }, 0)} XP
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => { setPhase("read"); setAnswers({}); setSubmitted(false); setAiFeedback(null); }} className="flex-1 rounded-xl font-bold">Nochmal lesen</Button>
              <Button onClick={onBack} className="flex-1 rounded-xl font-bold">Zurück zur Übersicht</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}