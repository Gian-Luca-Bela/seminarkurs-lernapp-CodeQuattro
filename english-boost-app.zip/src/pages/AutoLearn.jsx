/**
 * AutoLearn – Real adaptive learning mode.
 * Analyses the student's full attempt history, builds a learner profile,
 * then generates and runs an exercise session where difficulty, type, and
 * scaffolding automatically adjust based on live performance.
 */
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { cn, getTodayString } from "@/lib/utils";
import {
  buildLearnerProfile, pickFocusSkill, adjustDifficulty, EXERCISE_TYPES_BY_SKILL
} from "@/lib/adaptiveLearning";
import { generateAdaptiveExercises } from "@/lib/ai/generators";
import { useSessionPersistence } from "@/lib/useSessionPersistence";
import { useLearningState } from "@/lib/useLearningState";
import {
  Brain, Sparkles, ArrowLeft, CheckCircle2, XCircle, ArrowRight,
  TrendingUp, TrendingDown, Minus, RotateCcw, Trophy, Zap,
  ChevronRight, Loader2, AlertTriangle, Target, BarChart2, PlayCircle
} from "lucide-react";
import AILoadingState from "@/components/AILoadingState";

// ── helpers ───────────────────────────────────────────────────────────────────
const normalize = s => s?.trim().toLowerCase().replace(/[''`]/g, "'").replace(/\s+/g, " ") || "";

const SKILL_LABELS = {
  grammar: "Grammatik", vocabulary: "Vokabeln", reading: "Leseverstehen",
  writing: "Schreiben", listening: "Hörverstehen", speaking: "Sprechen", mediation: "Sprachmittlung"
};
const DIFF_LABELS = { easy: "Leicht", medium: "Mittel", hard: "Schwer" };
const DIFF_COLORS = {
  easy: "bg-green-100 text-green-700 border-green-200",
  medium: "bg-yellow-100 text-yellow-700 border-yellow-200",
  hard: "bg-red-100 text-red-700 border-red-200",
};

// ── Main page ─────────────────────────────────────────────────────────────────
export default function AutoLearn() {
  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const { data: attempts = [] } = useQuery({
    queryKey: ["all-attempts", user?.email],
    queryFn: () => base44.entities.ExerciseAttempt.filter({ user_email: user?.email }, "-created_date", 80),
    enabled: !!user?.email,
  });

  const profile = profiles?.[0];
  const queryClient = useQueryClient();
  const learnerProfile = buildLearnerProfile(attempts, profile?.weak_areas || []);
  const { state: learningState, save: saveLearningState } = useLearningState(user?.email);

  // ── Session persistence ───────────────────────────────────────────────────
  const persistence = useSessionPersistence("autolearn", user?.email);
  const [savedSession, setSavedSession] = useState(null);

  const [view, setView] = useState("dashboard"); // dashboard | loading | session | results
  const [exercises, setExercises] = useState([]);
  const [sessionSkill, setSessionSkill] = useState(null); // skill the loaded exercises belong to
  const [current, setCurrent] = useState(0);
  const [sessionAnswers, setSessionAnswers] = useState([]);
  const [currentDifficulty, setCurrentDifficulty] = useState(learnerProfile.recommendedDifficulty);
  const [manualDifficulty, setManualDifficulty] = useState("auto"); // "auto" | "easy" | "medium" | "hard"
  const [scaffolding, setScaffolding] = useState(learnerProfile.scaffolding);
  const [selected, setSelected] = useState(null);
  const [userText, setUserText] = useState("");
  const [revealed, setRevealed] = useState(false);
  const [hintVisible, setHintVisible] = useState(false);
  const [focusSkill, setFocusSkill] = useState(pickFocusSkill(learnerProfile));

  // Check for saved session on mount
  useEffect(() => {
    const saved = persistence.load();
    if (saved?.exercises?.length > 0 && saved.current < saved.exercises.length) {
      setSavedSession(saved);
    }
  }, []);

  // Auto-save session state whenever it changes (during active session)
  useEffect(() => {
    if (view === "session" && exercises.length > 0) {
      persistence.save({ exercises, current, sessionAnswers, currentDifficulty, scaffolding, focusSkill });
    }
  }, [view, current, sessionAnswers, currentDifficulty]);

  // Clear saved session when results are shown; save LearningState to DB
  useEffect(() => {
    if (view === "results") {
      persistence.clear();
      setSavedSession(null);
      // Persist adaptive state to DB so next session resumes from same level
      const correctCount = sessionAnswers.filter(a => a.isCorrect).length;
      saveLearningState({
        last_skill_focus: focusSkill,
        preferred_difficulty: currentDifficulty,
        scaffolding_level: scaffolding,
        total_correct: correctCount,
        total_answered: sessionAnswers.length,
        auto_detected_weak_areas: learnerProfile.allWeakSkills.map(w => w.skill),
      });
    }
  }, [view]);

  // Re-derive focus skill when learner profile loads,
  // but prefer persisted LearningState values from DB
  useEffect(() => {
    if (attempts.length > 0) {
      // Use DB-persisted skill if available, otherwise derive from data
      const persistedSkill = learningState?.last_skill_focus;
      const persistedDiff = learningState?.preferred_difficulty;
      const persistedScaff = learningState?.scaffolding_level;
      setFocusSkill(persistedSkill || pickFocusSkill(learnerProfile));
      setCurrentDifficulty(persistedDiff || learnerProfile.recommendedDifficulty);
      setScaffolding(persistedScaff || learnerProfile.scaffolding);
    }
  }, [attempts.length, learningState?.last_skill_focus]);

  // ── Auto-sync detected weak areas back to UserProfile ────────────────────
  const updateProfile = useMutation({
    mutationFn: (data) => base44.entities.UserProfile.update(profile.id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["user-profile"] }),
  });

  useEffect(() => {
    if (!profile?.id || attempts.length < 5) return;
    const detectedWeak = learnerProfile.allWeakSkills.map(w => w.skill);
    const currentWeak = profile.weak_areas || [];
    // Merge: add newly detected weak areas (don't remove manually set ones)
    const merged = Array.from(new Set([...currentWeak, ...detectedWeak])).slice(0, 6);
    const hasNew = detectedWeak.some(s => !currentWeak.includes(s));
    if (hasNew) {
      updateProfile.mutate({ weak_areas: merged });
    }
  }, [attempts.length, profile?.id]);

  // ── Resume saved session ──────────────────────────────────────────────────
  const resumeSession = () => {
    if (!savedSession) return;
    setExercises(savedSession.exercises);
    setSessionSkill(savedSession.focusSkill || focusSkill);
    setCurrent(savedSession.current);
    setSessionAnswers(savedSession.sessionAnswers || []);
    setCurrentDifficulty(savedSession.currentDifficulty || "medium");
    setScaffolding(savedSession.scaffolding || 2);
    setFocusSkill(savedSession.focusSkill || focusSkill);
    setSelected(null);
    setUserText("");
    setRevealed(false);
    setHintVisible(false);
    setSavedSession(null);
    setView("session");
  };

  // Effective difficulty: manual override or adaptive
  const effectiveDifficulty = manualDifficulty === "auto" ? currentDifficulty : manualDifficulty;
  const effectiveScaffolding = manualDifficulty === "easy" ? 1 : manualDifficulty === "hard" ? 3 : scaffolding;

  // ── Generate adaptive exercise batch ──────────────────────────────────────
  const generateExercises = async (skill = focusSkill, difficulty = effectiveDifficulty, scaff = effectiveScaffolding) => {
    setView("loading");
    try {
      const exs = await generateAdaptiveExercises({
        learnerProfile,
        skill,
        difficulty,
        scaffolding: scaff,
        profile,
      });
      setExercises(exs);
      setSessionSkill(skill);
      setCurrent(0);
      setSessionAnswers([]);
      setSelected(null);
      setUserText("");
      setRevealed(false);
      setHintVisible(false);
      setView("session");
    } catch {
      setView("dashboard");
    }
  };

  // ── Answer check ─────────────────────────────────────────────────────────
  const ex = exercises[current];
  const isMC = ex?.type === "multiple_choice";
  const isOpenQuestion = ex?.type === "open_question";
  const isText = !isMC;

  const checkAnswer = async () => {
    const userAns = isMC ? selected : userText;
    const correct = normalize(ex.correct_answer);
    const userNorm = normalize(userAns || "");
    // open_question: count as correct if student wrote something meaningful (self-evaluation)
    const isCorrect = isOpenQuestion
      ? userText.trim().length >= 10
      : isMC
        ? userNorm === correct
        : userNorm === correct || correct.includes(userNorm) || userNorm.includes(correct);

    const newAnswers = [...sessionAnswers, {
      question: ex.question, userAns, correctAns: ex.correct_answer,
      isCorrect, explanation: ex.explanation, topic: ex.topic, skill: ex.skill, difficulty: ex.difficulty
    }];
    setSessionAnswers(newAnswers);
    setRevealed(true);

    // Adaptive: adjust difficulty after every 2 answers
    if (newAnswers.length % 2 === 0) {
      const correctSoFar = newAnswers.filter(a => a.isCorrect).length;
      const next = adjustDifficulty(currentDifficulty, correctSoFar, newAnswers.length);
      if (next !== currentDifficulty) setCurrentDifficulty(next);
      // Scaffolding: if struggling → show hints automatically
      const recentAcc = newAnswers.slice(-4).filter(a => a.isCorrect).length / Math.min(newAnswers.length, 4);
      if (recentAcc < 0.4 && scaffolding > 1) setScaffolding(s => s - 1);
      else if (recentAcc >= 0.85 && scaffolding < 3) setScaffolding(s => s + 1);
    }

    // Log attempt
    if (user?.email) {
      base44.entities.ExerciseAttempt.create({
        user_email: user.email,
        exercise_id: `autolearn_${ex.skill}_${ex.topic || "general"}_${Date.now()}`,
        skill_area: ex.skill,
        topic_key: ex.topic || ex.skill,
        grade: profile?.grade || "8",
        is_correct: isCorrect,
        user_answer: String(userAns || ""),
        correct_answer: ex.correct_answer,
        xp_earned: isCorrect ? 8 : 0,
        attempt_date: getTodayString(),
        difficulty: ex.difficulty,
      });
    }
  };

  const next = () => {
    if (current + 1 >= exercises.length) {
      setView("results");
    } else {
      setCurrent(c => c + 1);
      setSelected(null);
      setUserText("");
      setRevealed(false);
      setHintVisible(false);
    }
  };

  // ── Score ──────────────────────────────────────────────────────────────────
  const correctCount = sessionAnswers.filter(a => a.isCorrect).length;
  const pct = sessionAnswers.length > 0 ? Math.round((correctCount / sessionAnswers.length) * 100) : 0;

  // ── VIEWS ──────────────────────────────────────────────────────────────────

  if (view === "loading") {
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto">
        <AILoadingState
          title="Adaptive Aufgaben werden generiert"
          icon={<Brain className="w-8 h-8 text-white" />}
          steps={[
            "Lernprofil wird analysiert…",
            "Schwachstellen werden ausgewertet…",
            "Schwierigkeitsgrad wird angepasst…",
            "Aufgaben werden erstellt…",
            "Fast fertig – noch einen Moment…",
          ]}
          contextLines={[
            `Fokus: ${SKILL_LABELS[focusSkill] || focusSkill}`,
            `Schwierigkeit: ${manualDifficulty === "auto" ? `${DIFF_LABELS[effectiveDifficulty]} (automatisch)` : DIFF_LABELS[effectiveDifficulty]}`,
            `${learnerProfile.totalAttempts} Versuche analysiert`,
          ]}
        />
      </div>
    );
  }

  if (view === "results") {
    const diffChange = pct >= 80 ? "up" : pct < 45 ? "down" : "same";
    const newDiff = adjustDifficulty(currentDifficulty, correctCount, sessionAnswers.length);
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
        <div className="text-center mb-6">
          <div className="text-5xl mb-2">{pct >= 80 ? "🏆" : pct >= 55 ? "💪" : "📚"}</div>
          <h2 className="text-2xl font-black">{correctCount} / {sessionAnswers.length} richtig</h2>
          <p className={cn("text-xl font-black mt-1", pct >= 80 ? "text-green-600" : pct >= 50 ? "text-yellow-600" : "text-red-600")}>{pct}%</p>
        </div>

        {/* Adaptive adjustment card */}
        <Card className={cn("border-2 mb-5", diffChange === "up" ? "border-green-300 bg-green-50" : diffChange === "down" ? "border-orange-300 bg-orange-50" : "border-border bg-card")}>
          <CardContent className="p-4 flex items-center gap-4">
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",
              diffChange === "up" ? "bg-green-200" : diffChange === "down" ? "bg-orange-200" : "bg-secondary")}>
              {diffChange === "up" ? <TrendingUp className="w-5 h-5 text-green-700" />
               : diffChange === "down" ? <TrendingDown className="w-5 h-5 text-orange-700" />
               : <Minus className="w-5 h-5 text-muted-foreground" />}
            </div>
            <div>
              <p className="font-black text-sm">
                {diffChange === "up" ? "Schwierigkeitsgrad erhöht!" : diffChange === "down" ? "Schwierigkeitsgrad angepasst" : "Schwierigkeitsgrad bleibt gleich"}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Nächste Session: <span className={cn("font-bold", DIFF_COLORS[newDiff].split(" ")[1])}>{DIFF_LABELS[newDiff]}</span>
                {" "}· Unterstützung: {scaffolding === 1 ? "Voll" : scaffolding === 2 ? "Mittel" : "Keine"}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Answers review */}
        <div className="space-y-2 mb-5">
          {sessionAnswers.map((a, i) => (
            <Card key={i} className={cn("border", a.isCorrect ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50")}>
              <CardContent className="p-3 flex items-start gap-2">
                {a.isCorrect ? <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" /> : <XCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                    {a.topic && <span className="text-[10px] font-bold text-muted-foreground">{a.topic}</span>}
                    <Badge className={cn("text-[10px] border", DIFF_COLORS[a.difficulty || "medium"])}>{DIFF_LABELS[a.difficulty || "medium"]}</Badge>
                  </div>
                  <p className="text-xs font-bold leading-snug">{a.question}</p>
                  {!a.isCorrect && (
                    <div className="mt-1">
                      <p className="text-[11px] text-red-700">Deine Antwort: <span className="font-medium">{a.userAns || "(leer)"}</span></p>
                      <p className="text-[11px] text-green-700 font-semibold">Richtig: {a.correctAns}</p>
                    </div>
                  )}
                  {a.explanation && <p className="text-[11px] text-muted-foreground mt-1 italic">{a.explanation}</p>}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <Button variant="outline" onClick={() => { setExercises([]); setSessionSkill(null); setView("dashboard"); }} className="gap-2 flex-1">
            <BarChart2 className="w-4 h-4" />Dashboard
          </Button>
          <Button onClick={() => generateExercises(focusSkill, newDiff, scaffolding)} className="gap-2 flex-1 brand-gradient text-white border-0 font-bold">
            <Sparkles className="w-4 h-4" />Neue Session starten
          </Button>
        </div>
      </div>
    );
  }

  if (view === "session") {
    const progress = (current / exercises.length) * 100;
    const correctSoFar = sessionAnswers.filter(a => a.isCorrect).length;
    const showHintAuto = scaffolding === 1 && ex?.hint;

    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => setView("dashboard")} className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />Abbrechen
          </button>
          <div className="flex items-center gap-2">
            <Badge className={cn("border text-xs font-bold", DIFF_COLORS[currentDifficulty])}>
              {DIFF_LABELS[currentDifficulty]}
            </Badge>
            <span className="text-xs font-bold text-muted-foreground">{current + 1}/{exercises.length}</span>
            <span className="text-xs font-bold text-green-600">{correctSoFar}✓</span>
          </div>
        </div>

        {/* Progress */}
        <div className="w-full h-2 bg-secondary rounded-full mb-5 overflow-hidden">
          <div className="h-full brand-gradient rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>

        {/* Difficulty adjustment notification */}
        {sessionAnswers.length > 0 && sessionAnswers.length % 2 === 0 && !revealed && (() => {
          const prevDiff = adjustDifficulty(currentDifficulty, correctSoFar - (sessionAnswers.at(-1)?.isCorrect ? 1 : 0), sessionAnswers.length - 1);
          if (prevDiff !== currentDifficulty) return (
            <div className={cn("mb-3 px-3 py-2 rounded-xl flex items-center gap-2 text-xs font-bold border animate-pop-in",
              currentDifficulty === "hard" ? "bg-red-50 border-red-200 text-red-700" : currentDifficulty === "easy" ? "bg-green-50 border-green-200 text-green-700" : "bg-yellow-50 border-yellow-200 text-yellow-700")}>
              {currentDifficulty === "hard" ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
              Angepasst: jetzt {DIFF_LABELS[currentDifficulty]}
            </div>
          );
        })()}

        {/* Exercise card */}
        <Card className="mb-4">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-3">
              {ex?.topic && <Badge className="bg-primary/10 text-primary border-0 text-xs font-bold">{ex.topic}</Badge>}
              <Badge className="bg-secondary text-secondary-foreground border-0 text-xs">{SKILL_LABELS[ex?.skill] || ex?.skill}</Badge>
            </div>
            {/* Source text for summary / mediation tasks */}
            {ex?.context_text && ex.context_text.trim().length > 0 && (
              <div className={cn(
                "mb-4 p-4 rounded-xl border",
                ex?.skill === "mediation" || ex?.topic?.toLowerCase().includes("mittlung")
                  ? "bg-cyan-50 border-cyan-200"
                  : "bg-blue-50 border-blue-200"
              )}>
                <p className={cn(
                  "text-xs font-bold mb-2",
                  ex?.skill === "mediation" || ex?.topic?.toLowerCase().includes("mittlung")
                    ? "text-cyan-800"
                    : "text-blue-800"
                )}>
                  {ex?.skill === "mediation" || ex?.topic?.toLowerCase().includes("mittlung")
                    ? "🌍 Ausgangstext – gib den Inhalt sinngemäß auf Englisch wieder"
                    : "📄 Ausgangstext – lies den Text und schreibe eine Zusammenfassung"}
                </p>
                <div className="max-h-48 overflow-y-auto pr-1">
                  <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-line">{ex.context_text}</p>
                </div>
              </div>
            )}

            <p className="font-black text-base leading-snug mb-4">{ex?.question}</p>

            {isMC && ex?.options && (
              <div className="space-y-2">
                {ex.options.map((opt, i) => {
                  let cls = "answer-btn";
                  if (revealed) {
                    if (normalize(opt) === normalize(ex.correct_answer)) cls += " answer-btn-correct";
                    else if (selected === opt && normalize(opt) !== normalize(ex.correct_answer)) cls += " answer-btn-wrong";
                  } else if (selected === opt) cls += " answer-btn-selected";
                  return (
                    <button key={i} className={cls} disabled={revealed} onClick={() => setSelected(opt)}>
                      <span className="font-bold text-muted-foreground mr-2">{String.fromCharCode(65 + i)}.</span>{opt}
                    </button>
                  );
                })}
              </div>
            )}

            {isOpenQuestion && (
              <div>
                <p className="text-xs text-muted-foreground mb-2">✍️ Schreibe deinen Text – danach siehst du die Musterlösung.</p>
                <textarea
                  value={userText}
                  onChange={e => setUserText(e.target.value)}
                  disabled={revealed}
                  placeholder="Schreibe hier deinen Text…"
                  className="w-full min-h-[90px] text-sm rounded-xl border-2 border-input px-3 py-2 bg-background resize-none focus:outline-none focus:border-primary"
                />
                {revealed && ex.correct_answer && (
                  <div className="mt-3 p-3 rounded-xl bg-blue-50 border border-blue-200">
                    <p className="text-xs font-bold text-blue-800 mb-1">📝 Musterlösung / Beispiel:</p>
                    <p className="text-sm text-blue-900 whitespace-pre-line">{ex.correct_answer}</p>
                  </div>
                )}
              </div>
            )}

            {isText && !isOpenQuestion && (
              <div>
                <Input
                  value={userText}
                  onChange={e => setUserText(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter" && !revealed && userText.trim()) checkAnswer(); }}
                  disabled={revealed}
                  placeholder="Deine Antwort…"
                  className="text-sm"
                  autoFocus
                />
                {revealed && (
                  <div className={cn("mt-3 p-3 rounded-xl border",
                    normalize(userText) === normalize(ex.correct_answer) ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200")}>
                    <p className="text-xs font-bold">Musterlösung:</p>
                    <p className="text-sm font-bold mt-0.5">{ex.correct_answer}</p>
                  </div>
                )}
              </div>
            )}

            {/* Hint */}
            {ex?.hint && (showHintAuto || hintVisible) && !revealed && (
              <div className="mt-3 p-3 rounded-xl bg-amber-50 border border-amber-200 flex gap-2">
                <span className="text-base flex-shrink-0">💡</span>
                <p className="text-xs text-amber-800">{ex.hint}</p>
              </div>
            )}
            {ex?.hint && scaffolding === 2 && !revealed && !hintVisible && (
              <button onClick={() => setHintVisible(true)} className="mt-2 text-xs text-primary font-semibold hover:underline flex items-center gap-1">
                <Sparkles className="w-3 h-3" />Hinweis anzeigen
              </button>
            )}

            {/* Explanation after reveal */}
            {revealed && ex?.explanation && (
              <div className="mt-3 p-3 rounded-xl bg-secondary/60 border border-border">
                <p className="text-xs text-muted-foreground">💡 {ex.explanation}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {!revealed ? (
          <Button
            onClick={checkAnswer}
            disabled={
              (isMC && !selected) ||
              (isOpenQuestion && userText.trim().length < 5) ||
              (isText && !isOpenQuestion && !userText.trim())
            }
            className="w-full font-bold brand-gradient text-white border-0"
          >{isOpenQuestion ? "Fertig – Musterlösung anzeigen" : "Antwort prüfen"}</Button>
        ) : (
          <Button onClick={next} className="w-full gap-2 font-bold brand-gradient text-white border-0">
            {current + 1 >= exercises.length ? <><Trophy className="w-4 h-4" />Ergebnisse sehen</> : <>Weiter<ChevronRight className="w-4 h-4" /></>}
          </Button>
        )}
      </div>
    );
  }

  // ── DASHBOARD view ─────────────────────────────────────────────────────────
  const weakSkills = learnerProfile.allWeakSkills;
  const isNewUser = attempts.length < 5;

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-in">

      {/* Resume saved session banner */}
      {savedSession && (
        <Card className="border-2 border-primary/40 bg-primary/5 mb-5 animate-pop-in">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl brand-gradient flex items-center justify-center flex-shrink-0">
              <PlayCircle className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-black text-sm">Unfertige Session gefunden</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {savedSession.exercises?.length} Aufgaben · {SKILL_LABELS[savedSession.focusSkill] || savedSession.focusSkill} · Frage {(savedSession.current || 0) + 1}
              </p>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <Button variant="outline" size="sm" onClick={() => { persistence.clear(); setSavedSession(null); }} className="text-xs h-8">
                Verwerfen
              </Button>
              <Button size="sm" onClick={resumeSession} className="brand-gradient text-white border-0 font-bold text-xs h-8 gap-1.5">
                <PlayCircle className="w-3.5 h-3.5" />Weitermachen
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-black flex items-center gap-2.5">
          <span className="w-9 h-9 rounded-2xl brand-gradient flex items-center justify-center">
            <Brain className="w-5 h-5 text-white" />
          </span>
          Auto-Lernmodus
        </h1>
        <p className="text-muted-foreground text-sm mt-1 ml-12">
          KI analysiert deine Fehler und passt Schwierigkeit & Aufgabentyp in Echtzeit an.
        </p>
      </div>

      {isNewUser && (
        <Card className="border-2 border-dashed border-primary/30 bg-primary/5 mb-5">
          <CardContent className="p-5 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-sm">Noch zu wenig Daten</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Löse mindestens 5 Aufgaben in anderen Modulen – dann kann der Auto-Modus dich optimal anpassen.
                Du kannst ihn aber schon jetzt starten!
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Weak areas detected */}
      {weakSkills.length > 0 && (
        <Card className="mb-4 border-orange-200 bg-orange-50">
          <CardContent className="p-4">
            <p className="text-xs font-black text-orange-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />Erkannte Schwachstellen
            </p>
            <div className="space-y-1.5">
              {weakSkills.map(ws => (
                <div key={ws.skill} className="flex items-center justify-between">
                  <span className="text-sm font-medium text-orange-900">{SKILL_LABELS[ws.skill] || ws.skill}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-1.5 bg-orange-200 rounded-full overflow-hidden">
                      <div className="h-full bg-orange-500 rounded-full" style={{ width: `${ws.accuracy}%` }} />
                    </div>
                    <span className="text-xs font-bold text-orange-700 w-8 text-right">{ws.accuracy}%</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Problematic topics */}
      {learnerProfile.problematicTopics.length > 0 && (
        <Card className="mb-5">
          <CardContent className="p-4">
            <p className="text-xs font-black text-muted-foreground uppercase tracking-wider mb-2">Fehleranfällige Themen</p>
            <div className="flex flex-wrap gap-1.5">
              {learnerProfile.problematicTopics.map(t => (
                <Badge key={t.topic} className="bg-red-100 text-red-700 border-red-200 text-xs font-bold">
                  {t.topic} <span className="opacity-70 ml-1">{t.errorRate}% Fehler</span>
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Focus skill selector */}
      <Card className="mb-4">
        <CardContent className="p-4">
          <p className="text-sm font-bold mb-2">Fokus für diese Session</p>
          <div className="flex flex-wrap gap-2">
            {Object.entries(SKILL_LABELS).map(([key, label]) => {
              const isWeak = weakSkills.some(w => w.skill === key);
              return (
                <button
                  key={key}
                  onClick={() => setFocusSkill(key)}
                  className={cn("px-3 py-1.5 rounded-xl text-sm border-2 font-medium transition-all",
                    focusSkill === key
                      ? "border-primary bg-primary/10 text-primary font-bold"
                      : "border-border hover:border-primary/40 bg-card")}
                >
                  {label}
                  {isWeak && <span className="ml-1 text-orange-500">⚠️</span>}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* ── Manual difficulty selector ── */}
      <Card className="mb-5 border-2 border-primary/20">
        <CardContent className="p-4">
          <p className="text-sm font-bold mb-1 flex items-center gap-2">
            <Target className="w-4 h-4 text-primary" />
            Schwierigkeitsgrad wählen
          </p>
          <p className="text-xs text-muted-foreground mb-3">
            Wähle selbst – oder lass die KI automatisch anpassen.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { key: "auto", label: "Automatisch", sub: "KI passt an", color: "border-primary bg-primary/5 text-primary", icon: "🤖" },
              { key: "easy", label: "Leicht", sub: "Mehr Hilfe, einfachere Aufgaben", color: "border-green-400 bg-green-50 text-green-700", icon: "🟢" },
              { key: "medium", label: "Mittel", sub: "Normales Schulniveau", color: "border-yellow-400 bg-yellow-50 text-yellow-700", icon: "🟡" },
              { key: "hard", label: "Schwer", sub: "Wenig Hilfe, Transfer-Aufgaben", color: "border-red-400 bg-red-50 text-red-700", icon: "🔴" },
            ].map(opt => (
              <button
                key={opt.key}
                onClick={() => setManualDifficulty(opt.key)}
                className={cn(
                  "rounded-xl border-2 p-3 text-left transition-all",
                  manualDifficulty === opt.key ? opt.color + " ring-2 ring-offset-1 ring-primary/30 font-bold" : "border-border bg-card hover:border-primary/30"
                )}
              >
                <div className="text-base mb-1">{opt.icon}</div>
                <div className="text-sm font-bold leading-tight">{opt.label}</div>
                <div className="text-[10px] text-muted-foreground leading-tight mt-0.5">{opt.sub}</div>
              </button>
            ))}
          </div>
          {manualDifficulty !== "auto" && (
            <p className="text-xs text-primary font-semibold mt-2 flex items-center gap-1">
              <Zap className="w-3 h-3" />
              {manualDifficulty === "easy" && "Aufgaben sind einfacher formuliert mit mehr Hilfestellungen."}
              {manualDifficulty === "medium" && "Aufgaben entsprechen dem normalen Schulniveau."}
              {manualDifficulty === "hard" && "Schwere Transfer-Aufgaben, weniger Hinweise, mehr Eigendenken."}
            </p>
          )}
        </CardContent>
      </Card>

      {/* CTA */}
      {exercises.length > 0 && sessionSkill === focusSkill && current < exercises.length ? (
        <div className="flex flex-col gap-2">
          <Button
            onClick={() => setView("session")}
            size="lg"
            className="w-full brand-gradient text-white border-0 font-black gap-2"
          >
            <PlayCircle className="w-5 h-5" />
            Session fortsetzen · Frage {current + 1} / {exercises.length}
          </Button>
          <Button
            variant="outline"
            onClick={() => generateExercises()}
            className="w-full gap-2 text-sm font-semibold"
          >
            <Sparkles className="w-4 h-4" />Neue Aufgaben generieren
          </Button>
        </div>
      ) : (
        <Button
          onClick={() => generateExercises()}
          size="lg"
          className="w-full brand-gradient text-white border-0 font-black gap-2"
        >
          <Brain className="w-5 h-5" />
          Session starten · {manualDifficulty === "auto" ? `${DIFF_LABELS[currentDifficulty]} (KI)` : DIFF_LABELS[manualDifficulty]} · {SKILL_LABELS[focusSkill]}
        </Button>
      )}

      {learnerProfile.neglectedSkills.length > 0 && (
        <p className="text-xs text-muted-foreground text-center mt-3">
          💡 Lange nicht geübt: {learnerProfile.neglectedSkills.map(s => SKILL_LABELS[s]).join(", ")}
        </p>
      )}
    </div>
  );
}