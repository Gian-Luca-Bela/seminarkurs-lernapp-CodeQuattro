import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn, getDaysUntil, formatDate, getTodayString } from "@/lib/utils";
import {
  Target, Calendar, Plus, Trash2, CheckCircle2, Clock,
  Sparkles, ChevronRight, Pencil, ArrowLeft, AlertTriangle, BookOpen
} from "lucide-react";
import CollapsibleSection from "@/components/ui/CollapsibleSection";
import ExamPrepPlan from "@/components/exams/ExamPrepPlan";

const EXAM_TYPES = [
  { value: "vokabeltest", label: "Vokabeltest", icon: "📝" },
  { value: "klassenarbeit", label: "Klassenarbeit", icon: "📋" },
  { value: "pruefung", label: "Mündliche Prüfung", icon: "🎙️" },
  { value: "other", label: "Sonstiges", icon: "📌" },
];

// Topics werden dynamisch aus den Skill-Optionen und user weiterbildung geladen
// Standard-Topics als Fallback
const DEFAULT_GRAMMAR_TOPICS = [
  "Simple Present", "Simple Past", "Present Perfect", "Past Perfect",
  "Future (will/going to)", "Conditional (if-clauses)", "Passive Voice",
  "Reported Speech", "Relative Clauses", "Gerund vs. Infinitive",
  "Comparison (adjectives)", "Modal Verbs", "Articles", "Prepositions",
];

const DEFAULT_VOCAB_THEMES = [
  "Family & Relationships", "School & Education", "Technology & Media",
  "Environment & Climate", "Travel & Holidays", "Sports & Health",
  "Work & Career", "Food & Culture", "Politics & Society",
  "Films & Literature", "City & Country Life", "Emotions & Personality",
];

const DEFAULT_WRITING_FORMATS = [
  "Summary", "Blog Post", "Formal Email", "Informal Email",
  "Comment / Opinion", "Report", "Article", "Letter",
  "Story / Narrative", "Characterisation", "Mediation",
];

const SKILL_OPTIONS = [
  { key: "grammar", label: "Grammatik", emoji: "📚" },
  { key: "vocabulary", label: "Vokabeln", emoji: "💬" },
  { key: "reading", label: "Leseverstehen", emoji: "📖" },
  { key: "writing", label: "Schreiben", emoji: "✍️" },
  { key: "listening", label: "Hörverstehen", emoji: "🎧" },
  { key: "speaking", label: "Sprechen", emoji: "🗣️" },
  { key: "mediation", label: "Sprachmittlung", emoji: "🌍" },
];

const DAILY_TIMES = [10, 15, 20, 30, 45, 60];

const EMPTY_FORM = {
  title: "",
  exam_type: "klassenarbeit",
  exam_date: "",
  grammar_topics: [],
  vocab_themes: [],
  writing_formats: [],
  skill_areas: [],
  weak_areas: [],
  daily_minutes: 20,
  notes: "",
};

export default function Exams() {
  const [view, setView] = useState("list"); // list | create | edit | plan
  const [editingExam, setEditingExam] = useState(null);
  const [planExam, setPlanExam] = useState(null);
  const [formData, setFormData] = useState(EMPTY_FORM);
  const [formStep, setFormStep] = useState(0);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];

  const { data: exams = [] } = useQuery({
    queryKey: ["exams", user?.email],
    queryFn: () => base44.entities.UpcomingExam.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });

  const createExam = useMutation({
    mutationFn: (data) => base44.entities.UpcomingExam.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["exams"] });
      setView("list");
      setFormData(EMPTY_FORM);
      setFormStep(0);
    },
  });

  const updateExam = useMutation({
    mutationFn: ({ id, data }) => base44.entities.UpcomingExam.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["exams"] });
      setView("list");
      setEditingExam(null);
      setFormData(EMPTY_FORM);
      setFormStep(0);
    },
  });

  const deleteExam = useMutation({
    mutationFn: (id) => base44.entities.UpcomingExam.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["exams"] }),
  });

  const handleSave = () => {
    if (!formData.title || !formData.exam_date) return;
    const payload = { ...formData, user_email: user.email, grade: profile?.grade || "8", is_active: true };
    if (editingExam) {
      updateExam.mutate({ id: editingExam.id, data: payload });
    } else {
      createExam.mutate(payload);
    }
  };

  const openCreate = () => {
    setEditingExam(null);
    setFormData(EMPTY_FORM);
    setFormStep(0);
    setView("create");
  };

  const openEdit = (exam) => {
    setEditingExam(exam);
    setFormData({
      title: exam.title || "",
      exam_type: exam.exam_type || "klassenarbeit",
      exam_date: exam.exam_date || "",
      grammar_topics: exam.grammar_topics || [],
      vocab_themes: exam.vocab_themes || [],
      writing_formats: exam.writing_formats || [],
      skill_areas: exam.skill_areas || [],
      weak_areas: exam.weak_areas || [],
      daily_minutes: exam.daily_minutes || 20,
      notes: exam.notes || "",
    });
    setFormStep(0);
    setView("edit");
  };

  const openPlan = (exam) => {
    setPlanExam(exam);
    setView("plan");
  };

  const sortedExams = [...exams].sort((a, b) => new Date(a.exam_date) - new Date(b.exam_date));
  const upcomingExams = sortedExams.filter(e => getDaysUntil(e.exam_date) >= 0);
  const pastExams = sortedExams.filter(e => getDaysUntil(e.exam_date) < 0);

  if (view === "plan" && planExam) {
    return <ExamPrepPlan exam={planExam} profile={profile} onBack={() => setView("list")} />;
  }

  if (view === "create" || view === "edit") {
    return (
      <ExamForm
        formData={formData}
        setFormData={setFormData}
        formStep={formStep}
        setFormStep={setFormStep}
        isEdit={view === "edit"}
        isPending={createExam.isPending || updateExam.isPending}
        onSave={handleSave}
        onBack={() => { setView("list"); setEditingExam(null); setFormData(EMPTY_FORM); setFormStep(0); }}
      />
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-black flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-2xl bg-orange-100 flex items-center justify-center">
              <Target className="w-5 h-5 text-orange-600" />
            </span>
            Tests & Klausurvorbereitung
          </h1>
          <p className="text-muted-foreground text-sm mt-1 ml-12">Personalisierte Vorbereitung für deine echten Prüfungen</p>
        </div>
        <Button onClick={openCreate} size="sm" className="gap-1.5">
          <Plus className="w-4 h-4" />Test eintragen
        </Button>
      </div>

      {upcomingExams.length === 0 ? (
        <Card className="border-dashed text-center mb-6">
          <CardContent className="p-10">
            <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="font-bold mb-1">Noch keine Tests eingetragen</p>
            <p className="text-sm text-muted-foreground mb-5">
              Trage deinen nächsten Test ein – mit Themen, Schwächen und täglicher Lernzeit.<br />
              Dann bekommst du einen echten, personalisierten Vorbereitungsplan.
            </p>
            <Button onClick={openCreate} className="gap-2">
              <Plus className="w-4 h-4" />Jetzt Test eintragen
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="mb-5">
          <CollapsibleSection
            title="Bevorstehende Tests"
            count={upcomingExams.length}
            countLabel="Tests"
            icon="📅"
            defaultOpen={true}
            badge={
              upcomingExams.some(e => getDaysUntil(e.exam_date) <= 7) ? (
                <span className="text-[10px] font-bold text-red-600 bg-red-50 px-1.5 py-0.5 rounded-full border border-red-200">
                  Bald!
                </span>
              ) : null
            }
          >
            <div className="space-y-3">
              {upcomingExams.map(exam => {
                const days = getDaysUntil(exam.exam_date);
                const urgentColor = days <= 3 ? "border-red-300 bg-red-50" : days <= 7 ? "border-orange-200 bg-orange-50" : "border-border bg-card";
                const topicCount = (exam.grammar_topics?.length || 0) + (exam.vocab_themes?.length || 0) + (exam.writing_formats?.length || 0);
                // Prep progress: inverse of days left (more days = less progress shown)
                const maxDays = 30;
                const prepProgress = Math.max(5, Math.round((1 - days / maxDays) * 100));
                return (
                  <Card key={exam.id} className={cn("border-2 transition-all", urgentColor)}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center text-xl flex-shrink-0",
                          days <= 3 ? "bg-red-100" : days <= 7 ? "bg-orange-100" : "bg-secondary")}>
                          {EXAM_TYPES.find(t => t.value === exam.exam_type)?.icon || "📌"}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <h3 className="font-black text-sm leading-snug">{exam.title}</h3>
                            <Badge className={cn("flex-shrink-0 border-0 text-xs font-bold",
                              days === 0 ? "bg-red-500 text-white" :
                              days === 1 ? "bg-red-400 text-white" :
                              days <= 3 ? "bg-red-100 text-red-700" :
                              days <= 7 ? "bg-orange-100 text-orange-700" :
                              "bg-secondary text-secondary-foreground")}>
                              {days === 0 ? "Heute!" : days === 1 ? "Morgen!" : `In ${days} Tagen`}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5 mb-2">{formatDate(exam.exam_date)}</p>
                          {/* Time-to-exam progress bar - based on actual days remaining */}
                          <div className="h-1.5 bg-muted rounded-full overflow-hidden mb-2">
                            <div
                              className={cn("h-full rounded-full transition-all", days <= 3 ? "bg-red-400" : days <= 7 ? "bg-orange-400" : "bg-primary")}
                              style={{ width: `${Math.min(100, Math.max(5, (1 - Math.max(0, days) / 30) * 100))}%` }}
                            />
                          </div>
                          <div className="flex flex-wrap gap-1.5">
                            {topicCount > 0 && (
                              <Badge variant="secondary" className="text-xs">{topicCount} Themen</Badge>
                            )}
                            {exam.skill_areas?.slice(0, 2).map(s => (
                              <Badge key={s} variant="outline" className="text-xs">{s}</Badge>
                            ))}
                            {exam.daily_minutes && (
                              <Badge variant="secondary" className="text-xs flex items-center gap-1">
                                <Clock className="w-2.5 h-2.5" />{exam.daily_minutes} Min/Tag
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-3 pt-3 border-t border-border/50">
                        <Button size="sm" onClick={() => openPlan(exam)} className="flex-1 gap-1.5 brand-gradient text-white border-0 font-bold">
                          <Sparkles className="w-3.5 h-3.5" />KI-Vorbereitungsplan
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => openEdit(exam)} className="gap-1.5">
                          <Pencil className="w-3.5 h-3.5" />Bearbeiten
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => deleteExam.mutate(exam.id)} className="text-destructive hover:bg-destructive/10 px-2">
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CollapsibleSection>
        </div>
      )}

      {pastExams.length > 0 && (
        <CollapsibleSection
          title="Vergangene Tests"
          count={pastExams.length}
          countLabel="Tests"
          icon="✅"
          defaultOpen={false}
        >
          <div className="space-y-2">
            {pastExams.slice(0, 5).map(exam => (
              <div key={exam.id} className="flex items-center gap-3 p-3 rounded-xl bg-secondary/50">
                <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-sm font-medium">{exam.title}</p>
                  <p className="text-xs text-muted-foreground">{formatDate(exam.exam_date)}</p>
                </div>
              </div>
            ))}
          </div>
        </CollapsibleSection>
      )}
    </div>
  );
}

// ── Multi-step Exam Form ──────────────────────────────────────────────────────
function ExamForm({ formData, setFormData, formStep, setFormStep, isEdit, isPending, onSave, onBack }) {
  const toggle = (field, value) => setFormData(d => ({
    ...d,
    [field]: d[field].includes(value) ? d[field].filter(v => v !== value) : [...d[field], value]
  }));

  const steps = [
    { label: "Grundinfos", emoji: "📋" },
    { label: "Grammatik", emoji: "📚" },
    { label: "Vokabeln", emoji: "💬" },
    { label: "Schreiben & Skills", emoji: "✍️" },
    { label: "Schwächen & Zeit", emoji: "⏱️" },
  ];

  const canProceed = formStep === 0 ? (!!formData.title && !!formData.exam_date) : true;

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
      <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground mb-5 group">
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        {isEdit ? "Zurück zu meinen Tests" : "Abbrechen"}
      </button>

      <h1 className="text-xl font-black mb-1">{isEdit ? "Test bearbeiten" : "Neuen Test eintragen"}</h1>
      <p className="text-sm text-muted-foreground mb-5">
        Gib an, was wirklich drankommt – je genauer, desto besser dein Vorbereitungsplan.
      </p>

      {/* Step indicator */}
      <div className="flex items-center gap-1 mb-6 overflow-x-auto pb-1">
        {steps.map((s, i) => (
          <div key={i} className="flex items-center gap-1 flex-shrink-0">
            <button
              onClick={() => i < formStep && setFormStep(i)}
              className={cn("flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-bold transition-all",
                i === formStep ? "bg-primary text-white" :
                i < formStep ? "bg-primary/10 text-primary cursor-pointer" :
                "bg-secondary text-muted-foreground")}
            >
              <span>{s.emoji}</span>
              <span className="hidden sm:inline">{s.label}</span>
            </button>
            {i < steps.length - 1 && <div className={cn("w-4 h-0.5 rounded", i < formStep ? "bg-primary" : "bg-border")} />}
          </div>
        ))}
      </div>

      {/* Step 0: Basic info */}
      {formStep === 0 && (
        <div className="space-y-4">
          <div>
            <Label className="text-sm font-bold">Bezeichnung *</Label>
            <Input value={formData.title} onChange={e => setFormData(d => ({ ...d, title: e.target.value }))}
              placeholder="z.B. Englisch Klassenarbeit Nr. 3" className="mt-1" />
          </div>
          <div>
            <Label className="text-sm font-bold">Art des Tests</Label>
            <div className="flex flex-wrap gap-2 mt-2">
              {EXAM_TYPES.map(t => (
                <button key={t.value} onClick={() => setFormData(d => ({ ...d, exam_type: t.value }))}
                  className={cn("px-3 py-1.5 rounded-xl text-sm border-2 font-medium transition-all",
                    formData.exam_type === t.value ? "border-primary bg-primary/5 text-primary font-bold" : "border-border hover:border-primary/40")}>
                  {t.icon} {t.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <Label className="text-sm font-bold">Datum *</Label>
            <Input type="date" value={formData.exam_date}
              onChange={e => setFormData(d => ({ ...d, exam_date: e.target.value }))}
              className="mt-1" min={getTodayString()} />
          </div>
          {formData.exam_date && formData.title && (
            <div className="p-3 bg-primary/5 border border-primary/20 rounded-xl text-sm text-primary font-medium">
              📅 {getDaysUntil(formData.exam_date)} Tage bis zum Test
            </div>
          )}
        </div>
      )}

      {/* Step 1: Grammar topics */}
      {formStep === 1 && (
        <div>
          <p className="text-sm text-muted-foreground mb-3">Welche Grammatikthemen kommen dran? Trag sie ein oder wähle aus der Liste.</p>
          <div className="flex flex-wrap gap-2 mb-3">
            {DEFAULT_GRAMMAR_TOPICS.map(t => (
              <button key={t} onClick={() => toggle("grammar_topics", t)}
                className={cn("px-3 py-2 rounded-xl text-sm border-2 font-medium transition-all",
                  formData.grammar_topics.includes(t) ? "border-primary bg-primary/10 text-primary font-bold" : "border-border hover:border-primary/40 bg-card")}>
                {t}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mb-2">Oder gib eigene ein (eine pro Zeile):</p>
          <textarea value={formData._grammarCustom || ""} onChange={e => setFormData(d => ({ ...d, _grammarCustom: e.target.value }))}
            placeholder="z.B. Passive Voice mit Modals..." className="w-full min-h-[60px] text-sm rounded-xl border border-input px-3 py-2 bg-background resize-none" />
          {formData.grammar_topics.length === 0 && !formData._grammarCustom && (
            <p className="text-xs text-muted-foreground mt-3 italic">Kein Grammatikthema? Einfach überspringen.</p>
          )}
        </div>
      )}

      {/* Step 2: Vocabulary themes */}
      {formStep === 2 && (
        <div>
          <p className="text-sm text-muted-foreground mb-3">Welche Vokabelthemen sollen abgefragt werden?</p>
          <div className="flex flex-wrap gap-2 mb-3">
            {DEFAULT_VOCAB_THEMES.map(t => (
              <button key={t} onClick={() => toggle("vocab_themes", t)}
                className={cn("px-3 py-2 rounded-xl text-sm border-2 font-medium transition-all",
                  formData.vocab_themes.includes(t) ? "border-primary bg-primary/10 text-primary font-bold" : "border-border hover:border-primary/40 bg-card")}>
                {t}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mb-2">Oder gib eigene ein (eine pro Zeile):</p>
          <textarea value={formData._vocabCustom || ""} onChange={e => setFormData(d => ({ ...d, _vocabCustom: e.target.value }))}
            placeholder="z.B. Business vocabulary..." className="w-full min-h-[60px] text-sm rounded-xl border border-input px-3 py-2 bg-background resize-none" />
          {formData.vocab_themes.length === 0 && !formData._vocabCustom && (
            <p className="text-xs text-muted-foreground mt-3 italic">Keine Vokabelthemen? Einfach überspringen.</p>
          )}
        </div>
      )}

      {/* Step 3: Writing formats & skills */}
      {formStep === 3 && (
        <div className="space-y-5">
          <div>
            <Label className="text-sm font-bold mb-2 block">Schreibformate</Label>
            <div className="flex flex-wrap gap-2 mb-3">
              {DEFAULT_WRITING_FORMATS.map(t => (
                <button key={t} onClick={() => toggle("writing_formats", t)}
                  className={cn("px-3 py-2 rounded-xl text-sm border-2 font-medium transition-all",
                    formData.writing_formats.includes(t) ? "border-primary bg-primary/10 text-primary font-bold" : "border-border hover:border-primary/40 bg-card")}>
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div>
            <Label className="text-sm font-bold mb-2 block">Welche Kompetenzbereiche werden geprüft?</Label>
            <div className="flex flex-wrap gap-2">
              {SKILL_OPTIONS.map(s => (
                <button key={s.key} onClick={() => toggle("skill_areas", s.key)}
                  className={cn("px-3 py-2 rounded-xl text-sm border-2 font-medium transition-all",
                    formData.skill_areas.includes(s.key) ? "border-primary bg-primary/10 text-primary font-bold" : "border-border hover:border-primary/40 bg-card")}>
                  {s.emoji} {s.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Step 4: Weak areas & daily time */}
      {formStep === 4 && (
        <div className="space-y-5">
          <div>
            <Label className="text-sm font-bold mb-2 block">Wo fühlst du dich unsicher?</Label>
            <p className="text-xs text-muted-foreground mb-3">Der Plan legt hier einen besonderen Fokus drauf.</p>
            <div className="flex flex-wrap gap-2">
              {[...SKILL_OPTIONS, { key: "pronunciation", label: "Aussprache", emoji: "🔊" }, { key: "writing_style", label: "Schreibstil", emoji: "🖊️" }].map(s => (
                <button key={s.key} onClick={() => toggle("weak_areas", s.key)}
                  className={cn("px-3 py-2 rounded-xl text-sm border-2 font-medium transition-all",
                    formData.weak_areas.includes(s.key) ? "border-destructive bg-destructive/10 text-destructive font-bold" : "border-border hover:border-destructive/30 bg-card")}>
                  {s.emoji} {s.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <Label className="text-sm font-bold mb-2 block">Wie viele Minuten pro Tag kannst du lernen?</Label>
            <div className="flex flex-wrap gap-2">
              {DAILY_TIMES.map(t => (
                <button key={t} onClick={() => setFormData(d => ({ ...d, daily_minutes: t }))}
                  className={cn("px-4 py-2 rounded-xl text-sm border-2 font-bold transition-all",
                    formData.daily_minutes === t ? "border-primary bg-primary text-white" : "border-border hover:border-primary/40 bg-card")}>
                  {t} Min
                </button>
              ))}
            </div>
          </div>
          <div>
            <Label className="text-sm font-bold mb-1 block">Zusätzliche Notizen (optional)</Label>
            <Input value={formData.notes} onChange={e => setFormData(d => ({ ...d, notes: e.target.value }))}
              placeholder="z.B. Kap. 3–5, Irregular verbs, Unit 7 vocab..." className="mt-1" />
          </div>
        </div>
      )}

      {/* Navigation */}
      <div className="flex gap-3 mt-6 pt-4 border-t border-border">
        {formStep > 0 && (
          <Button variant="outline" onClick={() => setFormStep(s => s - 1)} className="gap-1.5">
            <ArrowLeft className="w-4 h-4" />Zurück
          </Button>
        )}
        {formStep < steps.length - 1 ? (
          <Button onClick={() => setFormStep(s => s + 1)} disabled={!canProceed} className="flex-1 gap-1.5">
            Weiter <ChevronRight className="w-4 h-4" />
          </Button>
        ) : (
          <Button onClick={onSave} disabled={!formData.title || !formData.exam_date || isPending} className="flex-1 gap-2 brand-gradient text-white border-0 font-bold">
            <Sparkles className="w-4 h-4" />
            {isEdit ? "Änderungen speichern" : "Test speichern"}
          </Button>
        )}
      </div>
    </div>
  );
}