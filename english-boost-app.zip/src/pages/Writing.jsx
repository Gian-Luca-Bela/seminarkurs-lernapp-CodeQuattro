import { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { useCompletedTasks } from "@/lib/useCompletedTasks";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { PenLine, ChevronRight, Check, X, Lightbulb, Star, ArrowRight, Sparkles, BookOpen, Plus, Loader2, RefreshCw, ListOrdered, Image as ImageIcon, Trash2, Zap } from "lucide-react";
import { DIFFICULTY_COLORS, DIFFICULTY_LABELS } from "@/lib/constants";
import { calculateWritingXP, calculateSummaryXP } from "@/lib/xpSystem";
import GenreGuide from "@/components/writing/GenreGuide";
import SummaryTrainer from "@/components/writing/SummaryTrainer";
import GenerateWritingModal from "@/components/writing/GenerateWritingModal";

const GENRE_LABELS = {
  summary: "Summary", blog_post: "Blog Post", comment: "Kommentar",
  formal_email: "Formeller Brief/Email", informal_email: "Informelle Email",
  letter: "Brief", report: "Bericht", article: "Artikel",
  discussion: "Diskussion/Erörterung", characterisation: "Characterisation",
  creative: "Creative Writing", mediation: "Mediationstext",
  application: "Bewerbung", recommendation: "Empfehlung"
};

const GENRE_COLORS = {
  summary: "bg-blue-100 text-blue-700", blog_post: "bg-green-100 text-green-700",
  comment: "bg-yellow-100 text-yellow-700", formal_email: "bg-purple-100 text-purple-700",
  informal_email: "bg-pink-100 text-pink-700", discussion: "bg-orange-100 text-orange-700",
  creative: "bg-rose-100 text-rose-700", mediation: "bg-teal-100 text-teal-700",
};

const WRITING_STEPS = ["Vorbereitung", "Gliederung", "Schreiben", "Checkliste"];

export default function Writing() {
  const [selectedGenre, setSelectedGenre] = useState("all");
  const [selectedPrompt, setSelectedPrompt] = useState(null);
  const [writingMode, setWritingMode] = useState(false);
  const [triggeringDaily, setTriggeringDaily] = useState(false);
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [generating, setGenerating] = useState(false);

  const queryClient = useQueryClient();

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];
  const effectiveGrade = profile?.grade || "8";

  const { data: prompts = [], isLoading } = useQuery({
    queryKey: ["writing-prompts", effectiveGrade],
    queryFn: () => base44.entities.WritingPrompt.list("-created_date", 60),
  });

  const location = useLocation();
  const repeatTaskId = location.state?.taskId;
  const [isRepeatMode, setIsRepeatMode] = useState(false);
  const autoSelectedRef = useRef(false);
  const { completedTasks, markComplete } = useCompletedTasks(user?.email);
  const completedIds = new Set(completedTasks.filter(c => c.task_type === 'writing').map(c => c.task_id));

  useEffect(() => {
    if (repeatTaskId && prompts.length > 0 && !autoSelectedRef.current) {
      const prompt = prompts.find(p => p.id === repeatTaskId);
      if (prompt) {
        autoSelectedRef.current = true;
        setIsRepeatMode(true);
        setSelectedPrompt(prompt);
        setWritingMode(true);
      }
    }
  }, [repeatTaskId, prompts]);

  const today = new Date().toISOString().split("T")[0];
  const gradeFiltered = prompts.filter(p => (p.grade === effectiveGrade || p.grade === "both") && !completedIds.has(p.id));
  const filtered = gradeFiltered.filter(p => selectedGenre === "all" || p.genre === selectedGenre);
  const todayPrompts = filtered.filter(p => p.generated_date === today);
  const olderPrompts = filtered.filter(p => p.generated_date !== today);

  const genres = ["all", ...new Set(gradeFiltered.map(p => p.genre))];

  const handleGenerateCustom = async (genre, difficulty, customTopic = "") => {
    setGenerating(true);
    const topics8 = {
      comment: "Should schools ban smartphones? Give your opinion.",
      summary: "Summarise a short text about New York City",
      blog_post: "A day in the life of an American teenager",
      formal_email: "Write a formal email to an American school requesting information",
      informal_email: "Write to your American pen pal about your school",
      discussion: "Pros and cons of living in a big city",
      article: "Write about an important invention from the USA",
      report: "Report about a school trip to a national park",
      letter: "Write a letter to your exchange partner about your hometown",
      creative: "Write a short story set in New York",
      characterisation: "Describe a person who made a difference in their community",
    };
    const topics9 = {
      comment: "Should English be the only global language?",
      summary: "Summarise a text about global challenges",
      blog_post: "The good life – what does it mean to you?",
      formal_email: "Apply for a summer work placement in Australia",
      informal_email: "Write to your friend about your summer plans",
      discussion: "Advantages and disadvantages of social media for teenagers",
      article: "Write a magazine article about life in South Africa",
      report: "Report on English as a global language for your school magazine",
      letter: "Write a letter to the editor about environmental issues",
      creative: "Write a creative story about living in another culture",
      characterisation: "Describe a character who fights for tolerance and respect",
    };
    const topicMap = effectiveGrade === "9" ? topics9 : topics8;
    const topic = customTopic || topicMap[genre] || `Write a ${genre} about a topic relevant to Grade ${effectiveGrade}`;
    try {
      const res = await base44.functions.invoke("dailyContentGenerator", {
        single: { type: "writing", genre, topic, grade: effectiveGrade, difficulty }
      });
      queryClient.invalidateQueries({ queryKey: ["writing-prompts", effectiveGrade] });
    } finally {
      setGenerating(false);
    }
  };

  const handleTriggerDaily = async () => {
    setTriggeringDaily(true);
    try {
      await base44.functions.invoke("dailyContentGenerator", {});
      queryClient.invalidateQueries({ queryKey: ["writing-prompts", effectiveGrade] });
    } finally {
      setTriggeringDaily(false);
    }
  };

  if (writingMode && selectedPrompt) {
    if (selectedPrompt.genre === "summary") {
      return (
        <div className="p-4 md:p-6 max-w-3xl mx-auto">
          <Button variant="ghost" onClick={() => { setWritingMode(false); setSelectedPrompt(null); setIsRepeatMode(false); }} className="mb-4">← Zurück</Button>
          <h2 className="text-xl font-bold mb-4">Summary Training</h2>
          <SummaryTrainer
            sourceText={selectedPrompt.context || selectedPrompt.prompt_text}
            textTitle={selectedPrompt.title}
            minWords={selectedPrompt.min_words || 60}
            maxWords={selectedPrompt.max_words || 100}
            onDone={() => {
              if (!isRepeatMode) markComplete({ taskId: selectedPrompt.id, taskType: 'writing', taskTitle: selectedPrompt.title });
              setWritingMode(false); setSelectedPrompt(null); setIsRepeatMode(false);
            }}
          />
        </div>
      );
    }
    return <WritingWorkspace prompt={selectedPrompt} grade={profile?.grade} isRepeatMode={isRepeatMode} markComplete={markComplete} onBack={() => { setWritingMode(false); setSelectedPrompt(null); setIsRepeatMode(false); }} />;
  }

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-black flex items-center gap-2.5">
          <span className="w-9 h-9 rounded-2xl bg-pink-100 flex items-center justify-center">
            <PenLine className="w-5 h-5 text-pink-600" />
          </span>
          Schreiben
        </h1>
        <p className="text-muted-foreground text-sm mt-1 ml-12">Textsorten verstehen und üben</p>
      </div>

      <div className="mb-4 flex items-center justify-between gap-2">
        <span className="text-xs font-semibold text-muted-foreground px-3 py-1.5 bg-secondary rounded-xl">
          Klasse {effectiveGrade} · Täglich 3 neue Aufgaben
        </span>
        <div className="flex gap-2">
          {todayPrompts.length === 0 && (
            <Button size="sm" variant="outline" onClick={handleTriggerDaily} disabled={triggeringDaily} className="gap-1.5 text-xs">
              {triggeringDaily ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
              Heute generieren
            </Button>
          )}
          <Button size="sm" onClick={() => setShowGenerateModal(true)} className="gap-1.5 text-xs">
            <Plus className="w-3 h-3" /> Eigene Aufgabe
          </Button>
        </div>
      </div>

      {generating && (
        <div className="mb-4 p-3 rounded-xl bg-primary/5 border border-primary/20 flex items-center gap-2 text-sm text-primary">
          <Loader2 className="w-4 h-4 animate-spin" /> Aufgabe wird generiert...
        </div>
      )}

      <GenerateWritingModal
        open={showGenerateModal}
        onClose={() => setShowGenerateModal(false)}
        grade={effectiveGrade}
        onGenerate={handleGenerateCustom}
      />

      {/* Genre filter */}
      {filtered.length > 0 && (
        <div className="flex gap-2 overflow-x-auto pb-1 mb-5">
          {genres.map(g => (
            <button key={g} onClick={() => setSelectedGenre(g)}
              className={cn("px-3 py-1.5 rounded-full text-sm whitespace-nowrap transition-all",
                selectedGenre === g ? "bg-secondary text-foreground font-semibold border border-border" : "text-muted-foreground hover:text-foreground")}>
              {g === "all" ? "Alle Textsorten" : GENRE_LABELS[g] || g}
            </button>
          ))}
        </div>
      )}

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Array(4).fill(0).map((_, i) => <div key={i} className="h-40 bg-secondary rounded-2xl animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center py-16 text-center">
          <div className="w-16 h-16 rounded-3xl bg-pink-50 flex items-center justify-center mb-4 border border-pink-100">
            <PenLine className="w-8 h-8 text-pink-400" />
          </div>
          <p className="font-black text-sm mb-1">Noch keine Schreibaufgaben</p>
          <p className="text-xs text-muted-foreground max-w-xs">Klicke auf „Heute generieren" um die heutigen 3 Aufgaben zu erstellen.</p>
        </div>
      ) : (
        <>
          {todayPrompts.length > 0 && (
            <div className="mb-6">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Heute</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {todayPrompts.map(prompt => <WritingCard key={prompt.id} prompt={prompt} onClick={() => { setSelectedPrompt(prompt); setWritingMode(true); }} />)}
              </div>
            </div>
          )}
          {olderPrompts.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Frühere Aufgaben</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {olderPrompts.map(prompt => <WritingCard key={prompt.id} prompt={prompt} onClick={() => { setSelectedPrompt(prompt); setWritingMode(true); }} />)}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function ChecklistStep({ prompt, text, setText, uploadedImage, wordCount, generating, onGenerateFeedback }) {
  const [showText, setShowText] = useState(false);

  return (
    <Card>
      <CardHeader><CardTitle className="text-base">Finale Checkliste</CardTitle></CardHeader>
      <CardContent>
        {/* Text review / edit section */}
        {!uploadedImage && (
          <div className="mb-4">
            <button
              onClick={() => setShowText(!showText)}
              className="flex items-center gap-1.5 text-xs font-semibold text-primary hover:underline mb-2"
            >
              <PenLine className="w-3.5 h-3.5" />
              {showText ? "Text ausblenden ▲" : "Meinen Text anzeigen & bearbeiten ▼"}
            </button>
            {showText && (
              <div className="space-y-1">
                <Textarea
                  value={text}
                  onChange={e => setText(e.target.value)}
                  className="min-h-48 resize-none font-sans text-sm"
                />
                <p className="text-xs text-muted-foreground text-right">{wordCount} Wörter</p>
              </div>
            )}
          </div>
        )}

        <div className="space-y-2 mb-4">
          {prompt.dos?.map((d, i) => (
            <label key={i} className="flex items-start gap-2 cursor-pointer">
              <input type="checkbox" className="accent-primary mt-0.5" />
              <span className="text-sm">{d}</span>
            </label>
          ))}
          <label className="flex items-start gap-2 cursor-pointer">
            <input type="checkbox" className="accent-primary mt-0.5" />
            <span className="text-sm">Wortanzahl: {wordCount} Wörter ✓</span>
          </label>
        </div>
        <Button onClick={onGenerateFeedback} disabled={generating || (!uploadedImage && wordCount < 20)} className="w-full gap-2" size="lg">
          <Sparkles className="w-4 h-4" />
          {generating ? "Leo analysiert..." : "Feedback erhalten"}
        </Button>
      </CardContent>
    </Card>
  );
}

function WritingCard({ prompt, onClick }) {
  return (
    <Card className="card-hover cursor-pointer border-border/50" onClick={onClick}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-3">
          <h3 className="font-bold leading-tight">{prompt.title}</h3>
          <span className={cn("text-xs px-2 py-1 rounded-full whitespace-nowrap font-medium", GENRE_COLORS[prompt.genre] || "bg-secondary text-secondary-foreground")}>
            {GENRE_LABELS[prompt.genre] || prompt.genre}
          </span>
        </div>
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{prompt.prompt_text}</p>
        <div className="flex items-center justify-between">
          <div className="flex gap-1.5 flex-wrap">
            <Badge variant="outline" className="text-xs">Klasse {prompt.grade}</Badge>
            {prompt.difficulty && <span className={cn("text-xs px-2 py-0.5 rounded-full", DIFFICULTY_COLORS[prompt.difficulty])}>{DIFFICULTY_LABELS[prompt.difficulty]}</span>}
            {prompt.exam_relevant && <Badge className="bg-red-100 text-red-700 border-0 text-xs">Testrelevant</Badge>}
            {prompt.genre === "summary" && <Badge className="bg-blue-100 text-blue-700 border-0 text-xs">🎯 Geführtes Training</Badge>}
          </div>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </div>
      </CardContent>
    </Card>
  );
}

function WritingWorkspace({ prompt, grade, onBack, isRepeatMode = false, markComplete }) {
  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const queryClient = useQueryClient();
  const [step, setStep] = useState(0);
  const [brainstorm, setBrainstorm] = useState("");
  const [outline, setOutline] = useState("");
  const [text, setText] = useState("");
  const [showGuide, setShowGuide] = useState(true);
  const [showOutline, setShowOutline] = useState(false);
  const [showBrainstorm, setShowBrainstorm] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  const saveSubmission = useMutation({
    mutationFn: (data) => base44.entities.WritingSubmission.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["writing-submissions"] }),
  });

  const wordCount = text.trim().split(/\s+/).filter(w => w.length > 0).length;

  const handleImageUpload = async (file) => {
    if (!file) return;
    setUploadingImage(true);
    try {
      const res = await base44.integrations.Core.UploadFile({ file });
      setUploadedImage(res.file_url);
    } catch (error) {
      console.error("Upload failed:", error);
    } finally {
      setUploadingImage(false);
    }
  };

  const generateFeedback = async () => {
    setGenerating(true);
    try {
      const payload = {
        prompt: prompt.prompt_text,
        genre: prompt.genre,
        grade: grade || prompt.grade,
      };

      if (uploadedImage) {
        payload.image_url = uploadedImage;
      } else {
        payload.text = text;
      }

      const res = await base44.functions.invoke("anthropicAI", {
        task: "writing_feedback",
        payload,
      });
      const result = res.data;
      setFeedback(result);
      if (!isRepeatMode && markComplete) markComplete({ taskId: prompt.id, taskType: 'writing', taskTitle: prompt.title });
      if (user) {
        const xpEarned = calculateWritingXP(result.overall_score ?? 0, prompt.difficulty || 'medium');
        saveSubmission.mutate({
          user_email: user.email, prompt_id: prompt.id, genre: prompt.genre,
          content: uploadedImage ? `[Handschriftliche Antwort: ${uploadedImage}]` : text,
          word_count: uploadedImage ? 0 : wordCount,
          feedback: { overall_comment: result.encouragement, task_achievement: result.overall_score },
          status: "reviewed", xp_earned: xpEarned,
        });
      }
    } catch {
      setFeedback({
        overall_score: 3,
        task_achievement: "Dein Text geht auf die Aufgabe ein.",
        structure: "Die Grundstruktur ist erkennbar. Klare Absätze helfen.",
        language: "Du verwendest passende Vokabeln.",
        grammar: "Überprüfe Zeitformen und Satzbau.",
        style: `Achte auf den richtigen Stil für einen ${GENRE_LABELS[prompt.genre]}.`,
        strengths: ["Vollständiger Text", "Grundidee klar erkennbar"],
        improvements: ["Mehr Verbindungswörter (however, furthermore...)", "Auf Wortanzahl achten"],
        encouragement: "Gut gemacht! Schreiben braucht Übung – du machst Fortschritte! 💪"
      });
    }
    setGenerating(false);
    setSubmitted(true);
  };

  if (submitted && feedback) {
    return (
      <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-in">
        <Button variant="ghost" onClick={onBack} className="mb-4">← Zurück</Button>
        <h2 className="text-xl font-bold mb-4">Feedback zu deinem Text</h2>
        <div className="space-y-4">
          {feedback.overall_score && (
            <Card className="border-primary/30 bg-primary/5">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="text-4xl font-bold text-primary">{feedback.overall_score}/5</div>
                <div>
                  <p className="font-semibold">Gesamtbewertung</p>
                  <div className="flex gap-0.5 mt-1">
                    {Array(5).fill(0).map((_, i) => <Star key={i} className={cn("w-4 h-4", i < feedback.overall_score ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground")} />)}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          {[
            { key: "task_achievement", label: "Aufgabenerfüllung" },
            { key: "structure", label: "Struktur" },
            { key: "language", label: "Sprache & Vokabular" },
            { key: "grammar", label: "Grammatik" },
            { key: "style", label: "Stil & Register" },
          ].map(({ key, label }) => feedback[key] && (
            <Card key={key}><CardContent className="p-4">
              <h4 className="font-semibold text-sm mb-1">{label}</h4>
              <p className="text-sm text-muted-foreground">{feedback[key]}</p>
            </CardContent></Card>
          ))}
          {feedback.strengths?.length > 0 && (
            <Card className="border-green-200 bg-green-50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-green-700 mb-2">✅ Stärken</h4>
                <ul className="space-y-1">{feedback.strengths.map((s, i) => <li key={i} className="text-sm text-green-800 flex items-start gap-2"><Check className="w-4 h-4 mt-0.5 flex-shrink-0" />{s}</li>)}</ul>
              </CardContent>
            </Card>
          )}
          {feedback.improvements?.length > 0 && (
            <Card className="border-orange-200 bg-orange-50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-orange-700 mb-2">💡 Verbesserungsvorschläge</h4>
                <ul className="space-y-1">{feedback.improvements.map((s, i) => <li key={i} className="text-sm text-orange-800 flex items-start gap-2"><ArrowRight className="w-4 h-4 mt-0.5 flex-shrink-0" />{s}</li>)}</ul>
              </CardContent>
            </Card>
          )}
          {feedback.encouragement && (
            <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
              <CardContent className="p-4 flex gap-3">
                <span className="text-2xl">🦉</span>
                <p className="text-sm text-amber-800 italic">{feedback.encouragement}</p>
              </CardContent>
            </Card>
          )}
          <div className="flex items-center justify-between text-xs text-muted-foreground text-center">
            <span>{wordCount} Wörter</span>
            <div className="flex items-center gap-1 text-amber-600 font-semibold">
              <Zap className="w-3.5 h-3.5" />
              +{calculateWritingXP(feedback.overall_score ?? 0, prompt.difficulty || 'medium')} XP
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto animate-fade-in">
      <Button variant="ghost" onClick={onBack} className="mb-4">← Zurück</Button>
      {/* Step indicator */}
      <div className="flex items-center gap-1 mb-6 overflow-x-auto">
        {WRITING_STEPS.map((s, i) => (
          <div key={s} className="flex items-center gap-1 flex-shrink-0">
            <button onClick={() => setStep(i)} className={cn("px-3 py-1.5 rounded-full text-xs font-semibold transition-all whitespace-nowrap",
              i === step ? "bg-primary text-white" : i < step ? "bg-green-100 text-green-700" : "bg-secondary text-muted-foreground")}>
              {i < step ? "✓ " : ""}{s}
            </button>
            {i < WRITING_STEPS.length - 1 && <ArrowRight className="w-3 h-3 text-muted-foreground flex-shrink-0" />}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main workspace */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className="font-bold">{prompt.title}</h3>
                <span className={cn("text-xs px-2 py-1 rounded-full font-medium", GENRE_COLORS[prompt.genre] || "bg-secondary")}>{GENRE_LABELS[prompt.genre]}</span>
              </div>
              <p className="text-sm">{prompt.prompt_text}</p>
              {prompt.context && <p className="text-xs text-muted-foreground mt-2 italic">{prompt.context}</p>}
              {(prompt.min_words || prompt.max_words) && (
                <p className="text-xs text-primary mt-2 font-semibold">Wortanzahl: {prompt.min_words}–{prompt.max_words} Wörter</p>
              )}
            </CardContent>
          </Card>

          {step === 0 && (
            <Card>
              <CardHeader><CardTitle className="text-base">Vorbereitung</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">Sammle erste Ideen, Stichpunkte und Schlüsselbegriffe.</p>
                <Textarea value={brainstorm} onChange={e => setBrainstorm(e.target.value)}
                  placeholder="Ideen, Stichpunkte, Schlüsselbegriffe..." className="min-h-24 resize-none" />
                <Button onClick={() => setStep(1)} className="w-full">Weiter zur Gliederung →</Button>
              </CardContent>
            </Card>
          )}

          {step === 1 && (
            <Card>
              <CardHeader><CardTitle className="text-base">Gliederung</CardTitle></CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">Plane die Struktur deines Textes.</p>
                {prompt.structure_guide?.map((s, i) => (
                  <div key={i} className="flex items-start gap-2 mb-2 p-2 rounded-lg bg-secondary/50">
                    <span className="text-xs font-bold text-primary mt-0.5 w-5 flex-shrink-0">{i + 1}.</span>
                    <span className="text-sm">{s}</span>
                  </div>
                ))}
                <Textarea value={outline} onChange={e => setOutline(e.target.value)} placeholder="Deine Gliederung..." className="min-h-24 resize-none mt-3" />
                <Button onClick={() => setStep(2)} className="mt-3 w-full">Zum Schreiben →</Button>
              </CardContent>
            </Card>
          )}

          {step === 2 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center justify-between">
                  Schreiben
                  <span className={cn("text-xs font-normal", !uploadedImage && prompt.min_words && wordCount < prompt.min_words ? "text-muted-foreground" : "text-primary")}>
                    {uploadedImage ? "📷 Handschriftlich" : `${wordCount} Wörter`}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 mb-4">
                  {outline && (
                    <div>
                      <button onClick={() => setShowOutline(!showOutline)}
                        className="flex items-center gap-1.5 text-xs font-semibold text-primary hover:underline">
                        <ListOrdered className="w-3.5 h-3.5" />
                        {showOutline ? "Gliederung ausblenden ▲" : "Gliederung anzeigen ▼"}
                      </button>
                      {showOutline && (
                        <div className="p-3 rounded-lg bg-primary/5 border border-primary/20 text-sm text-muted-foreground whitespace-pre-wrap mt-2">
                          {outline}
                        </div>
                      )}
                    </div>
                  )}
                  {brainstorm && (
                    <div>
                      <button onClick={() => setShowBrainstorm(!showBrainstorm)}
                        className="flex items-center gap-1.5 text-xs font-semibold text-primary hover:underline">
                        <Lightbulb className="w-3.5 h-3.5" />
                        {showBrainstorm ? "Ideen ausblenden ▲" : "Ideen anzeigen ▼"}
                      </button>
                      {showBrainstorm && (
                        <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200 text-sm text-yellow-800 whitespace-pre-wrap mt-2">
                          {brainstorm}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {uploadedImage ? (
                  <div className="space-y-3">
                    <div className="relative border-2 border-primary/30 rounded-lg overflow-hidden bg-primary/5">
                      <img src={uploadedImage} alt="Handschriftliche Antwort" className="w-full h-auto" />
                      <button onClick={() => setUploadedImage(null)}
                        className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-lg hover:bg-red-600">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <Button onClick={() => setStep(3)} className="w-full">Zur Checkliste →</Button>
                    </div>
                    ) : (
                    <div className="space-y-3">
                     <Textarea value={text} onChange={e => setText(e.target.value)}
                       placeholder="Schreibe deinen Text hier..." className="min-h-64 resize-none font-sans" />
                     <div className="flex gap-2">
                       <Button onClick={() => setStep(3)} className="flex-1" disabled={wordCount < 20}>Zur Checkliste →</Button>
                      <label className="flex-1">
                        <input type="file" accept="image/*" onChange={e => handleImageUpload(e.target.files?.[0])}
                          disabled={uploadingImage} className="hidden" />
                        <Button variant="outline" className="w-full cursor-pointer" disabled={uploadingImage} asChild>
                          <span className="flex items-center justify-center gap-2">
                            <ImageIcon className="w-4 h-4" />
                            {uploadingImage ? "Wird hochgeladen..." : "Foto hochladen"}
                          </span>
                        </Button>
                      </label>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {step === 3 && (
            <ChecklistStep
              prompt={prompt}
              text={text}
              setText={setText}
              uploadedImage={uploadedImage}
              wordCount={wordCount}
              generating={generating}
              onGenerateFeedback={generateFeedback}
            />
          )}
        </div>

        {/* Sidebar: Genre Guide + tools */}
        <div className="space-y-4">
          {/* Genre Guide toggle */}
          <Card>
            <CardContent className="p-4">
              <button className="flex items-center justify-between w-full font-semibold text-sm mb-2"
                onClick={() => setShowGuide(!showGuide)}>
                <span className="flex items-center gap-1"><BookOpen className="w-4 h-4 text-primary" />Textsorten-Guide</span>
                <span>{showGuide ? "▲" : "▼"}</span>
              </button>
              {showGuide && <GenreGuide genreKey={prompt.genre} />}
            </CardContent>
          </Card>

          {prompt.donts?.length > 0 && (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-red-700 mb-2 flex items-center gap-1"><X className="w-4 h-4" />Don'ts</h4>
                <ul className="space-y-1">{prompt.donts.map((d, i) => <li key={i} className="text-xs text-red-800">• {d}</li>)}</ul>
              </CardContent>
            </Card>
          )}

          {prompt.useful_phrases?.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <p className="font-semibold text-sm mb-2 flex items-center gap-1"><Lightbulb className="w-4 h-4 text-yellow-500" />Nützliche Phrasen</p>
                {prompt.useful_phrases.map((p, i) => (
                  <div key={i} className="text-xs text-muted-foreground py-1 border-b border-border/50 last:border-0">• {p}</div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}