import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  ChevronRight, ChevronLeft, Check, BookOpen, GraduationCap,
  FileText, PenLine, Headphones, Mic, Zap
} from "lucide-react";

// Steps after welcome: grade, goals, weak_areas, time, summary
const TOTAL_STEPS = 4; // excludes welcome (0) and summary (5)

const GRADES = [
  { value: "8", label: "Klasse 8", emoji: "📗", desc: "Inhalte passend zur 8. Klasse" },
  { value: "9", label: "Klasse 9", emoji: "📘", desc: "Inhalte passend zur 9. Klasse" },
];

const GOALS = [
  { value: "klassenarbeit", label: "Klassenarbeit vorbereiten", icon: "📋" },
  { value: "test",          label: "Vokabeltest bestehen",      icon: "📝" },
  { value: "langfristig",   label: "Schritt für Schritt besser werden", icon: "📈" },
  { value: "luecken",       label: "Lücken gezielt schließen",  icon: "🔍" },
  { value: "hausaufgabe",   label: "Hausaufgabe erledigen",     icon: "🏠" },
];

const WEAK_AREAS = [
  { value: "vocabulary", label: "Vokabeln",    icon: BookOpen },
  { value: "grammar",    label: "Grammatik",   icon: GraduationCap },
  { value: "reading",    label: "Lesen",       icon: FileText },
  { value: "writing",    label: "Schreiben",   icon: PenLine },
  { value: "listening",  label: "Hören",       icon: Headphones },
  { value: "speaking",   label: "Sprechen",    icon: Mic },
];

const TIME_OPTIONS = [
  { value: 10, label: "10 Min", desc: "Schnell & gezielt" },
  { value: 20, label: "20 Min", desc: "Ideal für den Alltag" },
  { value: 30, label: "30 Min", desc: "Gründlich üben" },
  { value: 45, label: "45 Min+", desc: "Intensiv vorbereiten" },
];

const GOAL_LABELS = {
  klassenarbeit: "Klassenarbeit",
  test: "Vokabeltest",
  langfristig: "Langfristig besser",
  luecken: "Lücken schließen",
  hausaufgabe: "Hausaufgabe",
};

const AREA_LABELS = {
  vocabulary: "Vokabeln",
  grammar: "Grammatik",
  reading: "Lesen",
  writing: "Schreiben",
  listening: "Hören",
  speaking: "Sprechen",
};

export default function Onboarding() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [step, setStep] = useState(0);
  const [data, setData] = useState({
    grade: "",
    goals: [],
    weak_areas: [],
    daily_minutes: 20,
  });

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });

  const createProfile = useMutation({
    mutationFn: (profileData) => base44.entities.UserProfile.create(profileData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-profile"] });
      navigate("/");
    },
  });

  const toggle = (field, value) => {
    setData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(v => v !== value)
        : [...prev[field], value]
    }));
  };

  const canProceed = () => {
    if (step === 1) return data.grade !== "";
    if (step === 2) return data.goals.length > 0;
    return true;
  };

  const handleFinish = () => {
    createProfile.mutate({
      user_email: user.email,
      grade: data.grade,
      goals: data.goals,
      weak_areas: data.weak_areas,
      upcoming_topics: [],
      daily_minutes: data.daily_minutes,
      learning_style: "gemischt",
      wants_daily_plan: true,
      xp: 0, level: 1, streak: 0,
      onboarding_complete: true,
      badges: [],
    });
  };

  const firstName = user?.full_name?.split(" ")[0];

  // Step labels for progress indicator (steps 1–4)
  const stepLabels = ["Klasse", "Ziel", "Schwerpunkte", "Zeit"];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-brand-blue-light/20 flex items-center justify-center p-4">
      <div className="w-full max-w-md">

        {/* Brand header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2.5 mb-1">
            <div className="w-10 h-10 rounded-2xl brand-gradient flex items-center justify-center shadow-md">
              <span className="text-white font-black text-sm">EB</span>
            </div>
            <span className="text-xl font-black tracking-tight">
              English <span className="text-primary">Boost</span>
            </span>
          </div>
        </div>

        {/* Step progress bar (steps 1–4) */}
        {step >= 1 && step <= 4 && (
          <div className="mb-5">
            <div className="flex items-center justify-between mb-2 px-0.5">
              {stepLabels.map((label, i) => (
                <div key={i} className="flex flex-col items-center gap-1">
                  <div className={cn(
                    "w-7 h-7 rounded-full flex items-center justify-center text-xs font-black transition-all",
                    i + 1 < step ? "bg-primary text-white" :
                    i + 1 === step ? "bg-primary text-white ring-4 ring-primary/20" :
                    "bg-muted text-muted-foreground"
                  )}>
                    {i + 1 < step ? <Check className="w-3.5 h-3.5" /> : i + 1}
                  </div>
                  <span className={cn(
                    "text-[10px] font-semibold",
                    i + 1 === step ? "text-primary" : "text-muted-foreground"
                  )}>{label}</span>
                </div>
              ))}
            </div>
            <div className="relative h-1 bg-muted rounded-full overflow-hidden mt-1">
              <div
                className="absolute left-0 top-0 h-full bg-primary rounded-full transition-all duration-500"
                style={{ width: `${((step - 1) / TOTAL_STEPS) * 100}%` }}
              />
            </div>
          </div>
        )}

        <div className="bg-card rounded-3xl shadow-xl border border-border/50 overflow-hidden">
          <div className="p-6">

            {/* ── Step 0: Welcome ── */}
            {step === 0 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-black tracking-tight leading-snug">
                    {firstName ? `Hallo, ${firstName}! 👋` : "Willkommen! 👋"}
                  </h2>
                  <p className="text-muted-foreground text-sm mt-2 leading-relaxed">
                    English Boost hilft dir, besser in Englisch zu werden.
                  </p>
                </div>

                {/* What the app does */}
                <div className="rounded-2xl bg-muted/50 border border-border p-4 space-y-2.5">
                  <p className="text-xs font-black text-muted-foreground uppercase tracking-wider">Was dich erwartet</p>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { icon: "📖", label: "Vokabeln" },
                      { icon: "✏️", label: "Grammatik" },
                      { icon: "📄", label: "Texte lesen" },
                      { icon: "🎧", label: "Hörverstehen" },
                      { icon: "🖊️", label: "Schreiben" },
                      { icon: "🎯", label: "Testen üben" },
                    ].map(item => (
                      <div key={item.label} className="flex items-center gap-2.5 py-1">
                        <span className="text-lg">{item.icon}</span>
                        <span className="text-sm font-semibold">{item.label}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Button
                    onClick={() => setStep(1)}
                    className="w-full gap-2 rounded-xl font-black brand-gradient text-white border-0 shadow-sm h-12 text-base"
                  >
                    App einrichten <ChevronRight className="w-5 h-5" />
                  </Button>

                </div>
              </div>
            )}

            {/* ── Step 1: Grade ── */}
            {step === 1 && (
              <div className="space-y-4">
                <div>
                  <h2 className="text-xl font-black tracking-tight">In welche Klasse gehst du?</h2>
                  <p className="text-sm text-muted-foreground mt-1">Wir passen alle Inhalte an deinen Lehrplan an.</p>
                </div>
                <div className="space-y-2.5">
                  {GRADES.map(g => (
                    <button
                      key={g.value}
                      onClick={() => setData(prev => ({ ...prev, grade: g.value }))}
                      className={cn(
                        "w-full p-4 rounded-2xl border-2 text-left transition-all flex items-center gap-4",
                        data.grade === g.value
                          ? "border-primary bg-primary/8 shadow-sm"
                          : "border-border hover:border-primary/30 hover:bg-muted/40"
                      )}
                    >
                      <span className="text-3xl">{g.emoji}</span>
                      <div className="flex-1">
                        <div className="font-black text-base">{g.label}</div>
                        <div className="text-xs text-muted-foreground mt-0.5">{g.desc}</div>
                      </div>
                      {data.grade === g.value && (
                        <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                          <Check className="w-3.5 h-3.5 text-white" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* ── Step 2: Goals ── */}
            {step === 2 && (
              <div className="space-y-4">
                <div>
                  <h2 className="text-xl font-black tracking-tight">Was ist dein Ziel gerade?</h2>
                  <p className="text-sm text-muted-foreground mt-1">Mehrere möglich.</p>
                </div>
                <div className="space-y-2">
                  {GOALS.map(g => (
                    <button
                      key={g.value}
                      onClick={() => toggle("goals", g.value)}
                      className={cn(
                        "w-full p-3.5 rounded-2xl border-2 text-left flex items-center gap-3 transition-all",
                        data.goals.includes(g.value)
                          ? "border-primary bg-primary/8 shadow-sm"
                          : "border-border hover:border-primary/30 hover:bg-muted/40"
                      )}
                    >
                      <span className="text-lg flex-shrink-0">{g.icon}</span>
                      <span className="flex-1 font-semibold text-sm">{g.label}</span>
                      {data.goals.includes(g.value) && (
                        <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* ── Step 3: Weak Areas ── */}
            {step === 3 && (
              <div className="space-y-4">
                <div>
                  <h2 className="text-xl font-black tracking-tight">Wo möchtest du besser werden?</h2>
                  <p className="text-sm text-muted-foreground mt-1">Optional – du kannst auch nichts auswählen.</p>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  {WEAK_AREAS.map(area => {
                    const Icon = area.icon;
                    const selected = data.weak_areas.includes(area.value);
                    return (
                      <button
                        key={area.value}
                        onClick={() => toggle("weak_areas", area.value)}
                        className={cn(
                          "p-4 rounded-2xl border-2 text-left transition-all flex items-center gap-3",
                          selected
                            ? "border-primary bg-primary/8 shadow-sm"
                            : "border-border hover:border-primary/30 hover:bg-muted/40"
                        )}
                      >
                        <Icon className={cn("w-4 h-4 flex-shrink-0", selected ? "text-primary" : "text-muted-foreground")} />
                        <span className={cn("text-sm font-bold", selected ? "text-primary" : "text-foreground")}>{area.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ── Step 4: Time ── */}
            {step === 4 && (
              <div className="space-y-4">
                <div>
                  <h2 className="text-xl font-black tracking-tight">Wie viel Zeit hast du täglich?</h2>
                  <p className="text-sm text-muted-foreground mt-1">Auch 10 Minuten machen einen echten Unterschied.</p>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  {TIME_OPTIONS.map(t => (
                    <button
                      key={t.value}
                      onClick={() => setData(prev => ({ ...prev, daily_minutes: t.value }))}
                      className={cn(
                        "p-4 rounded-2xl border-2 text-center transition-all",
                        data.daily_minutes === t.value
                          ? "border-primary bg-primary/8 shadow-sm"
                          : "border-border hover:border-primary/30 hover:bg-muted/40"
                      )}
                    >
                      <div className="font-black text-2xl text-foreground">{t.label}</div>
                      <div className="text-xs text-muted-foreground mt-1">{t.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* ── Step 5: Summary ── */}
            {step === 5 && (
              <div className="space-y-5">
                {/* Hero */}
                <div className="text-center py-2">
                  <div className="text-4xl mb-2">🎉</div>
                  <h2 className="text-xl font-black tracking-tight">Alles bereit!</h2>
                  <p className="text-sm text-muted-foreground mt-1">Dein Profil ist eingerichtet. Hier eine Übersicht:</p>
                </div>

                {/* Summary cards */}
                <div className="space-y-2.5">
                  <SummaryCard
                    emoji="📗"
                    label="Klasse"
                    value={`Klasse ${data.grade}`}
                    color="bg-emerald-50 border-emerald-200"
                    valueColor="text-emerald-800"
                  />
                  <SummaryCard
                    emoji="🎯"
                    label="Deine Ziele"
                    value={data.goals.length > 0
                      ? data.goals.map(g => GOAL_LABELS[g]).join(", ")
                      : "–"}
                    color="bg-blue-50 border-blue-200"
                    valueColor="text-blue-800"
                  />
                  {data.weak_areas.length > 0 && (
                    <SummaryCard
                      emoji="💪"
                      label="Schwerpunkte"
                      value={data.weak_areas.map(a => AREA_LABELS[a]).join(", ")}
                      color="bg-violet-50 border-violet-200"
                      valueColor="text-violet-800"
                    />
                  )}
                  <SummaryCard
                    emoji="⏱️"
                    label="Täglich"
                    value={`${data.daily_minutes} Minuten`}
                    color="bg-amber-50 border-amber-200"
                    valueColor="text-amber-800"
                  />
                </div>

                <p className="text-xs text-muted-foreground text-center">
                  Alle Einstellungen kannst du jederzeit im Profil anpassen.
                </p>
              </div>
            )}

            {/* Navigation (steps 1–5) */}
            {step >= 1 && (
              <div className="flex gap-3 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setStep(s => s - 1)}
                  className="gap-1.5 rounded-xl font-bold px-4"
                >
                  <ChevronLeft className="w-4 h-4" />Zurück
                </Button>
                {step < 5 ? (
                  <Button
                    onClick={() => setStep(s => s + 1)}
                    disabled={!canProceed()}
                    className="flex-1 gap-1.5 rounded-xl font-bold"
                  >
                    Weiter <ChevronRight className="w-4 h-4" />
                  </Button>
                ) : (
                  <Button
                    onClick={handleFinish}
                    disabled={createProfile.isPending}
                    className="flex-1 gap-2 rounded-xl font-black brand-gradient text-white border-0 shadow-sm"
                  >
                    <Zap className="w-4 h-4" />
                    {createProfile.isPending ? "Wird eingerichtet…" : "Los geht's!"}
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>


      </div>
    </div>
  );
}

function SummaryCard({ emoji, label, value, color, valueColor }) {
  return (
    <div className={`flex items-start gap-3 p-3.5 rounded-2xl border ${color}`}>
      <span className="text-xl flex-shrink-0 mt-0.5">{emoji}</span>
      <div className="flex-1 min-w-0">
        <p className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-0.5">{label}</p>
        <p className={`text-sm font-bold leading-snug ${valueColor}`}>{value}</p>
      </div>
    </div>
  );
}