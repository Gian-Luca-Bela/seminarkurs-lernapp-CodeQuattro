import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { User, Settings, LogOut, Zap, Flame, Star, Edit2, Check, BookOpen, GraduationCap, FileText, PenLine, Headphones, Mic, Bell, Clock, Brain, Target, Palette, History } from "lucide-react";
import { useCompletedTasks } from "@/lib/useCompletedTasks";
import CompletedTasksTab from "@/components/profile/CompletedTasksTab";
import { getLevelName, getXPForNextLevel } from "@/lib/utils";
import { BADGES } from "@/lib/constants";
import { useTheme, THEMES } from "@/lib/ThemeContext";

const LEARNING_STYLES = [
  { value: "kurz_intensiv", label: "Kurz & intensiv", desc: "Schnelle, kompakte Einheiten (10-15 Min)" },
  { value: "kreativ", label: "Kreativ", desc: "Texte, Geschichten, kreatives Schreiben" },
  { value: "schreiben", label: "Schwergewicht Schreiben", desc: "Viele Schreibaufgaben & Feedback" },
  { value: "uebungen", label: "Viele Übungen", desc: "Drill, Multiple-Choice, Lücken" },
  { value: "gemischt", label: "Gemischt", desc: "Abwechslung aus allem" },
];

const SESSION_PREFS = [
  { value: "short", label: "Kurze Sessions", desc: "10-15 Min" },
  { value: "long", label: "Lange Sessions", desc: "30-45 Min" },
];

const CONTENT_FOCUS = [
  { value: "more_review", label: "Mehr Wiederholung", desc: "Bekanntes festigen" },
  { value: "more_new", label: "Mehr Neues", desc: "Neuen Stoff entdecken" },
  { value: "balanced", label: "Ausgewogen", desc: "Beides gleichmäßig" },
];

const GAMIFICATION_PREFS = [
  { value: "gamified", label: "Mehr Gamification", desc: "XP, Badges, Streaks im Vordergrund" },
  { value: "academic", label: "Mehr akademisch", desc: "Fokus auf Lerninhalte, weniger Spielelemente" },
];

const WEAK_AREA_OPTIONS = [
  { value: "vocabulary", label: "Vokabeln", icon: BookOpen },
  { value: "grammar", label: "Grammatik", icon: GraduationCap },
  { value: "reading", label: "Lesen", icon: FileText },
  { value: "writing", label: "Schreiben", icon: PenLine },
  { value: "listening", label: "Hören", icon: Headphones },
  { value: "speaking", label: "Sprechen", icon: Mic },
];

export default function Profile() {
  const [editing, setEditing] = useState(false);
  const [activeTab, setActiveTab] = useState("profile");
  const queryClient = useQueryClient();

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];
  const [formData, setFormData] = useState(null);

  const updateProfile = useMutation({
    mutationFn: (data) => base44.entities.UserProfile.update(profile.id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["user-profile"] }); setEditing(false); },
  });

  const startEdit = () => {
    setFormData({
      grade: profile?.grade || "8",
      daily_minutes: profile?.daily_minutes || 20,
      learning_style: profile?.learning_style || "gemischt",
      weak_areas: profile?.weak_areas || [],
      goals: profile?.goals || [],
      session_pref: profile?.session_pref || "short",
      content_focus: profile?.content_focus || "balanced",
      gamification_pref: profile?.gamification_pref || "gamified",
    });
    setEditing(true);
  };

  const toggleWeak = (val) => {
    setFormData(d => ({ ...d, weak_areas: d.weak_areas.includes(val) ? d.weak_areas.filter(v => v !== val) : [...d.weak_areas, val] }));
  };

  const { completedTasks, removeCompleted, starTask } = useCompletedTasks(user?.email);

  const xpData = getXPForNextLevel(profile?.xp || 0);
  const levelName = getLevelName(profile?.level || 1);
  const { themeId, setThemeId } = useTheme();

  const today = new Date().toISOString().split("T")[0];
  const yesterday = new Date(); yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split("T")[0];
  const lastActive = profile?.last_active;
  const streakActive = lastActive === today || lastActive === yesterdayStr;

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-in">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold flex items-center gap-2"><User className="w-6 h-6 text-primary" />Mein Konto</h1>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-secondary rounded-xl mb-6">
        <button onClick={() => setActiveTab("profile")}
          className={cn("flex-1 py-1.5 px-3 rounded-lg text-sm font-semibold transition-all", activeTab === "profile" ? "bg-card shadow text-foreground" : "text-muted-foreground hover:text-foreground")}>
          Profil & Einstellungen
        </button>
        <button onClick={() => setActiveTab("history")}
          className={cn("flex-1 py-1.5 px-3 rounded-lg text-sm font-semibold transition-all flex items-center justify-center gap-1.5", activeTab === "history" ? "bg-card shadow text-foreground" : "text-muted-foreground hover:text-foreground")}>
          <History className="w-3.5 h-3.5" />Verlauf
          {completedTasks.length > 0 && <span className="text-xs bg-primary text-white rounded-full px-1.5 py-0.5 leading-none">{completedTasks.length}</span>}
        </button>
      </div>

      {activeTab === "history" && (
        <CompletedTasksTab completedTasks={completedTasks} onDelete={removeCompleted} onStar={starTask} />
      )}

      {activeTab === "profile" && (
        <div className="space-y-4">
          {/* User card */}
          <Card className="overflow-hidden">
            <div className="h-24 bg-brand-gradient" />
            <CardContent className="p-5 -mt-12">
              <div className="flex items-end gap-4 mb-4">
                <div className="w-20 h-20 rounded-2xl bg-white border-4 border-background shadow-lg flex items-center justify-center text-4xl">
                  🦉
                </div>
                <div className="pb-1">
                  <h2 className="text-xl font-bold">{user?.full_name || "Schüler(in)"}</h2>
                  <p className="text-sm text-muted-foreground">{user?.email}</p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4 text-center mt-2">
                <div>
                  <div className="flex items-center justify-center gap-1 text-xl font-bold"><Star className="w-5 h-5 text-yellow-500" />{profile?.level || 1}</div>
                  <p className="text-xs text-muted-foreground">{levelName}</p>
                </div>
                <div>
                  <div className="flex items-center justify-center gap-1 text-xl font-bold"><Zap className="w-5 h-5 text-primary" />{profile?.xp || 0}</div>
                  <p className="text-xs text-muted-foreground">XP</p>
                </div>
                <div>
                  <div className="flex items-center justify-center gap-1 text-xl font-bold"><Flame className="w-5 h-5 text-orange-500" />{profile?.streak || 0}</div>
                  <p className="text-xs text-muted-foreground">Streak</p>
                </div>
              </div>
              <div className="mt-4">
                <div className="flex justify-between text-xs text-muted-foreground mb-1">
                  <span>Level {profile?.level || 1} → {(profile?.level || 1) + 1}</span>
                  <span>{xpData.current} / {xpData.next} XP</span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-brand-gradient rounded-full transition-all" style={{ width: `${xpData.progress}%` }} />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Profile settings */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-base flex items-center gap-2"><Settings className="w-4 h-4" />Lerneinstellungen</CardTitle>
              {!editing ? (
                <Button variant="outline" size="sm" onClick={startEdit} className="gap-1 h-7 text-xs"><Edit2 className="w-3 h-3" />Bearbeiten</Button>
              ) : (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => setEditing(false)} className="h-7 text-xs">Abbrechen</Button>
                  <Button size="sm" onClick={() => updateProfile.mutate(formData)} disabled={updateProfile.isPending} className="h-7 text-xs gap-1"><Check className="w-3 h-3" />Speichern</Button>
                </div>
              )}
            </CardHeader>
            <CardContent className="space-y-4">
              {!editing ? (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Klasse</span>
                    <Badge variant="secondary">Klasse {profile?.grade}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Lernzeit täglich</span>
                    <span className="text-sm font-semibold">{profile?.daily_minutes || 20} Min</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Lernstil</span>
                    <span className="text-sm font-semibold">{LEARNING_STYLES.find(s => s.value === profile?.learning_style)?.label || "Gemischt"}</span>
                  </div>
                  {profile?.weak_areas?.length > 0 && (
                    <div>
                      <span className="text-sm text-muted-foreground block mb-1.5">Schwächen</span>
                      <div className="flex flex-wrap gap-1.5">
                        {profile.weak_areas.map(a => <Badge key={a} variant="secondary" className="text-xs">{a}</Badge>)}
                      </div>
                    </div>
                  )}
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Session-Länge</span>
                    <span className="text-sm font-semibold">{SESSION_PREFS.find(s => s.value === profile?.session_pref)?.label || "Kurze Sessions"}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Inhaltsfokus</span>
                    <span className="text-sm font-semibold">{CONTENT_FOCUS.find(s => s.value === profile?.content_focus)?.label || "Ausgewogen"}</span>
                  </div>
                </div>
              ) : formData && (
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm">Klasse</Label>
                    <div className="flex gap-2 mt-1">
                      {["8", "9"].map(g => (
                        <button key={g} onClick={() => setFormData(d => ({ ...d, grade: g }))}
                          className={cn("px-4 py-2 rounded-xl text-sm font-semibold border-2 transition-all", formData.grade === g ? "border-primary bg-primary/5" : "border-border")}>{g}</button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm">Tägliche Lernzeit: {formData.daily_minutes} Min</Label>
                    <input type="range" min={10} max={60} step={5} value={formData.daily_minutes}
                      onChange={e => setFormData(d => ({ ...d, daily_minutes: parseInt(e.target.value) }))}
                      className="w-full mt-1 accent-primary" />
                    <div className="flex justify-between text-xs text-muted-foreground"><span>10</span><span>60</span></div>
                  </div>
                  <div>
                    <Label className="text-sm">Lernstil</Label>
                    <div className="space-y-1 mt-1">
                      {LEARNING_STYLES.map(s => (
                        <button key={s.value} onClick={() => setFormData(d => ({ ...d, learning_style: s.value }))}
                          className={cn("w-full p-2.5 rounded-xl border-2 text-left text-sm transition-all", formData.learning_style === s.value ? "border-primary bg-primary/5 font-semibold" : "border-border hover:border-primary/30")}>
                          {s.label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm">Schwächen (mehrere möglich)</Label>
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      {WEAK_AREA_OPTIONS.map(area => {
                        const Icon = area.icon;
                        return (
                          <button key={area.value} onClick={() => toggleWeak(area.value)}
                            className={cn("p-2 rounded-xl border-2 text-sm flex items-center gap-2 transition-all", formData.weak_areas.includes(area.value) ? "border-primary bg-primary/5 font-semibold" : "border-border")}>
                            <Icon className="w-4 h-4" />{area.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" />Session-Länge</Label>
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      {SESSION_PREFS.map(s => (
                        <button key={s.value} onClick={() => setFormData(d => ({ ...d, session_pref: s.value }))}
                          className={cn("p-3 rounded-xl border-2 text-left text-sm transition-all", formData.session_pref === s.value ? "border-primary bg-primary/5" : "border-border")}>
                          <p className="font-bold text-xs">{s.label}</p>
                          <p className="text-xs text-muted-foreground">{s.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm flex items-center gap-1.5"><Brain className="w-3.5 h-3.5" />Inhaltsfokus</Label>
                    <div className="grid grid-cols-3 gap-2 mt-1">
                      {CONTENT_FOCUS.map(s => (
                        <button key={s.value} onClick={() => setFormData(d => ({ ...d, content_focus: s.value }))}
                          className={cn("p-2.5 rounded-xl border-2 text-left text-xs transition-all", formData.content_focus === s.value ? "border-primary bg-primary/5" : "border-border")}>
                          <p className="font-bold">{s.label}</p>
                          <p className="text-muted-foreground mt-0.5">{s.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm flex items-center gap-1.5"><Target className="w-3.5 h-3.5" />Gamification-Stil</Label>
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      {GAMIFICATION_PREFS.map(s => (
                        <button key={s.value} onClick={() => setFormData(d => ({ ...d, gamification_pref: s.value }))}
                          className={cn("p-3 rounded-xl border-2 text-left text-sm transition-all", formData.gamification_pref === s.value ? "border-primary bg-primary/5" : "border-border")}>
                          <p className="font-bold text-xs">{s.label}</p>
                          <p className="text-xs text-muted-foreground">{s.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl border border-border bg-secondary/30">
                    <div className="flex items-center gap-2">
                      <Bell className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-semibold">Tägliche Erinnerung</p>
                        <p className="text-xs text-muted-foreground">Kommt bald – Push-Benachrichtigung</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs">Bald</Badge>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Badges */}
          <Card>
            <CardHeader><CardTitle className="text-base">Abzeichen</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 md:grid-cols-6 gap-3">
                {BADGES.map(badge => {
                  const earned = profile?.badges?.includes(badge.id);
                  return (
                    <div key={badge.id} className={cn("text-center p-2 rounded-xl", earned ? "bg-yellow-50 border border-yellow-200" : "bg-secondary/50 opacity-50")} title={badge.description}>
                      <div className="text-2xl">{badge.icon}</div>
                      <div className="text-xs mt-1 font-medium leading-tight">{badge.label}</div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Streak info */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3 mb-3">
                <Flame className="w-4 h-4 text-orange-500" />
                <span className="font-bold text-sm">Lern-Streak</span>
                <span className={`ml-auto text-xs font-semibold px-2 py-0.5 rounded-full ${streakActive ? "bg-orange-100 text-orange-700" : "bg-secondary text-muted-foreground"}`}>
                  {streakActive ? "Aktiv heute ✓" : "Heute noch nicht gelernt"}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-orange-400 to-red-500 rounded-full transition-all"
                    style={{ width: `${Math.min(((profile?.streak || 0) / 30) * 100, 100)}%` }} />
                </div>
                <span className="text-sm font-black text-orange-600">{profile?.streak || 0} Tage</span>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Ein Streak zählt, wenn du täglich lernst. Lerne heute, um deinen Streak zu erhalten!
              </p>
            </CardContent>
          </Card>

          {/* Theme Picker */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3">
                <Palette className="w-4 h-4 text-primary" />
                <span className="font-bold text-sm">App-Design</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {THEMES.map(theme => (
                  <button key={theme.id} onClick={() => setThemeId(theme.id)}
                    className={cn("p-3 rounded-xl border-2 text-left transition-all relative overflow-hidden",
                      themeId === theme.id ? "border-primary ring-2 ring-primary/30" : "border-border hover:border-primary/40 hover:shadow-sm")}>
                    {theme.preview && (
                      <div className="flex gap-1 mb-2">
                        {theme.preview.map((color, ci) => (
                          <div key={ci} className="h-4 rounded flex-1" style={{ backgroundColor: color }} />
                        ))}
                      </div>
                    )}
                    <div className="flex items-center gap-1.5">
                      <span className="text-base">{theme.emoji}</span>
                      <p className="font-bold text-xs leading-none">{theme.label}</p>
                      {themeId === theme.id && (
                        <div className="ml-auto w-4 h-4 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                          <Check className="w-2.5 h-2.5 text-white" />
                        </div>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{theme.desc}</p>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          <Button variant="outline" onClick={() => base44.auth.logout()} className="w-full gap-2 text-destructive hover:bg-destructive/5 border-destructive/20">
            <LogOut className="w-4 h-4" />Abmelden
          </Button>
        </div>
      )}
    </div>
  );
}