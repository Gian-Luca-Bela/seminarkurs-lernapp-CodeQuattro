import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import {
  BarChart3, Zap, Flame, Target, TrendingUp, AlertCircle,
  CheckCircle2, BookOpen, Star, Trophy
} from "lucide-react";
import { SKILL_AREAS, SKILL_COLORS, BADGES } from "@/lib/constants";
import { getLevelName, getXPForNextLevel } from "@/lib/utils";
import { cn } from "@/lib/utils";
import MistakeInsights from "@/components/MistakeInsights";

const SKILL_DOT_COLORS = {
  vocabulary: "#16a34a", grammar: "#2563eb", reading: "#7c3aed",
  listening: "#ea580c", writing: "#f43f5e", speaking: "#ca8a04", mediation: "#0d9488",
};

export default function Progress() {
  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];

  const { data: attempts = [] } = useQuery({
    queryKey: ["all-attempts", user?.email],
    queryFn: () => base44.entities.ExerciseAttempt.filter({ user_email: user?.email }, "-created_date", 200),
    enabled: !!user?.email,
  });

  const xpData = getXPForNextLevel(profile?.xp || 0);
  const levelName = getLevelName(profile?.level || 1);

  const skillStats = SKILL_AREAS.map(skill => {
    const skillAttempts = attempts.filter(a => a.skill_area === skill.key);
    const correct = skillAttempts.filter(a => a.is_correct).length;
    const accuracy = skillAttempts.length > 0 ? Math.round((correct / skillAttempts.length) * 100) : 0;
    return { ...skill, total: skillAttempts.length, correct, accuracy };
  }).filter(s => s.total > 0);

  const mistakes = attempts.filter(a => !a.is_correct).slice(0, 8);
  const totalCorrect = attempts.filter(a => a.is_correct).length;
  const totalAttempts = attempts.length;
  const overallAccuracy = totalAttempts > 0 ? Math.round((totalCorrect / totalAttempts) * 100) : 0;

  const chartData = SKILL_AREAS.map(skill => {
    const sa = attempts.filter(a => a.skill_area === skill.key);
    return { name: skill.label.substring(0, 5), count: sa.length, correct: sa.filter(a => a.is_correct).length };
  }).filter(d => d.count > 0);

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto animate-fade-up space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black tracking-tight flex items-center gap-2.5">
          <span className="w-9 h-9 rounded-2xl brand-gradient flex items-center justify-center shadow-sm">
            <BarChart3 className="w-5 h-5 text-white" />
          </span>
          Mein Fortschritt
        </h1>
        <p className="text-muted-foreground text-sm mt-1 ml-12">Was du schon kannst – und wo du noch wachsen kannst</p>
      </div>

      {/* Top stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          {
            icon: <span className="text-2xl font-black text-primary">{profile?.level || 1}</span>,
            label: levelName,
            sub: "Aktuelles Level",
            bg: "bg-primary/8 border-primary/20",
            extra: <ProgressBar value={xpData.progress} className="mt-2.5 h-1.5" />,
          },
          {
            icon: <span className="text-2xl font-black text-brand-yellow flex items-center gap-1"><Zap className="w-5 h-5" />{profile?.xp || 0}</span>,
            label: "XP gesamt",
            sub: `${xpData.current} / ${xpData.next} zum nächsten Level`,
            bg: "bg-yellow-50 border-yellow-200",
          },
          {
            icon: <span className="text-2xl font-black text-brand-orange flex items-center gap-1"><Flame className="w-5 h-5" />{profile?.streak || 0}</span>,
            label: "Tage-Streak",
            sub: "Lern täglich weiter!",
            bg: "bg-orange-50 border-orange-200",
          },
          {
            icon: <span className="text-2xl font-black text-primary flex items-center gap-1">{overallAccuracy}%</span>,
            label: "Genauigkeit",
            sub: `${totalCorrect} / ${totalAttempts} richtig`,
            bg: overallAccuracy >= 80 ? "bg-emerald-50 border-emerald-200" : overallAccuracy >= 60 ? "bg-yellow-50 border-yellow-200" : "bg-red-50 border-red-200",
          },
        ].map((s, i) => (
          <div key={i} className={`rounded-2xl border p-4 ${s.bg}`}>
            <div className="mb-1.5">{s.icon}</div>
            <p className="font-black text-sm text-foreground">{s.label}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">{s.sub}</p>
            {s.extra}
          </div>
        ))}
      </div>

      {/* Transit-map style skill routes */}
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <div className="flex items-center gap-2.5 px-5 py-4 border-b border-border/60">
          <TrendingUp className="w-4 h-4 text-primary" />
          <h2 className="font-black text-sm">Lernrouten – Kompetenzübersicht</h2>
          {skillStats.length === 0 && <Badge variant="outline" className="ml-auto text-xs">Noch keine Daten</Badge>}
        </div>

        {skillStats.length === 0 ? (
          <div className="flex flex-col items-center py-12 px-6 text-center">
            <div className="w-14 h-14 rounded-3xl brand-gradient-soft flex items-center justify-center mb-4 border border-border/40">
              <BookOpen className="w-7 h-7 text-primary" />
            </div>
            <p className="font-black text-sm text-foreground mb-1">Noch keine Übungen abgeschlossen</p>
            <p className="text-xs text-muted-foreground max-w-xs">Starte eine Grammatik-, Vokabel- oder Leseübung, um deine persönlichen Lernrouten zu sehen.</p>
            <div className="mt-4">
              <a href="/daily-plan" className="text-xs font-bold text-primary hover:underline">→ Zum Tagesplan</a>
            </div>
          </div>
        ) : (
          <div className="p-5 space-y-4">
            {skillStats.map((skill, i) => {
              const color = SKILL_DOT_COLORS[skill.key] || "#22c55e";
              const colors = SKILL_COLORS[skill.key] || SKILL_COLORS.vocabulary;
              const isWeak = skill.accuracy < 60;
              return (
                <div key={skill.key} className="flex items-center gap-4">
                  {/* Route station dot */}
                  <div className="flex flex-col items-center flex-shrink-0" style={{ width: 20 }}>
                    <div
                      className="w-3 h-3 rounded-full border-2 border-white shadow-sm flex-shrink-0"
                      style={{ background: color, boxShadow: `0 0 0 2px ${color}40` }}
                    />
                    {i < skillStats.length - 1 && (
                      <div className="w-0.5 h-7 mt-1" style={{ background: `${color}30` }} />
                    )}
                  </div>
                  {/* Skill info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className={cn("text-xs font-bold px-2 py-0.5 rounded-full", colors.bg, colors.text)}>
                          {skill.label}
                        </span>
                        {isWeak && (
                          <span className="text-[10px] font-bold text-orange-600 bg-orange-50 border border-orange-200 px-1.5 py-0.5 rounded-full">
                            Schwerpunkt
                          </span>
                        )}
                      </div>
                      <span className={cn("text-xs font-black", isWeak ? "text-orange-600" : skill.accuracy >= 80 ? "text-primary" : "text-foreground")}>
                        {skill.accuracy}%
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{
                          width: `${skill.accuracy}%`,
                          background: isWeak
                            ? "linear-gradient(90deg, #f97316, #fb923c)"
                            : `linear-gradient(90deg, ${color}, ${color}cc)`,
                        }}
                      />
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-1">{skill.correct} von {skill.total} richtig</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Chart */}
        {chartData.length > 0 && (
          <div className="rounded-2xl border border-border bg-card overflow-hidden">
            <div className="flex items-center gap-2.5 px-5 py-4 border-b border-border/60">
              <BarChart3 className="w-4 h-4 text-primary" />
              <h2 className="font-black text-sm">Aufgaben nach Bereich</h2>
            </div>
            <div className="p-5">
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={chartData} margin={{ top: 0, right: 0, left: -24, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 11, fontWeight: 600 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: "1px solid hsl(215,18%,90%)", fontSize: 12, fontWeight: 600 }}
                    formatter={(v, n) => [v, n === "correct" ? "Richtig ✓" : "Gesamt"]}
                  />
                  <Bar dataKey="count" fill="hsl(215,18%,92%)" radius={[6,6,0,0]} />
                  <Bar dataKey="correct" fill="hsl(145,72%,32%)" radius={[6,6,0,0]} />
                </BarChart>
              </ResponsiveContainer>
              <div className="flex items-center gap-4 mt-2 justify-center">
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-muted-foreground">
                  <span className="w-3 h-3 rounded-sm bg-muted-foreground/30" />Gesamt
                </span>
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-primary">
                  <span className="w-3 h-3 rounded-sm bg-primary" />Richtig
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Mistake patterns */}
        <div>
          <MistakeInsights attempts={attempts} />
        </div>
      </div>

      {/* Recent errors */}
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <div className="flex items-center gap-2.5 px-5 py-4 border-b border-border/60">
          <AlertCircle className="w-4 h-4 text-destructive" />
          <h2 className="font-black text-sm">Letzte Fehler</h2>
        </div>
        <div className="p-4">
          {mistakes.length === 0 ? (
            <div className="flex flex-col items-center py-8 text-center">
              <CheckCircle2 className="w-10 h-10 text-primary mb-2" />
              <p className="text-sm font-black">Keine Fehler bisher!</p>
              <p className="text-xs text-muted-foreground mt-1">Entweder hast du noch nicht geübt – oder du bist wirklich gut. Weiter so! 💪</p>
            </div>
          ) : (
            <div className="space-y-2">
              {mistakes.map((m, i) => {
                const colors = SKILL_COLORS[m.skill_area] || SKILL_COLORS.vocabulary;
                return (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-muted/50">
                    <div className={cn("w-2 h-2 rounded-full mt-1.5 flex-shrink-0", colors.dot)} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold capitalize text-foreground">{m.skill_area || "Übung"}</p>
                      {m.user_answer && <p className="text-[11px] text-destructive mt-0.5">Deine Antwort: <em>{m.user_answer}</em></p>}
                      {m.correct_answer && <p className="text-[11px] text-primary font-semibold">Richtig: {m.correct_answer}</p>}
                    </div>
                    <p className="text-[11px] text-muted-foreground whitespace-nowrap">{m.created_date?.split("T")[0]}</p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* What to do next */}
      {skillStats.length > 0 && (
        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          <div className="flex items-center gap-2.5 px-5 py-4 border-b border-border/60">
            <Target className="w-4 h-4 text-primary" />
            <h2 className="font-black text-sm">Was solltest du als nächstes üben?</h2>
          </div>
          <div className="p-5 space-y-3">
            {skillStats.filter(s => s.accuracy < 70).length > 0 ? (
              skillStats
                .filter(s => s.accuracy < 70)
                .sort((a, b) => a.accuracy - b.accuracy)
                .slice(0, 3)
                .map((skill) => {
                  const colors = SKILL_COLORS[skill.key] || SKILL_COLORS.vocabulary;
                  return (
                    <div key={skill.key} className={`flex items-center justify-between p-3.5 rounded-xl ${colors.bg} border ${colors.border}`}>
                      <div>
                        <p className={`text-sm font-bold ${colors.text}`}>{skill.label}</p>
                        <p className="text-xs text-muted-foreground">{skill.accuracy}% Genauigkeit – hier gibt es Verbesserungspotential</p>
                      </div>
                      <a href={`/${skill.key}`} className={`text-xs font-black ${colors.text} hover:underline`}>Üben →</a>
                    </div>
                  );
                })
            ) : (
              <div className="flex items-center gap-3 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                <div>
                  <p className="text-sm font-bold text-emerald-800">Ausgezeichnete Leistung!</p>
                  <p className="text-xs text-emerald-700">Alle Bereiche über 70% – versuche jetzt härtere Übungen oder neue Themen.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Badges */}
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <div className="flex items-center gap-2.5 px-5 py-4 border-b border-border/60">
          <Trophy className="w-4 h-4 text-brand-yellow" />
          <h2 className="font-black text-sm">Abzeichen</h2>
        </div>
        <div className="p-5">
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
            {BADGES.map((badge) => {
              const earned = profile?.badges?.includes(badge.id);
              return (
                <div
                  key={badge.id}
                  className={cn(
                    "flex flex-col items-center text-center p-3.5 rounded-2xl border transition-all",
                    earned
                      ? "bg-brand-yellow-light border-yellow-200 shadow-sm"
                      : "bg-muted/40 border-border/40 opacity-50"
                  )}
                >
                  <span className="text-2xl mb-1.5">{badge.icon}</span>
                  <p className={cn("text-[11px] font-black leading-tight", earned ? "text-foreground" : "text-muted-foreground")}>
                    {badge.label}
                  </p>
                  <p className="text-[10px] text-muted-foreground mt-0.5 leading-tight">{badge.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}