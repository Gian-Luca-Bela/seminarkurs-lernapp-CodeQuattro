import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn, getTodayString, getDaysUntil } from "@/lib/utils";
import {
  Target, Zap, Play, Check, Clock, BookOpen, GraduationCap, FileText,
  PenLine, Headphones, Sparkles, RefreshCw, Mic, RotateCcw, ChevronRight,
  AlertTriangle, Trophy, Loader2, Shuffle, Settings2
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import AILoadingState from "@/components/AILoadingState";

// ── Constants ────────────────────────────────────────────────────────────────
const SKILL_ICONS = {
  vocabulary: BookOpen, grammar: GraduationCap, reading: FileText,
  writing: PenLine, listening: Headphones, speaking: Mic, mediation: Target,
};
const SKILL_LABELS = {
  vocabulary: "Vokabeln", grammar: "Grammatik", reading: "Lesen",
  writing: "Schreiben", listening: "Hören", speaking: "Sprechen", mediation: "Sprachmittlung",
};
const SKILL_COLORS = {
  vocabulary: { bg: "bg-blue-100", text: "text-blue-700", border: "border-blue-200" },
  grammar:    { bg: "bg-purple-100", text: "text-purple-700", border: "border-purple-200" },
  reading:    { bg: "bg-teal-100", text: "text-teal-700", border: "border-teal-200" },
  writing:    { bg: "bg-orange-100", text: "text-orange-700", border: "border-orange-200" },
  listening:  { bg: "bg-pink-100", text: "text-pink-700", border: "border-pink-200" },
  speaking:   { bg: "bg-lime-100", text: "text-lime-700", border: "border-lime-200" },
  mediation:  { bg: "bg-indigo-100", text: "text-indigo-700", border: "border-indigo-200" },
};
const SKILL_PATHS = {
  vocabulary: "/vocabulary", grammar: "/grammar", reading: "/reading",
  writing: "/writing", listening: "/listening", speaking: "/speaking", mediation: "/mediation",
};
const SESSION_TYPE_CONFIG = {
  review:             { label: "Wiederholung",    emoji: "🔄", bg: "bg-blue-100",   text: "text-blue-700",   section: "Wiederholung" },
  weak_area:          { label: "Schwäche stärken",emoji: "💪", bg: "bg-red-100",    text: "text-red-700",    section: "Schwächen stärken" },
  confidence_builder: { label: "Stärke zeigen",   emoji: "⭐", bg: "bg-green-100",  text: "text-green-700",  section: "Sicherheit aufbauen" },
  transfer:           { label: "Transfer",         emoji: "🎯", bg: "bg-purple-100", text: "text-purple-700", section: "Transfer / Anwendung" },
  challenge:          { label: "Herausforderung",  emoji: "🔥", bg: "bg-orange-100", text: "text-orange-700", section: "Herausforderung" },
};
const DIFF_CONFIG = {
  easy:   { label: "Leicht", color: "bg-green-100 text-green-700 border-green-200" },
  medium: { label: "Mittel", color: "bg-yellow-100 text-yellow-700 border-yellow-200" },
  hard:   { label: "Schwer", color: "bg-red-100 text-red-700 border-red-200" },
};
const FOCUS_MODES = [
  { key: "mixed",      label: "Gemischt",   emoji: "🎲" },
  { key: "vocabulary", label: "Vokabeln",   emoji: "📖" },
  { key: "grammar",    label: "Grammatik",  emoji: "📐" },
  { key: "exam_prep",  label: "Prüfungsvorbereitung", emoji: "🎓" },
];

// ── Fallback plan builder ─────────────────────────────────────────────────────
function buildFallbackPlan(profile, attempts = [], exams = [], savedSets = []) {
  const weakAreas = profile?.weak_areas || [];
  const grade = profile?.grade || "8";
  const diff = profile?.preferred_difficulty || "medium";

  const recentWrong = attempts.filter(a => !a.is_correct).map(a => a.skill_area).filter(Boolean);
  const wrongSkills = [...new Set(recentWrong)];
  const weakSkill = wrongSkills[0] || weakAreas[0] || "grammar";
  const strongSkill = (["vocabulary","grammar","reading","writing"].find(s => !wrongSkills.includes(s))) || "vocabulary";
  const upcomingExam = exams?.sort((a, b) => new Date(a.exam_date) - new Date(b.exam_date))[0];
  const hasSavedVocab = savedSets.length > 0;

  const sessions = [
    {
      skill_area: hasSavedVocab ? "vocabulary" : "grammar",
      topic_key: hasSavedVocab ? "saved_vocab_review" : "tenses_review",
      title: hasSavedVocab ? `Vokabeln aus "${savedSets[0]?.name || "gespeichertem Set"}" wiederholen` : "Grammatik-Wiederholung: Zeiten",
      description: hasSavedVocab
        ? `Gehe dein gespeichertes Vokabelset "${savedSets[0]?.name}" durch und teste dich mit Karteikarten.`
        : "Wiederhole die englischen Zeitformen mit gezielten Übungsaufgaben.",
      duration_minutes: 10,
      session_type: "review",
      difficulty: "easy",
      why: "Regelmäßige Wiederholung ist der Schlüssel zum Behalten.",
      action: hasSavedVocab ? "/vocab-trainer" : "/grammar",
    },
    {
      skill_area: weakSkill,
      topic_key: weakSkill + "_practice",
      title: `${SKILL_LABELS[weakSkill] || weakSkill} gezielt üben`,
      description: `Du hast zuletzt bei ${SKILL_LABELS[weakSkill] || weakSkill} Fehler gemacht. Heute fokussiert trainieren für mehr Sicherheit.`,
      duration_minutes: 15,
      session_type: "weak_area",
      difficulty: diff,
      why: "Schwachstellen direkt angehen bringt den größten Fortschritt.",
      action: SKILL_PATHS[weakSkill] || "/grammar",
    },
    {
      skill_area: strongSkill,
      topic_key: strongSkill + "_confidence",
      title: `${SKILL_LABELS[strongSkill] || strongSkill} – Stärke zeigen`,
      description: `Du bist gut bei ${SKILL_LABELS[strongSkill] || strongSkill}. Eine motivierende Übungsrunde, um dein Niveau zu halten.`,
      duration_minutes: 10,
      session_type: "confidence_builder",
      difficulty: "easy",
      why: "Erfolge motivieren und stärken das Selbstvertrauen.",
      action: SKILL_PATHS[strongSkill] || "/vocabulary",
    },
    {
      skill_area: grade === "9" ? "writing" : "reading",
      topic_key: grade === "9" ? "formal_writing" : "reading_comprehension",
      title: grade === "9" ? "Formelles Schreiben üben" : "Leseverstehen: Textarbeit",
      description: grade === "9"
        ? "Übe das Schreiben eines formellen Texts – z.B. Brief, Artikel oder Kommentar."
        : "Lies einen kurzen Englischtext und beantworte gezielte Verständnisfragen.",
      duration_minutes: 12,
      session_type: "transfer",
      difficulty: diff,
      why: "Transfer-Aufgaben verbinden verschiedene Sprachfertigkeiten.",
      action: grade === "9" ? "/writing" : "/reading",
    },
  ];

  if (upcomingExam && getDaysUntil(upcomingExam.exam_date) <= 7) {
    sessions.push({
      skill_area: upcomingExam.skill_areas?.[0] || "grammar",
      topic_key: "exam_challenge",
      title: `🎓 Prüfungsvorbereitung: ${upcomingExam.title}`,
      description: `Deine Prüfung "${upcomingExam.title}" ist in ${getDaysUntil(upcomingExam.exam_date)} Tag(en)! Intensive Vorbereitung jetzt.`,
      duration_minutes: 15,
      session_type: "challenge",
      difficulty: "hard",
      why: `Nur noch ${getDaysUntil(upcomingExam.exam_date)} Tage bis zur Prüfung – jetzt alles geben!`,
      action: "/exams",
    });
  }

  return {
    user_email: profile?.user_email || "",
    plan_date: getTodayString(),
    sessions: sessions.map(s => ({ ...s, completed: false, xp_earned: 0 })),
    total_xp_possible: sessions.reduce((sum, s) => sum + s.duration_minutes * 2, 0),
    total_xp_earned: 0,
    completed: false,
    reason: `Guten Tag! Dein heutiger Plan ist auf dein Profil (Klasse ${grade}) zugeschnitten. Viel Erfolg! 💪`,
  };
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function DailyPlan() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [generating, setGenerating] = useState(false);
  const [localPlan, setLocalPlan] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [manualDifficulty, setManualDifficulty] = useState("medium");
  const [focusMode, setFocusMode] = useState("mixed");
  const [customMinutes, setCustomMinutes] = useState(null);

  // ── Data ──────────────────────────────────────────────────────────────────
  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];

  const { data: exams = [] } = useQuery({
    queryKey: ["exams", user?.email],
    queryFn: () => base44.entities.UpcomingExam.filter({ user_email: user?.email, is_active: true }),
    enabled: !!user?.email,
  });
  const { data: attempts = [] } = useQuery({
    queryKey: ["recent-attempts", user?.email],
    queryFn: () => base44.entities.ExerciseAttempt.filter({ user_email: user?.email }, "-created_date", 40),
    enabled: !!user?.email,
  });
  const { data: savedSets = [] } = useQuery({
    queryKey: ["saved-sets", user?.email],
    queryFn: () => base44.entities.SavedVocabSet.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const { data: existingPlans, isLoading: loadingExisting } = useQuery({
    queryKey: ["daily-plans", user?.email, getTodayString()],
    queryFn: () => base44.entities.DailyPlan.filter({ user_email: user?.email, plan_date: getTodayString() }),
    enabled: !!user?.email,
  });
  const existingPlan = existingPlans?.[0];

  const savePlanMutation = useMutation({
    mutationFn: (data) => base44.entities.DailyPlan.create(data),
    onSuccess: (saved) => {
      setLocalPlan(saved);
      queryClient.invalidateQueries({ queryKey: ["daily-plans"] });
    },
  });
  const updatePlanMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.DailyPlan.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["daily-plans"] }),
  });
  const deletePlanMutation = useMutation({
    mutationFn: (id) => base44.entities.DailyPlan.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["daily-plans"] });
      setLocalPlan(null);
    },
  });

  const displayPlan = localPlan || existingPlan;

  // ── Derived stats ─────────────────────────────────────────────────────────
  const completedCount = displayPlan?.sessions?.filter(s => s.completed).length || 0;
  const totalCount = displayPlan?.sessions?.length || 0;
  const xpEarned = displayPlan?.total_xp_earned || 0;
  const xpTotal = displayPlan?.total_xp_possible || 1;
  const progressPct = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const upcomingExam = useMemo(() =>
    exams?.sort((a, b) => new Date(a.exam_date) - new Date(b.exam_date))[0],
    [exams]
  );
  const daysUntilExam = upcomingExam ? getDaysUntil(upcomingExam.exam_date) : null;

  // Analyze recent performance
  const weakAreasFromAttempts = useMemo(() => {
    const skillErrors = {};
    attempts.forEach(a => {
      if (!a.skill_area) return;
      if (!skillErrors[a.skill_area]) skillErrors[a.skill_area] = { correct: 0, total: 0 };
      skillErrors[a.skill_area].total++;
      if (a.is_correct) skillErrors[a.skill_area].correct++;
    });
    return Object.entries(skillErrors)
      .map(([skill, s]) => ({ skill, accuracy: Math.round((s.correct / s.total) * 100) }))
      .filter(s => s.accuracy < 65)
      .sort((a, b) => a.accuracy - b.accuracy);
  }, [attempts]);

  // ── Generate plan ─────────────────────────────────────────────────────────
  const generatePlan = async (rebuild = false) => {
    if (!profile) return;
    if (rebuild && existingPlan?.id) {
      await deletePlanMutation.mutateAsync(existingPlan.id);
    }
    setGenerating(true);

    const dailyMinutes = customMinutes || profile.daily_minutes || 20;
    const weakAreas = [...new Set([
      ...weakAreasFromAttempts.map(w => w.skill),
      ...(profile.weak_areas || []),
    ])].slice(0, 4);
    const savedVocabNames = savedSets.slice(0, 3).map(s => s.name);
    const recentTopics = [...new Set(attempts.filter(a => !a.is_correct).map(a => a.topic_key).filter(Boolean))].slice(0, 5);

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert English teacher creating a PERSONALIZED daily study plan for a German Gymnasium student.

STUDENT PROFILE:
- Grade: ${profile.grade} (Gymnasium)
- Available time today: ${dailyMinutes} minutes
- Chosen difficulty: ${manualDifficulty}
- Focus mode: ${focusMode}
- Weak areas (from data): ${weakAreas.join(", ") || "none detected"}
- Profile weak areas: ${profile.weak_areas?.join(", ") || "none"}
- Goals: ${profile.goals?.join(", ") || "general improvement"}
- Learning style: ${profile.learning_style || "mixed"}
- Saved vocabulary sets: ${savedVocabNames.join(", ") || "none"}
- Recent mistake topics: ${recentTopics.join(", ") || "none"}
${upcomingExam ? `- UPCOMING EXAM: "${upcomingExam.title}" in ${daysUntilExam} days! Topics: ${upcomingExam.vocab_themes?.join(", ")} / ${upcomingExam.grammar_topics?.join(", ")}` : ""}

RULES:
1. Create EXACTLY ${dailyMinutes <= 15 ? 3 : dailyMinutes <= 25 ? 4 : 5} sessions
2. ALWAYS include: 1 review, 1 weak_area (if weak areas exist), 1 confidence_builder, 1 transfer
3. Add challenge ONLY if time >= 25 min
4. Total duration must be <= ${dailyMinutes} minutes
5. Each session needs a CONCRETE, actionable description — not vague instructions
6. Descriptions MUST be in German, age-appropriate, and specific
7. Difficulty = ${manualDifficulty}: ${manualDifficulty === "easy" ? "simple language, lots of support, scaffolded tasks" : manualDifficulty === "medium" ? "standard school level" : "harder transfer tasks, minimal guidance, independent thinking"}
8. ${focusMode !== "mixed" ? `Focus mode: ${focusMode} — prioritize this skill area` : "Mixed focus: balance all skills"}
9. ${savedVocabNames.length > 0 ? `Use saved vocab set "${savedVocabNames[0]}" for vocabulary review` : "Use grade-appropriate vocabulary"}
10. Each session needs a direct_path — must be one of: /vocabulary, /grammar, /reading, /writing, /listening, /speaking, /mediation, /vocab-trainer, /auto-learn, /exams
11. DO NOT send student to non-existent pages

For each session provide: skill_area, topic_key, title, description (German, concrete, 1-2 sentences), duration_minutes, session_type (review/weak_area/confidence_builder/transfer/challenge), difficulty (easy/medium/hard), why (1 sentence motivation in German), direct_path, concrete_task (what exactly to do, in German)`,
        response_json_schema: {
          type: "object",
          properties: {
            greeting: { type: "string" },
            sessions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill_area: { type: "string" },
                  topic_key: { type: "string" },
                  title: { type: "string" },
                  description: { type: "string" },
                  duration_minutes: { type: "number" },
                  session_type: { type: "string" },
                  difficulty: { type: "string" },
                  why: { type: "string" },
                  direct_path: { type: "string" },
                  concrete_task: { type: "string" },
                }
              }
            },
            motivation: { type: "string" },
          }
        }
      });

      // Validate and fix paths
      const validPaths = Object.values(SKILL_PATHS).concat(["/vocab-trainer", "/auto-learn", "/exams"]);
      const sessions = (result.sessions || []).map(s => ({
        ...s,
        completed: false,
        xp_earned: 0,
        direct_path: validPaths.includes(s.direct_path) ? s.direct_path : (SKILL_PATHS[s.skill_area] || "/vocabulary"),
        difficulty: ["easy","medium","hard"].includes(s.difficulty) ? s.difficulty : manualDifficulty,
      }));

      const planData = {
        user_email: user.email,
        plan_date: getTodayString(),
        sessions,
        total_xp_possible: sessions.reduce((sum, s) => sum + (s.duration_minutes || 10) * 2, 0),
        total_xp_earned: 0,
        completed: false,
        reason: result.greeting || result.motivation || "Dein personalisierter Tagesplan ist bereit!",
      };

      savePlanMutation.mutate(planData);
      setLocalPlan({ ...planData, id: null });
    } catch {
      const fallback = buildFallbackPlan(
        { ...profile, user_email: user.email },
        attempts, exams, savedSets
      );
      savePlanMutation.mutate(fallback);
      setLocalPlan(fallback);
    }
    setGenerating(false);
  };

  // ── Mark session complete ─────────────────────────────────────────────────
  const markComplete = async (sessionIndex) => {
    const target = localPlan || existingPlan;
    if (!target) return;
    const updatedSessions = target.sessions.map((s, i) =>
      i === sessionIndex ? { ...s, completed: true, xp_earned: (s.duration_minutes || 10) * 2 } : s
    );
    const newXp = updatedSessions.filter(s => s.completed).reduce((sum, s) => sum + (s.xp_earned || 0), 0);
    const allDone = updatedSessions.every(s => s.completed);
    const updated = { ...target, sessions: updatedSessions, total_xp_earned: newXp, completed: allDone };
    setLocalPlan(updated);
    if (target.id) {
      updatePlanMutation.mutate({ id: target.id, data: { sessions: updatedSessions, total_xp_earned: newXp, completed: allDone } });
    }
    
    // Award XP when day is completed
    if (allDone && user && profile) {
      try {
        await base44.entities.UserProfile.update(profile.id, { xp: (profile.xp || 0) + newXp });
        queryClient.invalidateQueries({ queryKey: ["user-profile"] });
      } catch (err) {
        console.error("XP award failed:", err);
      }
    }
  };

  // ── Swap single task ──────────────────────────────────────────────────────
  const swapTask = async (sessionIndex) => {
    const target = localPlan || existingPlan;
    if (!target) return;
    const session = target.sessions[sessionIndex];
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Replace this study task with a different one of the same type.
Session type: ${session.session_type}
Skill area: ${session.skill_area}
Current title: ${session.title}
Student grade: ${profile?.grade}
Difficulty: ${manualDifficulty}
Create a DIFFERENT task for the same skill/type. Respond in German. Return JSON.`,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            description: { type: "string" },
            concrete_task: { type: "string" },
            why: { type: "string" },
          }
        }
      });
      const updatedSessions = target.sessions.map((s, i) =>
        i === sessionIndex ? { ...s, title: result.title || s.title, description: result.description || s.description, concrete_task: result.concrete_task, why: result.why || s.why } : s
      );
      const updated = { ...target, sessions: updatedSessions };
      setLocalPlan(updated);
      if (target.id) updatePlanMutation.mutate({ id: target.id, data: { sessions: updatedSessions } });
    } catch {}
  };

  // ── RENDER ────────────────────────────────────────────────────────────────
  if (generating) {
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto">
        <AILoadingState
          title="KI-Tagesplan wird erstellt"
          icon={<Target className="w-8 h-8 text-white" />}
          steps={[
            "Dein Lernprofil wird analysiert…",
            "Schwachstellen werden ausgewertet…",
            "Aufgaben werden ausgewählt…",
            "Plan wird personalisiert…",
            "Fast fertig…",
          ]}
          contextLines={[
            profile ? `Klasse ${profile.grade}` : "",
            `Schwierigkeit: ${manualDifficulty === "easy" ? "Leicht" : manualDifficulty === "medium" ? "Mittel" : "Schwer"}`,
            `${customMinutes || profile?.daily_minutes || 20} Minuten verfügbar`,
          ].filter(Boolean)}
        />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-up">

      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <div className="flex items-start justify-between mb-5">
        <div>
          <h1 className="text-2xl font-black tracking-tight flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-2xl brand-gradient flex items-center justify-center shadow-sm">
              <Target className="w-5 h-5 text-white" />
            </span>
            KI-Tagesplan
          </h1>
          <p className="text-muted-foreground text-sm mt-1 ml-12">
            {new Date().toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long" })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {!displayPlan && (
            <Button
              variant="outline" size="sm"
              onClick={() => setShowSettings(s => !s)}
              className={cn("gap-1.5 rounded-xl font-bold h-8", showSettings && "border-primary bg-primary/5")}
            >
              <Settings2 className="w-3.5 h-3.5" />Einstellungen
            </Button>
          )}
          {displayPlan && (
            <>
              <Button
                variant="outline" size="sm"
                onClick={() => generatePlan(true)}
                className="gap-1.5 rounded-xl font-bold h-8"
              >
                <RefreshCw className="w-3.5 h-3.5" />Neu erstellen
              </Button>
            </>
          )}
        </div>
      </div>

      {/* ── Exam warning banner ────────────────────────────────────────────── */}
      {upcomingExam && daysUntilExam <= 5 && (
        <div className={cn("mb-4 p-3 rounded-2xl border-2 flex items-center gap-3",
          daysUntilExam <= 2 ? "border-red-300 bg-red-50" : "border-orange-300 bg-orange-50")}>
          <AlertTriangle className={cn("w-5 h-5 flex-shrink-0", daysUntilExam <= 2 ? "text-red-600" : "text-orange-600")} />
          <div className="flex-1">
            <p className="font-black text-sm">{upcomingExam.title}</p>
            <p className="text-xs text-muted-foreground">
              {daysUntilExam === 0 ? "Heute!" : daysUntilExam === 1 ? "Morgen!" : `In ${daysUntilExam} Tagen`}
            </p>
          </div>
          <Button asChild size="sm" className="brand-gradient text-white border-0 text-xs h-8 rounded-xl font-bold flex-shrink-0">
            <Link to="/exams">Vorbereiten</Link>
          </Button>
        </div>
      )}

      {/* ── Settings panel (pre-generation) ───────────────────────────────── */}
      {!displayPlan && showSettings && (
        <Card className="mb-4 border-2 border-primary/20 animate-fade-up">
          <CardContent className="p-4 space-y-4">
            <div>
              <p className="text-sm font-bold mb-2">Schwierigkeit</p>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { key: "easy", label: "Leicht", sub: "Mehr Hilfe", color: "border-green-400 bg-green-50 text-green-700" },
                  { key: "medium", label: "Mittel", sub: "Schulniveau", color: "border-yellow-400 bg-yellow-50 text-yellow-700" },
                  { key: "hard", label: "Schwer", sub: "Transfer", color: "border-red-400 bg-red-50 text-red-700" },
                ].map(d => (
                  <button key={d.key} onClick={() => setManualDifficulty(d.key)}
                    className={cn("rounded-xl border-2 p-2.5 text-sm font-bold transition-all text-left",
                      manualDifficulty === d.key ? d.color + " ring-2 ring-offset-1 ring-primary/30" : "border-border bg-card hover:border-primary/30")}>
                    {d.label}
                    <div className="text-xs font-normal text-muted-foreground">{d.sub}</div>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-sm font-bold mb-2">Fokus</p>
              <div className="grid grid-cols-2 gap-2">
                {FOCUS_MODES.map(m => (
                  <button key={m.key} onClick={() => setFocusMode(m.key)}
                    className={cn("rounded-xl border-2 p-2.5 text-sm font-medium transition-all text-left flex items-center gap-2",
                      focusMode === m.key ? "border-primary bg-primary/8 text-primary font-bold" : "border-border bg-card hover:border-primary/30")}>
                    <span>{m.emoji}</span>{m.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-sm font-bold mb-2">Zeit heute</p>
              <div className="flex gap-2 flex-wrap">
                {[10, 15, 20, 30, 45].map(min => (
                  <button key={min} onClick={() => setCustomMinutes(min)}
                    className={cn("px-3 py-1.5 rounded-xl border-2 text-sm font-medium transition-all",
                      customMinutes === min ? "border-primary bg-primary/10 text-primary font-bold" : "border-border hover:border-primary/30")}>
                    {min} Min
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── Empty state / Generate ────────────────────────────────────────── */}
      {!displayPlan && !loadingExisting ? (
        <div className="rounded-3xl border-2 border-dashed border-primary/25 bg-gradient-to-br from-primary/5 to-blue-50 p-10 text-center">
          <div className="w-16 h-16 rounded-3xl brand-gradient flex items-center justify-center mx-auto mb-5 shadow-md">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-xl font-black mb-2">KI-Tagesplan erstellen</h2>
          <p className="text-muted-foreground text-sm mb-3 max-w-sm mx-auto leading-relaxed">
            Die KI erstellt einen echten, personalisierten Lernplan für heute –
            basierend auf deinen Schwächen, Zielen und der verfügbaren Zeit.
          </p>

          {/* Quick settings preview */}
          <div className="flex items-center justify-center gap-2 flex-wrap mb-5 text-xs">
            <span className={cn("px-2.5 py-1 rounded-full font-bold border",
              manualDifficulty === "easy" ? "bg-green-100 text-green-700 border-green-200" :
              manualDifficulty === "hard" ? "bg-red-100 text-red-700 border-red-200" :
              "bg-yellow-100 text-yellow-700 border-yellow-200")}>
              {manualDifficulty === "easy" ? "Leicht" : manualDifficulty === "medium" ? "Mittel" : "Schwer"}
            </span>
            <span className="px-2.5 py-1 rounded-full font-bold border bg-muted text-muted-foreground border-border">
              {FOCUS_MODES.find(f => f.key === focusMode)?.emoji} {FOCUS_MODES.find(f => f.key === focusMode)?.label}
            </span>
            <span className="px-2.5 py-1 rounded-full font-bold border bg-muted text-muted-foreground border-border">
              <Clock className="w-3 h-3 inline mr-1" />{customMinutes || profile?.daily_minutes || 20} Min
            </span>
          </div>

          {!profile ? (
            <div>
              <p className="text-sm text-orange-600 mb-4 font-medium">Bitte schließe zuerst das Onboarding ab.</p>
              <Button asChild variant="outline" className="rounded-xl font-bold"><Link to="/profile">Zum Profil</Link></Button>
            </div>
          ) : (
            <Button onClick={() => generatePlan(false)} size="lg" className="gap-2 rounded-2xl brand-gradient text-white border-0 shadow-sm font-bold px-8">
              <Sparkles className="w-5 h-5" />Tagesplan generieren
            </Button>
          )}
        </div>
      ) : displayPlan ? (
        <div className="space-y-4">

          {/* ── Greeting ─────────────────────────────────────────────────── */}
          {displayPlan.reason && (
            <div className="flex items-start gap-3 p-4 rounded-2xl bg-gradient-to-br from-amber-50 to-yellow-50 border border-amber-200">
              <span className="text-2xl flex-shrink-0">🦉</span>
              <p className="text-sm text-amber-800 font-medium leading-relaxed">{displayPlan.reason}</p>
            </div>
          )}

          {/* ── Progress overview ─────────────────────────────────────────── */}
          <Card className="border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-brand-yellow" />
                  <span className="font-black text-sm">Tagesfortschritt</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-muted-foreground">{completedCount}/{totalCount} Aufgaben</span>
                  <span className="text-sm font-black text-primary">{xpEarned}/{xpTotal} XP</span>
                </div>
              </div>
              <Progress value={progressPct} className="h-2.5" />
              {displayPlan.completed && (
                <p className="text-xs text-green-700 font-bold mt-2 text-center flex items-center justify-center gap-1">
                  <Trophy className="w-3.5 h-3.5" />Tagesplan abgeschlossen! Fantastisch!
                </p>
              )}
            </CardContent>
          </Card>

          {/* ── Weak areas detected ───────────────────────────────────────── */}
          {weakAreasFromAttempts.length > 0 && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-orange-50 border border-orange-200 text-xs">
              <AlertTriangle className="w-3.5 h-3.5 text-orange-600 flex-shrink-0" />
              <span className="text-orange-800 font-medium">
                Letzte Fehler bei: {weakAreasFromAttempts.slice(0, 3).map(w => SKILL_LABELS[w.skill] || w.skill).join(", ")}
                {" "}→ Im Plan berücksichtigt.
              </span>
            </div>
          )}

          {/* ── Plan settings bar ────────────────────────────────────────── */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs text-muted-foreground font-medium">Plan-Einstellungen:</span>
            {[
              { key: "easy", label: "Leicht" },
              { key: "medium", label: "Mittel" },
              { key: "hard", label: "Schwer" },
            ].map(d => (
              <button key={d.key}
                onClick={() => { setManualDifficulty(d.key); generatePlan(true); }}
                className={cn("text-xs px-2.5 py-1 rounded-full border font-bold transition-all",
                  manualDifficulty === d.key
                    ? d.key === "easy" ? "bg-green-100 text-green-700 border-green-300"
                    : d.key === "hard" ? "bg-red-100 text-red-700 border-red-300"
                    : "bg-yellow-100 text-yellow-700 border-yellow-300"
                    : "border-border text-muted-foreground hover:border-primary/40")}>
                {d.label}
              </button>
            ))}
            <span className="text-xs text-muted-foreground ml-1">Schwierigkeit ändern & Plan neu laden</span>
          </div>

          {/* ── Session cards ─────────────────────────────────────────────── */}
          <div className="space-y-3">
            {displayPlan.sessions?.map((session, i) => {
              const Icon = SKILL_ICONS[session.skill_area] || BookOpen;
              const colors = SKILL_COLORS[session.skill_area] || SKILL_COLORS.vocabulary;
              const typeConf = SESSION_TYPE_CONFIG[session.session_type];
              const diffConf = DIFF_CONFIG[session.difficulty] || DIFF_CONFIG.medium;
              const path = session.direct_path || SKILL_PATHS[session.skill_area] || "/vocabulary";

              return (
                <Card
                  key={i}
                  className={cn(
                    "border transition-all duration-200",
                    session.completed
                      ? "opacity-60 border-border/50 bg-muted/30"
                      : "border-border bg-card shadow-sm hover:shadow-md"
                  )}
                >
                  <CardContent className="p-4">
                    {/* Section label */}
                    {typeConf && (
                      <div className="flex items-center gap-1.5 mb-2">
                        <span className="text-sm">{typeConf.emoji}</span>
                        <span className={cn("text-[11px] font-black uppercase tracking-wider", typeConf.text)}>
                          {typeConf.section}
                        </span>
                      </div>
                    )}

                    <div className="flex items-start gap-3">
                      {/* Skill icon */}
                      <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0", colors.bg)}>
                        {session.completed
                          ? <Check className="w-5 h-5 text-green-600" />
                          : <Icon className={cn("w-5 h-5", colors.text)} />
                        }
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <h3 className={cn("font-black text-sm leading-snug mb-1", session.completed && "line-through text-muted-foreground")}>
                          {session.title}
                        </h3>
                        <p className="text-xs text-muted-foreground leading-relaxed mb-2">
                          {session.description}
                        </p>

                        {/* Concrete task box */}
                        {session.concrete_task && !session.completed && (
                          <div className="bg-primary/5 border border-primary/15 rounded-xl p-2.5 mb-2">
                            <p className="text-xs font-bold text-primary mb-0.5">📋 Aufgabe:</p>
                            <p className="text-xs text-foreground">{session.concrete_task}</p>
                          </div>
                        )}

                        {/* Why */}
                        {session.why && !session.completed && (
                          <p className="text-[11px] text-muted-foreground italic mb-2">💡 {session.why}</p>
                        )}

                        {/* Badges */}
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[11px] font-bold text-muted-foreground bg-muted px-2 py-0.5 rounded-full flex items-center gap-1">
                            <Clock className="w-3 h-3" />{session.duration_minutes} Min
                          </span>
                          <span className={cn("text-[11px] font-bold px-2 py-0.5 rounded-full", colors.bg, colors.text)}>
                            {SKILL_LABELS[session.skill_area] || session.skill_area}
                          </span>
                          <span className={cn("text-[11px] font-bold px-2 py-0.5 rounded-full border", diffConf.color)}>
                            {diffConf.label}
                          </span>
                          {session.completed && (
                            <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-green-100 text-green-700">
                              ✓ +{session.xp_earned || 0} XP
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Action buttons */}
                    {!session.completed && (
                      <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border/50">
                        <Button asChild size="sm" className="flex-1 brand-gradient text-white border-0 font-bold rounded-xl gap-1.5 h-9"
                          onClick={() => markComplete(i)}>
                          <Link to={path}>
                            <Play className="w-4 h-4" />Jetzt starten
                          </Link>
                        </Button>
                        <Button
                          variant="outline" size="sm"
                          onClick={() => markComplete(i)}
                          className="h-9 rounded-xl font-bold text-xs px-3 gap-1.5"
                          title="Als erledigt markieren"
                        >
                          <Check className="w-3.5 h-3.5" />Erledigt
                        </Button>
                        <Button
                          variant="ghost" size="sm"
                          onClick={() => swapTask(i)}
                          className="h-9 w-9 rounded-xl p-0 flex-shrink-0"
                          title="Aufgabe austauschen"
                        >
                          <Shuffle className="w-3.5 h-3.5 text-muted-foreground" />
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* ── Completed celebration ─────────────────────────────────────── */}
          {displayPlan.completed && (
            <div className="rounded-3xl border-2 border-green-300 bg-gradient-to-br from-green-50 to-emerald-50 text-center p-8">
              <div className="text-4xl mb-3">🎉</div>
              <h3 className="font-black text-lg text-green-800">Tagesplan abgeschlossen!</h3>
              <p className="text-sm text-green-700 mt-1">
                Fantastisch! Du hast {displayPlan.total_xp_earned} XP verdient.
              </p>
              <Button
                onClick={() => generatePlan(true)}
                className="mt-4 gap-2 brand-gradient text-white border-0 rounded-2xl font-bold"
              >
                <Sparkles className="w-4 h-4" />Neuen Plan erstellen
              </Button>
            </div>
          )}

          {/* ── Footer actions ─────────────────────────────────────────────── */}
          {!displayPlan.completed && (
            <div className="pt-1 pb-2 text-center">
              <p className="text-xs text-muted-foreground">
                Plan wird für heute gespeichert.{" "}
                <button onClick={() => generatePlan(true)} className="text-primary font-semibold hover:underline">
                  Plan neu erstellen
                </button>
              </p>
            </div>
          )}
        </div>
      ) : (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      )}
    </div>
  );
}