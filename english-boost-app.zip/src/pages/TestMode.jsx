import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn, getDaysUntil } from "@/lib/utils";
import {
  Target, Clock, Zap, AlertTriangle, CheckCircle2, Brain,
  ChevronRight, RotateCcw, Trophy, Star, BookOpen, ArrowRight,
  Timer, Calendar
} from "lucide-react";
import TransformationFeedback from "@/components/TransformationFeedback";
import { getExamMode, getWeakSkills } from "@/lib/recommendations";

const MODES = [
  {
    id: "tomorrow",
    label: "Ich schreibe morgen",
    icon: "🚨",
    desc: "Last-Minute-Modus: die wichtigsten Inhalte in 20 Min",
    color: "border-red-300 bg-red-50",
    textColor: "text-red-700",
    daysHint: 1,
  },
  {
    id: "three_days",
    label: "In 3 Tagen",
    icon: "🔴",
    desc: "Intensiv-Modus: gezieltes Üben mit Fokus auf Schwächen",
    color: "border-orange-300 bg-orange-50",
    textColor: "text-orange-700",
    daysHint: 3,
  },
  {
    id: "next_week",
    label: "Nächste Woche",
    icon: "📅",
    desc: "Aufbau-Modus: systematische Vorbereitung über mehrere Tage",
    color: "border-yellow-300 bg-yellow-50",
    textColor: "text-yellow-700",
    daysHint: 7,
  },
  {
    id: "simulation",
    label: "Klausur-Simulation",
    icon: "🎯",
    desc: "Gemischte Aufgaben wie in einer echten Klassenarbeit, mit Timer",
    color: "border-blue-300 bg-blue-50",
    textColor: "text-blue-700",
    daysHint: null,
  },
  {
    id: "confidence",
    label: "Confidence-Check",
    icon: "💬",
    desc: "Wie sicher bist du? Selbsteinschätzung + gezielte Übungen",
    color: "border-purple-300 bg-purple-50",
    textColor: "text-purple-700",
    daysHint: null,
  },
  {
    id: "weak_booster",
    label: "Schwächen-Booster",
    icon: "📈",
    desc: "Nur deine schwächsten Themen, wiederholt und erklärt",
    color: "border-teal-300 bg-teal-50",
    textColor: "text-teal-700",
    daysHint: null,
  },
];

const SKILL_AREAS = ["grammar", "vocabulary", "reading", "writing"];

export default function TestMode() {
  const [selectedMode, setSelectedMode] = useState(null);
  const [activeSession, setActiveSession] = useState(false);
  const [confidenceMap, setConfidenceMap] = useState({});
  const [checklist, setChecklist] = useState({});

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const { data: exams = [] } = useQuery({
    queryKey: ["exams", user?.email],
    queryFn: () => base44.entities.UpcomingExam.filter({ user_email: user?.email, is_active: true }),
    enabled: !!user?.email,
  });
  const { data: attempts = [] } = useQuery({
    queryKey: ["all-attempts", user?.email],
    queryFn: () => base44.entities.ExerciseAttempt.filter({ user_email: user?.email }, "-created_date", 100),
    enabled: !!user?.email,
  });
  const { data: exercises = [] } = useQuery({
    queryKey: ["all-exercises"],
    queryFn: () => base44.entities.Exercise.list("-created_date", 200),
  });

  const profile = profiles?.[0];
  const grade = profile?.grade || "8";
  const weakSkills = getWeakSkills(attempts);
  const nextExam = [...exams].sort((a, b) => new Date(a.exam_date) - new Date(b.exam_date)).find(e => getDaysUntil(e.exam_date) >= 0);

  if (activeSession) {
    return (
      <TestSession
        mode={selectedMode}
        exercises={exercises}
        attempts={attempts}
        grade={grade}
        weakSkills={weakSkills}
        confidenceMap={confidenceMap}
        user={user}
        onDone={() => { setActiveSession(false); setSelectedMode(null); }}
      />
    );
  }

  if (selectedMode?.id === "confidence") {
    return (
      <ConfidenceCheck
        confidenceMap={confidenceMap}
        setConfidenceMap={setConfidenceMap}
        onStart={() => setActiveSession(true)}
        onBack={() => setSelectedMode(null)}
      />
    );
  }

  if (selectedMode) {
    return (
      <ModePreview
        mode={selectedMode}
        nextExam={nextExam}
        weakSkills={weakSkills}
        grade={grade}
        checklist={checklist}
        setChecklist={setChecklist}
        onStart={() => setActiveSession(true)}
        onBack={() => setSelectedMode(null)}
      />
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-up">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-black flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl brand-gradient flex items-center justify-center">
            <Target className="w-5 h-5 text-white" />
          </div>
          Test & Klassenarbeit
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Dein intelligenter Vorbereitungs-Modus</p>
      </div>

      {/* Upcoming exam banner */}
      {nextExam && (
        <div className={cn("rounded-2xl border-2 p-4 mb-6", getDaysUntil(nextExam.exam_date) <= 3 ? "border-red-300 bg-red-50" : "border-orange-200 bg-orange-50")}>
          <div className="flex items-center gap-2 mb-1">
            <AlertTriangle className={cn("w-4 h-4", getDaysUntil(nextExam.exam_date) <= 3 ? "text-red-500" : "text-orange-500")} />
            <span className={cn("text-xs font-black uppercase tracking-wider", getDaysUntil(nextExam.exam_date) <= 3 ? "text-red-700" : "text-orange-700")}>
              Nächster Test erkannt
            </span>
          </div>
          <p className="font-black text-sm text-foreground">{nextExam.title}</p>
          <p className="text-xs text-muted-foreground mt-0.5 font-semibold">
            {getDaysUntil(nextExam.exam_date) === 0 ? "⚠️ Heute!" : getDaysUntil(nextExam.exam_date) === 1 ? "⚠️ Morgen!" : `In ${getDaysUntil(nextExam.exam_date)} Tagen`}
          </p>
        </div>
      )}

      {/* Weak skills preview */}
      {weakSkills.length > 0 && (
        <div className="rounded-2xl border border-orange-200 bg-orange-50/60 p-4 mb-6">
          <p className="text-xs font-black text-orange-700 uppercase tracking-wider mb-2">📉 Erkannte Schwächen</p>
          <div className="flex flex-wrap gap-2">
            {weakSkills.slice(0, 4).map(ws => (
              <Badge key={ws.skill} className="bg-orange-100 text-orange-700 border-0 font-bold text-xs">
                {ws.skill} · {ws.accuracy}%
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Mode selection */}
      <div className="section-header">
        <h2 className="text-sm font-black text-foreground uppercase tracking-wider">Modus wählen</h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {MODES.map(mode => (
          <button
            key={mode.id}
            onClick={() => setSelectedMode(mode)}
            className={cn("p-4 rounded-2xl border-2 text-left transition-all hover:shadow-md hover:-translate-y-0.5 card-hover", mode.color)}
          >
            <div className="text-2xl mb-2">{mode.icon}</div>
            <p className={cn("font-black text-sm mb-1", mode.textColor)}>{mode.label}</p>
            <p className="text-xs text-muted-foreground leading-relaxed">{mode.desc}</p>
          </button>
        ))}
      </div>

      {/* Pre-test checklist always visible */}
      <PreTestChecklist checklist={checklist} setChecklist={setChecklist} />
    </div>
  );
}

// ── Mode Preview ────────────────────────────────────────────────────────────────
function ModePreview({ mode, nextExam, weakSkills, grade, checklist, setChecklist, onStart, onBack }) {
  const examMode = nextExam ? getExamMode(getDaysUntil(nextExam.exam_date)) : null;

  const tips = {
    tomorrow: ["Fokus nur auf die wichtigsten Vokabeln und Grammatikregeln", "Keine neuen Themen mehr anfangen", "Mach nach 20 Min eine Pause", "Gut schlafen ist wichtiger als noch 2 Stunden lernen"],
    three_days: ["Jeden Tag 30 Min lernen ist besser als einmal 90 Min", "Nutze den Schwächen-Booster für deine schwächsten Themen", "Mach nach jeder Session eine kurze Pause"],
    next_week: ["Starte mit den Bereichen, die du am wenigsten magst", "Plane 4-5 Sessions über die Woche verteilt", "Nutze den Daily Plan als Grundlage"],
    simulation: ["Keine Hilfsmittel während der Simulation!", "Timer läuft – versuche ruhig zu bleiben", "Analysiere danach deine Fehler"],
    weak_booster: ["Diese Übungen wiederholen sich bis du sie beherrschst", "Erkläre dir selbst die Fehler laut", "Passe das Tempo an – kein Stress!"],
  };

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-up">
      <Button variant="ghost" onClick={onBack} className="mb-4 gap-1 text-muted-foreground">← Zurück</Button>

      <div className={cn("rounded-2xl border-2 p-5 mb-5", mode.color)}>
        <div className="text-3xl mb-2">{mode.icon}</div>
        <h2 className={cn("text-xl font-black mb-1", mode.textColor)}>{mode.label}</h2>
        <p className="text-sm text-muted-foreground">{mode.desc}</p>
      </div>

      {nextExam && (
        <div className="bg-card border border-border rounded-2xl p-4 mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="w-4 h-4 text-primary" />
            <p className="text-xs font-black text-muted-foreground uppercase">Dein nächster Test</p>
          </div>
          <p className="font-black">{nextExam.title}</p>
          <div className="flex gap-2 mt-2 flex-wrap">
            {nextExam.topics?.map(t => <Badge key={t} variant="secondary" className="text-xs">{t}</Badge>)}
          </div>
        </div>
      )}

      {weakSkills.length > 0 && (
        <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 mb-4">
          <p className="text-xs font-black text-orange-700 mb-2 uppercase">Priorität: Schwächen</p>
          {weakSkills.slice(0, 3).map(ws => (
            <div key={ws.skill} className="flex items-center justify-between py-1">
              <span className="text-sm text-orange-800 font-medium">{ws.skill}</span>
              <div className="flex items-center gap-2">
                <div className="w-16 h-1.5 bg-orange-200 rounded-full overflow-hidden">
                  <div className="h-full bg-orange-500 rounded-full" style={{ width: `${ws.accuracy}%` }} />
                </div>
                <span className="text-xs font-bold text-orange-700">{ws.accuracy}%</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {tips[mode.id] && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-4">
          <p className="text-xs font-black text-amber-700 mb-2 uppercase">💡 Tipps für diesen Modus</p>
          <ul className="space-y-1">
            {tips[mode.id].map((t, i) => (
              <li key={i} className="text-sm text-amber-800 flex items-start gap-2">
                <span className="text-amber-500 mt-0.5">•</span>{t}
              </li>
            ))}
          </ul>
        </div>
      )}

      <PreTestChecklist checklist={checklist} setChecklist={setChecklist} compact />

      <Button onClick={onStart} size="lg" className="w-full brand-gradient text-white border-0 font-black rounded-2xl mt-4 gap-2">
        <Zap className="w-5 h-5" />Modus starten
      </Button>
    </div>
  );
}

// ── Confidence Check ────────────────────────────────────────────────────────────
function ConfidenceCheck({ confidenceMap, setConfidenceMap, onStart, onBack }) {
  const areas = [
    { key: "grammar", label: "Grammatik", emoji: "📚" },
    { key: "vocabulary", label: "Vokabeln", emoji: "💬" },
    { key: "reading", label: "Leseverstehen", emoji: "📖" },
    { key: "writing", label: "Schreiben", emoji: "✍️" },
    { key: "listening", label: "Hörverstehen", emoji: "🎧" },
    { key: "speaking", label: "Sprechen", emoji: "🗣️" },
  ];

  const RATINGS = [
    { value: 1, label: "Sehr unsicher", emoji: "😰" },
    { value: 2, label: "Unsicher", emoji: "😟" },
    { value: 3, label: "Geht so", emoji: "😐" },
    { value: 4, label: "Sicher", emoji: "😊" },
    { value: 5, label: "Sehr sicher", emoji: "😎" },
  ];

  const allRated = areas.every(a => confidenceMap[a.key]);

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-up">
      <Button variant="ghost" onClick={onBack} className="mb-4">← Zurück</Button>
      <h2 className="text-xl font-black mb-1">Confidence-Check</h2>
      <p className="text-muted-foreground text-sm mb-5">Wie sicher fühlst du dich in jedem Bereich? Deine Einschätzung hilft uns, den richtigen Fokus zu finden.</p>

      <div className="space-y-4">
        {areas.map(area => (
          <div key={area.key} className="bg-card border border-border rounded-2xl p-4">
            <p className="font-bold text-sm mb-3">{area.emoji} {area.label}</p>
            <div className="flex gap-2 flex-wrap">
              {RATINGS.map(r => (
                <button
                  key={r.value}
                  onClick={() => setConfidenceMap(m => ({ ...m, [area.key]: r.value }))}
                  className={cn(
                    "flex flex-col items-center gap-1 px-3 py-2 rounded-xl border-2 text-xs font-bold transition-all flex-1",
                    confidenceMap[area.key] === r.value
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border hover:border-primary/40"
                  )}
                >
                  <span className="text-base">{r.emoji}</span>
                  <span className="hidden sm:block">{r.label}</span>
                  <span className="sm:hidden">{r.value}</span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {allRated && (
        <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-2xl">
          <p className="text-sm font-bold text-green-800 mb-2">✅ Auswertung bereit!</p>
          <div className="flex flex-wrap gap-2">
            {areas.filter(a => (confidenceMap[a.key] || 0) <= 2).map(a => (
              <Badge key={a.key} className="bg-red-100 text-red-700 border-0 text-xs font-bold">
                {a.label}: Fokus nötig
              </Badge>
            ))}
            {areas.filter(a => (confidenceMap[a.key] || 0) >= 4).map(a => (
              <Badge key={a.key} className="bg-green-100 text-green-700 border-0 text-xs">
                {a.label}: ✓ Gut
              </Badge>
            ))}
          </div>
        </div>
      )}

      <Button onClick={onStart} disabled={!allRated} size="lg" className="w-full mt-4 brand-gradient text-white font-black rounded-2xl">
        <ArrowRight className="w-4 h-4 mr-2" />Gezieltes Training starten
      </Button>
    </div>
  );
}

// ── Test Session ────────────────────────────────────────────────────────────────
function TestSession({ mode, exercises, attempts, grade, weakSkills, confidenceMap, user, onDone }) {
  const queryClient = useQueryClient();
  const [qIndex, setQIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const [timeLeft, setTimeLeft] = useState(null);
  const timerRef = useRef(null);

  const logAttempt = useMutation({
    mutationFn: (data) => base44.entities.ExerciseAttempt.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["recent-attempts"] }),
  });

  // Filter and shuffle exercises for this mode – longer, more varied sessions
  const sessionExercises = (() => {
    const shuffle = arr => [...arr].sort(() => Math.random() - 0.5);
    const gradeEx = exercises.filter(e => e.grade === grade || e.grade === "both");

    if (mode.id === "weak_booster") {
      const weakTopics = weakSkills.map(ws => ws.skill);
      const weak = gradeEx.filter(e => weakTopics.includes(e.skill_area));
      // Repeat weak exercises twice for reinforcement, shuffled
      return shuffle([...weak, ...weak]).slice(0, 24);
    }

    if (mode.id === "tomorrow") {
      // Last-minute: exam-relevant first, then fill with all types
      const examRel = shuffle(gradeEx.filter(e => e.exam_relevant));
      const rest = shuffle(gradeEx.filter(e => !e.exam_relevant));
      return [...examRel, ...rest].slice(0, 20);
    }

    if (mode.id === "three_days") {
      // Intensive: rotate skill areas, focus on medium+hard
      const medHard = shuffle(gradeEx.filter(e => e.difficulty === "medium" || e.difficulty === "hard"));
      const easy = shuffle(gradeEx.filter(e => e.difficulty === "easy"));
      return [...medHard, ...easy].slice(0, 25);
    }

    if (mode.id === "next_week") {
      // Systematic: all skills, balanced difficulty
      return SKILL_AREAS.flatMap(skill =>
        shuffle(gradeEx.filter(e => e.skill_area === skill)).slice(0, 5)
      ).slice(0, 30);
    }

    if (mode.id === "simulation") {
      // Exam simulation: balanced skill areas, mixed difficulty, varied types
      const types = ["multiple_choice", "fill_blank", "sentence_transformation", "error_correction", "true_false"];
      const pool = SKILL_AREAS.flatMap(skill =>
        shuffle(gradeEx.filter(e => e.skill_area === skill)).slice(0, 6)
      );
      // Ensure variety in types
      const byType = types.flatMap(t => shuffle(gradeEx.filter(e => e.type === t)).slice(0, 3));
      const combined = shuffle([...new Map([...pool, ...byType].map(e => [e.id, e])).values()]);
      return combined.slice(0, 25);
    }

    if (mode.id === "confidence") {
      const lowConf = Object.entries(confidenceMap).filter(([, v]) => v <= 2).map(([k]) => k);
      const medConf = Object.entries(confidenceMap).filter(([, v]) => v === 3).map(([k]) => k);
      const lowEx = shuffle(gradeEx.filter(e => lowConf.includes(e.skill_area)));
      const medEx = shuffle(gradeEx.filter(e => medConf.includes(e.skill_area)));
      return [...lowEx, ...lowEx, ...medEx].slice(0, 24); // repeat low-confidence areas
    }

    return shuffle(gradeEx.filter(e => e.exam_relevant)).slice(0, 20);
  })();

  // Timer for simulation mode
  useEffect(() => {
    if (mode.id === "simulation" && !done) {
      setTimeLeft(20 * 60); // 20 minutes
      timerRef.current = setInterval(() => {
        setTimeLeft(t => {
          if (t <= 1) { clearInterval(timerRef.current); setDone(true); return 0; }
          return t - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [mode.id, done]);

  const current = sessionExercises[qIndex];

  const handleSubmit = () => {
    if (!selected || !current) return;
    const isCorrect = current.type === "multiple_choice"
      ? selected === current.correct_answer
      : selected.trim().toLowerCase() === current.correct_answer?.trim().toLowerCase();
    setSubmitted(true);
    if (isCorrect) setScore(s => s + 1);
    if (user) {
      logAttempt.mutate({
        user_email: user.email,
        exercise_id: current.id,
        skill_area: current.skill_area,
        topic_key: current.topic_key,
        grade: current.grade,
        is_correct: isCorrect,
        user_answer: selected,
        correct_answer: current.correct_answer,
        attempt_date: new Date().toISOString().split("T")[0],
        xp_earned: isCorrect ? (current.xp_reward || 10) : 0,
      });
    }
  };

  const handleNext = () => {
    if (qIndex < sessionExercises.length - 1) {
      setQIndex(i => i + 1);
      setSelected(null);
      setSubmitted(false);
    } else {
      setDone(true);
    }
  };

  if (sessionExercises.length === 0) {
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto">
        <Button variant="ghost" onClick={onDone} className="mb-4">← Zurück</Button>
        <div className="text-center py-16">
          <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="font-bold mb-2">Keine Übungen für diesen Modus gefunden</p>
          <p className="text-sm text-muted-foreground mb-4">Bitte füge zuerst Übungen hinzu.</p>
          <Button onClick={onDone}>Zurück</Button>
        </div>
      </div>
    );
  }

  if (done) {
    const pct = Math.round((score / sessionExercises.length) * 100);
    return (
      <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-up">
        <div className="text-center py-8">
          <div className="text-5xl mb-4">{pct === 100 ? "🏆" : pct >= 70 ? "🎉" : pct >= 50 ? "👍" : "💪"}</div>
          <h2 className="text-2xl font-black mb-2">{score} / {sessionExercises.length} richtig</h2>
          <p className="text-4xl font-black text-primary mb-4">{pct}%</p>
          <div className="w-full max-w-xs mx-auto mb-6">
            <Progress value={pct} className="h-3 rounded-full" />
          </div>
          <p className="text-muted-foreground text-sm mb-6">
            {pct === 100 ? "Perfekt! Du bist bereit!" : pct >= 70 ? "Gut gemacht! Noch ein paar Schwächen gezielt üben." : "Weiter üben – du schaffst das!"}
          </p>
          <div className="flex gap-3 justify-center flex-wrap">
            <Button variant="outline" onClick={() => { setQIndex(0); setSelected(null); setSubmitted(false); setScore(0); setDone(false); }} className="gap-2 rounded-xl">
              <RotateCcw className="w-4 h-4" />Nochmal
            </Button>
            <Button onClick={onDone} className="gap-2 rounded-xl brand-gradient text-white border-0">
              <Trophy className="w-4 h-4" />Fertig
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const isCorrect = submitted && (current?.type === "multiple_choice"
    ? selected === current.correct_answer
    : selected?.trim().toLowerCase() === current?.correct_answer?.trim().toLowerCase());

  const formatTime = (s) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-up">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <Button variant="ghost" onClick={onDone} className="gap-1 text-muted-foreground text-sm">← Abbrechen</Button>
        <div className="flex items-center gap-3">
          {timeLeft !== null && (
            <div className={cn("flex items-center gap-1 px-3 py-1.5 rounded-xl text-sm font-black", timeLeft < 120 ? "bg-red-100 text-red-700" : "bg-secondary text-foreground")}>
              <Timer className="w-3.5 h-3.5" />{formatTime(timeLeft)}
            </div>
          )}
          <span className="text-sm text-muted-foreground">{qIndex + 1} / {sessionExercises.length}</span>
        </div>
      </div>

      <Progress value={(qIndex / sessionExercises.length) * 100} className="h-1.5 mb-5 rounded-full" />

      {/* Mode badge */}
      <div className="flex items-center gap-2 mb-4">
        <span className="text-lg">{mode.icon}</span>
        <Badge className={cn("text-xs font-black border-0", mode.color, mode.textColor)}>{mode.label}</Badge>
        <Badge variant="outline" className="text-xs">{current?.skill_area}</Badge>
      </div>

      {/* Question */}
      <div className="bg-card border border-border rounded-2xl p-5 mb-4">
        {current?.context_text && (
          <div className="bg-secondary/60 rounded-xl p-3 mb-4 text-sm italic text-muted-foreground">
            {current.context_text}
          </div>
        )}
        <p className="font-bold text-base mb-4">{current?.question}</p>

        {current?.type === "multiple_choice" && current.options && (
          <div className="space-y-2">
            {current.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => !submitted && setSelected(opt)}
                disabled={submitted}
                className={cn(
                  "w-full p-3.5 rounded-xl border-2 text-left text-sm font-medium transition-all cursor-pointer",
                  submitted
                    ? opt === current.correct_answer ? "border-green-500 bg-green-50 text-green-800"
                      : opt === selected ? "border-red-400 bg-red-50 text-red-700" : "border-border opacity-40"
                    : selected === opt ? "border-primary bg-primary/10 text-primary font-bold" : "border-border hover:border-primary/40 hover:bg-primary/5"
                )}
              >
                {opt}
              </button>
            ))}
          </div>
        )}

        {(current?.type === "fill_blank" || current?.type === "error_correction" || current?.type === "sentence_transformation") && !submitted && (
          <input
            className="w-full p-3 rounded-xl border-2 border-border focus:border-primary outline-none text-sm"
            placeholder={current.type === "error_correction" ? "Korrigierter Satz..." : "Deine Antwort..."}
            value={selected || ""}
            onChange={e => setSelected(e.target.value)}
          />
        )}

        {submitted && (current?.type === "sentence_transformation" || current?.type === "error_correction") ? (
          <TransformationFeedback
            exercise={current}
            userAnswer={selected}
            onContinue={handleNext}
            onMarkCorrect={(counted) => {
              if (counted && !isCorrect) setScore(s => s + 1);
              handleNext();
            }}
          />
        ) : submitted ? (
          <div className={cn("mt-4 p-4 rounded-xl border", isCorrect ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200")}>
            <div className="flex items-center gap-2 mb-2">
              {isCorrect
                ? <CheckCircle2 className="w-4 h-4 text-green-600" />
                : <AlertTriangle className="w-4 h-4 text-red-500" />
              }
              <span className={cn("text-sm font-black", isCorrect ? "text-green-700" : "text-red-700")}>
                {isCorrect ? "Richtig! ✓" : `Falsch. Richtige Antwort: ${current.correct_answer}`}
              </span>
            </div>
            {current.explanation && (
              <p className="text-xs text-muted-foreground leading-relaxed">{current.explanation}</p>
            )}
            <Button onClick={handleNext} size="sm" className="mt-3 gap-2 rounded-xl">
              Weiter <ChevronRight className="w-3.5 h-3.5" />
            </Button>
          </div>
        ) : null}

        {!submitted && (
          <Button onClick={handleSubmit} disabled={!selected} className="w-full mt-4 rounded-xl font-bold">
            Antworten
          </Button>
        )}
      </div>
    </div>
  );
}

// ── Pre-Test Checklist ──────────────────────────────────────────────────────────
function PreTestChecklist({ checklist, setChecklist, compact = false }) {
  const items = [
    { id: "vocab", label: "Alle Vokabeln wiederholt" },
    { id: "grammar", label: "Grammatikregeln nochmal gelesen" },
    { id: "examples", label: "Beispielsätze angeschaut" },
    { id: "mistakes", label: "Typische Fehler im Blick" },
    { id: "sleep", label: "Gut geschlafen / ausgeruht" },
    { id: "material", label: "Materialien/Stift bereit" },
  ];

  const checked = Object.values(checklist).filter(Boolean).length;

  return (
    <div className={cn("rounded-2xl border border-green-200 bg-green-50 p-4", compact ? "mt-4" : "mt-6")}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-black text-green-700 uppercase tracking-wider">✅ Vortest-Checkliste</p>
        <span className="text-xs font-bold text-green-700">{checked}/{items.length}</span>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {items.map(item => (
          <button
            key={item.id}
            onClick={() => setChecklist(c => ({ ...c, [item.id]: !c[item.id] }))}
            className={cn(
              "flex items-center gap-2 p-2 rounded-xl text-xs font-medium text-left transition-all border",
              checklist[item.id] ? "bg-green-200 border-green-300 text-green-800" : "bg-white border-green-100 text-green-700"
            )}
          >
            <div className={cn("w-4 h-4 rounded flex items-center justify-center flex-shrink-0", checklist[item.id] ? "bg-green-500" : "border-2 border-green-300")}>
              {checklist[item.id] && <CheckCircle2 className="w-3 h-3 text-white" />}
            </div>
            {item.label}
          </button>
        ))}
      </div>
    </div>
  );
}