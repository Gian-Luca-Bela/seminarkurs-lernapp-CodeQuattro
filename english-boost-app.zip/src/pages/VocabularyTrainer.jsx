// ─── Vocabulary Trainer – rich exercise modes with stable state & validation ────
import { useState, useMemo, useRef, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { BookOpen, Zap, Check, X, ChevronRight, RotateCcw, AlertTriangle, ArrowLeftRight, Layers, Search } from "lucide-react";
import { DIFFICULTY_COLORS, DIFFICULTY_LABELS } from "@/lib/constants";
import { shuffleArray } from "@/lib/utils";
import XPToast from "@/components/XPToast";
import { useXP } from "@/lib/useXP";

const TRAINER_MODES = [
  { id: "flashcard", label: "Karteikarten", icon: "🃏", desc: "Flip-Karten mit Übersetzung" },
  { id: "synonym", label: "Synonym-Nuancen", icon: "🔄", desc: "Formell vs. informell unterscheiden" },
  { id: "antonym", label: "Antonym-Matching", icon: "↔️", desc: "Gegensätze zuordnen" },
  { id: "context", label: "Wort im Kontext", icon: "📖", desc: "Richtige Form im Satz einsetzen" },
  { id: "false_friend", label: "False Friend Challenge", icon: "⚠️", desc: "Gefährliche Verwechslungen erkennen" },
  { id: "word_family", label: "Wortfamilien-Builder", icon: "🌳", desc: "Verwandte Wörter bilden" },
  { id: "collocation", label: "Kollokations-Builder", icon: "🔗", desc: "Typische Wortkombinationen" },
];

export default function VocabularyTrainer() {
  const [mode, setMode] = useState(null);
  const [grade, setGrade] = useState("all");
  const [theme, setTheme] = useState("Alle");

  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: words = [] } = useQuery({
    queryKey: ["vocabulary"],
    queryFn: () => base44.entities.VocabularyItem.list("-created_date", 200),
  });

  const filteredWords = words.filter(w => {
    const matchGrade = grade === "all" || w.grade === grade || w.grade === "both";
    const matchTheme = theme === "Alle" || w.theme === theme;
    return matchGrade && matchTheme;
  });

  const themes = ["Alle", ...Array.from(new Set(words.map(w => w.theme).filter(Boolean)))];

  if (mode) {
    return (
      <TrainerSession
        mode={mode}
        words={filteredWords}
        user={user}
        onBack={() => setMode(null)}
      />
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-up">
      <div className="mb-6">
        <h1 className="text-2xl font-black flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-500 flex items-center justify-center">
            <BookOpen className="w-5 h-5 text-white" />
          </div>
          Vokabel-Trainer
        </h1>
        <p className="text-muted-foreground text-sm mt-1">{words.length} Wörter · Wähle deinen Trainingsmodus</p>
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-3 flex-wrap">
        {["all", "8", "9"].map(g => (
          <button key={g} onClick={() => setGrade(g)}
            className={cn("px-3 py-1.5 rounded-full text-xs font-bold transition-all border", grade === g ? "bg-primary text-white border-primary" : "border-border text-muted-foreground hover:border-primary/40")}>
            {g === "all" ? "Alle Klassen" : `Klasse ${g}`}
          </button>
        ))}
      </div>
      <div className="flex gap-2 mb-5 overflow-x-auto pb-1">
        {themes.map(t => (
          <button key={t} onClick={() => setTheme(t)}
            className={cn("px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition-all border", theme === t ? "bg-secondary border-border font-bold" : "border-transparent text-muted-foreground hover:text-foreground")}>
            {t}
          </button>
        ))}
      </div>

      <div className="text-xs text-muted-foreground mb-4">{filteredWords.length} Wörter für Training verfügbar</div>

      {/* Mode grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {TRAINER_MODES.map(m => {
          const hasWords = filteredWords.length >= 2;
          const isFalseFriend = m.id === "false_friend" && filteredWords.filter(w => w.is_false_friend).length === 0;
          const disabled = !hasWords || isFalseFriend;
          return (
            <button
              key={m.id}
              onClick={() => !disabled && setMode(m)}
              disabled={disabled}
              className={cn(
                "p-4 rounded-2xl border-2 text-left transition-all",
                disabled ? "border-border bg-secondary/30 opacity-50 cursor-not-allowed"
                  : "border-border hover:border-primary/40 hover:bg-primary/5 hover:shadow-sm card-hover"
              )}
            >
              <div className="text-2xl mb-2">{m.icon}</div>
              <p className="font-black text-sm mb-0.5">{m.label}</p>
              <p className="text-xs text-muted-foreground">{m.desc}</p>
              {isFalseFriend && <p className="text-xs text-orange-500 mt-1">Keine False Friends in Auswahl</p>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── Trainer Session dispatcher ─────────────────────────────────────────────────
function TrainerSession({ mode, words, user, onBack }) {
  const queryClient = useQueryClient();
  const [showXP, setShowXP] = useState(false);
  const [lastXP, setLastXP] = useState(0);
  const { data: profile } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const { awardXP } = useXP(user, profile?.[0]);
  
  const logAttempt = useMutation({
    mutationFn: (data) => base44.entities.ExerciseAttempt.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["recent-attempts"] }),
  });

  const log = useCallback((word, correct) => {
    if (!user) return;
    const xpEarned = correct ? 10 : 0;
    logAttempt.mutate({
      user_email: user.email,
      exercise_id: word.id,
      skill_area: "vocabulary",
      topic_key: word.theme || "vocabulary",
      grade: word.grade,
      is_correct: correct,
      attempt_date: new Date().toISOString().split("T")[0],
      xp_earned: xpEarned,
    });
    if (correct) {
      awardXP(xpEarned);
      setLastXP(xpEarned);
      setShowXP(true);
    }
  }, [user, logAttempt, awardXP]);

  // Shuffle ONCE when the session is created, stored in a ref so it never changes
  const shufRef = useRef(null);
  if (!shufRef.current) shufRef.current = shuffleArray([...words]);
  const shuf = shufRef.current;

  return (
    <>
      <XPToast amount={lastXP} show={showXP} onDone={() => setShowXP(false)} />
      {mode.id === "flashcard" && <FlashcardTrainer words={shuf} onBack={onBack} onLog={log} />}
      {mode.id === "synonym" && <SynonymTrainer words={shuf.filter(w => w.synonyms?.length >= 2)} onBack={onBack} onLog={log} />}
      {mode.id === "antonym" && <AntonymTrainer words={shuf.filter(w => w.antonyms?.length >= 1)} onBack={onBack} onLog={log} />}
      {mode.id === "context" && <ContextTrainer words={shuf.filter(w => w.example_sentence)} onBack={onBack} onLog={log} />}
      {mode.id === "false_friend" && <FalseFriendTrainer words={shuf.filter(w => w.is_false_friend)} onBack={onBack} onLog={log} />}
      {mode.id === "word_family" && <WordFamilyTrainer words={shuf.filter(w => w.word_family?.length >= 2)} onBack={onBack} onLog={log} />}
      {mode.id === "collocation" && <CollocationTrainer words={shuf.filter(w => w.collocations?.length >= 2)} onBack={onBack} onLog={log} />}
      {!["flashcard", "synonym", "antonym", "context", "false_friend", "word_family", "collocation"].includes(mode.id) && <div className="p-6"><Button onClick={onBack}>← Zurück</Button></div>}
    </>
  );
}

// ── Shared header/progress ──────────────────────────────────────────────────────
function SessionHeader({ mode, index, total, onBack }) {
  return (
    <div className="mb-5">
      <div className="flex items-center justify-between mb-3">
        <Button variant="ghost" onClick={onBack} className="gap-1 text-muted-foreground text-sm">← Beenden</Button>
        <span className="text-sm text-muted-foreground font-medium">{index + 1} / {total}</span>
      </div>
      <div className="flex items-center gap-2 mb-2">
        <span className="text-base">{mode.icon}</span>
        <span className="text-xs font-black text-primary uppercase tracking-wider">{mode.label}</span>
      </div>
      <div className="h-1.5 bg-secondary rounded-full">
        <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${(index / total) * 100}%` }} />
      </div>
    </div>
  );
}

function AnswerFeedback({ correct, explanation, onNext }) {
  return (
    <div className={cn("mt-4 p-4 rounded-2xl border", correct ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200")}>
      <div className="flex items-center gap-2 mb-1">
        {correct ? <Check className="w-4 h-4 text-green-600" /> : <X className="w-4 h-4 text-red-500" />}
        <span className={cn("font-black text-sm", correct ? "text-green-700" : "text-red-700")}>
          {correct ? "Richtig! ✓" : "Nicht ganz!"}
        </span>
      </div>
      {explanation && <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{explanation}</p>}
      <Button size="sm" onClick={onNext} className="mt-3 gap-1 rounded-xl">Weiter <ChevronRight className="w-3.5 h-3.5" /></Button>
    </div>
  );
}

// ── Flashcard ──────────────────────────────────────────────────────────────────
function FlashcardTrainer({ words, onBack, onLog }) {
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [transitioning, setTransitioning] = useState(false);

  const w = useMemo(() => words[i] ?? null, [i, words]);

  if (words.length === 0 || !w) return <EmptyTrainer onBack={onBack} />;

  const next = (correct) => {
    if (transitioning) return;
    setTransitioning(true);
    onLog(w, correct);
    setTimeout(() => {
      setFlipped(false);
      setI(x => (x + 1) % words.length);
      setTransitioning(false);
    }, 180);
  };

  return (
    <div className="p-4 md:p-6 max-w-xl mx-auto animate-fade-up">
      <SessionHeader mode={{ icon: "🃏", label: "Karteikarten" }} index={i} total={words.length} onBack={onBack} />
      <div className="flex items-center justify-center gap-2 mb-3 text-xs font-bold">
        <span className="px-2.5 py-1 rounded-full bg-blue-100 text-blue-700">🇬🇧 Englisch</span>
        <span className="text-muted-foreground">→</span>
        <span className="px-2.5 py-1 rounded-full bg-yellow-100 text-yellow-700">🇩🇪 Deutsch</span>
      </div>
      {/* Only clickable to flip when not yet flipped and not transitioning */}
      <div
        onClick={() => { if (!flipped && !transitioning) setFlipped(true); }}
        style={{ cursor: flipped ? "default" : "pointer" }}
      >
        <div className={cn(
          "min-h-56 rounded-2xl border-2 p-7 flex flex-col items-center justify-center text-center transition-all duration-200",
          flipped ? "border-primary bg-primary/5" : "border-border hover:border-primary/30",
          transitioning ? "opacity-0 scale-98" : "opacity-100 scale-100"
        )}>
          {!flipped ? (
            <>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">🇬🇧 Englisches Wort</p>
              <p className="text-4xl font-black mb-2">{w.word}</p>
              {w.part_of_speech && <p className="text-xs text-muted-foreground italic">{w.part_of_speech}</p>}
              <p className="text-xs text-muted-foreground mt-3 uppercase tracking-wider">Tippen zum Aufdecken</p>
            </>
          ) : (
            <>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-3">🇩🇪 Deutsche Übersetzung</p>
              <p className="text-2xl font-black text-primary mb-2">{w.translation_de || "–"}</p>
              {w.definition_de && <p className="text-sm text-muted-foreground mt-1">{w.definition_de}</p>}
              {w.example_sentence && <p className="text-sm text-muted-foreground italic mt-2">"{w.example_sentence}"</p>}
              {w.is_false_friend && (
                <div className="mt-3 px-3 py-1.5 bg-red-100 border border-red-200 rounded-xl">
                  <p className="text-xs text-red-700 font-bold">⚠️ False Friend!</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
      {flipped && !transitioning && (
        <div className="flex gap-3 mt-4 animate-fade-in">
          <Button variant="outline" onClick={() => next(false)} className="flex-1 gap-2 border-red-200 text-red-600 hover:bg-red-50 rounded-xl font-bold">
            <X className="w-4 h-4" />Noch nicht
          </Button>
          <Button onClick={() => next(true)} className="flex-1 gap-2 rounded-xl font-bold">
            <Check className="w-4 h-4" />Gewusst!
          </Button>
        </div>
      )}
    </div>
  );
}

// ── Synonym Nuance ──────────────────────────────────────────────────────────────
function SynonymTrainer({ words, onBack, onLog }) {
  const [i, setI] = useState(0);
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);

  // Store computed question data in a ref – keyed by index – so re-renders NEVER reshuffle
  const cacheRef = useRef({});

  const getQuestion = (idx) => {
    if (cacheRef.current[idx]) return cacheRef.current[idx];
    const word = words[idx];
    const syns = word.synonyms || [];
    const corr = syns[0];
    const distractors = Array.from(new Set(
      words
        .filter((_, j) => j !== idx)
        .flatMap(x => x.synonyms || [])
        .filter(s => s !== corr && !syns.includes(s))
    )).slice(0, 3);
    const pool = shuffleArray([corr, ...distractors]).slice(0, 4);
    if (!pool.includes(corr)) pool[pool.length - 1] = corr;
    const result = { word, corr, pool };
    cacheRef.current[idx] = result;
    return result;
  };

  if (words.length === 0) return <EmptyTrainer onBack={onBack} message="Keine Wörter mit mehreren Synonymen gefunden." />;

  const { word: w, corr: correctSynonym, pool: options } = getQuestion(i);

  const next = () => { setSelected(null); setSubmitted(false); setI(x => (x + 1) % words.length); };
  const submit = () => {
    if (!selected || submitted) return;
    setSubmitted(true);
    onLog(w, selected === correctSynonym);
  };

  return (
    <div className="p-4 md:p-6 max-w-xl mx-auto animate-fade-up">
      <SessionHeader mode={{ icon: "🔄", label: "Synonym-Nuancen" }} index={i} total={words.length} onBack={onBack} />
      <div className="bg-card border border-border rounded-2xl p-5 mb-4">
        <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Welches Wort ist ein Synonym für:</p>
        <p className="text-2xl font-black mb-1">{w.word}</p>
        {w.definition_en && <p className="text-sm text-muted-foreground italic">"{w.definition_en}"</p>}
        <div className="mt-2 flex items-center gap-1.5">
          <span className="text-xs bg-blue-100 text-blue-700 font-bold px-2 py-0.5 rounded-full">🇬🇧 Englisch → Englisch</span>
        </div>
      </div>
      <div className="space-y-2">
        {options.map((opt, idx) => (
          <button key={`${i}-${idx}`} onClick={() => !submitted && setSelected(opt)}
            className={cn("w-full p-3.5 rounded-xl border-2 text-left text-sm font-medium transition-all",
              submitted
                ? opt === correctSynonym ? "border-green-500 bg-green-50 text-green-800"
                  : opt === selected ? "border-red-400 bg-red-50" : "border-border opacity-40"
                : selected === opt ? "border-primary bg-primary/8" : "border-border hover:border-primary/40"
            )}>
            {opt}
          </button>
        ))}
      </div>
      {submitted
        ? <AnswerFeedback correct={selected === correctSynonym} explanation={`Synonyme von "${w.word}": ${(w.synonyms || []).join(", ")}`} onNext={next} />
        : <Button onClick={submit} disabled={!selected} className="w-full mt-4 rounded-xl font-bold">Antworten</Button>
      }
    </div>
  );
}

// ── Antonym Matching ──────────────────────────────────────────────────────────
function AntonymTrainer({ words, onBack, onLog }) {
  const validWords = useMemo(() => words.filter(w => w.antonyms?.length >= 1), [words]);

  const [i, setI] = useState(0);
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const cacheRef = useRef({});

  const getQuestion = (idx) => {
    if (cacheRef.current[idx]) return cacheRef.current[idx];
    const word = validWords[idx % validWords.length];
    const ca = word.antonyms[0];
    const dist = Array.from(new Set(
      validWords.filter((_, j) => j !== idx).flatMap(x => x.antonyms || []).filter(a => a !== ca)
    )).slice(0, 3);
    let opts = shuffleArray([ca, ...dist]).slice(0, 4);
    if (!opts.includes(ca)) opts[0] = ca;
    const result = { word, ca, opts };
    cacheRef.current[idx] = result;
    return result;
  };

  if (validWords.length === 0) return <EmptyTrainer onBack={onBack} message="Keine Wörter mit Antonymen gefunden. Füge Antonyme zu deinen Vokabeln hinzu." />;

  const { word: w, ca: correctAntonym, opts: options } = getQuestion(i);
  const next = () => { setSelected(null); setSubmitted(false); setI(x => (x + 1) % validWords.length); };
  const submit = () => {
    if (!selected || submitted) return;
    setSubmitted(true);
    onLog(w, selected === correctAntonym);
  };

  return (
    <div className="p-4 md:p-6 max-w-xl mx-auto animate-fade-up">
      <SessionHeader mode={{ icon: "↔️", label: "Antonym-Matching" }} index={i % validWords.length} total={validWords.length} onBack={onBack} />
      <div className="bg-card border border-border rounded-2xl p-5 mb-4">
        <div className="flex items-center gap-2 mb-2">
          <ArrowLeftRight className="w-4 h-4 text-primary" />
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Gegenteil von:</p>
        </div>
        <p className="text-2xl font-black">{w.word}</p>
        <p className="text-sm text-muted-foreground mt-1">{w.definition_en}</p>
      </div>
      <div className="space-y-2">
        {options.map((opt, idx) => (
          <button key={`${i}-${idx}`} onClick={() => !submitted && setSelected(opt)}
            className={cn("w-full p-3.5 rounded-xl border-2 text-left text-sm font-medium transition-all",
              submitted ? opt === correctAntonym ? "border-green-500 bg-green-50 text-green-800" : opt === selected ? "border-red-400 bg-red-50" : "border-border opacity-40"
              : selected === opt ? "border-primary bg-primary/8" : "border-border hover:border-primary/40"
            )}>
            {opt}
          </button>
        ))}
      </div>
      {submitted
        ? <AnswerFeedback correct={selected === correctAntonym} explanation={`Antonyme: ${w.antonyms?.join(", ")}`} onNext={next} />
        : <Button onClick={submit} disabled={!selected} className="w-full mt-4 rounded-xl font-bold">Antworten</Button>
      }
    </div>
  );
}

// ── Word in Context ────────────────────────────────────────────────────────────
function ContextTrainer({ words, onBack, onLog }) {
  const [i, setI] = useState(0);
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const cacheRef = useRef({});

  const getQuestion = (idx) => {
    if (cacheRef.current[idx]) return cacheRef.current[idx];
    const word = words[idx];
    const blank = word.example_sentence?.replace(new RegExp(`\\b${word.word}\\b`, "gi"), "_____") || "";
    const dist = shuffleArray(words.filter((_, j) => j !== idx)).slice(0, 3).map(x => x.word);
    const opts = shuffleArray([word.word, ...dist]).slice(0, 4);
    const result = { word, blank, opts };
    cacheRef.current[idx] = result;
    return result;
  };

  if (words.length === 0) return <EmptyTrainer onBack={onBack} />;

  const { word: w, blank: blankSentence, opts: options } = getQuestion(i);
  const next = () => { setSelected(null); setSubmitted(false); setI(x => (x + 1) % words.length); };
  const submit = () => {
    if (!selected || submitted) return;
    setSubmitted(true);
    onLog(w, selected === w.word);
  };

  return (
    <div className="p-4 md:p-6 max-w-xl mx-auto animate-fade-up">
      <SessionHeader mode={{ icon: "📖", label: "Wort im Kontext" }} index={i} total={words.length} onBack={onBack} />
      <div className="bg-card border border-border rounded-2xl p-5 mb-4">
        <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">Welches Wort passt in die Lücke?</p>
        <p className="text-base font-medium leading-relaxed italic">"{blankSentence}"</p>
        {w.theme && <Badge variant="secondary" className="mt-2 text-xs">{w.theme}</Badge>}
      </div>
      <div className="space-y-2">
        {options.map((opt, idx) => (
          <button key={`${i}-${idx}`} onClick={() => !submitted && setSelected(opt)}
            className={cn("w-full p-3.5 rounded-xl border-2 text-left text-sm font-medium transition-all",
              submitted ? opt === w.word ? "border-green-500 bg-green-50 text-green-800" : opt === selected ? "border-red-400 bg-red-50" : "border-border opacity-40"
              : selected === opt ? "border-primary bg-primary/8" : "border-border hover:border-primary/40"
            )}>
            {opt}
          </button>
        ))}
      </div>
      {submitted
        ? <AnswerFeedback correct={selected === w.word} explanation={w.definition_en} onNext={next} />
        : <Button onClick={submit} disabled={!selected} className="w-full mt-4 rounded-xl font-bold">Antworten</Button>
      }
    </div>
  );
}

// ── False Friend Challenge ─────────────────────────────────────────────────────
function FalseFriendTrainer({ words, onBack, onLog }) {
  const [i, setI] = useState(0);
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const cacheRef = useRef({});

  const getQuestion = (idx) => {
    if (cacheRef.current[idx]) return cacheRef.current[idx];
    const word = words[idx];
    const corr = word.translation_de;
    // Use German translations of other words as distractors
    const distractors = shuffleArray(
      words
        .filter((_, j) => j !== idx)
        .map(w => w.translation_de)
        .filter(t => t && t !== corr)
    ).slice(0, 3);
    // Pad with generic German words if not enough distractors
    const fallbacks = ["anpassen", "bemerken", "erreichen", "verlassen", "bestehen", "erkennen"];
    while (distractors.length < 3) {
      const fb = fallbacks.find(f => f !== corr && !distractors.includes(f));
      if (fb) distractors.push(fb); else break;
    }
    let opts = shuffleArray([corr, ...distractors.slice(0, 3)]);
    if (!opts.includes(corr)) opts[0] = corr;
    const result = { word, corr, opts };
    cacheRef.current[idx] = result;
    return result;
  };

  if (words.length === 0) return <EmptyTrainer onBack={onBack} message="Keine False Friends in dieser Auswahl." />;

  const { word: w, corr: correct, opts: options } = getQuestion(i);
  const next = () => { setSelected(null); setSubmitted(false); setI(x => (x + 1) % words.length); };

  return (
    <div className="p-4 md:p-6 max-w-xl mx-auto animate-fade-up">
      <SessionHeader mode={{ icon: "⚠️", label: "False Friend Challenge" }} index={i} total={words.length} onBack={onBack} />
      <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-5 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <AlertTriangle className="w-4 h-4 text-red-500" />
          <p className="text-xs font-black text-red-700 uppercase tracking-wider">False Friend!</p>
        </div>
        <p className="text-2xl font-black mb-1">{w.word}</p>
        <p className="text-sm text-red-700">Was bedeutet dieses englische Wort auf Deutsch?</p>
      </div>
      <div className="space-y-2">
        {options.map((opt, idx) => (
          <button key={`${i}-${idx}`} onClick={() => !submitted && setSelected(opt)}
            className={cn("w-full p-3.5 rounded-xl border-2 text-left text-sm font-medium transition-all",
              submitted ? opt === correct ? "border-green-500 bg-green-50 text-green-800" : opt === selected ? "border-red-400 bg-red-50" : "border-border opacity-40"
              : selected === opt ? "border-primary bg-primary/8" : "border-border hover:border-primary/40"
            )}>
            {opt}
          </button>
        ))}
      </div>
      {submitted
        ? <AnswerFeedback correct={selected === correct} explanation={w.false_friend_note || `Die korrekte Übersetzung ist: ${correct}`} onNext={next} />
        : <Button onClick={() => { if (selected) { setSubmitted(true); onLog(w, selected === correct); }}} disabled={!selected} className="w-full mt-4 rounded-xl font-bold">Antworten</Button>
      }
    </div>
  );
}

// ── Word Family Builder ───────────────────────────────────────────────────────
function WordFamilyTrainer({ words, onBack, onLog }) {
  const [i, setI] = useState(0);
  const [input, setInput] = useState("");
  const [submitted, setSubmitted] = useState(false);
  
  const { w, target } = useMemo(() => {
    if (words.length === 0) return { w: null, target: "" };
    const word = words[i] ?? words[0];
    return { w: word, target: word.word_family?.[0] || word.word + "ing" };
  }, [i, words]);

  if (words.length === 0 || !w) return <EmptyTrainer onBack={onBack} message="Keine Wörter mit Wortfamilien gefunden." />;

  const next = () => { setInput(""); setSubmitted(false); setI(x => (x + 1) % words.length); };
  const correct = input.trim().toLowerCase() === target.toLowerCase();
  
  return (
    <div className="p-4 md:p-6 max-w-xl mx-auto animate-fade-up">
      <SessionHeader mode={{ icon: "🌳", label: "Wortfamilien" }} index={i} total={words.length} onBack={onBack} />
      <div className="bg-card border border-border rounded-2xl p-5 mb-4">
        <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">Nenne ein weiteres Wort aus der Wortfamilie von:</p>
        <p className="text-2xl font-black mb-2">{w.word}</p>
        <p className="text-sm text-muted-foreground">{w.definition_en}</p>
        {!submitted && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            <p className="text-xs text-muted-foreground w-full">Wortfamilie enthält u.a.:</p>
            {w.word_family?.slice(1).map(wf => (
              <Badge key={wf} variant="secondary" className="text-xs opacity-50">???</Badge>
            ))}
          </div>
        )}
      </div>
      {!submitted ? (
        <>
          <input
            className="w-full p-3 rounded-xl border-2 border-border focus:border-primary outline-none text-sm mb-3"
            placeholder="Verwandtes Wort eingeben..."
            value={input}
            onChange={e => setInput(e.target.value)}
          />
          <Button onClick={() => { if (input && !submitted) { setSubmitted(true); onLog(w, correct); }}} disabled={!input} className="w-full rounded-xl font-bold">Prüfen</Button>
        </>
      ) : (
        <AnswerFeedback
          correct={correct}
          explanation={`Alle Wörter aus der Familie: ${[w.word, ...(w.word_family || [])].join(", ")}`}
          onNext={next}
        />
      )}
    </div>
  );
}

// ── Collocation Builder ────────────────────────────────────────────────────────
function CollocationTrainer({ words, onBack, onLog }) {
  const [i, setI] = useState(0);
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const cacheRef = useRef({});

  const getQuestion = (idx) => {
    if (cacheRef.current[idx]) return cacheRef.current[idx];
    const word = words[idx];
    const corr = word.collocations?.[0];
    const wrongOpts = [
      `make ${word.word}`, `do ${word.word}`, `bring ${word.word}`, `give ${word.word}`,
      `have ${word.word}`, `take ${word.word}`
    ].filter(o => o !== corr).slice(0, 3);
    let opts = shuffleArray([corr, ...wrongOpts]).slice(0, 4).filter(Boolean);
    if (!opts.includes(corr)) opts[0] = corr;
    const result = { word, corr, opts };
    cacheRef.current[idx] = result;
    return result;
  };

  if (words.length === 0) return <EmptyTrainer onBack={onBack} message="Keine Wörter mit Kollokationen gefunden." />;

  const { word: w, corr: correct, opts: options } = getQuestion(i);
  const next = () => { setSelected(null); setSubmitted(false); setI(x => (x + 1) % words.length); };

  return (
    <div className="p-4 md:p-6 max-w-xl mx-auto animate-fade-up">
      <SessionHeader mode={{ icon: "🔗", label: "Kollokations-Builder" }} index={i} total={words.length} onBack={onBack} />
      <div className="bg-card border border-border rounded-2xl p-5 mb-4">
        <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">Welche Kollokation ist KORREKT?</p>
        <p className="text-xl font-black mb-1">"{w.word}"</p>
        <p className="text-sm text-muted-foreground">{w.definition_en}</p>
      </div>
      <div className="space-y-2">
        {options.map((opt, idx) => (
          <button key={`${i}-${idx}`} onClick={() => !submitted && setSelected(opt)}
            className={cn("w-full p-3.5 rounded-xl border-2 text-left text-sm font-medium transition-all",
              submitted ? opt === correct ? "border-green-500 bg-green-50 text-green-800" : opt === selected ? "border-red-400 bg-red-50" : "border-border opacity-40"
              : selected === opt ? "border-primary bg-primary/8" : "border-border hover:border-primary/40"
            )}>
            {opt}
          </button>
        ))}
      </div>
      {submitted
        ? <AnswerFeedback correct={selected === correct} explanation={`Alle Kollokationen: ${w.collocations?.join(", ")}`} onNext={next} />
        : <Button onClick={() => { if (selected) { setSubmitted(true); onLog(w, selected === correct); }}} disabled={!selected} className="w-full mt-4 rounded-xl font-bold">Antworten</Button>
      }
    </div>
  );
}

function EmptyTrainer({ onBack, message = "Keine Wörter für diesen Trainer in der aktuellen Auswahl." }) {
  return (
    <div className="p-4 md:p-6 max-w-xl mx-auto text-center py-16">
      <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
      <p className="font-bold mb-2">Nicht genug Inhalt</p>
      <p className="text-sm text-muted-foreground mb-4">{message}</p>
      <Button onClick={onBack}>← Zurück</Button>
    </div>
  );
}