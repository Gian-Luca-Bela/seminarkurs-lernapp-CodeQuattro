/**
 * Seed Grammar Data Page
 * Imports comprehensive grammar curriculum into the database
 */

import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { GRAMMAR_LESSONS, GRAMMAR_EXERCISES } from "@/lib/seedGrammarContent";
import { ArrowLeft, Zap, Check } from "lucide-react";
import { Link } from "react-router-dom";

export default function SeedGrammarData() {
  const [status, setStatus] = useState("ready"); // ready | loading | success | error
  const [progress, setProgress] = useState(0);
  const [total, setTotal] = useState(0);
  const [error, setError] = useState(null);

  const seedLessons = useMutation({
    mutationFn: async () => {
      setStatus("loading");
      setTotal(GRAMMAR_LESSONS.length + GRAMMAR_EXERCISES.length);
      setProgress(0);

      try {
        // Seed lessons
        for (const lesson of GRAMMAR_LESSONS) {
          await base44.entities.GrammarLesson.create(lesson);
          setProgress((p) => p + 1);
        }

        // Seed exercises
        for (const exercise of GRAMMAR_EXERCISES) {
          await base44.entities.Exercise.create(exercise);
          setProgress((p) => p + 1);
        }

        setStatus("success");
      } catch (err) {
        setError(err.message);
        setStatus("error");
      }
    },
  });

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-in">
      <Link
        to="/grammar"
        className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors mb-6 group"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        Zurück zur Grammatik
      </Link>

      <Card>
        <CardContent className="p-8">
          {status === "ready" && (
            <div className="space-y-4">
              <div>
                <h2 className="text-xl font-black mb-2">Umfassender Grammatik-Lehrplan laden</h2>
                <p className="text-sm text-muted-foreground mb-4">
                  Dies importiert {GRAMMAR_LESSONS.length} Lektionen und{" "}
                  {GRAMMAR_EXERCISES.length} Übungen in 3 Schwierigkeitsstufen:
                </p>
                <ul className="text-sm text-muted-foreground space-y-1 mb-4 ml-4">
                  <li>🟢 <strong>Grundlagen</strong> (7 Lektionen) – Foundation & basic tenses</li>
                  <li>🟡 <strong>Mittelstufe</strong> (9 Lektionen) – Intermediate structures</li>
                  <li>🔴 <strong>Fortgeschritten</strong> (10 Lektionen) – Advanced grammar</li>
                </ul>
                <p className="text-xs text-muted-foreground">
                  Enthält Present/Past/Future Tenses, Conditional, Passive, Reported Speech,
                  Relative Clauses und mehr.
                </p>
              </div>

              <Button
                onClick={() => seedLessons.mutate()}
                className="w-full gap-2 brand-gradient text-white border-0 font-black rounded-2xl"
                size="lg"
              >
                <Zap className="w-5 h-5" />
                Daten jetzt laden
              </Button>
            </div>
          )}

          {status === "loading" && (
            <div className="space-y-4">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full brand-gradient flex items-center justify-center mx-auto mb-3 animate-spin">
                  <span className="text-white font-bold">⚡</span>
                </div>
                <h3 className="font-black mb-2">Daten werden geladen…</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {progress} / {total} Items importiert
                </p>
                <Progress value={(progress / total) * 100} className="h-2" />
              </div>
            </div>
          )}

          {status === "success" && (
            <div className="text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mx-auto">
                <Check className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="font-black text-lg mb-1">Erfolgreich geladen!</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {total} Grammatik-Items sind jetzt verfügbar.
                </p>
              </div>
              <Button
                asChild
                className="w-full gap-2 brand-gradient text-white border-0 font-black rounded-2xl"
              >
                <Link to="/grammar">Zur Grammatik</Link>
              </Button>
            </div>
          )}

          {status === "error" && (
            <div className="text-center space-y-4">
              <div className="text-4xl mb-2">❌</div>
              <div>
                <h3 className="font-black text-lg mb-1">Fehler beim Laden</h3>
                <p className="text-sm text-muted-foreground mb-4">{error}</p>
              </div>
              <Button
                onClick={() => {
                  setStatus("ready");
                  setError(null);
                  setProgress(0);
                }}
                className="w-full gap-2"
              >
                Nochmal versuchen
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}