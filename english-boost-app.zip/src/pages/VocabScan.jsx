// ─── Vokabeln scannen – Main page orchestrator ───────────────────────────────
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Camera } from "lucide-react";
import ScanUploadStep from "@/components/vocab-scan/ScanUploadStep";
import ColumnClarifyStep from "@/components/vocab-scan/ColumnClarifyStep";
import ReviewEditStep from "@/components/vocab-scan/ReviewEditStep";
import ActionSelectStep from "@/components/vocab-scan/ActionSelectStep";

export const STEPS = {
  UPLOAD: "upload",
  CLARIFY: "clarify",
  REVIEW: "review",
  ACTION: "action",
};

export default function VocabScan() {
  const navigate = useNavigate();
  const [step, setStep] = useState(STEPS.UPLOAD);
  const [rawPairs, setRawPairs] = useState([]);   // [{ col1, col2 }] – raw from OCR
  const [pairs, setPairs] = useState([]);          // [{ en, de }] – confirmed
  const [savedSetId, setSavedSetId] = useState(null);
  const [setName, setSetName] = useState("");

  const handleOcrDone = ({ pairs: detected, needsClarify, col1Label, col2Label }) => {
    setRawPairs({ pairs: detected, col1Label, col2Label });
    if (needsClarify) {
      setStep(STEPS.CLARIFY);
    } else {
      setPairs(detected);
      setStep(STEPS.REVIEW);
    }
  };

  const handleClarifyDone = (swapped) => {
    const confirmed = rawPairs.pairs.map(p =>
      swapped ? { en: p.col2, de: p.col1 } : { en: p.col1, de: p.col2 }
    );
    setPairs(confirmed);
    setStep(STEPS.REVIEW);
  };

  const handleReviewDone = (editedPairs, name) => {
    setPairs(editedPairs);
    setSetName(name);
    setStep(STEPS.ACTION);
  };

  const handleBack = () => {
    if (step === STEPS.CLARIFY) setStep(STEPS.UPLOAD);
    else if (step === STEPS.REVIEW) setStep(rawPairs.col1Label ? STEPS.CLARIFY : STEPS.UPLOAD);
    else if (step === STEPS.ACTION) setStep(STEPS.REVIEW);
    else navigate(-1);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-card/95 backdrop-blur-sm border-b border-border/60 px-4 py-3 flex items-center gap-3">
        <button onClick={handleBack} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
          ← Zurück
        </button>
        <div className="flex items-center gap-2 flex-1 justify-center">
          <div className="w-7 h-7 rounded-xl bg-emerald-500 flex items-center justify-center">
            <Camera className="w-4 h-4 text-white" />
          </div>
          <span className="font-black text-sm">Vokabeln scannen</span>
        </div>
        {/* Step indicator */}
        <div className="flex gap-1">
          {[STEPS.UPLOAD, STEPS.REVIEW, STEPS.ACTION].map((s, i) => (
            <div key={s} className={`w-2 h-2 rounded-full transition-all ${
              step === s || (step === STEPS.CLARIFY && i === 0) ? "bg-primary scale-125" :
              [STEPS.REVIEW, STEPS.ACTION].indexOf(step) > i ? "bg-primary/40" : "bg-border"
            }`} />
          ))}
        </div>
      </div>

      {step === STEPS.UPLOAD && (
        <ScanUploadStep onDone={handleOcrDone} />
      )}
      {step === STEPS.CLARIFY && (
        <ColumnClarifyStep
          col1Label={rawPairs.col1Label}
          col2Label={rawPairs.col2Label}
          sample={rawPairs.pairs?.slice(0, 3)}
          onDone={handleClarifyDone}
        />
      )}
      {step === STEPS.REVIEW && (
        <ReviewEditStep
          initialPairs={pairs}
          onDone={handleReviewDone}
          onBack={handleBack}
        />
      )}
      {step === STEPS.ACTION && (
        <ActionSelectStep
          pairs={pairs}
          setName={setName}
          savedSetId={savedSetId}
          onSetSaved={setSavedSetId}
        />
      )}
    </div>
  );
}