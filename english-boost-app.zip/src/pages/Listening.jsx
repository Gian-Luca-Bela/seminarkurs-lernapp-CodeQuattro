import { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { useCompletedTasks } from "@/lib/useCompletedTasks";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Headphones, Play, Pause, RotateCcw, ChevronRight, Eye, EyeOff, Sparkles, Plus, Loader2, RefreshCw, Zap } from "lucide-react";
import GenerateListeningModal from "@/components/reading/GenerateListeningModal";
import { cn } from "@/lib/utils";
import { base44 } from "@/api/base44Client";
import { calculateExerciseXP } from "@/lib/xpSystem";
import { MASCOT_WRONG_MESSAGES, MASCOT_CELEBRATE_MESSAGES } from "@/lib/constants";
import XPToast from "@/components/XPToast";
import { useXP } from "@/lib/useXP";

const DIFFICULTY_STYLES = { easy: "bg-green-100 text-green-700", medium: "bg-yellow-100 text-yellow-700", hard: "bg-red-100 text-red-700" };
const DIFFICULTY_LABELS = { easy: "Einfach", medium: "Mittel", hard: "Schwer" };

const CHARS_PER_SEC = 14;

function parseSegments(text) {
  if (!text) return [{ speaker: null, text: '' }];
  const lines = text.split('\n').filter(l => l.trim());
  const dialogPattern = /^([A-Z][a-zA-Z]+(?:\s[A-Z][a-zA-Z]+)?):\s*(.+)/;
  const dialogLines = lines.filter(l => dialogPattern.test(l.trim()));
  if (dialogLines.length < 3) return [{ speaker: null, text }];
  return lines.flatMap(line => {
    const match = line.trim().match(dialogPattern);
    if (match) return [{ speaker: match[1], text: match[2] }];
    if (line.trim()) return [{ speaker: null, text: line.trim() }];
    return [];
  });
}

function getVoices(speakers) {
  const voices = window.speechSynthesis.getVoices();
  const enVoices = voices.filter(v => v.lang.startsWith('en'));
  if (!enVoices.length) return {};
  const female = enVoices.find(v => /female|woman|girl|zira|samantha|karen|moira|fiona/i.test(v.name)) || enVoices[0];
  const male = enVoices.find(v => /male|man|guy|david|daniel|alex|lee|james/i.test(v.name) && v !== female) || enVoices[enVoices.length - 1];
  const map = {};
  speakers.forEach((s, i) => { map[s] = i % 2 === 0 ? female : male; });
  return map;
}

function useTTS(text) {
  const [playing, setPlaying] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [rate, setRate] = useState(1.0);
  const timerRef = useRef(null);
  const startTimeRef = useRef(0);
  const elapsedAtStartRef = useRef(0);
  const segmentIndexRef = useRef(0);
  const rateRef = useRef(1.0);

  const segments = parseSegments(text || '');
  const totalChars = segments.reduce((s, seg) => s + seg.text.length, 0);
  const estimatedTotal = Math.ceil(totalChars / CHARS_PER_SEC);
  // char offset at start of each segment
  const segCharOffsets = segments.reduce((acc, seg, i) => {
    acc.push(i === 0 ? 0 : acc[i - 1] + segments[i - 1].text.length);
    return acc;
  }, []);

  const uniqueSpeakers = [...new Set(segments.map(s => s.speaker).filter(Boolean))];

  useEffect(() => { rateRef.current = rate; }, [rate]);
  useEffect(() => {
    return () => { window.speechSynthesis?.cancel(); clearInterval(timerRef.current); };
  }, []);
  useEffect(() => {
    window.speechSynthesis?.cancel();
    clearInterval(timerRef.current);
    setPlaying(false);
    setElapsed(0);
    segmentIndexRef.current = 0;
    elapsedAtStartRef.current = 0;
  }, [text]);

  const startFromSegment = (segIdx, elapsedSecs) => {
    if (!text || segIdx >= segments.length) return;
    window.speechSynthesis.cancel();
    clearInterval(timerRef.current);
    segmentIndexRef.current = segIdx;
    elapsedAtStartRef.current = elapsedSecs;
    setElapsed(elapsedSecs);
    const voiceMap = getVoices(uniqueSpeakers);

    const speakSegment = (idx) => {
      if (idx >= segments.length) { setPlaying(false); clearInterval(timerRef.current); setElapsed(estimatedTotal); return; }
      const seg = segments[idx];
      const utt = new SpeechSynthesisUtterance(seg.text);
      utt.lang = 'en-GB';
      utt.rate = rateRef.current;
      if (seg.speaker && voiceMap[seg.speaker]) utt.voice = voiceMap[seg.speaker];
      utt.onstart = () => {
        segmentIndexRef.current = idx;
        setPlaying(true);
        if (idx === segIdx) {
          startTimeRef.current = Date.now();
          clearInterval(timerRef.current);
          timerRef.current = setInterval(() => {
            const secs = elapsedAtStartRef.current + (Date.now() - startTimeRef.current) / 1000 * rateRef.current;
            setElapsed(Math.min(secs, estimatedTotal));
          }, 100);
        }
      };
      utt.onend = () => speakSegment(idx + 1);
      utt.onerror = (e) => { if (e.error !== 'interrupted') { setPlaying(false); clearInterval(timerRef.current); } };
      window.speechSynthesis.speak(utt);
    };
    speakSegment(segIdx);
  };

  const getCurrentElapsed = () => elapsedAtStartRef.current + (Date.now() - startTimeRef.current) / 1000 * rateRef.current;

  const toggle = () => {
    if (playing) {
      const cur = getCurrentElapsed();
      // find segment at current elapsed
      const charPos = Math.floor(cur * CHARS_PER_SEC);
      let segIdx = 0;
      for (let i = segCharOffsets.length - 1; i >= 0; i--) {
        if (charPos >= segCharOffsets[i]) { segIdx = i; break; }
      }
      window.speechSynthesis.cancel();
      clearInterval(timerRef.current);
      segmentIndexRef.current = segIdx;
      elapsedAtStartRef.current = cur;
      setElapsed(cur);
      setPlaying(false);
    } else {
      startFromSegment(segmentIndexRef.current, elapsedAtStartRef.current);
    }
  };

  const restart = () => { elapsedAtStartRef.current = 0; startFromSegment(0, 0); };
  const stop = () => {
    window.speechSynthesis?.cancel(); clearInterval(timerRef.current);
    segmentIndexRef.current = 0; elapsedAtStartRef.current = 0;
    setPlaying(false); setElapsed(0);
  };
  const seekTo = (pct) => {
    const targetElapsed = (pct / 100) * estimatedTotal;
    const charPos = Math.floor((pct / 100) * totalChars);
    let segIdx = 0;
    for (let i = segCharOffsets.length - 1; i >= 0; i--) {
      if (charPos >= segCharOffsets[i]) { segIdx = i; break; }
    }
    elapsedAtStartRef.current = targetElapsed;
    startFromSegment(segIdx, targetElapsed);
  };
  const changeRate = (r) => {
    rateRef.current = r; setRate(r);
    if (playing) { const cur = getCurrentElapsed(); elapsedAtStartRef.current = cur; startFromSegment(segmentIndexRef.current, cur); }
  };

  const progress = estimatedTotal > 0 ? Math.min(100, (elapsed / estimatedTotal) * 100) : 0;
  const fmt = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  return { loading: false, playing, progress, elapsed, totalSeconds: estimatedTotal, fmt, rate, toggle, restart, changeRate, stop, seekTo };
}

export default function Listening() {
  const [selectedText, setSelectedText] = useState(null);
  const [showTranscript, setShowTranscript] = useState(false);
  const [answers, setAnswers] = useState({});
  const [notes, setNotes] = useState("");
  const [phase, setPhase] = useState("listen");
  const [aiFeedback, setAiFeedback] = useState(null);
  const [checkingAnswers, setCheckingAnswers] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [triggeringDaily, setTriggeringDaily] = useState(false);
  const [showXP, setShowXP] = useState(false);
  const [lastXP, setLastXP] = useState(0);
  const [leoMessage, setLeoMessage] = useState("");
  const { data: user } = useQuery({ queryKey: ["current-user"], queryFn: () => base44.auth.me() });
  const { data: profiles } = useQuery({
    queryKey: ["user-profile", user?.email],
    queryFn: () => base44.entities.UserProfile.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });
  const profile = profiles?.[0];
  const { awardXP } = useXP(user, profile);

  const effectiveGrade = profiles?.[0]?.grade || "8";

  const location = useLocation();
  const repeatTaskId = location.state?.taskId;
  const [isRepeatMode, setIsRepeatMode] = useState(false);
  const autoSelectedRef = useRef(false);
  const { completedTasks, markComplete } = useCompletedTasks(user?.email);
  const completedIds = new Set(completedTasks.filter(c => c.task_type === 'listening').map(c => c.task_id));

  const tts = useTTS(selectedText?.body || "");

  const queryClient = useQueryClient();

  const { data: listeningTexts = [], isLoading: isLoadingTexts } = useQuery({
    queryKey: ["listening-texts", effectiveGrade],
    queryFn: () => base44.entities.ReadingText.filter({ grade: effectiveGrade, content_type: "listening" }),
  });

  const today = new Date().toISOString().split("T")[0];
  const oneWeekAgo = new Date(); oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  const oneWeekAgoStr = oneWeekAgo.toISOString().split("T")[0];
  const availableTexts = listeningTexts.filter(t => !completedIds.has(t.id));
  const todayTexts = availableTexts.filter(t => t.generated_date === today);
  const olderTexts = availableTexts.filter(t => t.generated_date !== today && t.generated_date >= oneWeekAgoStr);

  useEffect(() => {
    if (repeatTaskId && listeningTexts.length > 0 && !autoSelectedRef.current) {
      const text = listeningTexts.find(t => t.id === repeatTaskId);
      if (text) {
        autoSelectedRef.current = true;
        setIsRepeatMode(true);
        setSelectedText(text);
      }
    }
  }, [repeatTaskId, listeningTexts]);

  const handleGenerateListening = async (topicObj, difficulty) => {
    setGenerating(true);
    try {
      const res = await base44.functions.invoke("anthropicAI", {
        task: "generate_listening",
        payload: { topic: topicObj.topic, type: topicObj.type, grade: effectiveGrade, difficulty }
      });
      const secs = Math.ceil((res.data.script?.length || 0) / 14);
      const dur = `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')}`;
      await base44.entities.ReadingText.create({
        title: res.data.title,
        body: res.data.script,
        grade: effectiveGrade,
        difficulty,
        content_type: "listening",
        questions: res.data.questions,
        topic: topicObj.topic,
        duration: dur,
        generated_date: today,
      });
      queryClient.invalidateQueries({ queryKey: ["listening-texts", effectiveGrade] });
    } finally {
      setGenerating(false);
    }
  };

  const handleTriggerDaily = async () => {
    setTriggeringDaily(true);
    try {
      await base44.functions.invoke("dailyContentGenerator", {});
      queryClient.invalidateQueries({ queryKey: ["listening-texts", effectiveGrade] });
    } finally {
      setTriggeringDaily(false);
    }
  };

  const handleBack = () => {
    tts.stop();
    setSelectedText(null);
    setShowTranscript(false);
    setAnswers({});
    setPhase("listen");
    setAiFeedback(null);
    setIsRepeatMode(false);
  };

  if (selectedText) {
    return (
      <div className="p-4 md:p-6 max-w-3xl mx-auto animate-fade-in">
        <XPToast amount={lastXP} show={showXP} onDone={() => setShowXP(false)} />
        <Button variant="ghost" onClick={handleBack} className="mb-4">← Zurück</Button>

        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <h1 className="text-xl font-bold">{selectedText.title}</h1>
            <div className="flex gap-2 mt-1">
              <Badge variant="secondary">{selectedText.type}</Badge>
              <Badge variant="outline">Klasse {selectedText.grade}</Badge>
              <span className={cn("text-xs px-2 py-0.5 rounded-full font-medium", DIFFICULTY_STYLES[selectedText.difficulty])}>{DIFFICULTY_LABELS[selectedText.difficulty]}</span>
            </div>
          </div>
        </div>

        {/* Audio Player UI */}
        {phase === "listen" && (
          <Card className="mb-4 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <button onClick={tts.toggle} disabled={tts.loading}
                  className="w-14 h-14 rounded-full bg-primary flex items-center justify-center text-white hover:bg-primary/90 transition-colors shadow-lg disabled:opacity-60">
                  {tts.loading ? <Loader2 className="w-6 h-6 animate-spin" /> : tts.playing ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
                </button>
                <div className="flex-1">
                  <div
                    className="relative h-3 bg-white/60 rounded-full overflow-hidden cursor-pointer group"
                    onClick={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      const pct = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
                      tts.seekTo(pct);
                    }}
                  >
                    <div className="h-full bg-primary rounded-full" style={{ width: `${tts.progress}%`, transition: "width 0.016s linear" }} />
                    <div
                      className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white border-2 border-primary rounded-full shadow opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                      style={{ left: `calc(${tts.progress}% - 8px)` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>{tts.fmt(tts.elapsed)}</span>
                    <span>{tts.totalSeconds > 0 ? tts.fmt(tts.totalSeconds) : (selectedText.duration || "~2:00") + " Min."}</span>
                  </div>
                </div>
                <button onClick={tts.restart} className="text-muted-foreground hover:text-foreground transition-colors" title="Neustart">
                  <RotateCcw className="w-5 h-5" />
                </button>
              </div>
              <div className="flex gap-2">
                {[0.75, 1.0, 1.25].map(r => (
                  <Button key={r} size="sm" variant="outline"
                    className={cn("text-xs", tts.rate === r && "bg-primary text-white border-primary")}
                    onClick={() => tts.changeRate(r)}>
                    {r}×
                  </Button>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-3 text-center">
                🔊 Browser-Voiceover (Englisch) – Drücke Play zum Starten
              </p>
            </CardContent>
          </Card>
        )}

        {/* Notes area */}
        {phase === "listen" && (
          <Card className="mb-4">
            <CardContent className="p-4">
              <p className="text-sm font-medium mb-2">Notizen während des Hörens</p>
              <Textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Schreibe hier deine Notizen auf..." className="min-h-24 resize-none text-sm" />
            </CardContent>
          </Card>
        )}



        {phase === "listen" && (
          <Button onClick={() => setPhase("questions")} className="w-full">Zu den Aufgaben</Button>
        )}

        {phase === "questions" && (
          <div className="space-y-4">
            <h3 className="font-bold">Aufgaben zum Hörtext</h3>
            {/* Mini audio player during questions */}
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="py-3 px-4">
                <div className="flex items-center gap-3">
                  <button onClick={tts.toggle} disabled={tts.loading}
                    className="w-9 h-9 rounded-full bg-primary flex items-center justify-center text-white hover:bg-primary/90 transition-colors flex-shrink-0 disabled:opacity-60">
                    {tts.loading ? <Loader2 className="w-4 h-4 animate-spin" /> : tts.playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className="relative h-2 bg-white/60 rounded-full overflow-hidden cursor-pointer"
                      onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); tts.seekTo(Math.max(0, Math.min(100, ((e.clientX - r.left) / r.width) * 100))); }}>
                      <div className="h-full bg-primary rounded-full" style={{ width: `${tts.progress}%` }} />
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground mt-0.5">
                      <span>{tts.fmt(tts.elapsed)}</span>
                      <span>{tts.totalSeconds > 0 ? tts.fmt(tts.totalSeconds) : selectedText.duration}</span>
                    </div>
                  </div>
                  <button onClick={tts.restart} className="text-muted-foreground hover:text-foreground transition-colors flex-shrink-0">
                    <RotateCcw className="w-4 h-4" />
                  </button>
                  <div className="flex gap-1">
                    {[0.75, 1.0, 1.25].map(r => (
                      <button key={r} onClick={() => tts.changeRate(r)}
                        className={cn("text-xs px-1.5 py-0.5 rounded font-medium transition-colors", tts.rate === r ? "bg-primary text-white" : "bg-white/60 text-muted-foreground hover:text-foreground")}>
                        {r}×
                      </button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
            {notes.trim() && (
              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="p-4">
                  <p className="text-xs font-bold text-amber-700 mb-1">📝 Deine Notizen</p>
                  <p className="text-sm text-amber-900 whitespace-pre-line">{notes}</p>
                </CardContent>
              </Card>
            )}
            {selectedText.questions.map((q, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <p className="font-semibold text-sm mb-2">{i + 1}. {q.q}</p>
                  <Textarea value={answers[i] || ""} onChange={e => setAnswers(a => ({ ...a, [i]: e.target.value }))}
                    placeholder="Deine Antwort auf Englisch..." className="min-h-20 resize-none text-sm" />
                </CardContent>
              </Card>
            ))}
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setPhase("listen")}>← Nochmal hören</Button>
              <Button onClick={async () => {
                tts.stop();
                setCheckingAnswers(true);
                setPhase("review");
                try {
                  const answersArray = selectedText.questions.map((_, i) => answers[i] || "");
                  const res = await base44.functions.invoke("anthropicAI", {
                    task: "check_listening_answers",
                    payload: { questions: selectedText.questions, answers: answersArray, script: selectedText.body, grade: selectedText.grade || "8" }
                  });
                  const results = res.data.results;
                  setAiFeedback(results);
                  // Compute Leo message once (avoid glitch from re-renders)
                  const allOk = results.every(f => f.is_correct);
                  setLeoMessage(allOk
                    ? MASCOT_CELEBRATE_MESSAGES[Math.floor(Math.random() * MASCOT_CELEBRATE_MESSAGES.length)]
                    : MASCOT_WRONG_MESSAGES[Math.floor(Math.random() * MASCOT_WRONG_MESSAGES.length)]);
                  // Award XP here, not in render
                  if (!isRepeatMode) {
                    markComplete({ taskId: selectedText.id, taskType: 'listening', taskTitle: selectedText.title });
                    const totalXP = results.reduce((sum, f) => f.is_correct ? sum + calculateExerciseXP("exercise", selectedText.difficulty || "medium", true) : sum, 0);
                    if (totalXP > 0 && user) { awardXP(totalXP); setLastXP(totalXP); setShowXP(true); }
                  }
                } catch { /* fallback: show transcript */ }
                setCheckingAnswers(false);
              }} className="flex-1 gap-2">
                <Sparkles className="w-4 h-4" />Mit Leo auswerten
              </Button>
            </div>
          </div>
        )}

        {phase === "review" && (
          <div className="space-y-4">
            {(() => {
              const allCorrect = !checkingAnswers && aiFeedback && aiFeedback.every(f => f.is_correct);
              const bg = checkingAnswers ? "bg-amber-50 border-amber-200" : allCorrect ? "bg-green-50 border-green-200" : "bg-orange-50 border-orange-200";
              const textHead = checkingAnswers ? "text-amber-800" : allCorrect ? "text-green-700" : "text-orange-800";
              const displayMsg = checkingAnswers ? "Leo schaut sich deine Antworten gerade genau an... 🦉" : leoMessage;
              return (
                <div className={`p-4 rounded-xl border flex items-center gap-3 ${bg}`}>
                  <span className="text-2xl">{checkingAnswers ? "🦉" : allCorrect ? "🎉" : "🦉"}</span>
                  <div className="flex-1">
                    <p className={`font-bold text-sm ${textHead}`}>Leo sagt:</p>
                    <p className={`text-sm mt-0.5 ${textHead} opacity-80`}>{displayMsg}</p>
                  </div>
                  {checkingAnswers && <Loader2 className="w-5 h-5 animate-spin text-amber-600 ml-auto" />}
                </div>
              );
            })()}


            {/* AI Feedback per question */}
            {aiFeedback && selectedText.questions.map((q, i) => {
               const fb = aiFeedback.find(f => f.question_index === i);
               return (
                 <Card key={i} className={fb ? (fb.is_correct ? "border-green-300" : "border-orange-300") : ""}>
                   <CardContent className="p-4">
                     <p className="font-semibold text-sm mb-1">{i + 1}. {q.q}</p>
                     {answers[i] && <p className="text-xs text-muted-foreground mb-2">Deine Antwort: {answers[i]}</p>}
                     {fb && (
                       <div className={cn("p-3 rounded-lg text-sm", fb.is_correct ? "bg-green-50 border border-green-200" : "bg-orange-50 border border-orange-200")}>
                         <p className={cn("font-semibold mb-1", fb.is_correct ? "text-green-700" : "text-orange-700")}>
                           {fb.is_correct ? "✅" : "💡"} {fb.feedback_de}
                         </p>
                         <p className="text-xs text-muted-foreground">Musterlösung: {fb.model_answer}</p>
                       </div>
                     )}
                   </CardContent>
                 </Card>
               );
             })}

            {aiFeedback && lastXP > 0 && (
              <div className="flex items-center justify-center gap-1.5 text-sm font-semibold text-amber-600">
                <Zap className="w-4 h-4" />+{lastXP} XP
              </div>
            )}

            <Button variant="outline" onClick={() => setShowTranscript(!showTranscript)} className="w-full gap-2">
              {showTranscript ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {showTranscript ? "Transkript ausblenden" : "Transkript anzeigen"}
            </Button>
            {showTranscript && (
              <Card className="border-dashed">
                <CardContent className="p-4">
                  <h4 className="font-bold mb-3">Volles Transkript</h4>
                  <p className="text-sm leading-relaxed whitespace-pre-line">{selectedText.body}</p>
                </CardContent>
              </Card>
            )}
            <Button variant="outline" onClick={handleBack} className="w-full">Zurück zur Übersicht</Button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2"><Headphones className="w-6 h-6 text-primary" />Hören</h1>
        <p className="text-muted-foreground text-sm mt-0.5">Hörverständnisse üben</p>
      </div>
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-4 text-sm text-blue-700">
        🔊 <strong>Audio aktiviert:</strong> Texte werden per Browser-Voiceover auf Englisch vorgelesen. Lautstärke & Geschwindigkeit einstellbar.
      </div>

      <div className="mb-4 flex items-center justify-between gap-2">
        <span className="text-xs font-semibold text-muted-foreground px-3 py-1.5 bg-secondary rounded-xl">
          Klasse {effectiveGrade} · Täglich 3 neue Hörtexte
        </span>
        <div className="flex gap-2">
          {todayTexts.length === 0 && (
            <Button size="sm" variant="outline" onClick={handleTriggerDaily} disabled={triggeringDaily} className="gap-1.5 text-xs">
              {triggeringDaily ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
              Heute generieren
            </Button>
          )}
          <Button size="sm" onClick={() => setShowGenerateModal(true)} className="gap-1.5 text-xs">
            <Plus className="w-3 h-3" /> Eigenes Hörverständnis
          </Button>
        </div>
      </div>

      {generating && (
        <div className="mb-4 p-3 rounded-xl bg-primary/5 border border-primary/20 flex items-center gap-2 text-sm text-primary">
          <Loader2 className="w-4 h-4 animate-spin" /> Hörtext wird generiert...
        </div>
      )}

      <GenerateListeningModal
        open={showGenerateModal}
        onClose={() => setShowGenerateModal(false)}
        grade={effectiveGrade}
        onGenerate={handleGenerateListening}
      />

      {isLoadingTexts ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Array(3).fill(0).map((_, i) => <div key={i} className="h-32 bg-secondary rounded-2xl animate-pulse" />)}
        </div>
      ) : listeningTexts.length === 0 ? (
        <div className="flex flex-col items-center py-16 text-center">
          <div className="w-16 h-16 rounded-3xl bg-blue-50 flex items-center justify-center mb-4 border border-blue-100">
            <Headphones className="w-8 h-8 text-blue-400" />
          </div>
          <p className="font-black text-sm mb-1">Noch keine Hörtexte</p>
          <p className="text-xs text-muted-foreground max-w-xs">Klicke auf „Heute generieren" um die heutigen 3 Hörtexte zu erstellen.</p>
        </div>
      ) : (
        <>
          {todayTexts.length > 0 && (
            <div className="mb-6">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Heute</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {todayTexts.map(s => <ListeningCard key={s.id} sample={s} onClick={() => { setIsRepeatMode(false); setSelectedText(s); }} />)}
              </div>
            </div>
          )}
          {olderTexts.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Frühere Texte</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {olderTexts.map(s => <ListeningCard key={s.id} sample={s} onClick={() => { setIsRepeatMode(false); setSelectedText(s); }} />)}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function ListeningCard({ sample, onClick }) {
  const totalSecs = Math.ceil((sample.body?.length || 0) / 14);
  const dMins = Math.floor(totalSecs / 60);
  const dSecs = totalSecs % 60;
  const durationDisplay = totalSecs > 0 ? `${dMins}:${String(dSecs).padStart(2, '0')}` : (sample.duration || "~2:00");
  return (
    <Card className="card-hover cursor-pointer border-border/50" onClick={onClick}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-bold">{sample.title}</h3>
          {sample.text_type && <Badge variant="secondary" className="text-xs whitespace-nowrap">{sample.text_type}</Badge>}
        </div>
        <div className="flex gap-1.5 mb-3">
          <Badge variant="outline" className="text-xs">Klasse {sample.grade}</Badge>
          {sample.difficulty && <span className={cn("text-xs px-2 py-0.5 rounded-full", DIFFICULTY_STYLES[sample.difficulty])}>{DIFFICULTY_LABELS[sample.difficulty]}</span>}
        </div>
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span className="flex items-center gap-1"><Headphones className="w-3.5 h-3.5" />{durationDisplay} Min</span>
          <span>{sample.questions?.length || 0} Aufgaben</span>
          <ChevronRight className="w-4 h-4" />
        </div>
      </CardContent>
    </Card>
  );
}