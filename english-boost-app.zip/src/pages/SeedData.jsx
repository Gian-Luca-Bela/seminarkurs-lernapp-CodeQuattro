// ─── Seed Data Admin Page ─────────────────────────────────────────────────────
// Run once to populate the database with demo content
import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Database, Check, Loader2, AlertTriangle, Zap, BookOpen } from "lucide-react";
import { Link } from "react-router-dom";
import {
  VOCAB_GRADE_8, VOCAB_GRADE_9, GRAMMAR_LESSONS_SEED,
  EXERCISES_SEED, READING_TEXTS_SEED, WRITING_PROMPTS_SEED
} from "@/lib/seedContent";

const SEED_TASKS = [
  { id: "vocab_8", label: "Vokabeln Klasse 8", count: VOCAB_GRADE_8.length, data: VOCAB_GRADE_8, entity: "VocabularyItem" },
  { id: "vocab_9", label: "Vokabeln Klasse 9", count: VOCAB_GRADE_9.length, data: VOCAB_GRADE_9, entity: "VocabularyItem" },
  { id: "grammar", label: "Grammatik-Lektionen", count: GRAMMAR_LESSONS_SEED.length, data: GRAMMAR_LESSONS_SEED, entity: "GrammarLesson" },
  { id: "exercises", label: "Übungen (Grammar + Vocab)", count: EXERCISES_SEED.length, data: EXERCISES_SEED, entity: "Exercise" },
  { id: "readings", label: "Lesetexte", count: READING_TEXTS_SEED.length, data: READING_TEXTS_SEED, entity: "ReadingText" },
  { id: "writing", label: "Schreibaufgaben", count: WRITING_PROMPTS_SEED.length, data: WRITING_PROMPTS_SEED, entity: "WritingPrompt" },
];

export default function SeedData() {
  const [status, setStatus] = useState({});
  const [running, setRunning] = useState(false);

  const runTask = async (task) => {
    setStatus(s => ({ ...s, [task.id]: "running" }));
    try {
      await base44.entities[task.entity].bulkCreate(task.data);
      setStatus(s => ({ ...s, [task.id]: "done" }));
    } catch (e) {
      setStatus(s => ({ ...s, [task.id]: "error" }));
    }
  };

  const runAll = async () => {
    setRunning(true);
    for (const task of SEED_TASKS) {
      await runTask(task);
    }
    setRunning(false);
  };

  const allDone = SEED_TASKS.every(t => status[t.id] === "done");

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto animate-fade-up">
      <div className="mb-6">
        <h1 className="text-2xl font-black flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center">
            <Database className="w-5 h-5 text-white" />
          </div>
          Demo-Daten laden
        </h1>
        <p className="text-muted-foreground text-sm mt-1">Lädt Beispielinhalte in die Datenbank. Nur einmal ausführen!</p>
      </div>

      {allDone && (
        <div className="mb-5 p-4 bg-green-50 border border-green-200 rounded-2xl">
          <div className="flex items-center gap-2">
            <Check className="w-5 h-5 text-green-600" />
            <p className="font-black text-green-800">Alle Daten erfolgreich geladen! 🎉</p>
          </div>
          <p className="text-sm text-green-700 mt-1">Du kannst jetzt die App mit echten Inhalten nutzen.</p>
        </div>
      )}

      <div className="space-y-3 mb-6">
        {SEED_TASKS.map(task => {
          const s = status[task.id];
          return (
            <div key={task.id} className="flex items-center gap-4 p-4 bg-card border border-border rounded-2xl">
              <div className={cn("w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0",
                s === "done" ? "bg-green-100" : s === "error" ? "bg-red-100" : s === "running" ? "bg-primary/10" : "bg-secondary"
              )}>
                {s === "done" ? <Check className="w-4 h-4 text-green-600" /> :
                  s === "error" ? <AlertTriangle className="w-4 h-4 text-red-500" /> :
                  s === "running" ? <Loader2 className="w-4 h-4 text-primary animate-spin" /> :
                  <Database className="w-4 h-4 text-muted-foreground" />}
              </div>
              <div className="flex-1">
                <p className="font-bold text-sm">{task.label}</p>
                <p className="text-xs text-muted-foreground">{task.count} Einträge · {task.entity}</p>
              </div>
              <div className="flex items-center gap-2">
                {s === "done" && <Badge className="bg-green-100 text-green-700 border-0 text-xs">✓ Geladen</Badge>}
                {s === "error" && <Badge className="bg-red-100 text-red-700 border-0 text-xs">Fehler</Badge>}
                {!s && (
                  <Button size="sm" variant="outline" onClick={() => runTask(task)} className="text-xs rounded-xl">
                    Laden
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <Button onClick={runAll} disabled={running || allDone} size="lg" className="w-full brand-gradient text-white border-0 font-black rounded-2xl gap-2">
        {running ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5" />}
        {running ? "Wird geladen..." : allDone ? "✓ Alle Daten geladen" : "Alle Daten auf einmal laden"}
      </Button>

      <p className="text-xs text-muted-foreground text-center mt-3">
        ⚠️ Daten werden doppelt hinzugefügt, wenn du diese Seite mehrfach ausführst.
      </p>

      <div className="mt-8 pt-6 border-t border-border">
        <div className="flex items-center gap-2 mb-4">
          <BookOpen className="w-5 h-5 text-primary" />
          <h2 className="font-black text-sm">Erweiterte Grammatik-Inhalte</h2>
        </div>
        <p className="text-xs text-muted-foreground mb-3">
          Umfassender Grammatik-Lehrplan mit 26 Lektionen und 50+ Übungen in 3 Schwierigkeitsstufen:
        </p>
        <Button
          asChild
          variant="outline"
          className="w-full border-primary/30 text-primary hover:bg-primary/5 rounded-2xl font-bold gap-2"
        >
          <Link to="/seed-grammar">
            <Zap className="w-4 h-4" />
            Grammatik-Lehrplan laden
          </Link>
        </Button>
      </div>
    </div>
  );
}