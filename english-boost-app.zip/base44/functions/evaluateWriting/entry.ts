import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const question = body.question;
    const userAnswer = body.userAnswer || body.student_answer;
    const correctAnswer = body.correctAnswer || body.model_solution;
    const skill = body.skill || "writing";

    if (!userAnswer || userAnswer.trim() === "") {
      return Response.json({ error: 'Student answer is required' }, { status: 400 });
    }

    const getCriteria = (skillArea) => {
      if (skillArea === "reading" || skillArea === "listening") {
        return `- Verständnis: Wurde die Kernfrage beantwortet?
- Korrektheit: Stimmt die Antwort mit der Musterlösung überein?
- Vollständigkeit: Fehlende Informationen?`;
      }
      return `- Sinngemäße Vollständigkeit: Werden Kernpunkte der Aufgabe erfüllt?
- Grammatik & Syntax: Sind Fehler vorhanden?
- Vokabeln & Ausdrücke: Sind sie angemessen gewählt?
- Kohäsion: Ist der Text logisch aufgebaut?`;
    };

    const prompt = `Du bist ein erfahrener Englischlehrer.

AUFGABE: ${question}

SCHÜLER-ANTWORT:
${userAnswer}

MUSTERLÖSUNG / BEISPIEL:
${correctAnswer}

BEWERTUNGSKRITERIEN:
${getCriteria(skill)}

Bewerte die Antwort und gib Feedback auf Deutsch:

ANTWORT IM JSON FORMAT:
{
  "result": "correct" | "mostly_correct" | "meaning_ok" | "incomplete",
  "feedback_de": "Klare Kurzbewertung auf Deutsch (1–2 Sätze)",
  "improvements": "Ein konkreter Verbesserungstipp (optional)"
}

- "correct": Erfüllt die Aufgabe vollständig und richtig
- "mostly_correct": Erfüllt die Aufgabe, aber kleine Fehler oder Auslassungen
- "meaning_ok": Grundidee klar, aber Fehler vorhanden
- "incomplete": Zu kurz, zu vage oder unvollständig`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          result: { type: 'string', enum: ['correct', 'mostly_correct', 'meaning_ok', 'incomplete'] },
          feedback_de: { type: 'string' },
          improvements: { type: 'string' }
        },
        required: ['result', 'feedback_de']
      }
    });

    return Response.json(result);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});