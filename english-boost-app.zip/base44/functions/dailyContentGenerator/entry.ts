import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Anthropic from 'npm:@anthropic-ai/sdk@0.27.0';

const anthropic = new Anthropic({ apiKey: Deno.env.get("ANTHROPIC_API_KEY") });

const CLASS8_READING_TOPICS = [
  { topic: "Kids in America – teen life and school", textType: "article" },
  { topic: "New York City – the city that never sleeps", textType: "narrative" },
  { topic: "Thanksgiving – an American holiday", textType: "factual" },
  { topic: "Advertisements and consumer culture", textType: "article" },
  { topic: "School rules – dos and don'ts", textType: "dialogue" },
  { topic: "The Pacific Northwest – nature and people", textType: "report" },
  { topic: "Internet hoaxes and fake news", textType: "article" },
  { topic: "Native Americans – history and present", textType: "factual" },
  { topic: "A nation invents itself – American inventions", textType: "factual" },
  { topic: "Travel to the USA – blog and guide", textType: "blog_post" },
];

const CLASS9_READING_TOPICS = [
  { topic: "English as a global language – different varieties worldwide", textType: "article" },
  { topic: "G'day Australia – life, culture and landscape Down Under", textType: "factual" },
  { topic: "South Africa – rainbow nation, languages and diversity", textType: "report" },
  { topic: "English in India – history, use and importance today", textType: "article" },
  { topic: "The language of tolerance and respect – diversity in society", textType: "article" },
  { topic: "The good life? – food culture, health and lifestyle choices", textType: "blog_post" },
  { topic: "California dreaming – Hollywood, nature and the American Dream", textType: "narrative" },
  { topic: "Cause and effect – environmental and social issues in California", textType: "report" },
  { topic: "Letters to the editor – argumentative writing and having a voice", textType: "letter" },
];

const CLASS8_LISTENING_TOPICS = [
  { topic: "Kids in America – teen life", type: "interview", difficulty: "easy" },
  { topic: "Thanksgiving – an American holiday", type: "report", difficulty: "medium" },
  { topic: "Life in New York City", type: "report", difficulty: "medium" },
  { topic: "A day at an American school", type: "dialogue", difficulty: "easy" },
  { topic: "Advertising and consumer culture", type: "report", difficulty: "medium" },
  { topic: "The Pacific Northwest – nature and Native Americans", type: "report", difficulty: "hard" },
  { topic: "Internet hoaxes and fake news", type: "report", difficulty: "medium" },
  { topic: "Famous American inventions", type: "interview", difficulty: "medium" },
];

const CLASS9_LISTENING_TOPICS = [
  { topic: "English as a global language – accents and varieties", type: "interview", difficulty: "medium" },
  { topic: "G'day Australia – life and culture Down Under", type: "report", difficulty: "easy" },
  { topic: "South Africa – rainbow nation and its languages", type: "report", difficulty: "medium" },
  { topic: "English in India – a global success story", type: "interview", difficulty: "medium" },
  { topic: "The language of tolerance and respect", type: "dialogue", difficulty: "medium" },
  { topic: "The good life – food choices and healthy living", type: "report", difficulty: "easy" },
  { topic: "California dreaming – sun, films and the American Dream", type: "report", difficulty: "medium" },
  { topic: "Climate and environment – cause and effect in California", type: "report", difficulty: "hard" },
  { topic: "Having a voice – young people and political participation", type: "interview", difficulty: "hard" },
];

const CLASS8_WRITING_TOPICS = [
  { genre: "blog_post", topic: "A day in the life of an American teenager" },
  { genre: "informal_email", topic: "Write to your American pen pal about your school" },
  { genre: "summary", topic: "Summarise a short text about New York City" },
  { genre: "comment", topic: "Should schools ban smartphones? Give your opinion." },
  { genre: "formal_email", topic: "Write a formal email to an American school requesting information" },
  { genre: "creative", topic: "Write a short story set in New York" },
  { genre: "letter", topic: "Write a letter to your exchange partner about Thanksgiving" },
  { genre: "report", topic: "Report about a trip to the Pacific Northwest" },
  { genre: "blog_post", topic: "Your favourite American invention and why" },
];

const CLASS9_WRITING_TOPICS = [
  { genre: "comment", topic: "Should English be the only global language?" },
  { genre: "comment", topic: "Is social media doing more harm than good for teenagers?" },
  { genre: "discussion", topic: "Advantages and disadvantages of social media for teenagers" },
  { genre: "formal_email", topic: "Apply for a summer work placement in Australia" },
  { genre: "formal_email", topic: "Write a formal complaint letter to a company about a product" },
  { genre: "article", topic: "Write a magazine article about life in South Africa" },
  { genre: "letter", topic: "Write a letter to the editor about environmental issues in California" },
  { genre: "blog_post", topic: "The good life – what does it mean to you?" },
  { genre: "report", topic: "Report on English as a global language for your school magazine" },
  { genre: "characterisation", topic: "Describe a character who fights for tolerance and respect" },
];

const CLASS8_MEDIATION_TOPICS = [
  { topic: "Klimawandel in deutschen Städten", source_lang: "de", target_lang: "en", difficulty: "medium" },
  { topic: "Schulregeln an deutschen Schulen", source_lang: "de", target_lang: "en", difficulty: "easy" },
  { topic: "American school system overview", source_lang: "en", target_lang: "de", difficulty: "medium" },
  { topic: "Jugendliche und Social Media", source_lang: "de", target_lang: "en", difficulty: "easy" },
  { topic: "Thanksgiving traditions in the US", source_lang: "en", target_lang: "de", difficulty: "medium" },
];

const CLASS9_MEDIATION_TOPICS = [
  { topic: "Englisch als Weltsprache – Vor- und Nachteile", source_lang: "de", target_lang: "en", difficulty: "medium" },
  { topic: "Australian wildlife conservation efforts", source_lang: "en", target_lang: "de", difficulty: "medium" },
  { topic: "Toleranz und Vielfalt in der Gesellschaft", source_lang: "de", target_lang: "en", difficulty: "hard" },
  { topic: "California's water crisis explained", source_lang: "en", target_lang: "de", difficulty: "hard" },
  { topic: "Esskultur und Lebensstil in Deutschland", source_lang: "de", target_lang: "en", difficulty: "easy" },
];

const CLASS8_SPEAKING_TOPICS = [
  { speaking_type: "Meinung äußern", topic: "social media and teenagers", time_seconds: 60 },
  { speaking_type: "Bildbeschreibung", topic: "busy street scene in a US city", time_seconds: 90 },
  { speaking_type: "Rollenspiel", topic: "at a tourist information office in London", time_seconds: 120 },
  { speaking_type: "Diskussion", topic: "Should schools ban smartphones?", time_seconds: 90 },
  { speaking_type: "Präsentation", topic: "a place in the USA you would like to visit", time_seconds: 120 },
  { speaking_type: "Bildbeschreibung", topic: "group of teenagers in a park", time_seconds: 90 },
  { speaking_type: "Meinung äußern", topic: "Is homework necessary or not?", time_seconds: 60 },
  { speaking_type: "Rollenspiel", topic: "ordering food at an American diner", time_seconds: 90 },
];

const CLASS9_SPEAKING_TOPICS = [
  { speaking_type: "Diskussion", topic: "English as a global language – pros and cons", time_seconds: 90 },
  { speaking_type: "Präsentation", topic: "a current global problem (climate, inequality, fake news)", time_seconds: 120 },
  { speaking_type: "Bildbeschreibung", topic: "a city skyline at night – urban life", time_seconds: 90 },
  { speaking_type: "Meinung äußern", topic: "Should the voting age be lowered to 16?", time_seconds: 90 },
  { speaking_type: "Diskussion", topic: "Advantages and disadvantages of social media for society", time_seconds: 90 },
  { speaking_type: "Präsentation", topic: "life and culture in Australia or South Africa", time_seconds: 120 },
  { speaking_type: "Bildbeschreibung", topic: "people from different cultures meeting", time_seconds: 90 },
  { speaking_type: "Meinung äußern", topic: "Is it more important to be happy or successful?", time_seconds: 90 },
];

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function pickByDifficulty(arr, difficulty) {
  const filtered = arr.filter(t => t.difficulty === difficulty);
  return filtered.length > 0 ? pickRandom(filtered) : pickRandom(arr);
}

const DIFFICULTY_GUIDE = {
  reading: {
    easy: 'SCHWIERIGKEITSGRAD LEICHT: Kurze, einfache Sätze (Hauptsätze, kaum Nebensätze). Nur Present Simple, Past Simple und will-future. Häufige Alltagsvokabeln (Schuljahr 7-8). TEXTLÄNGE: 170-210 Wörter.',
    medium: 'SCHWIERIGKEITSGRAD MITTEL: Gemischte Satzstrukturen (Relativ- und Nebensätze). Present Perfect, Conditional I, Passiv möglich. B1-Vokabular (Schuljahr 8-9), einige weniger gebräuchliche Wörter. TEXTLÄNGE: 220-265 Wörter.',
    hard: 'SCHWIERIGKEITSGRAD SCHWER: Komplexe Sätze mit Relativ-, Kausal- und Konditionalsätzen. Alle Zeiten inkl. Past Perfect und Conditional II. B1-B2 Vokabular, einige Redewendungen. TEXTLÄNGE: 270-310 Wörter.',
  },
  listening: {
    easy: 'SCHWIERIGKEITSGRAD LEICHT: Einfache Satzstruktur (Hauptsätze). Langsames Sprechtempo impliziert. Present/Past Simple, direkte Sprache. Alltagsvokabular (Schuljahr 7-8). TEXTLÄNGE: 140-180 Wörter.',
    medium: 'SCHWIERIGKEITSGRAD MITTEL: Normales Sprechtempo. Einige komplexere Sätze und Nebensätze. Present Perfect, Passiv möglich. B1-Vokabular. TEXTLÄNGE: 190-230 Wörter.',
    hard: 'SCHWIERIGKEITSGRAD SCHWER: Höheres Sprechtempo impliziert, natürliche Umgangssprache, Kontraktionen. Komplexe Grammatik. B1-B2 Vokabular, einige Redewendungen. TEXTLÄNGE: 240-275 Wörter.',
  },
  writing: {
    easy: 'SCHWIERIGKEITSGRAD LEICHT: Einfache, einteilige Aufgabe. Konkretes persönliches Thema. WORTANZAHL: 80-120. Detaillierte 4-Schritte-Strukturhilfe. Einfache useful phrases (present/past tense, A2-B1).',
    medium: 'SCHWIERIGKEITSGRAD MITTEL: Zweiteilige Aufgabe (z.B. beschreiben + begründen). Konkretes bis leicht abstraktes Thema. WORTANZAHL: 120-160. Klare 3-Schritte-Struktur. Mittelschwere useful phrases (B1, Meinung äußern, Conditional I).',
    hard: 'SCHWIERIGKEITSGRAD SCHWER: Mehrschichtige Aufgabe mit mehreren Teilanforderungen. Abstraktes oder argumentatives Thema. WORTANZAHL: 160-200. Formelles Register, Passiv, Conditional II. Anspruchsvolle useful phrases (B1-B2).',
  },
  mediation: {
    easy: 'SCHWIERIGKEITSGRAD LEICHT: Kurzer Ausgangstext (90-120 Wörter). Bekanntes Alltagsthema. Einfache Sätze, direkte Informationsübertragung, wenig Paraphrase nötig.',
    medium: 'SCHWIERIGKEITSGRAD MITTEL: Ausgangstext 125-155 Wörter. Teilweise komplexere Inhalte. Paraphrase und Anpassung an Zielgruppe erforderlich, einige idiomatische Ausdrücke.',
    hard: 'SCHWIERIGKEITSGRAD SCHWER: Ausgangstext 160-190 Wörter. Anspruchsvollere Inhalte mit komplexer Satzstruktur. Deutliche Paraphrase und stilistische Anpassung zwingend notwendig.',
  },
  speaking: {
    easy: 'SCHWIERIGKEITSGRAD LEICHT: Konkretes persönliches Thema (eigene Erfahrungen, Vorlieben). Einfache Phrasen ausreichend (present/past simple). Setze time_seconds auf 60. Einfache konkrete Tipps.',
    medium: 'SCHWIERIGKEITSGRAD MITTEL: Leicht abstraktes Thema. Meinung mit 2-3 Gründen begründen. Setze time_seconds auf 90. Tipps zu Argumentation und Verknüpfungswörtern.',
    hard: 'SCHWIERIGKEITSGRAD SCHWER: Abstraktes oder kontroverses Thema. Pro/Contra-Argumentation mit Begründungen und Gegenargumenten. Setze time_seconds auf 120. Anspruchsvolle Phrasen für Debatte.',
  },
};

async function generateReadingText(topic, textType, grade, difficulty) {
  const msg = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 2500,
    messages: [{
      role: "user",
      content: `Erstelle einen Lesetext (${textType}) für Klasse ${grade} Gymnasium Englisch zum Thema "${topic}".

${DIFFICULTY_GUIDE.reading[difficulty]}

Anforderungen:
- Authentischer, interessanter Text (Textlänge exakt gemäß Schwierigkeitsgrad oben einhalten)
- 4-5 Verständnisfragen gemischt (multiple_choice, detail, true_false, inference)
- Für multiple_choice: 4 Optionen, correct ist der Index (0-3)
- Für detail/inference: correct ist die Musterantwort als String
- Für true_false: correct ist true oder false

Antworte NUR mit einem JSON-Objekt:
{
  "title": "<Titel>",
  "body": "<Fließtext, Absätze mit \\n\\n getrennt>",
  "text_type": "${textType}",
  "topic": "${topic}",
  "grade": "${grade}",
  "difficulty": "${difficulty}",
  "word_count": <Anzahl>,
  "vocabulary_focus": ["<Wort1>", "<Wort2>", "<Wort3>", "<Wort4>"],
  "questions": [
    { "type": "multiple_choice", "question": "<Frage>", "options": ["A","B","C","D"], "correct": 0 },
    { "type": "detail", "question": "<Frage>", "correct": "<Musterantwort>" },
    { "type": "true_false", "question": "<Aussage>", "correct": true },
    { "type": "inference", "question": "<Frage>", "correct": "<Musterantwort>" }
  ]
}`
    }]
  });
  const raw = msg.content[0].text.trim();
  return JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1));
}

async function generateListeningText(topic, type, grade, difficulty) {
  const msg = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 2000,
    messages: [{
      role: "user",
      content: `Erstelle einen ${type} (Hörtext) für Klasse ${grade} Gymnasium Englisch zum Thema "${topic}".

${DIFFICULTY_GUIDE.listening[difficulty]}

Anforderungen:
- Natürliches, gesprochenes Englisch (British oder American)
- Länge exakt gemäß Schwierigkeitsgrad oben einhalten
- 4 Verständnisfragen (detail, inference, main_idea, open Typen)

Antworte NUR mit einem JSON-Objekt:
{
  "title": "<Titel>",
  "script": "<der vollständige Text, Absätze mit \\n\\n getrennt>",
  "questions": [
    { "q": "<Frage auf Englisch>", "type": "detail" },
    { "q": "<Frage auf Englisch>", "type": "detail" },
    { "q": "<Frage auf Englisch>", "type": "main_idea" },
    { "q": "<Frage auf Englisch>", "type": "open" }
  ],
  "duration": "<z.B. 2:30>"
}`
    }]
  });
  const raw = msg.content[0].text.trim();
  return JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1));
}

async function generateWritingPrompt(genre, topic, grade, difficulty) {
  const isSummary = genre === 'summary';
  const contextDescription = isSummary
    ? '"<vollstaendiger Lesetext auf Englisch, ca. 200 Woerter, den der Schueler zusammenfassen soll>"'
    : '"<optionaler Kontext/Situation, 1-2 Saetze>"';
  const summaryHint = isSummary
    ? '\nWICHTIG: Da dies eine Summary-Aufgabe ist, muss das Feld "context" einen vollstaendigen, zusammenhaengenden Lesetext auf Englisch enthalten (ca. 180-250 Woerter). Kein Kurzsatz!'
    : '';
  const msg = await anthropic.messages.create({
    model: 'claude-opus-4-5',
    max_tokens: 2000,
    messages: [{
      role: 'user',
      content: `Erstelle eine Schreibaufgabe (${genre}) fuer Klasse ${grade} Gymnasium Englisch zum Thema "${topic}".\n\n${DIFFICULTY_GUIDE.writing[difficulty]}${summaryHint}\n\nAntworte NUR mit einem JSON-Objekt:\n{\n  "title": "<kurzer Titel>",\n  "genre": "${genre}",\n  "grade": "${grade}",\n  "difficulty": "${difficulty}",\n  "prompt_text": "<die eigentliche Schreibaufgabe auf Englisch, 2-3 Saetze>",\n  "context": ${contextDescription},\n  "min_words": <Zahl>,\n  "max_words": <Zahl>,\n  "structure_guide": ["<Schritt 1>", "<Schritt 2>", "<Schritt 3>"],\n  "useful_phrases": ["<Phrase 1>", "<Phrase 2>", "<Phrase 3>", "<Phrase 4>"],\n  "dos": ["<Tipp 1>", "<Tipp 2>", "<Tipp 3>"],\n  "donts": ["<Fehler 1>", "<Fehler 2>"],\n  "exam_relevant": true\n}`
    }]
  });
  const raw = msg.content[0].text.trim();
  return JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1));
}

async function generateMediationTask(topic, sourceLang, targetLang, grade, difficulty) {
  const msg = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 2000,
    messages: [{
      role: "user",
      content: `Erstelle eine Mediationsaufgabe für Klasse ${grade} Gymnasium Englisch zum Thema "${topic}".
${DIFFICULTY_GUIDE.mediation[difficulty]}

Der Ausgangstext soll die oben angegebene Länge haben. Realistisch und authentisch.

Antworte NUR mit einem JSON-Objekt:
{
  "title": "<kurzer Titel>",
  "grade": "${grade}",
  "difficulty": "${difficulty}",
  "source_lang": "${sourceLang}",
  "target_lang": "${targetLang}",
  "context": "<Situation: Warum muss man mediieren? 1-2 Sätze auf Deutsch>",
  "source_text": "<der Ausgangstext, Absätze mit \\n\\n getrennt>",
  "task": "<genaue Aufgabenstellung auf Englisch>",
  "target_audience": "<Zielgruppe z.B. 'your English exchange partner'>",
  "useful_phrases": ["<Phrase 1>", "<Phrase 2>", "<Phrase 3>", "<Phrase 4>"],
  "key_points": ["<Kernpunkt 1>", "<Kernpunkt 2>", "<Kernpunkt 3>"]
}`
    }]
  });
  const raw = msg.content[0].text.trim();
  return JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1));
}

async function generateSpeakingPrompt(speaking_type, topic, grade, difficulty) {
  const msg = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 1500,
    messages: [{
      role: "user",
      content: `Erstelle eine Sprechaufgabe (${speaking_type}) fuer Klasse ${grade} Gymnasium Englisch zum Thema "${topic}".

${DIFFICULTY_GUIDE.speaking[difficulty]}

Antworte NUR mit einem JSON-Objekt:
{
  "title": "<kurzer Titel auf Deutsch>",
  "speaking_type": "${speaking_type}",
  "grade": "${grade}",
  "difficulty": "${difficulty}",
  "prompt_text": "<die Aufgabenstellung auf Englisch, 2-3 Saetze>",
  "tips": ["<Tipp 1 auf Englisch>", "<Tipp 2>", "<Tipp 3>", "<Tipp 4>"],
  "useful_phrases": ["<Phrase 1>", "<Phrase 2>", "<Phrase 3>", "<Phrase 4>"],
  "time_seconds": <Zahl zwischen 60 und 120>
}`
    }]
  });
  const raw = msg.content[0].text.trim();
  return JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1));
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const today = new Date().toISOString().split("T")[0];

    // Single generation mode (custom prompt request from frontend)
    if (body.single) {
      const { type, genre, topic, grade, difficulty, source_lang, target_lang } = body.single;
      if (type === "writing") {
        const data = await generateWritingPrompt(genre, topic, grade, difficulty);
        await base44.asServiceRole.entities.WritingPrompt.create({
          ...data, grade, difficulty, generated_date: today,
        });
        return Response.json({ success: true });
      }
      if (type === "mediation") {
        const data = await generateMediationTask(topic, source_lang, target_lang, grade, difficulty);
        await base44.asServiceRole.entities.MediationTask.create({
          ...data, grade, difficulty, generated_date: today, topic,
        });
        return Response.json({ success: true });
      }
    }

    const difficulties = ["easy", "medium", "hard"];
    const grades = ["8", "9"];

    // Check existing content for today
    const [existingReading, existingWriting, existingMediation, existingSpeaking, allListening] = await Promise.all([
      base44.asServiceRole.entities.ReadingText.filter({ generated_date: today }),
      base44.asServiceRole.entities.WritingPrompt.filter({ generated_date: today }),
      base44.asServiceRole.entities.MediationTask.filter({ generated_date: today }),
      base44.asServiceRole.entities.SpeakingPrompt.filter({ generated_date: today }),
      base44.asServiceRole.entities.ReadingText.filter({ content_type: "listening" }),
    ]);

    const tasks = [];

    for (const grade of grades) {
      const readingTopics = grade === "8" ? CLASS8_READING_TOPICS : CLASS9_READING_TOPICS;
      const listeningTopics = grade === "8" ? CLASS8_LISTENING_TOPICS : CLASS9_LISTENING_TOPICS;
      const writingTopics = grade === "8" ? CLASS8_WRITING_TOPICS : CLASS9_WRITING_TOPICS;
      const mediationTopics = grade === "8" ? CLASS8_MEDIATION_TOPICS : CLASS9_MEDIATION_TOPICS;
      const speakingTopics = grade === "8" ? CLASS8_SPEAKING_TOPICS : CLASS9_SPEAKING_TOPICS;

      const alreadyReading = existingReading.filter(r => r.grade === grade && r.content_type !== "listening");
      const alreadyListening = existingReading.filter(r => r.grade === grade && r.content_type === "listening");
      const usedListeningTopics = new Set(allListening.filter(t => t.grade === grade).map(t => t.topic).filter(Boolean));
      const alreadyWriting = existingWriting.filter(r => r.grade === grade);
      const alreadyMediation = existingMediation.filter(r => r.grade === grade);
      const alreadySpeaking = existingSpeaking.filter(r => r.grade === grade);

      if (alreadyReading.length < 3) {
        for (const difficulty of difficulties) {
          const topicObj = pickRandom(readingTopics);
          tasks.push(
            generateReadingText(topicObj.topic, topicObj.textType, grade, difficulty)
              .then(data => base44.asServiceRole.entities.ReadingText.create({
                ...data, grade, difficulty, generated_date: today, content_type: "reading",
              }))
          );
        }
      }

      if (alreadyListening.length < 3) {
        for (const difficulty of difficulties) {
          const availableTopics = listeningTopics.filter(t => !usedListeningTopics.has(t.topic));
          const pool = availableTopics.length > 0 ? availableTopics : listeningTopics;
          const topicObj = pickByDifficulty(pool, difficulty);
          usedListeningTopics.add(topicObj.topic);
          tasks.push(
            generateListeningText(topicObj.topic, topicObj.type, grade, difficulty)
              .then(data => {
                const secs = Math.ceil((data.script?.length || 0) / 14);
                const dur = `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')}`;
                return base44.asServiceRole.entities.ReadingText.create({
                  title: data.title, body: data.script, grade, difficulty,
                  generated_date: today, content_type: "listening",
                  questions: data.questions, topic: topicObj.topic, duration: dur,
                });
              })
          );
        }
      }

      if (alreadyWriting.length < 3) {
        for (const difficulty of difficulties) {
          const topicObj = pickRandom(writingTopics);
          tasks.push(
            generateWritingPrompt(topicObj.genre, topicObj.topic, grade, difficulty)
              .then(data => base44.asServiceRole.entities.WritingPrompt.create({
                ...data, grade, difficulty, generated_date: today,
              }))
          );
        }
      }

      if (alreadyMediation.length < 3) {
        for (const difficulty of difficulties) {
          const topicObj = pickByDifficulty(mediationTopics, difficulty);
          tasks.push(
            generateMediationTask(topicObj.topic, topicObj.source_lang, topicObj.target_lang, grade, difficulty)
              .then(data => base44.asServiceRole.entities.MediationTask.create({
                ...data, grade, difficulty, generated_date: today, topic: topicObj.topic,
              }))
          );
        }
      }

      if (alreadySpeaking.length < 3) {
        for (const difficulty of difficulties) {
          const topicObj = pickRandom(speakingTopics);
          tasks.push(
            generateSpeakingPrompt(topicObj.speaking_type, topicObj.topic, grade, difficulty)
              .then(data => base44.asServiceRole.entities.SpeakingPrompt.create({
                ...data, grade, difficulty, generated_date: today,
              }))
          );
        }
      }
    }

    await Promise.all(tasks);

    return Response.json({ success: true, message: `Daily content generated for ${today}`, count: tasks.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});