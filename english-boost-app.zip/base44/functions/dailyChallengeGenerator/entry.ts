import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const today = new Date().toISOString().split('T')[0];

    // Check if challenge already exists for today
    const existing = await base44.entities.DailyChallenge.filter({
      user_email: user.email,
      challenge_date: today,
    });

    if (existing && existing.length > 0) {
      return Response.json({
        status: 'already_exists',
        challenge: existing[0],
      });
    }

    // Get recent attempts to determine skill focus
    const recentAttempts = await base44.entities.ExerciseAttempt.filter(
      { user_email: user.email },
      '-created_date',
      20
    );

    // Determine most recent skill areas
    const skillCounts = {};
    recentAttempts?.forEach(a => {
      if (a.skill_area) {
        skillCounts[a.skill_area] = (skillCounts[a.skill_area] || 0) + 1;
      }
    });

    const recentSkills = Object.entries(skillCounts)
      .sort((a, b) => b[1] - a[1])
      .map(([skill]) => skill);

    const targetSkill = recentSkills[0] || 'vocabulary';

    // Get user profile for grade
    const profiles = await base44.entities.UserProfile.filter({
      user_email: user.email,
    });
    const userGrade = profiles?.[0]?.grade || '8';

    // Generate challenge using Claude
    const prompt = `Generate a quick daily English challenge question for a German student in grade ${userGrade}.
Skill: ${targetSkill}
Task type: multiple choice (easy-medium difficulty)
Time: ~2-3 minutes max

Return ONLY valid JSON (no markdown):
{
  "question": "Clear question text",
  "context": "Optional context (can be empty)",
  "options": ["Option A", "Option B", "Option C", "Option D"],
  "correct_answer": "Option A",
  "explanation": "Why this is correct (optional)"
}`;

    const challengeData = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          question: { type: 'string' },
          context: { type: 'string' },
          options: { type: 'array', items: { type: 'string' } },
          correct_answer: { type: 'string' },
          explanation: { type: 'string' },
        },
        required: ['question', 'options', 'correct_answer'],
      },
    });

    // Create challenge
    const challenge = await base44.entities.DailyChallenge.create({
      user_email: user.email,
      challenge_date: today,
      skill_area: targetSkill,
      task_type: 'multiple_choice',
      question: challengeData.question,
      context: challengeData.context || '',
      difficulty: 'medium',
      options: challengeData.options,
      correct_answer: challengeData.correct_answer,
      xp_reward: 15,
      completed: false,
    });

    return Response.json({
      status: 'created',
      challenge,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});