import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Anthropic from 'npm:@anthropic-ai/sdk@0.27.0';

const anthropic = new Anthropic({ apiKey: Deno.env.get("ANTHROPIC_API_KEY") });

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { task, payload } = await req.json();

    // Writing Feedback
    if (task === "writing_feedback") {
      const { text, image_url, prompt, genre, grade } = payload;
      const genreLabels = {
        summary: "Summary", blog_post: "Blog Post", comment: "Kommentar",
        formal_email: "Formeller Brief/Email", informal_email: "Informelle Email",
        letter: "Brief", report: "Bericht", article: "Artikel",
        discussion: "Diskussion/Erörterung", characterisation: "Characterisation",
        creative: "Creative Writing", mediation: "Mediationstext",
      };

      const messageContent = image_url
        ? [
            { type: "text", text: `Du bist ein erfahrener Englischlehrer an einem deutschen Gymnasium (Klasse ${grade}).
Lies die handschriftliche Antwort im Bild und bewerte sie als ${genreLabels[genre] || genre}-Text eines Schülers der Klasse ${grade}.

Aufgabe: ${prompt}

Antworte NUR mit einem JSON-Objekt (kein Markdown, kein Text darum herum):
{
  "overall_score": 3,
  "task_achievement": "Feedback auf Deutsch",
  "structure": "Feedback auf Deutsch",
  "language": "Feedback auf Deutsch",
  "grammar": "Feedback auf Deutsch",
  "style": "Feedback auf Deutsch",
  "strengths": ["Stärke 1", "Stärke 2"],
  "improvements": ["Verbesserung 1", "Verbesserung 2"],
  "encouragement": "Kurze ermutigende Nachricht auf Deutsch"
}` },
            { type: "image", source: { type: "url", url: image_url } }
          ]
        : `Du bist ein erfahrener Englischlehrer an einem deutschen Gymnasium (Klasse ${grade}).
Bewerte folgenden ${genreLabels[genre] || genre}-Text eines Schülers der Klasse ${grade}.

Aufgabe: ${prompt}

Schülertext:
${text}

Antworte NUR mit einem JSON-Objekt (kein Markdown, kein Text darum herum):
{
  "overall_score": 3,
  "task_achievement": "Feedback auf Deutsch",
  "structure": "Feedback auf Deutsch",
  "language": "Feedback auf Deutsch",
  "grammar": "Feedback auf Deutsch",
  "style": "Feedback auf Deutsch",
  "strengths": ["Stärke 1", "Stärke 2"],
  "improvements": ["Verbesserung 1", "Verbesserung 2"],
  "encouragement": "Kurze ermutigende Nachricht auf Deutsch"
}`;

      const msg = await anthropic.messages.create({
        model: "claude-opus-4-5",
        max_tokens: 1024,
        messages: [{ role: "user", content: messageContent }]
      });
      const raw = msg.content[0].text.trim();
      const jsonStart = raw.indexOf('{');
      const jsonEnd = raw.lastIndexOf('}') + 1;
      return Response.json(JSON.parse(raw.slice(jsonStart, jsonEnd)));
    }

    // Reading Answer Check
    if (task === "check_reading_answers") {
      const { questions, answers, textBody, grade } = payload;
      const msg = await anthropic.messages.create({
        model: "claude-opus-4-5",
        max_tokens: 1500,
        messages: [{
          role: "user",
          content: `Du bist ein Englischlehrer (Klasse ${grade} Gymnasium). Überprüfe die Antworten eines Schülers auf Verständnisfragen zu einem englischen Text.

TEXT:
${textBody}

Bewerte jede Antwort und antworte NUR mit einem JSON-Array (kein Markdown):
[
  {
    "question_index": 0,
    "is_correct": true,
    "score": 1,
    "feedback_de": "kurzes Feedback auf Deutsch, max 2 Sätze",
    "model_answer": "Musterlösung auf Englisch, 1-2 Sätze"
  }
]

Fragen und Schülerantworten:
${questions.map((q, i) => {
  const a = Array.isArray(answers) ? answers[i] : answers[String(i)] || answers[i];
  return `Q${i}: ${q.question || q.q}\nAntwort: ${a || "(keine Antwort)"}`;
}).join("\n\n")}`
        }]
      });
      const raw = msg.content[0].text.trim();
      const arrStart = raw.indexOf('[');
      const arrEnd = raw.lastIndexOf(']') + 1;
      return Response.json({ results: JSON.parse(raw.slice(arrStart, arrEnd)) });
    }

    // Listening Answer Check
    if (task === "check_listening_answers") {
      const { questions, answers, script, grade } = payload;
      const msg = await anthropic.messages.create({
        model: "claude-opus-4-5",
        max_tokens: 1500,
        messages: [{
          role: "user",
          content: `Du bist ein Englischlehrer (Klasse ${grade} Gymnasium). Überprüfe die Antworten eines Schülers auf Hörverständnisfragen.

TRANSKRIPT:
${script}

Antworte NUR mit einem JSON-Array:
[
  {
    "question_index": 0,
    "is_correct": true,
    "score": 1,
    "feedback_de": "kurzes Feedback auf Deutsch, max 2 Sätze",
    "model_answer": "Musterlösung auf Englisch"
  }
]

Fragen und Schülerantworten:
${questions.map((q, i) => {
  const a = Array.isArray(answers) ? answers[i] : answers[String(i)] || answers[i];
  return `Q${i}: ${q.q}\nAntwort: ${a || "(keine Antwort)"}`;
}).join("\n\n")}`
        }]
      });
      const raw = msg.content[0].text.trim();
      const arrStart = raw.indexOf('[');
      const arrEnd = raw.lastIndexOf(']') + 1;
      return Response.json({ results: JSON.parse(raw.slice(arrStart, arrEnd)) });
    }

    // Generate Listening Text
    if (task === "generate_listening") {
      const { topic, type, grade, difficulty } = payload;
      const msg = await anthropic.messages.create({
        model: "claude-opus-4-5",
        max_tokens: 2000,
        messages: [{
          role: "user",
          content: `Erstelle einen ${type} (Hörtext) für Klasse ${grade} Gymnasium Englisch zum Thema "${topic}". Schwierigkeit: ${difficulty}.

Anforderungen:
- Natürliches, gesprochenes Englisch (British oder American)
- Länge: ca. 200-280 Wörter
- Klasse 8: Themen aus dem Lehrplan (USA, Kids in America, New York, Werbung, Schulregeln, Pacific Northwest, Internet, Erfindungen)
- Klasse 9: Themen aus dem Lehrplan (World Englishes, Australien, Südafrika, Indien, Tolerance & Respect, Food & Lifestyle, California, Umwelt, Argumentative Texte)
- 4 Verständnisfragen (detail, inference, main_idea, summary Typen)

Antworte NUR mit einem JSON-Objekt:
{
  "title": "Titel",
  "script": "der vollständige Text, Absätze mit \\n\\n getrennt",
  "questions": [
    { "q": "Frage auf Englisch", "type": "detail" },
    { "q": "Frage auf Englisch", "type": "detail" },
    { "q": "Frage auf Englisch", "type": "main_idea" },
    { "q": "Frage auf Englisch", "type": "open" }
  ],
  "duration": "2:30"
}`
        }]
      });
      const raw = msg.content[0].text.trim();
      const jsonStart = raw.indexOf('{');
      const jsonEnd = raw.lastIndexOf('}') + 1;
      return Response.json(JSON.parse(raw.slice(jsonStart, jsonEnd)));
    }

    // Generate Reading Text
    if (task === "generate_reading") {
      const { topic, textType, grade, difficulty } = payload;
      const msg = await anthropic.messages.create({
        model: "claude-opus-4-5",
        max_tokens: 2500,
        messages: [{
          role: "user",
          content: `Erstelle einen Lesetext (${textType}) für Klasse ${grade} Gymnasium Englisch zum Thema "${topic}". Schwierigkeit: ${difficulty}.

Anforderungen:
- Klasse 8: Themen aus dem Lehrplan (USA/Americans, New York, Werbung, Schulregeln, Pacific Northwest, Internet/Hoaxes, Erfindungen, Reisen)
- Klasse 9: Themen aus dem Lehrplan (World Englishes, Australien, Südafrika, Indien, Tolerance & Respect, Food & Lifestyle, California dreaming, Cause & Effect, Letters to the editor, Short films)
- Authentischer, interessanter Text, ca. 250-350 Wörter
- 4-5 Verständnisfragen gemischt (multiple_choice, detail, true_false, inference)
- Für multiple_choice: 4 Optionen, correct ist der Index (0-3)
- Für detail/inference: correct ist die Musterantwort als String
- Für true_false: correct ist true oder false

Antworte NUR mit einem JSON-Objekt:
{
  "title": "Titel",
  "body": "Fließtext, Absätze mit \\n\\n getrennt",
  "text_type": "${textType}",
  "topic": "${topic}",
  "grade": "${grade}",
  "difficulty": "${difficulty}",
  "word_count": 300,
  "vocabulary_focus": ["Wort1", "Wort2", "Wort3", "Wort4"],
  "questions": [
    { "type": "multiple_choice", "question": "Frage", "options": ["A","B","C","D"], "correct": 0 },
    { "type": "detail", "question": "Frage", "correct": "Musterantwort" },
    { "type": "true_false", "question": "Aussage", "correct": true },
    { "type": "inference", "question": "Frage", "correct": "Musterantwort" }
  ]
}`
        }]
      });
      const raw = msg.content[0].text.trim();
      const jsonStart = raw.indexOf('{');
      const jsonEnd = raw.lastIndexOf('}') + 1;
      return Response.json(JSON.parse(raw.slice(jsonStart, jsonEnd)));
    }

    // Summary Feedback
    if (task === "summary_feedback") {
      const { summary, image_url, sourceText, textTitle } = payload;

      const jsonTemplate = `Antworte NUR mit diesem JSON-Objekt (kein Markdown, kein Text darum herum):
{
  "score": 3,
  "main_idea": "Feedback ob Hauptaussagen korrekt wiedergegeben werden",
  "own_words": "Feedback zu Paraphrase vs Kopieren",
  "neutral": "Feedback zum neutralen Ton",
  "tense": "Feedback zur Zeitform Simple Present",
  "length": "Feedback zur Laenge",
  "strengths": ["Staerke 1", "Staerke 2"],
  "improvements": ["Verbesserung 1", "Verbesserung 2", "Verbesserung 3"],
  "overall": "Zusammenfassung des Feedbacks auf Deutsch, ermutigend aber ehrlich",
  "tip": "Eine wichtige Merkregel fuer Summaries"
}`;

      const baseText = `Du bist ein strenger aber fairer Englischlehrer an einem deutschen Gymnasium.
Bewerte die Zusammenfassung (Summary) eines Schuelers zum folgenden Originaltext.

ORIGINALTEXT (Titel: "${textTitle}"):
"""
${sourceText}
"""

BEWERTUNGSKRITERIEN:
1. Inhaltliche Uebereinstimmung: Gibt der Schueler die HAUPTAUSSAGEN des Originals wieder? Wenn nicht, bewerte streng (Score 1-2).
2. Eigene Worte: Paraphrase oder abgeschrieben?
3. Neutraler Ton: Keine eigene Meinung?
4. Simple Present: Richtige Zeitform?
5. Laenge: Angemessen?

Wenn die Summary inhaltlich NICHT zum Originaltext passt, weise explizit darauf hin und gib Score 1-2.

${jsonTemplate}`;

      const messageContent = image_url
        ? [
            { type: "text", text: baseText + "\n\nDie Schueler-Summary ist handschriftlich als Bild beigefuegt. Lies sie sorgfaeltig:" },
            { type: "image", source: { type: "url", url: image_url } }
          ]
        : baseText + `\n\nSCHUELER-ZUSAMMENFASSUNG:\n"""\n${summary}\n"""`;

      const msg = await anthropic.messages.create({
        model: "claude-opus-4-5",
        max_tokens: 1500,
        messages: [{ role: "user", content: messageContent }]
      });

      const raw = msg.content[0].text.trim();
      const jsonStart = raw.indexOf('{');
      const jsonEnd = raw.lastIndexOf('}') + 1;
      return Response.json(JSON.parse(raw.slice(jsonStart, jsonEnd)));
    }

    // Speaking Feedback
    if (task === "speaking_feedback") {
      const { transcript, promptText, promptType, grade, pronunciation_self_score } = payload;
      const pronunciationNote = pronunciation_self_score != null
        ? `Der Schueler hat seine eigene Aussprache mit ${pronunciation_self_score}/5 bewertet. Beziehe das in dein Feedback ein und gib einen kurzen Aussprache-Kommentar im Feld "pronunciation".
`
        : '';
      const strictnessNote = grade === '9'
        ? 'Klasse 9: Bewerte strenger – hohere Erwartungen an Grammatik, Vokabular und Struktur. Kleinere Fehler sollten sich auf den Score auswirken.'
        : 'Klasse 8: Bewerte fair und ermutigend – Grundfehler benennen, aber nicht uebergewichten.';
      const msg = await anthropic.messages.create({
        model: "claude-opus-4-5",
        max_tokens: 1200,
        messages: [{
          role: "user",
          content: `Du bist ein erfahrener Englischlehrer an einem deutschen Gymnasium (Klasse ${grade}).
Bewerte die muendliche Antwort eines Schuelers auf folgende Sprechaufgabe.

Aufgabe (${promptType}): ${promptText}

Transkript der Schuelerantwort:
"""\n${transcript}\n"""

HINWEISE ZUR BEWERTUNG:
- ${pronunciationNote}
- Fuellwoerter wie "ehm", "uh", "um" sind normal beim Sprechen. Wenn sie nur 2-3 Mal vorkommen: nicht beanstanden. Erst wenn sie sehr haeufig (5+ Mal) auftreten, in der Fluency-Bewertung erwaehnen.
- ${strictnessNote}

Bewerte sachlich und auf Deutsch. Antworte NUR mit einem JSON-Objekt (kein Markdown):
{
  "score": 3,
  "fluency": "Feedback zur Flüssigkeit und Pausenstruktur",
  "vocabulary": "Feedback zu Wortschatz und Ausdrucksvielfalt",
  "grammar": "Feedback zu Grammatik und Satzbau",
  "pronunciation": "Kommentar zur Aussprache basierend auf der Selbsteinschätzung des Schülers",
  "task_achievement": "Wurde die Aufgabe erfüllt?",
  "strengths": ["Stärke 1", "Stärke 2"],
  "improvements": ["Verbesserungsvorschlag 1", "Verbesserungsvorschlag 2"],
  "encouragement": "Kurze ermutigende Nachricht"
}`
        }]
      });
      const raw = msg.content[0].text.trim();
      const jsonStart = raw.indexOf('{');
      const jsonEnd = raw.lastIndexOf('}') + 1;
      return Response.json(JSON.parse(raw.slice(jsonStart, jsonEnd)));
    }

    // Correct/validate English word
    if (task === "correct_english_word") {
      const { word } = payload;
      const msg = await anthropic.messages.create({
        model: "claude-opus-4-5",
        max_tokens: 150,
        messages: [{
          role: "user",
          content: `You are an English dictionary assistant. The user typed: "${word}"

Respond ONLY with a JSON object, no markdown:
{
  "is_english": true or false (is this a real English word or phrase?),
  "recognized": true or false (can you identify what word/phrase was intended?),
  "corrected": "the correctly spelled English word or phrase, or null if not recognizable",
  "note": "short note in German if corrected or not recognized, otherwise null"
}`
        }]
      });
      const raw = msg.content[0].text.trim();
      const js = raw.indexOf('{');
      const je = raw.lastIndexOf('}') + 1;
      return Response.json(JSON.parse(raw.slice(js, je)));
    }

    return Response.json({ error: 'Unknown task' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});