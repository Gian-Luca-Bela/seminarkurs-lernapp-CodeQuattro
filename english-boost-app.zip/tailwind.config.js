/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx,js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'Inter', 'sans-serif'],
      },
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)',
        xl: 'calc(var(--radius) + 4px)',
        '2xl': 'calc(var(--radius) + 8px)',
        '3xl': 'calc(var(--radius) + 16px)',
      },
      colors: {
        background: 'hsl(var(--background))',
        surface: 'hsl(var(--card))',
        foreground: 'hsl(var(--foreground))',
        card: {
          DEFAULT: 'hsl(var(--card))',
          foreground: 'hsl(var(--card-foreground))'
        },
        popover: {
          DEFAULT: 'hsl(var(--popover))',
          foreground: 'hsl(var(--popover-foreground))'
        },
        primary: {
          DEFAULT: 'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground))'
        },
        secondary: {
          DEFAULT: 'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground))'
        },
        muted: {
          DEFAULT: 'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))'
        },
        accent: {
          DEFAULT: 'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground))'
        },
        destructive: {
          DEFAULT: 'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))'
        },
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))',
        brand: {
          green: 'hsl(var(--brand-green))',
          'green-light': 'hsl(var(--brand-green-light))',
          'green-mid': 'hsl(var(--brand-green-mid))',
          lime: 'hsl(var(--brand-lime))',
          blue: 'hsl(var(--brand-blue))',
          'blue-light': 'hsl(var(--brand-blue-light))',
          yellow: 'hsl(var(--brand-yellow))',
          'yellow-light': 'hsl(var(--brand-yellow-light))',
          orange: 'hsl(var(--brand-orange))',
          'orange-light': 'hsl(var(--brand-orange-light))',
        },
        chart: {
          '1': 'hsl(var(--chart-1))',
          '2': 'hsl(var(--chart-2))',
          '3': 'hsl(var(--chart-3))',
          '4': 'hsl(var(--chart-4))',
          '5': 'hsl(var(--chart-5))',
        },
      },
      fontWeight: {
        '600': '600',
        '700': '700',
        '800': '800',
        '900': '900',
      },
      keyframes: {
        'accordion-down': {
          from: { height: '0' },
          to: { height: 'var(--radix-accordion-content-height)' }
        },
        'accordion-up': {
          from: { height: 'var(--radix-accordion-content-height)' },
          to: { height: '0' }
        },
        'fade-in': {
          from: { opacity: '0', transform: 'translateY(8px)' },
          to: { opacity: '1', transform: 'translateY(0)' }
        },
        'fade-up': {
          from: { opacity: '0', transform: 'translateY(12px)' },
          to: { opacity: '1', transform: 'translateY(0)' }
        },
        'pop-in': {
          '0%':   { opacity: '0', transform: 'scale(0.9)' },
          '70%':  { transform: 'scale(1.03)' },
          '100%': { opacity: '1', transform: 'scale(1)' }
        },
        'slide-in': {
          from: { opacity: '0', transform: 'translateX(-12px)' },
          to: { opacity: '1', transform: 'translateX(0)' }
        },
        'slide-right': {
          from: { opacity: '0', transform: 'translateX(-10px)' },
          to: { opacity: '1', transform: 'translateX(0)' }
        },
        'pulse-green': {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(34, 197, 94, 0.4)' },
          '50%': { boxShadow: '0 0 0 8px rgba(34, 197, 94, 0)' }
        },
        'pulse-ring': {
          '0%, 100%': { boxShadow: '0 0 0 0 hsl(var(--primary) / 0.35)' },
          '50%': { boxShadow: '0 0 0 8px hsl(var(--primary) / 0)' }
        }
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up': 'accordion-up 0.2s ease-out',
        'fade-in': 'fade-in 0.3s ease-out',
        'fade-up': 'fade-up 0.35s ease-out',
        'pop-in': 'pop-in 0.3s ease-out',
        'slide-in': 'slide-in 0.3s ease-out',
        'slide-right': 'slide-right 0.3s ease-out',
        'pulse-green': 'pulse-green 2s infinite',
        'pulse-ring': 'pulse-ring 2s infinite',
      },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(135deg, hsl(var(--brand-gradient-from)) 0%, hsl(var(--brand-gradient-to)) 100%)',
        'brand-gradient-lime': 'linear-gradient(135deg, hsl(var(--brand-gradient-from)) 0%, hsl(var(--brand-gradient-lime-to)) 100%)',
        'brand-gradient-warm': 'linear-gradient(135deg, hsl(var(--brand-gradient-from)) 0%, hsl(var(--brand-gradient-to)) 100%)',
        'brand-gradient-soft': 'linear-gradient(135deg, hsl(var(--secondary)) 0%, hsl(var(--accent) / 0.15) 100%)',
        'hero-pattern': "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%2315803d' fill-opacity='0.06'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
      },
      safelist: [
        'bg-green-50', 'bg-green-100', 'bg-blue-50', 'bg-blue-100', 'bg-yellow-50', 'bg-yellow-100',
        'bg-orange-50', 'bg-orange-100', 'bg-purple-50', 'bg-purple-100', 'bg-pink-50', 'bg-pink-100',
        'bg-teal-50', 'bg-teal-100', 'bg-lime-50', 'bg-lime-100',
        'text-green-600', 'text-green-700', 'text-green-800',
        'text-blue-600', 'text-blue-700', 'text-blue-800',
        'text-yellow-600', 'text-yellow-700', 'text-orange-600', 'text-orange-700', 'text-orange-800',
        'text-purple-600', 'text-purple-700', 'text-pink-600', 'text-pink-700',
        'text-teal-600', 'text-teal-700',
        'border-green-200', 'border-blue-200', 'border-yellow-200', 'border-orange-200',
        'border-purple-200', 'border-pink-200', 'border-teal-200',
        'bg-green-500', 'bg-blue-500', 'bg-yellow-500', 'bg-orange-500', 'bg-purple-500',
        'bg-teal-500', 'bg-pink-500',
        'answer-btn', 'answer-btn-correct', 'answer-btn-wrong', 'answer-btn-selected',
      ]
    }
  },
  plugins: [require("tailwindcss-animate")],
}